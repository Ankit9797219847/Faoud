# Hosting guide — Next.js only, no Django

The backend is no longer a separate Django server. Every endpoint the
frontend needs now runs as Next.js API routes (`pages/api/`) backed by
Prisma + Postgres, inside `./frontend`. `./django-backend` and `./backend`
are both kept in the zip for reference only — neither is used anymore.

## Run it

```bash
cd faoud-platform
docker compose up --build
docker compose exec app npx prisma db seed
```

Then open **http://localhost:3000**. Three logins are seeded (password for
all: `changeme123`):

| Email | Role |
|---|---|
| `am@faoud.com` | Account Manager |
| `brand@faoud.com` | Brand Owner |
| `factory@faoud.com` | Factory Owner |
| `admin@faoud.com` | Admin |

## What's actually running

```
faoud-platform/
├── frontend/                 # THIS is the whole app now
│   ├── pages/api/             # the ported backend — auth, all 36 resources, workflows
│   ├── prisma/schema.prisma   # the ~50 models needed for what's wired (ported from Django)
│   └── pages/, components/    # the UI, unchanged from before
├── django-backend/            # reference only — not used
├── backend/                   # old Express — reference only — not used
└── docker-compose.yml         # Postgres + the Next.js app, two services
```

## What's ported and working

- **Auth** — signup/login/logout/me, httpOnly session cookie + real CSRF
  double-submit-cookie check (same mechanism Django used, just implemented
  here instead)
- **36+ data tables** — full CRUD via a generic Prisma-backed handler
- **Case workflow** — stages, transitions, priority/color, AM assignment, notes
- **Bids** — case-scoped lists, tagging, accept
- **Dispatch** — the 3-role handoff
- **Services admin, Briefs, QC entries, Formulation upload** (local disk,
  not S3 — see below)
- **Brand/Factory/AM dashboard landing pages**, factory profile, AM brands
  and materials pages, brand payments history, and a real (simplified)
  new-case creation form — replacing a "dynamic questionnaire" flow that
  didn't actually exist anywhere in shadow-api-main and had nothing to port
- **Public marketplace/blog/contact/dashboard pages** — these previously
  pointed at a dead Express client on `localhost:4000` and were broken;
  they're now wired to real Next.js API routes (`/api/marketplace/*`,
  `/api/blog*`, `/api/contact`, `/api/orders`) on new Prisma models
  (`PublicProduct`, `BlogPost`, `ContactLead`, `MarketplaceOrder`)
- **Marketing** — the real onboarding/lead-scoring funnel (`OnboardingData`
  + `OnboardingAttachment`, ported from `marketing.models`), a "coming soon"
  site toggle, waitlist capture, and event-campaign short links with click
  tracking (`EventCampaign`/`CampaignLink`/`ClickEvent`, `/api/go/[token]`)
- **Comms** — real case-scoped chat (`/cases/:id/messages`), read receipts,
  and the Brand↔Factory `ChatPermission` toggle AMs can flip per case;
  mounted as a chat panel on the Brand and AM case-detail pages (Factory
  doesn't have its own case-detail page yet, so it's not there)
- **Insights** — the admin KPI dashboard (brand owners/factories added,
  cases, bids, factory-selected, units requirement, dispatched, total paid)
  at `/am/insights`, ported from `insights.admin_dashboard`
- **Admin panel** — a distinct `admin` role (superuser across every
  resource) with `/admin/dashboard` (KPIs + coming-soon toggle + content
  shortcuts) and `/admin/data` (every table, including blog posts,
  marketplace catalog, contact leads, waitlist, campaign links)

- **Payments** — the real ledger: `Order` → `PaymentLayer` (ADVANCE/FINAL/
  SAMPLE) → Razorpay Checkout → `/api/payments/verify` (signature-checked)
  and `/api/payments/webhook` (server-to-server, also signature-checked),
  ported from `payments.models`/`payments.views`. `ServicePayment` covers
  the ServiceRequest upfront-payment flow the same way. A `PaymentCheckoutPanel`
  is mounted on the Brand case-detail page. **All of this works end to end
  once you set `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` /
  `RAZORPAY_WEBHOOK_SECRET`** (see `.env.example` / `docker-compose.yml`) —
  without them, every payment route returns a clear 501 instead of crashing.
- **Notifications** — `lib/server/notify.js` sends real email (SMTP via
  nodemailer) and WhatsApp (generic Meta-Cloud-API-shaped webhook), and
  always records a `UserNotification` row either way. Wired into the
  payment-verified flow as an example; wire more triggers (case stage
  changes, bid accepted, etc.) into `notifyUser()` the same way. Needs
  `SMTP_*` / `WHATSAPP_API_*` env vars to actually send — logs a warning
  and no-ops otherwise.

## Known simplifications — read before assuming full parity

- **File storage is local disk** (`public/uploads/`), not S3. Fine for
  running this yourself; swap in an S3 SDK call before real production use.
- **No Celery** — scheduled/background jobs (bulk notifications, etc.)
  weren't ported; nothing in the wired UI currently depends on them.
- **Insights' "total paid" is sourced from the `Charge` ledger** (add-on
  billing) in the KPI dashboard specifically — the real `Order`/
  `PaymentLayer` ledger now exists (see Payments above) and would be a
  better source; this hasn't been switched over yet.
- A couple of niceties are API-only for now, no dedicated UI yet: campaign
  link creation (`/api/marketing/campaign-links`) and the public onboarding
  funnel capture aren't yet wired into the homepage's actual funnel UI —
  the backend is ready, the homepage doesn't call it yet.
- Chat is polling-based (refetches on load/send), not websocket push.
- `next@14.2.5` has a known security advisory (unrelated to anything in
  this pass) — worth upgrading before going to production:
  https://nextjs.org/blog/security-update-2025-12-11

## Before pointing this at faoud.com

- Set `SESSION_SECRET` to a real random value (not the placeholder in
  docker-compose.yml).
- Put Postgres on a real managed instance, not the `db` container.
- Move file uploads to S3.
- Run `npx prisma migrate dev --name init` locally once to get a real
  migration history, then use `prisma migrate deploy` in production instead
  of `db push`.
