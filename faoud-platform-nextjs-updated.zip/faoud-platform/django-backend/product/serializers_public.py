from .models import Product, Subcategory, Category
from rest_framework import serializers




class PublicProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    category_slug = serializers.CharField(source='category.slug', read_only=True)
    subcategory_name = serializers.CharField(source='subcategory.name', read_only=True)
    subcategory_slug = serializers.CharField(source='subcategory.slug', read_only=True)
    
    class Meta:
        model = Product
        fields = [
            'id',
            'name',
            'sku_and_pm',
            'picture',
            'benchmark',
            'category_name',
            'category_slug',
            'subcategory_name',
            'subcategory_slug',
        ]


class PublicSubcategorySerializer(serializers.ModelSerializer):
    category_slug = serializers.CharField(source='category.slug', read_only=True)
    class Meta:
        model = Subcategory
        fields = ['id', 'name', 'slug', 'category_slug']

class PublicCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Subcategory
        fields = ['id', 'name', 'slug',]
    
    