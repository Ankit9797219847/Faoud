import pandas as pd
from django.core.management.base import BaseCommand
from django.utils.text import slugify

from product.models import Category, Subcategory

class Command(BaseCommand):
    help = 'Import categories and subcategories from CSV'

    def add_arguments(self, parser):
        parser.add_argument('csv_file', type=str)

    def handle(self, *args, **kwargs):
        csv_file = kwargs['csv_file']
        df = pd.read_csv(csv_file, header=None)

        for index, row in df.iterrows():
            category_name = row[0]
            if pd.isna(category_name):
                continue

            # Create or get Category
            category, created = Category.objects.get_or_create(name=category_name.strip())
            if created:
                self.stdout.write(self.style.SUCCESS(f"Created category: {category.name}"))

            # Add subcategories from rest of the row
            for subcat in row[1:]:
                if pd.isna(subcat):
                    continue
                subcat_name = subcat.strip()
                subcategory, sub_created = Subcategory.objects.get_or_create(
                    name=subcat_name,
                    category=category
                )
                if sub_created:
                    self.stdout.write(self.style.SUCCESS(f"  Added subcategory: {subcategory.name}"))

        self.stdout.write(self.style.SUCCESS("Import completed successfully."))
