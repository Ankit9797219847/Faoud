from django.core.management.base import BaseCommand
from product.models import Product, Category, Subcategory


class Command(BaseCommand):
    help = "Replaces old subcategories with new ones for products in 'F Neuratuatics'"

    def handle(self, *args, **kwargs):
        category_name = "F Nutraceuticals"

        # Subcategory name mapping: {old: new}
        subcategory_map = {
            "tablets": "Tablets",
            "capsules": "Capsules",
            "gummies": "Gummies",
            "effervescent tablets": "Effervescence Tablets"
        }

        # Get the category
        try:
            category = Category.objects.get(name__iexact=category_name)
        except Category.DoesNotExist:
            self.stdout.write(self.style.ERROR(f"Category '{category_name}' not found."))
            return

        # For each mapping
        for old_name, new_name in subcategory_map.items():
            try:
                old_sub = Subcategory.objects.get(name=old_name, category=category)
                new_sub = Subcategory.objects.get(name=new_name, category=category)
            except Subcategory.DoesNotExist as e:
                self.stdout.write(self.style.WARNING(f"Missing subcategory: {e}"))
                continue

            # Find and update products
            products_to_update = Product.objects.filter(category=category, subcategory=old_sub)

            count = products_to_update.count()

            for product in products_to_update:
                product.subcategory = new_sub
                product.save()

            self.stdout.write(
                self.style.SUCCESS(f"Replaced '{old_name}' with '{new_name}' for {count} products.")
            )
