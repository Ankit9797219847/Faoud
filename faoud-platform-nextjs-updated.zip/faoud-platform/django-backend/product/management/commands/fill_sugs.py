from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils.text import slugify

from product.models import Category, Subcategory


def base_slug(text: str) -> str:
    s = slugify(text or "").strip("-")
    return s or "item"

def unique_slug_global(model, desired_name, exclude_id=None):
    root = slugify(desired_name or "").strip("-")[:180] or "item"
    slug = root
    i = 2
    while model.objects.filter(slug=slug).exclude(id=exclude_id).exists():
        slug = f"{root}-{i}"
        i += 1
    return slug

# use it for Subcategory too (global, not by category):


def unique_slug_within_category(model, desired_name, category_id, exclude_id=None):
    """For Subcategory: uniqueness scoped to category_id."""
    root = base_slug(desired_name)[:180]
    slug = root
    i = 2
    while True:
        qs = model.objects.filter(category_id=category_id, slug=slug)
        if exclude_id:
            qs = qs.exclude(id=exclude_id)
        if not qs.exists():
            return slug
        slug = f"{root}-{i}"
        i += 1

class Command(BaseCommand):
    help = "Re-init slugs; auto-suffix duplicates as -2, -3, ... (Categories globally; Subcategories within category)."

    def add_arguments(self, parser):
        parser.add_argument("--force", action="store_true",
                            help="Rebuild slugs even if a row already has a slug.")
        parser.add_argument("--only", choices=["cat", "sub"], default=None,
                            help="Only process categories (cat) or subcategories (sub).")
        parser.add_argument("--dry-run", action="store_true", help="Do not write changes.")

    @transaction.atomic
    def handle(self, *args, **opts):
        force = opts["force"]
        only = opts["only"]
        dry = opts["dry_run"]

        updated_total = 0

        if only in (None, "cat"):
            updated_total += self._reinit_categories(force=force, dry=dry)

        if only in (None, "sub"):
            updated_total += self._reinit_subcategories(force=force, dry=dry)

        suffix = " (dry-run)" if dry else ""
        self.stdout.write(self.style.SUCCESS(f"Done. Updated rows: {updated_total}{suffix}"))

    def _reinit_categories(self, force=False, dry=False):
        count = 0
        # Lock rows to avoid race during concurrent runs
        qs = Category.objects.all().only("id", "name", "slug").select_for_update()
        for c in qs:
            desired = unique_slug_global(Category, c.name, exclude_id=c.id)
            if force or not c.slug or c.slug != desired:
                msg = f"Category #{c.id}: '{c.slug}' -> '{desired}'"
                if dry:
                    self.stdout.write(msg + " [dry]")
                else:
                    c.slug = desired
                    c.save(update_fields=["slug"])
                    self.stdout.write(msg)
                count += 1
        return count

    def _reinit_subcategories(self, force=False, dry=False):
        count = 0
        qs = (Subcategory.objects
              .select_related("category")
              .only("id", "name", "slug", "category_id")
              .select_for_update())
        for sc in qs:
            desired = unique_slug_global(Subcategory, sc.name, exclude_id=sc.id)
            if force or not sc.slug or sc.slug != desired:
                msg = f"Subcategory #{sc.id} (cat {sc.category_id}): '{sc.slug}' -> '{desired}'"
                if dry:
                    self.stdout.write(msg + " [dry]")
                else:
                    sc.slug = desired
                    sc.save(update_fields=["slug"])
                    self.stdout.write(msg)
                count += 1
        return count