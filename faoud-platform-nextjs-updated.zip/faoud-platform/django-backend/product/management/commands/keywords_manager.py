"""
Django management command for keywords management.
Usage:
  python manage.py keywords_manager export [--output=filename.xlsx]
  python manage.py keywords_manager import <file.xlsx>
  python manage.py keywords_manager template [--output=filename.xlsx]
"""
import os
from django.core.management.base import BaseCommand, CommandError
from django.conf import settings
from product.keywords_manager import KeywordsExporter, KeywordsImporter


class Command(BaseCommand):
    help = 'Manage keywords for categories and subcategories via Excel'
    
    def add_arguments(self, parser):
        parser.add_argument(
            'action',
            type=str,
            choices=['export', 'import', 'template'],
            help='Action to perform: export (with data), import (from file), or template (empty)'
        )
        parser.add_argument(
            'file',
            nargs='?',
            type=str,
            help='File path (required for import, optional for export/template)'
        )
        parser.add_argument(
            '--output',
            type=str,
            help='Output file path for export/template commands'
        )
    
    def handle(self, *args, **options):
        action = options['action']
        file_path = options.get('file')
        output_path = options.get('output')
        
        if action in ['export', 'template']:
            self._handle_export(action, output_path)
        elif action == 'import':
            if not file_path:
                raise CommandError('File path is required for import action')
            self._handle_import(file_path)
    
    def _handle_export(self, action: str, output_path: str = None):
        """Handle export or template generation."""
        try:
            exporter = KeywordsExporter()
            include_data = action == 'export'
            template_bytes = exporter.generate_template(include_data=include_data)
            
            # Determine output file path
            if not output_path:
                action_name = 'export' if include_data else 'template'
                output_path = os.path.join(
                    settings.BASE_DIR,
                    f'keywords_{action_name}.xlsx'
                )
            
            # Write to file
            with open(output_path, 'wb') as f:
                f.write(template_bytes)
            
            action_name = 'exported' if include_data else 'created'
            self.stdout.write(
                self.style.SUCCESS(
                    f'✓ Keywords {action_name} successfully to: {output_path}'
                )
            )
        except Exception as e:
            raise CommandError(f'Export failed: {str(e)}')
    
    def _handle_import(self, file_path: str):
        """Handle import from Excel file."""
        if not os.path.exists(file_path):
            raise CommandError(f'File not found: {file_path}')
        
        try:
            with open(file_path, 'rb') as f:
                importer = KeywordsImporter(f)
                
                # Validate
                is_valid, errors = importer.validate_file()
                if not is_valid:
                    for error in errors:
                        self.stdout.write(self.style.ERROR(f'✗ {error}'))
                    raise CommandError('File validation failed')
                
                # Import
                results = importer.import_keywords()
                
                # Display results
                self.stdout.write(
                    self.style.SUCCESS(
                        f'✓ Import completed successfully!'
                    )
                )
                self.stdout.write(f'  Categories updated: {results["categories_updated"]}')
                self.stdout.write(f'  Subcategories updated: {results["subcategories_updated"]}')
                
                if results['errors']:
                    self.stdout.write(self.style.WARNING(f'\n⚠ Errors encountered:'))
                    for error in results['errors']:
                        self.stdout.write(f'  - {error}')
                
                if results['skipped']:
                    self.stdout.write(self.style.WARNING(f'\n⚠ Rows skipped:'))
                    for skip in results['skipped']:
                        self.stdout.write(f'  - {skip}')
                
                importer.close()
        except Exception as e:
            raise CommandError(f'Import failed: {str(e)}')
