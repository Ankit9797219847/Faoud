from django.contrib import admin
from django.db.models import (
    Value, BooleanField, IntegerField, Case as DjCase, When, F, Q, Count
)
from django.db.models.functions import Coalesce, Length, Replace
from django.http import HttpResponse
from django.contrib import messages
from django.urls import path
from django.shortcuts import render, redirect
from django.utils.html import format_html

from .models import (
    AnswerOption, Category, Product, ChosenAnswer, ProductDocument,
    ProductPackagingMaterial, ProductRawMaterial, Question,
    Subcategory, Parameter, POM, ProductGroup
)
from .keywords_manager import KeywordsExporter, KeywordsImporter

# =========================
# Shared annotation utility
# =========================
from django.db.models import Value, BooleanField, IntegerField, Case as DjCase, When, F, Q
from django.db.models.functions import Coalesce, Length, Replace

def with_taxonomy_metrics(qs):
    # normalize to empty strings
    desc = Coalesce(F('description'), Value(''))
    kw   = Coalesce(F('keywords'), Value(''))

    description_len = Length(desc)

    # commas = len(kw) - len(kw with commas removed)
    comma_count = Length(kw) - Length(Replace(kw, Value(','), Value('')))

    keyword_count = DjCase(
        When(Q(keywords__isnull=True) | Q(keywords=''), then=Value(0)),
        default=comma_count + Value(1),
        output_field=IntegerField(),
    )

    has_image = DjCase(
        When(Q(image__isnull=True) | Q(image=''), then=Value(False)),
        default=Value(True),
        output_field=BooleanField(),
    )

    return qs.annotate(
        description_len=description_len,
        keyword_count=keyword_count,
        has_image=has_image,
    )
# =========================
# Admin filters & actions
# =========================

class HasImageFilter(admin.SimpleListFilter):
    title = 'has image'
    parameter_name = 'has_image'

    def lookups(self, request, model_admin):
        return (('yes', 'Yes'), ('no', 'No'))

    def queryset(self, request, queryset):
        if self.value() == 'yes':
            return queryset.filter(~Q(image__isnull=True), ~Q(image=''))
        if self.value() == 'no':
            return queryset.filter(Q(image__isnull=True) | Q(image=''))
        return queryset


class MissingTextFilter(admin.SimpleListFilter):
    title = 'missing text'
    parameter_name = 'missing'

    def lookups(self, request, model_admin):
        return (
            ('keywords', 'Missing keywords'),
            ('description', 'Missing description'),
        )

    def queryset(self, request, queryset):
        if self.value() == 'keywords':
            return queryset.filter(Q(keywords__isnull=True) | Q(keywords=''))
        if self.value() == 'description':
            return queryset.filter(Q(description__isnull=True) | Q(description=''))
        return queryset


def export_taxonomy_csv(modeladmin, request, queryset):
    import csv
    from django.http import HttpResponse

    qs = with_taxonomy_metrics(queryset)
    model_name = queryset.model.__name__.lower()

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{model_name}_taxonomy_audit.csv"'
    writer = csv.writer(response)

    base_headers = ['id', 'name']
    if queryset.model is Subcategory:
        base_headers.append('category')

    writer.writerow(base_headers + [
        'keyword_count', 'description_len', 'has_image', 'keywords', 'description',
    ])

    for obj in qs:
        row = [obj.id, obj.name]
        if isinstance(obj, Subcategory):
            row.append(getattr(obj.category, 'name', ''))
        row += [
            getattr(obj, 'keyword_count', 0),
            getattr(obj, 'description_len', 0),
            getattr(obj, 'has_image', False),
            obj.keywords or '',
            (obj.description or '').strip(),
        ]
        writer.writerow(row)

    return response

export_taxonomy_csv.short_description = "Export taxonomy audit (CSV)"


def export_keywords_excel(modeladmin, request, queryset):
    """Export keywords to Excel file."""
    try:
        exporter = KeywordsExporter()
        return exporter.get_http_response(include_data=True)
    except ImportError:
        messages.error(request, "openpyxl library is required for this feature. Install it with: pip install openpyxl")
        return None

export_keywords_excel.short_description = "📊 Export keywords to Excel"


def import_keywords_excel(modeladmin, request, queryset):
    """Redirect to import view - action just needs to exist in admin."""
    return redirect('admin:import_keywords')

import_keywords_excel.short_description = "📤 Import keywords from Excel"

# =========================
# Shared Admin mixin
# =========================

class TaxonomyMetricsMixin:
    """
    Adds metrics columns + sorting based on annotations from with_taxonomy_metrics().
    """
    list_display = (
        'name',
        'keyword_count_display',
        'description_len_display',
        'has_image_display',
    )
    search_fields = ('name', 'keywords')
    ordering = ('name',)
    actions = [export_taxonomy_csv, export_keywords_excel, import_keywords_excel]

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return with_taxonomy_metrics(qs)

    @admin.display(description='Keywords (#)', ordering='keyword_count')
    def keyword_count_display(self, obj):
        return getattr(obj, 'keyword_count', 0)

    @admin.display(description='Description (chars)', ordering='description_len')
    def description_len_display(self, obj):
        return getattr(obj, 'description_len', 0)

    @admin.display(boolean=True, description='Has image', ordering='has_image')
    def has_image_display(self, obj):
        return bool(getattr(obj, 'has_image', False))

# =========================
# Category & Subcategory
# =========================

class KeywordsAdminMixin:
    """Mixin to add import keywords view to admin."""
    
    def get_urls(self):
        """Add custom URL for keywords import."""
        urls = super().get_urls()
        custom_urls = [
            path('import-keywords/', 
                 self.admin_site.admin_view(self.import_keywords_view),
                 name='import_keywords'),
        ]
        return custom_urls + urls
    
    def import_keywords_view(self, request):
        """Handle Excel file upload for keywords import."""
        context = {
            'title': 'Import Keywords',
            'opts': self.model._meta,
            'has_view_permission': True,
        }
        
        if request.method == 'POST':
            if 'file' not in request.FILES:
                messages.error(request, '❌ No file provided')
                return render(request, 'admin/import_keywords_form.html', context)
            
            file_obj = request.FILES['file']
            
            if not file_obj.name.endswith(('.xlsx', '.xls')):
                messages.error(request, '❌ Only Excel files (.xlsx, .xls) are supported')
                return render(request, 'admin/import_keywords_form.html', context)
            
            try:
                importer = KeywordsImporter(file_obj)
                is_valid, errors = importer.validate_file()
                
                if not is_valid:
                    for error in errors:
                        messages.error(request, f'❌ {error}')
                else:
                    results = importer.import_keywords()
                    
                    total_updated = results['categories_updated'] + results['subcategories_updated']
                    
                    if total_updated > 0:
                        messages.success(
                            request,
                            f'✓ Successfully updated {total_updated} items '
                            f'({results["categories_updated"]} categories, '
                            f'{results["subcategories_updated"]} subcategories)'
                        )
                    else:
                        messages.warning(request, '⚠ No items were updated')
                    
                    if results['errors']:
                        for error in results['errors']:
                            messages.warning(request, f'⚠ {error}')
                
                importer.close()
                
                # Redirect to changelist after successful import
                if total_updated > 0:
                    return redirect('admin:product_category_changelist')
                    
            except ImportError:
                messages.error(request, '❌ openpyxl is required. Install with: pip install openpyxl')
            except Exception as e:
                messages.error(request, f'❌ Import failed: {str(e)}')
        
        return render(request, 'admin/import_keywords_form.html', context)


@admin.register(Category)
class CategoryAdmin(KeywordsAdminMixin, TaxonomyMetricsMixin, admin.ModelAdmin):
    list_filter = (HasImageFilter, MissingTextFilter)


@admin.register(Subcategory)
class SubcategoryAdmin(KeywordsAdminMixin, TaxonomyMetricsMixin, admin.ModelAdmin):
    list_display = ('name', 'category', 'keyword_count_display', 'description_len_display', 'has_image_display')
    list_filter  = (HasImageFilter, MissingTextFilter, 'category')
    search_fields = ('name', 'keywords', 'category__name')

# =========================
# Your existing admins
# =========================

class POMInline(admin.TabularInline):
    model = POM
    extra = 0
    readonly_fields = ('parameter',)
    fields = ('parameter', 'is_active', 'price', 'quantity', 'value')
    ordering = ('parameter__name',)

    def has_add_permission(self, request, obj=None):
        return False

@admin.register(Parameter)
class ParameterAdmin(admin.ModelAdmin):
    list_display = ('name', 'subcategory', 'unit', 'default_price', 'is_active')
    list_filter = ('subcategory__category', 'subcategory')
    search_fields = ('name', 'subcategory__name')
    list_editable = ('is_active', 'default_price')
    ordering = ('subcategory__name', 'name')

@admin.register(POM)
class POMAdmin(admin.ModelAdmin):
    list_display = ('case', 'parameter', 'is_active', 'price', 'quantity')
    list_filter = ('parameter__subcategory', 'is_active')
    search_fields = ('case__name', 'parameter__name')
    autocomplete_fields = ['case', 'parameter']
    readonly_fields = ('created_at', 'updated_at')

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    search_fields = ('name', 'cases__name', 'brand__name')
    filter_horizontal = ('briefs', 'formulations', 'cases', 'raw_materials', 'packaging_materials')
    list_filter = ('isFaoud_Product', 'is_original', 'brand', 'created_at', 'category', 'product_group')
    ordering = ('-created_at',)
    list_display = (
        'name', 'display_category', 'display_subcategory', 'brand',
        'isFaoud_Product', 'is_original', 'version_number',
        'display_product_group', 'created_at'
    )
    readonly_fields = ('created_at', 'version_number', 'product_group', 'parent_product', 'created_from_case')

    def display_category(self, obj):
        return obj.category.name if obj.category else "-"
    display_category.short_description = "Category"

    def display_subcategory(self, obj):
        return obj.subcategory.name if obj.subcategory else "-"
    display_subcategory.short_description = "Subcategory"

    def display_product_group(self, obj):
        if obj.product_group:
            # Avoid N+1: get_version_count() calls .products.count(), acceptable for admin; optimize later if needed.
            return f"{obj.product_group.name} ({obj.product_group.get_version_count()} versions)"
        return "-"
    display_product_group.short_description = "Product Group"

    def get_list_display_links(self, request, list_display):
        return ('name',)

admin.site.register(ChosenAnswer)

class AnswerOptionInline(admin.TabularInline):
    model = AnswerOption
    extra = 1

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('question_text', 'question_type', 'next_question')
    inlines = [AnswerOptionInline]
    list_filter = ('question_type',)
    ordering = ('-id',)

admin.site.register(AnswerOption)
admin.site.register(ProductRawMaterial)
admin.site.register(ProductPackagingMaterial)
admin.site.register(ProductDocument)

class ProductInline(admin.TabularInline):
    model = Product
    extra = 0
    fields = ('name', 'version_number', 'is_original', 'isFaoud_Product', 'created_at')
    readonly_fields = ('name', 'version_number', 'is_original', 'isFaoud_Product', 'created_at')
    can_delete = False
    show_change_link = True

    def has_add_permission(self, request, obj=None):
        return False

@admin.register(ProductGroup)
class ProductGroupAdmin(admin.ModelAdmin):
    list_display = ('name', 'group_identifier', 'display_original_product', 'version_count', 'created_at')
    readonly_fields = ('group_identifier', 'created_at', 'updated_at')
    search_fields = ('name', 'group_identifier', 'original_product__name')
    list_filter = ('created_at',)
    inlines = [ProductInline]

    def display_original_product(self, obj):
        if obj.original_product:
            return obj.original_product.name
        return "-"
    display_original_product.short_description = "Original Product"

    def version_count(self, obj):
        return obj.get_version_count()
    version_count.short_description = "Total Versions"