from rest_framework import serializers
from materials.models import PackagingMaterial, RawMaterial
from materials.serializers import PackagingMaterialSerializer, RawMaterialSerializer
from supply.serializers import SupplierSerializer
from utils.serializers import BrandSerializer, BriefSerializer
from .models import (
    Category, Product, ProductDocument, ProductPackagingMaterial, 
    ProductRawMaterial, Question, AnswerOption, ChosenAnswer, 
    Subcategory, ProductGroup
)


# class QuestionSerializer(serializers.ModelSerializer):

#     class Meta:
#         model = Question
#         fields = ("question_text", "question_type", "options","id", )
#         depth = 1


class ChosenAnswerSerializer(serializers.ModelSerializer):

    class Meta:
        model = ChosenAnswer
        fields = ["brand_owner", "answer", "case", "question"]

    def validate(self, attrs):
        if not self.context["request"].user.brandowner:
            raise serializers.ValidationError("User is not a brand owner")

        if not attrs["answer"] or not attrs["case"]:
            raise serializers.ValidationError("Answer and case are required")

        return attrs

    def create(self, validated_data):
        validated_data["brand_owner"] = self.context["request"].user.brandowner
        validated_data["question"] = validated_data["answer"].for_question
        return super().create(validated_data)


class ProductRawMaterialSerializer(serializers.ModelSerializer):
    raw_material = RawMaterialSerializer()
    price = serializers.DecimalField(max_digits=10, decimal_places=2)
    supplier = SupplierSerializer()
    #to add supplier serializer
    class Meta:
        model = ProductRawMaterial
        fields = ['id', 'raw_material', 'price', 'supplier']


class ProductDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductDocument
        fields = ['id', 'name', 'file', 'uploaded_at']

class ProductPackagingMaterialSerializer(serializers.ModelSerializer):
    packaging_material = PackagingMaterialSerializer()
    price = serializers.DecimalField(max_digits=10, decimal_places=2)
    supplier = SupplierSerializer()
    #to add supplier serializer

    class Meta:
        model = ProductPackagingMaterial
        fields = ['id', 'packaging_material', 'price', 'supplier']


class ProductSerializer(serializers.ModelSerializer):
    briefs = BriefSerializer(many=True, read_only=True)
    brands = BrandSerializer(many=True, read_only=True)
    raw_materials = ProductRawMaterialSerializer(source='productrawmaterial_set', many=True, read_only=True)
    packaging_materials = ProductPackagingMaterialSerializer(source='productpackagingmaterial_set', many=True, read_only=True)
    raw_material_ids = serializers.ListField(
        child=serializers.IntegerField(), write_only=True, required=False
    )
    packaging_material_ids = serializers.ListField(
        child=serializers.IntegerField(), write_only=True, required=False
    )
    raw_material_prices = serializers.ListField(
        child=serializers.DecimalField(max_digits=10, decimal_places=2), write_only=True, required=False
    )
    packaging_material_prices = serializers.ListField(
        child=serializers.DecimalField(max_digits=10, decimal_places=2), write_only=True, required=False
    )
    documents = ProductDocumentSerializer(many=True, read_only=True)

    class Meta:
        model = Product
        fields = [
            'id',
            'name',
            'sku_and_pm', 'quantity', 'eta',
            'stages',
            'briefs',
            'formulations',
            'brands',
            'raw_materials',
            'packaging_materials',
            'raw_material_ids',
            'raw_material_prices',
            'packaging_material_ids',
            'packaging_material_prices',
            'picture',
            'documents',
            'category',
            'subcategory',
            'benchmark',
            'isFaoud_Product'
        ]

    def create(self, validated_data):
        raw_material_ids = validated_data.pop('raw_material_ids', [])
        raw_material_prices = validated_data.pop('raw_material_prices', [])
        packaging_material_ids = validated_data.pop('packaging_material_ids', [])
        packaging_material_prices = validated_data.pop('packaging_material_prices', [])
        formulations = validated_data.pop('formulations', [])

        product = Product.objects.create(**validated_data)

        # product.formulations.set(formulations_ids)
        # Associate Raw Materials with prices
        for rm_id, price in zip(raw_material_ids, raw_material_prices):
            ProductRawMaterial.objects.create(
                product=product,
                raw_material_id=rm_id,
                price=price
            )

        # Associate Packaging Materials with prices
        for pm_id, price in zip(packaging_material_ids, packaging_material_prices):
            ProductPackagingMaterial.objects.create(
                product=product,
                packaging_material_id=pm_id,
                price=price
            )

        return product

    def update(self, instance, validated_data):
        raw_material_ids = validated_data.pop('raw_material_ids', [])
        raw_material_prices = validated_data.pop('raw_material_prices', [])
        packaging_material_ids = validated_data.pop('packaging_material_ids', [])
        packaging_material_prices = validated_data.pop('packaging_material_prices', [])

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # Update Raw Materials
        if raw_material_ids and raw_material_prices:
            ProductRawMaterial.objects.filter(product=instance).delete()
            for rm_id, price in zip(raw_material_ids, raw_material_prices):
                ProductRawMaterial.objects.create(
                    product=instance,
                    raw_material_id=rm_id,
                    price=price
                )

        # Update Packaging Materials
        if packaging_material_ids and packaging_material_prices:
            ProductPackagingMaterial.objects.filter(product=instance).delete()
            for pm_id, price in zip(packaging_material_ids, packaging_material_prices):
                ProductPackagingMaterial.objects.create(
                    product=instance,
                    packaging_material_id=pm_id,
                    price=price
                )

        return instance

    def to_representation(self, instance):
        data = super().to_representation(instance)
        if not data.get('picture'):
            if instance.subcategory and instance.subcategory.image:
                data['picture'] = instance.subcategory.image.url
            elif instance.category and instance.category.image:
                data['picture'] = instance.category.image.url
            else:
                data['picture'] = None
        return data


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name','slug', 'image']


class SubcategorySerializer(serializers.ModelSerializer):
    category_slug = serializers.CharField(source='category.slug', read_only=True)
    class Meta:
        model = Subcategory
        fields = ['id', 'name', 'category', 'slug', 'image', 'category_slug']

class AnswerOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = AnswerOption
        fields = '__all__'

class ChosenAnswerSerializer(serializers.ModelSerializer):
    selected_options = AnswerOptionSerializer(many=True, required=False)

    class Meta:
        model = ChosenAnswer
        fields = '__all__'





class QuestionSerializer(serializers.ModelSerializer):
    next_question = serializers.PrimaryKeyRelatedField(read_only=True)
    options = AnswerOptionSerializer(many=True)

    class Meta:
        model = Question
        fields = ['id', 'question_text', 'question_type', 'options', 'next_question']


class FaoudProductSerializer(serializers.ModelSerializer):
    """
    Serializer for creating and managing Faoud marketplace products.
    These products are created by Account Managers and can be selected by Brand Owners.
    """
    raw_material_ids = serializers.ListField(
        child=serializers.IntegerField(), write_only=True, required=False
    )
    packaging_material_ids = serializers.ListField(
        child=serializers.IntegerField(), write_only=True, required=False
    )
    raw_material_prices = serializers.ListField(
        child=serializers.DecimalField(max_digits=10, decimal_places=2), write_only=True, required=False
    )
    packaging_material_prices = serializers.ListField(
        child=serializers.DecimalField(max_digits=10, decimal_places=2), write_only=True, required=False
    )
    raw_materials = ProductRawMaterialSerializer(source='productrawmaterial_set', many=True, read_only=True)
    packaging_materials = ProductPackagingMaterialSerializer(source='productpackagingmaterial_set', many=True, read_only=True)
    documents = ProductDocumentSerializer(many=True, read_only=True)
    category_name = serializers.CharField(source='category.name', read_only=True)
    subcategory_name = serializers.CharField(source='subcategory.name', read_only=True)

    class Meta:
        model = Product
        fields = [
            'id',
            'name',
            'sku_and_pm',
            'category',
            'category_name',
            'subcategory',
            'subcategory_name',
            'picture',
            'benchmark',
            'raw_materials',
            'packaging_materials',
            'raw_material_ids',
            'raw_material_prices',
            'packaging_material_ids',
            'packaging_material_prices',
            'documents',
            'created_at',
            'isFaoud_Product'
        ]
        read_only_fields = ['id', 'created_at', 'isFaoud_Product']

    def validate(self, attrs):
        """
        Validate that required fields for Faoud products are present.
        """
        if not attrs.get('name'):
            raise serializers.ValidationError("Product name is required.")
        
        if not attrs.get('category'):
            raise serializers.ValidationError("Category is required for Faoud products.")
        
        if not attrs.get('subcategory'):
            raise serializers.ValidationError("Subcategory is required for Faoud products.")
        
        return attrs

    def create(self, validated_data):
        """
        Create a Faoud product with isFaoud_Product=True and brand=None.
        Also creates a ProductGroup and sets versioning fields.
        """
        raw_material_ids = validated_data.pop('raw_material_ids', [])
        raw_material_prices = validated_data.pop('raw_material_prices', [])
        packaging_material_ids = validated_data.pop('packaging_material_ids', [])
        packaging_material_prices = validated_data.pop('packaging_material_prices', [])

        # Force Faoud product settings
        validated_data['isFaoud_Product'] = True
        validated_data['brand'] = None  # Faoud products don't belong to any brand
        validated_data['is_original'] = True  # This is an original Faoud marketplace product
        validated_data['version_number'] = 1  # First version

        # Create a ProductGroup FIRST (before the product)
        from .models import ProductGroup
        product_name = validated_data.get('name', 'Unnamed Product')
        category = validated_data.get('category')
        
        product_group = ProductGroup.objects.create(
            name=product_name,
            product_type=category.name if category else None,
            last_version_number=1
        )
        
        # Now assign the product_group to the product data
        validated_data['product_group'] = product_group

        # Create the product with the group already assigned
        product = Product.objects.create(**validated_data)

        # Update the product_group to reference this product as the original
        product_group.original_product = product
        product_group.save(update_fields=['original_product'])

        # Associate Raw Materials with prices
        for rm_id, price in zip(raw_material_ids, raw_material_prices):
            ProductRawMaterial.objects.create(
                product=product,
                raw_material_id=rm_id,
                price=price
            )

        # Associate Packaging Materials with prices
        for pm_id, price in zip(packaging_material_ids, packaging_material_prices):
            ProductPackagingMaterial.objects.create(
                product=product,
                packaging_material_id=pm_id,
                price=price
            )

        return product

    def update(self, instance, validated_data):
        """
        Update a Faoud product, ensuring it remains a Faoud product.
        """
        # Ensure it stays a Faoud product
        if not instance.isFaoud_Product:
            raise serializers.ValidationError("Cannot update a non-Faoud product with this serializer.")

        raw_material_ids = validated_data.pop('raw_material_ids', [])
        raw_material_prices = validated_data.pop('raw_material_prices', [])
        packaging_material_ids = validated_data.pop('packaging_material_ids', [])
        packaging_material_prices = validated_data.pop('packaging_material_prices', [])

        # Update basic fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # Update Raw Materials
        if raw_material_ids and raw_material_prices:
            ProductRawMaterial.objects.filter(product=instance).delete()
            for rm_id, price in zip(raw_material_ids, raw_material_prices):
                ProductRawMaterial.objects.create(
                    product=instance,
                    raw_material_id=rm_id,
                    price=price
                )

        # Update Packaging Materials
        if packaging_material_ids and packaging_material_prices:
            ProductPackagingMaterial.objects.filter(product=instance).delete()
            for pm_id, price in zip(packaging_material_ids, packaging_material_prices):
                ProductPackagingMaterial.objects.create(
                    product=instance,
                    packaging_material_id=pm_id,
                    price=price
                )

        return instance


# ============================================================================
# Product Group & Versioning Serializers
# ============================================================================

class ProductVersionMinimalSerializer(serializers.ModelSerializer):
    """Minimal serializer for displaying product versions in a list"""
    category_name = serializers.CharField(source='category.name', read_only=True)
    subcategory_name = serializers.CharField(source='subcategory.name', read_only=True)
    case_name = serializers.SerializerMethodField()
    
    class Meta:
        model = Product
        fields = [
            'id', 'name', 'version_number', 'is_original', 
            'isFaoud_Product', 'created_at', 'category_name',
            'subcategory_name', 'modification_notes', 'case_name',
            'picture'
        ]
        read_only_fields = fields
    
    def get_case_name(self, obj):
        if obj.created_from_case:
            return obj.created_from_case.name or f"Case {obj.created_from_case.id}"
        return None


class ProductGroupSerializer(serializers.ModelSerializer):
    """Serializer for ProductGroup with all versions"""
    original_product = ProductVersionMinimalSerializer(read_only=True)
    versions = serializers.SerializerMethodField()
    version_count = serializers.SerializerMethodField()
    latest_version_number = serializers.SerializerMethodField()
    
    class Meta:
        model = ProductGroup
        fields = [
            'id', 'group_identifier', 'name', 'description',
            'original_product', 'versions', 'version_count',
            'latest_version_number', 'created_at', 'updated_at'
        ]
        read_only_fields = fields
    
    def get_versions(self, obj):
        """Get all products in this group ordered by version"""
        products = obj.products.all().select_related(
            'category', 'subcategory', 'created_from_case'
        ).order_by('version_number')
        return ProductVersionMinimalSerializer(products, many=True).data
    
    def get_version_count(self, obj):
        return obj.get_version_count()
    
    def get_latest_version_number(self, obj):
        return obj.get_latest_version_number()


class ProductGroupMinimalSerializer(serializers.ModelSerializer):
    """Minimal group info for embedding in product serializers"""
    version_count = serializers.SerializerMethodField()
    
    class Meta:
        model = ProductGroup
        fields = ['id', 'group_identifier', 'name', 'version_count']
        read_only_fields = fields
    
    def get_version_count(self, obj):
        return obj.get_version_count()


class CaseProductSerializer(serializers.ModelSerializer):
    """
    Serializer for products assigned to cases.
    Includes versioning and group information.
    """
    raw_materials = ProductRawMaterialSerializer(source='productrawmaterial_set', many=True, read_only=True)
    packaging_materials = ProductPackagingMaterialSerializer(source='productpackagingmaterial_set', many=True, read_only=True)
    documents = ProductDocumentSerializer(many=True, read_only=True)
    category_name = serializers.CharField(source='category.name', read_only=True)
    subcategory_name = serializers.CharField(source='subcategory.name', read_only=True)
    product_group_info = ProductGroupMinimalSerializer(source='product_group', read_only=True)
    parent_product_name = serializers.CharField(source='parent_product.name', read_only=True)
    
    class Meta:
        model = Product
        fields = [
            'id', 'name', 'sku_and_pm', 'quantity', 'eta',
            'category', 'category_name', 'subcategory', 'subcategory_name',
            'picture', 'benchmark', 'raw_materials', 'packaging_materials',
            'documents', 'created_at', 'isFaoud_Product',
            # Versioning fields
            'product_group_info', 'version_number', 'is_original',
            'parent_product', 'parent_product_name', 'created_from_case',
            'modification_notes'
        ]
        read_only_fields = [
            'id', 'created_at', 'isFaoud_Product', 'version_number',
            'is_original', 'parent_product', 'created_from_case',
            'product_group_info', 'parent_product_name'
        ]
