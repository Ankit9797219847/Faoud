"""
Keywords Manager Utility
Handles export and import of keywords for Categories and Subcategories via Excel.
"""
import io
from datetime import datetime
from typing import Dict, List, Tuple

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
except ImportError:
    openpyxl = None

from django.http import HttpResponse
from django.db import transaction
from .models import Category, Subcategory


class KeywordsExporter:
    """Exports categories and subcategories with their keywords to Excel."""
    
    CATEGORY_SHEET = "Categories"
    SUBCATEGORY_SHEET = "Subcategories"
    INSTRUCTION_SHEET = "Instructions"
    
    def __init__(self):
        if not openpyxl:
            raise ImportError("openpyxl is required. Install it with: pip install openpyxl")
    
    def generate_template(self, include_data: bool = True) -> bytes:
        """
        Generate an Excel template with existing keywords.
        
        Args:
            include_data: If True, includes current data; if False, returns empty template
        
        Returns:
            Bytes of the Excel file
        """
        wb = openpyxl.Workbook()
        wb.remove(wb.active)  # Remove default sheet
        
        # Add instruction sheet
        self._create_instruction_sheet(wb)
        
        # Add category sheet
        self._create_category_sheet(wb, include_data)
        
        # Add subcategory sheet
        self._create_subcategory_sheet(wb, include_data)
        
        # Save to bytes
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        return output.getvalue()
    
    def _create_instruction_sheet(self, wb):
        """Create the instruction sheet."""
        ws = wb.create_sheet(self.INSTRUCTION_SHEET, 0)
        
        instructions = [
            ["Keywords Management Template"],
            [],
            ["INSTRUCTIONS:"],
            ["1. Do NOT modify the ID column - it's used to match records"],
            ["2. Do NOT modify the Name column - it's for reference only"],
            ["3. Keywords should be comma-separated (e.g., 'organic, natural, eco-friendly')"],
            ["4. Description is the HTML/text description of the item"],
            ["5. Leave keywords and description empty if you want to clear them"],
            ["6. Use the Categories sheet for main categories"],
            ["7. Use the Subcategories sheet for subcategories"],
            ["8. Keep the 'Category' column in Subcategories sheet (for reference)"],
            [],
            ["COLUMNS:"],
            ["ID - Unique identifier (DO NOT CHANGE)"],
            ["Name - Product name (DO NOT CHANGE, for reference only)"],
            ["Keywords - Comma-separated keywords to update"],
            ["Description - HTML/text description of the item"],
            ["Category - Category name (Subcategories sheet only, for reference)"],
            [],
            ["TIPS:"],
            ["- Use descriptive, SEO-friendly keywords"],
            ["- Separate multiple keywords with commas"],
            ["- Description supports HTML formatting"],
            ["- Avoid special characters in keywords"],
            ["- Keep keywords concise and relevant"],
        ]
        
        for row_idx, row_data in enumerate(instructions, 1):
            for col_idx, value in enumerate(row_data, 1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                if row_idx == 1:
                    cell.font = Font(bold=True, size=14)
                elif row_data[0] and row_data[0].isupper() and len(row_data[0]) < 20:
                    cell.font = Font(bold=True, size=11)
        
        ws.column_dimensions['A'].width = 50
        ws.column_dimensions['B'].width = 50
    
    def _create_category_sheet(self, wb, include_data: bool):
        """Create the categories sheet."""
        ws = wb.create_sheet(self.CATEGORY_SHEET)
        
        # Headers
        headers = ["ID", "Name", "Keywords", "Description", "Notes"]
        self._style_header_row(ws, headers)
        
        if include_data:
            categories = Category.objects.all().order_by('name')
            for row_idx, category in enumerate(categories, 2):
                ws.cell(row=row_idx, column=1, value=category.id)
                ws.cell(row=row_idx, column=2, value=category.name)
                ws.cell(row=row_idx, column=3, value=category.keywords or "")
                ws.cell(row=row_idx, column=4, value=category.description or "")
                ws.cell(row=row_idx, column=5, value="")
                # Freeze ID and Name columns by making them read-only
                ws.cell(row=row_idx, column=1).alignment = Alignment(horizontal='center')
                ws.cell(row=row_idx, column=2).alignment = Alignment(horizontal='left', wrap_text=True)
                ws.cell(row=row_idx, column=3).alignment = Alignment(horizontal='left', wrap_text=True)
                ws.cell(row=row_idx, column=4).alignment = Alignment(horizontal='left', wrap_text=True)
        
        self._set_column_widths(ws, [8, 25, 40, 50, 30])
    
    def _create_subcategory_sheet(self, wb, include_data: bool):
        """Create the subcategories sheet."""
        ws = wb.create_sheet(self.SUBCATEGORY_SHEET)
        
        # Headers
        headers = ["ID", "Subcategory Name", "Category", "Keywords", "Description", "Notes"]
        self._style_header_row(ws, headers)
        
        if include_data:
            subcategories = Subcategory.objects.select_related('category').order_by('category__name', 'name')
            for row_idx, subcat in enumerate(subcategories, 2):
                ws.cell(row=row_idx, column=1, value=subcat.id)
                ws.cell(row=row_idx, column=2, value=subcat.name)
                ws.cell(row=row_idx, column=3, value=subcat.category.name)
                ws.cell(row=row_idx, column=4, value=subcat.keywords or "")
                ws.cell(row=row_idx, column=5, value=subcat.description or "")
                ws.cell(row=row_idx, column=6, value="")
                # Alignment
                ws.cell(row=row_idx, column=1).alignment = Alignment(horizontal='center')
                ws.cell(row=row_idx, column=2).alignment = Alignment(horizontal='left', wrap_text=True)
                ws.cell(row=row_idx, column=3).alignment = Alignment(horizontal='left', wrap_text=True)
                ws.cell(row=row_idx, column=4).alignment = Alignment(horizontal='left', wrap_text=True)
                ws.cell(row=row_idx, column=5).alignment = Alignment(horizontal='left', wrap_text=True)
        
        self._set_column_widths(ws, [8, 25, 20, 40, 50, 30])
    
    def _style_header_row(self, ws, headers: List[str]):
        """Style the header row with colors and fonts."""
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF", size=11)
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.border = border
    
    def _set_column_widths(self, ws, widths: List[int]):
        """Set column widths."""
        for col_idx, width in enumerate(widths, 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = width
    
    def get_http_response(self, include_data: bool = True) -> HttpResponse:
        """Get HTTP response with Excel file."""
        template_bytes = self.generate_template(include_data)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        response = HttpResponse(
            template_bytes,
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = f'attachment; filename="keywords_template_{timestamp}.xlsx"'
        return response


class KeywordsImporter:
    """Imports keywords from Excel file and updates the database."""
    
    def __init__(self, file_obj):
        """
        Initialize the importer with an Excel file object.
        
        Args:
            file_obj: Django UploadedFile object
        """
        if not openpyxl:
            raise ImportError("openpyxl is required. Install it with: pip install openpyxl")
        
        self.file_obj = file_obj
        self.wb = openpyxl.load_workbook(file_obj)
        self.results = {
            'categories_updated': 0,
            'subcategories_updated': 0,
            'errors': [],
            'skipped': []
        }
    
    def validate_file(self) -> Tuple[bool, List[str]]:
        """
        Validate the Excel file structure.
        
        Returns:
            Tuple of (is_valid, error_messages)
        """
        errors = []
        
        required_sheets = ['Categories', 'Subcategories']
        for sheet_name in required_sheets:
            if sheet_name not in self.wb.sheetnames:
                errors.append(f"Missing required sheet: {sheet_name}")
        
        return len(errors) == 0, errors
    
    @transaction.atomic
    def import_keywords(self) -> Dict:
        """
        Import keywords from Excel file and update database.
        
        Returns:
            Dictionary with import results
        """
        is_valid, errors = self.validate_file()
        if not is_valid:
            self.results['errors'] = errors
            return self.results
        
        # Import categories
        self._import_categories()
        
        # Import subcategories
        self._import_subcategories()
        
        return self.results
    
    def _import_categories(self):
        """Import keywords and descriptions for categories from Excel."""
        ws = self.wb['Categories']
        
        for row_idx in range(2, ws.max_row + 1):  # Skip header row
            try:
                category_id = ws.cell(row=row_idx, column=1).value
                keywords = ws.cell(row=row_idx, column=3).value
                description = ws.cell(row=row_idx, column=4).value
                
                if category_id is None:
                    continue  # Skip empty rows
                
                try:
                    category = Category.objects.get(id=category_id)
                    category.keywords = keywords or ""
                    category.description = description or ""
                    category.save()
                    self.results['categories_updated'] += 1
                except Category.DoesNotExist:
                    self.results['errors'].append(
                        f"Category ID {category_id} not found (row {row_idx})"
                    )
            except Exception as e:
                self.results['errors'].append(
                    f"Error processing category row {row_idx}: {str(e)}"
                )
    
    def _import_subcategories(self):
        """Import keywords and descriptions for subcategories from Excel."""
        ws = self.wb['Subcategories']
        
        for row_idx in range(2, ws.max_row + 1):  # Skip header row
            try:
                subcat_id = ws.cell(row=row_idx, column=1).value
                keywords = ws.cell(row=row_idx, column=4).value
                description = ws.cell(row=row_idx, column=5).value
                
                if subcat_id is None:
                    continue  # Skip empty rows
                
                try:
                    subcategory = Subcategory.objects.get(id=subcat_id)
                    subcategory.keywords = keywords or ""
                    subcategory.description = description or ""
                    subcategory.save()
                    self.results['subcategories_updated'] += 1
                except Subcategory.DoesNotExist:
                    self.results['errors'].append(
                        f"Subcategory ID {subcat_id} not found (row {row_idx})"
                    )
            except Exception as e:
                self.results['errors'].append(
                    f"Error processing subcategory row {row_idx}: {str(e)}"
                )
    
    def close(self):
        """Close the workbook."""
        self.wb.close()
