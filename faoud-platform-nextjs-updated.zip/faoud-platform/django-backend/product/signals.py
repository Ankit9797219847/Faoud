# signals.py
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from .models import Case, Parameter, POM

@receiver(post_save, sender=Case)
def handle_case_pom(sender, instance, created, **kwargs):
    """Create POM entries when case is created/updated with product"""
    if instance.product and instance.product.subcategory:
        subcategory = instance.product.subcategory
        for param in subcategory.parameters.filter(is_active=True):
            POM.objects.get_or_create(
                case=instance,
                parameter=param,
                defaults={
                    'price': param.default_price,
                    'quantity': param.default_quantity,
                    'is_active': True
                }
            )

@receiver(post_save, sender=Parameter)
def propagate_parameter(sender, instance, created, **kwargs):
    """Add new parameter to all relevant cases"""
    if created and instance.is_active:
        cases = Case.objects.filter(product__subcategory=instance.subcategory)
        for case in cases:
            POM.objects.get_or_create(
                case=case,
                parameter=instance,
                defaults={
                    'price': instance.default_price,
                    'quantity': instance.default_quantity,
                    'is_active': True
                }
            )

@receiver(pre_save, sender=Case)
def update_pom_on_product_change(sender, instance, **kwargs):
    """Handle product changes by updating POM entries"""
    if instance.pk:
        try:
            original = Case.objects.get(pk=instance.pk)
            if original.product != instance.product:
                # Remove old POM entries
                POM.objects.filter(
                    case=instance,
                    parameter__subcategory=original.product.subcategory
                ).delete()
                # Create new entries
                if instance.product and instance.product.subcategory:
                    subcategory = instance.product.subcategory
                    for param in subcategory.parameters.filter(is_active=True):
                        POM.objects.create(
                            case=instance,
                            parameter=param,
                            price=param.default_price,
                            quantity=param.default_quantity,
                            is_active=True
                        )
        except Case.DoesNotExist:
            pass