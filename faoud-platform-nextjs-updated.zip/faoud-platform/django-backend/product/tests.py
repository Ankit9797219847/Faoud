from django.contrib.auth.models import User
from django.test import override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient, APITestCase

from case.models import Case
from product.models import Category, Product, ProductGroup, Subcategory
from product.services import ProductCloningService, ProductGroupService
from user.models import AM, BrandOwner


@override_settings(ROOT_URLCONF="shadow.urls")
class ProductListViewAPITest(APITestCase):
    def setUp(self):
        self.client = APIClient()

        self.brand_user = User.objects.create_user(username="brand-owner-product", password="pass")
        self.brand_owner = BrandOwner.objects.create(user=self.brand_user, name="Brand Owner Product")

        self.other_brand_user = User.objects.create_user(username="other-brand-product", password="pass")
        self.other_brand_owner = BrandOwner.objects.create(user=self.other_brand_user, name="Other Brand Owner Product")

        self.am_user = User.objects.create_user(username="am-product", password="pass")
        self.am = AM.objects.create(
            user=self.am_user,
            name="AM Product",
            contact_email="am-product@example.com",
            contact_phone="9999999999",
        )

        self.case_without_product = Case.objects.create(
            brand_owner=self.brand_owner,
            name="Case Without Product",
            category="npd_without",
            active=0,
        )
        self.case_without_product.am.add(self.am)

        self.other_case_without_product = Case.objects.create(
            brand_owner=self.other_brand_owner,
            name="Other Case Without Product",
            category="npd_without",
            active=0,
        )

    def authenticate(self, user):
        self.client.force_authenticate(user=user)

    def test_brand_owner_gets_null_when_case_has_no_product(self):
        self.authenticate(self.brand_user)

        response = self.client.get(reverse("product-list", kwargs={"case_id": self.case_without_product.id}))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIsNone(response.data)

    def test_account_manager_gets_empty_list_when_case_has_no_product(self):
        self.authenticate(self.am_user)

        response = self.client.get(reverse("product-list", kwargs={"case_id": self.case_without_product.id}))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data, [])

    def test_brand_owner_cannot_fetch_other_brand_case_product(self):
        self.authenticate(self.brand_user)

        response = self.client.get(reverse("product-list", kwargs={"case_id": self.other_case_without_product.id}))

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)


@override_settings(ROOT_URLCONF="shadow.urls")
class ProductVersioningServiceTest(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="product-service-user", password="pass")
        self.brand_owner_user = User.objects.create_user(username="product-service-brand-owner", password="pass")
        self.brand_owner = BrandOwner.objects.create(user=self.brand_owner_user, name="Service Brand Owner")

        self.category = Category.objects.create(name="Skin Care")
        self.subcategory = Subcategory.objects.create(name="Cream", category=self.category)

        self.faoud_product = Product.objects.create(
            name="Marketplace Cream",
            category=self.category,
            subcategory=self.subcategory,
            isFaoud_Product=True,
        )

        self.case = Case.objects.create(
            brand_owner=self.brand_owner,
            name="Clone Target Case",
            category="npd_without",
            active=0,
        )

    def test_create_product_group_uses_only_valid_model_fields(self):
        group = ProductGroupService.create_product_group(self.faoud_product)

        self.faoud_product.refresh_from_db()
        self.assertEqual(group.name, self.faoud_product.name)
        self.assertEqual(group.product_type, self.category.name)
        self.assertEqual(group.last_version_number, 1)
        self.assertEqual(group.original_product, self.faoud_product)
        self.assertEqual(self.faoud_product.product_group, group)
        self.assertTrue(self.faoud_product.is_original)
        self.assertEqual(self.faoud_product.version_number, 1)

    def test_clone_product_for_case_updates_group_version_state(self):
        group = ProductGroupService.create_product_group(self.faoud_product)

        cloned_product = ProductCloningService.clone_product_for_case(
            original_product=self.faoud_product,
            case=self.case,
            created_by_user=self.user,
        )

        group.refresh_from_db()
        self.assertEqual(cloned_product.product_group, group)
        self.assertEqual(cloned_product.parent_product, self.faoud_product)
        self.assertFalse(cloned_product.isFaoud_Product)
        self.assertEqual(cloned_product.version_number, 2)
        self.assertEqual(group.last_version_number, 2)
        self.assertEqual(ProductGroup.objects.count(), 1)
