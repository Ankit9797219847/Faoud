from django.db import models
import uuid

from case.models import Case
from materials.models import PackagingMaterial, RawMaterial
from supply.models import PMSupplier, RMSupplier
from django.utils.text import slugify
from django_ckeditor_5.fields import CKEditor5Field


class ProductGroup(models.Model):
    """
    Groups related products together (original Faoud product + all case-specific copies).
    Each group represents a product family with versions.
    """
    name = models.CharField(max_length=255, db_column='group_name', help_text="Human readable group name")
    product_type = models.CharField(max_length=100, blank=True, null=True, help_text="Type of products in this group")
    last_version_number = models.PositiveIntegerField(default=1, help_text="Last version number used")
    is_active = models.BooleanField(default=True)
    original_product = models.ForeignKey(
        'Product', 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='original_for_group',
        help_text="Reference to the original Faoud marketplace product"
    )
    created_by = models.ForeignKey(
        'auth.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="User who created this group"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'product_productgroup'

    def __str__(self):
        return f"Group: {self.name}"

    @property
    def group_identifier(self):
        """Returns UUID based on ID for backwards compatibility"""
        return uuid.uuid5(uuid.NAMESPACE_OID, f"product_group_{self.id}")

    def get_version_count(self):
        """Returns the total number of products in this group"""
        return self.products.count()

    def get_latest_version_number(self):
        """Returns the highest version number in this group or last_version_number"""
        latest = self.products.aggregate(models.Max('version_number'))
        max_from_products = latest['version_number__max'] or 0
        return max(max_from_products, self.last_version_number)


class Category(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='category_images/', blank=True, null=True)  # New image field
    slug = models.SlugField(blank=True, null=True, unique=True)
    description = CKEditor5Field(blank=True, null=True)  # New description field
    keywords = models.TextField(blank=True, null=True)
    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name)
            slug = base_slug
            counter = 1

            # Check for existing slugs and increment until unique
            while Category.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1

            self.slug = slug

        super().save(*args, **kwargs)


class Subcategory(models.Model):
    name = models.CharField(max_length=100)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="subcategories")
    # New fields to calculate quote_bo and assign default tag
    multiplier = models.DecimalField(max_digits=5, decimal_places=2, default=1.0)
    additive = models.DecimalField(max_digits=10, decimal_places=2, default=0.0)
    auto_bid = models.BooleanField(default=False)
    image = models.ImageField(upload_to='subcategory_images/', blank=True, null=True)  # New image field
    slug = models.SlugField(blank=True, null=True, unique=True)
    description = CKEditor5Field(blank=True, null=True)  # New description field
    keywords = models.TextField(blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name)
            slug = base_slug
            counter = 1

            while Subcategory.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1

            self.slug = slug

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} ({self.category.name})"

class Product(models.Model):

    name = models.CharField(max_length=100)
    sku_and_pm = models.CharField(max_length=100, blank=True, null=True)  # Renamed from form_factor
    quantity = models.PositiveIntegerField(default=0)  # New field
    eta = models.DateField(blank=True, null=True)  # New field
    stages = models.TextField(blank=True, null=True)
    briefs = models.ManyToManyField("utils.Brief", related_name="products", blank=True)
    formulations = models.ManyToManyField("formulation.Formulation", related_name="products", blank=True)
    brand = models.ForeignKey("utils.Brand",on_delete=models.SET_NULL, related_name="products", blank=True, null=True)
    cases = models.ManyToManyField("case.Case", related_name="products", blank=True)
    raw_materials = models.ManyToManyField(RawMaterial, related_name="products", blank=True)
    packaging_materials = models.ManyToManyField(PackagingMaterial, related_name="products", blank=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, related_name="products")
    subcategory = models.ForeignKey(Subcategory, on_delete=models.SET_NULL, null=True, related_name="products")
    created_at = models.DateTimeField(auto_now_add=True) 
    benchmark = models.TextField(blank=True, null=True)  # New benchmark field
    picture = models.ImageField(upload_to='products/', blank=True, null=True)  # New picture field
    isFaoud_Product = models.BooleanField(default=False, help_text="Indicates if this is a Faoud marketplace product")
    
    # Product Grouping & Versioning Fields
    product_group = models.ForeignKey(
        ProductGroup, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='products',
        db_index=True,
        help_text="Links this product to its product group"
    )
    version_number = models.PositiveIntegerField(
        default=1,
        help_text="Version number within the product group"
    )
    is_original = models.BooleanField(
        default=False,
        db_column='is_current_version',  # Map to existing column
        help_text="True if this is the original Faoud marketplace product"
    )
    parent_product = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='derived_products',
        db_column='created_from_product_id',  # Map to existing column
        help_text="The product this was cloned from"
    )
    created_from_case = models.ForeignKey(
        "case.Case",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='spawned_products',
        help_text="The case this product copy was created for"
    )
    modification_notes = models.TextField(
        blank=True,
        null=True,
        db_column='edit_reason',  # Map to existing column
        help_text="Notes about changes made in this version"
    )
    version_created_at = models.DateTimeField(
        auto_now_add=False,
        null=True,
        blank=True,
        help_text="When this version was created"
    )
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['product_group', 'version_number']),
            models.Index(fields=['is_original', 'isFaoud_Product']),
            models.Index(fields=['created_from_case']),
        ]
    
    def __str__(self):
        if self.version_number > 1 or not self.is_original:
            return f"{self.name} (v{self.version_number})"
        return self.name    
    



class ProductDocument(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='documents')
    name = models.CharField(max_length=100)
    file = models.FileField(upload_to='product_documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.product.name}"


class ProductRawMaterial(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    raw_material = models.ForeignKey(RawMaterial, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    supplier = models.ForeignKey(RMSupplier, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        unique_together = ('product', 'raw_material')

class ProductPackagingMaterial(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    packaging_material = models.ForeignKey(PackagingMaterial, on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    supplier = models.ForeignKey(PMSupplier, on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        unique_together = ('product', 'packaging_material')



class Question(models.Model):
    QUESTION_TYPES = [
        ('MC', 'Multiple Choice'),
        ('SA', 'Short Answer'),
        ('LA', 'Long Answer'),
        ('FU', 'File Upload'),
        ('DS', 'Date Selection'),
        ('YN', 'Yes/No'),
    ]
    CATEGORY_CHOICES = [
        ('npd_without', 'NPD without Formulation'),
        ('npd_with', 'NPD with Formulation'),
        ('reorder', 'Reorder Earlier Products'),
        ('onboarding', 'Onboarding the BrandOnwer'),
        ('dormantProduct', 'Dormant Product'),
    ]
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES, default='npd_without')  # To differentiate trees
    question_text = models.TextField(blank=True, default="")
    starting_question = models.BooleanField(default=False)
    question_type = models.CharField(max_length=2, choices=QUESTION_TYPES, default='SA')
    options = models.ManyToManyField('AnswerOption', blank=True, related_name='questions')  # For MC and SC types
    next_question = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL, related_name='previous_questions')

    is_case_specific = models.BooleanField(default=False)  # Whether the question is specific to a particular case
    case = models.ForeignKey("case.Case", on_delete=models.CASCADE, related_name="additional_questions", blank=True, null=True)  # Case-specific question
    created_by_am = models.BooleanField(default=False)  # Whether this question was added by an Account Manager

    def __str__(self):
        return self.question_text

class AnswerOption(models.Model):
    option_text = models.TextField(blank=True, null=True)
    next_question = models.ForeignKey(Question, null=True, blank=True, on_delete=models.CASCADE, related_name='prev_answer_options')

    def __str__(self):
        return self.option_text

class ChosenAnswer(models.Model):
    brand_owner = models.ForeignKey("user.BrandOwner", on_delete=models.SET_NULL, related_name="answers", blank=True, null=True)
    case = models.ForeignKey("case.Case", on_delete=models.CASCADE, related_name="answers", blank=True, null=True)
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name="chosen_answers", blank=True, null=True)
    answer_text = models.TextField(blank=True, null=True)  # For SA, LA, DS
    answer_file = models.FileField(upload_to='uploads/', null=True, blank=True)  # For FU
    selected_options = models.ManyToManyField(AnswerOption, blank=True)  # For MC, SC

    is_case_specific = models.BooleanField(default=False)  # Whether this answer is for a case-specific question
    order_index = models.PositiveIntegerField(default=0)  # NEW: Track order of questions

    class Meta:
        ordering = ['order_index']  # Ensures retrieval maintains order


    def __str__(self):
        return f"Answer to {self.question}"



from django.db import models

class Parameter(models.Model):
    subcategory = models.ForeignKey(
        Subcategory, 
        on_delete=models.CASCADE, 
        related_name='product_parameters'  # Add a unique related_name
    )
    name = models.CharField(max_length=100)
    unit = models.CharField(max_length=50, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    default_price = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        blank=True, 
        null=True
    )
    default_quantity = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        blank=True, 
        null=True
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} ({self.subcategory.name})"

class POM(models.Model):
    case = models.ForeignKey(
        Case, 
        on_delete=models.CASCADE, 
        related_name='pom_parameters'
    )
    parameter = models.ForeignKey(
        Parameter, 
        on_delete=models.CASCADE
    )
    is_active = models.BooleanField(default=True)
    price = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        blank=True, 
        null=True
    )
    quantity = models.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        blank=True, 
        null=True
    )
    value = models.CharField(
        max_length=255, 
        blank=True, 
        null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('case', 'parameter')

    def __str__(self):
        return f"{self.parameter.name} for Case {self.case.id}"
