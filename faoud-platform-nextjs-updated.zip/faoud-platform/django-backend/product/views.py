from datetime import datetime
import json
from django.utils import timezone
from django.db import transaction
from rest_framework import status
from rest_framework.response import Response
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from formulation.models import Formulation
from materials.models import PackagingMaterial, RawMaterial
from materials.serializers import PackagingMaterialSerializer, RawMaterialSerializer
from payments.signals import create_user_features
from payments.utils import add_feature_to_case_and_user
from supply.models import Factory, PMSupplier, RMSupplier
from supply.serializers import FactorySerializer
from user.permissions import IsBrandOwner, IsAccountManager
from utils.models import Brief
from .models import Category, Product, ProductDocument, ProductPackagingMaterial, ProductRawMaterial, Question, ChosenAnswer, AnswerOption, Subcategory, ProductGroup
from .serializers import CategorySerializer, ProductDocumentSerializer, ProductSerializer, QuestionSerializer, ChosenAnswerSerializer, SubcategorySerializer
from case.models import Case, ProgressStage, Service, Stage
from case.serializers import CaseSerializer, ServiceSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from user.permissions import IsAccountManager
from .models import Question, ChosenAnswer
from .serializers import QuestionSerializer, ChosenAnswerSerializer
from case.models import Case
import random
from utils.models import Brand
from user.models import AM  # Assuming AM is the Account Manager model
from case.models import Stage  # Import required models
from rest_framework.decorators import action
from case.serializers_public import PublicCaseSerializer 
from supply.serializers_public import PublicFactorySerializer 
from .serializers_public import PublicProductSerializer, PublicSubcategorySerializer 
from django.contrib.contenttypes.models import ContentType
from leads.models import LeadItem

class QuestionView(viewsets.ViewSet):
    permission_classes = [IsBrandOwner]

    def newCase(self, request):
        category = request.query_params.get('category', 'npd_without')  # Default to npd_without if not provided

        # Fetch the first question based on the category
        first_question = Question.objects.filter(starting_question=True, category=category)
        if not first_question:
            return Response({"error": "No starting question found for this category."}, status=status.HTTP_404_NOT_FOUND)

        # Initialize case fields
        start_date = datetime.now()  # Set the current date and time as the start date
        default_stage = Stage.objects.filter(order=0).first()  # Assuming there's a stage with order = 0
        if not default_stage:
            return Response({"error": "Initial stage not found."}, status=status.HTTP_404_NOT_FOUND)

        # Randomly assign an Account Manager
        account_managers = AM.objects.filter(user__groups__name='superAM')  # Filter AMs by user group
        if not account_managers.exists():
            account_managers = []
            return Response({"error": "No Account Managers available in the specified group."}, status=status.HTTP_404_NOT_FOUND)




        # Create the new case without assigning many-to-many fields yet
        
        new_case = Case.objects.create(
            brand_owner=request.user.brandowner,
            start_date=start_date,
            eta=None,  # ETA can be set later
            quantity=None,  # Quantity can be set later
            formulation=None,
            category=category  # Default to None unless NPD with formulation
        )

        # Now assign many-to-many fields (stages and am)
        new_case.am.set(account_managers)  # Assign the randomly selected Account Manager


        progress_stage = new_case.progress_stages.filter(stage=default_stage).first()
        if progress_stage and progress_stage.completion_date:
            return Response({"error": f"The stage '{default_stage.name}' is already completed."},
                            status=status.HTTP_400_BAD_REQUEST)

        # If the stage has not been completed yet, create or update the ProgressStage
        if not progress_stage:
            progress_stage = ProgressStage.objects.create(
                case=new_case,
                stage=default_stage,
                order_in_timeline=default_stage.order
            )

        # Mark the new stage as completed
        progress_stage.completion_date = request.data.get('completion_date', None) or timezone.now().date()
        progress_stage.save()
        serialized_questions = QuestionSerializer(first_question, many=True)

        # Ensure created_by on the corresponding lead reflects the creator
        try:
            ct_case = ContentType.objects.get_for_model(Case)
            LeadItem.objects.filter(source_ct=ct_case, source_id=new_case.id).update(created_by=request.user)
        except Exception:
            pass

        return Response({
            "questions": serialized_questions.data,
            "case": new_case.id
        }, status=status.HTTP_201_CREATED)

    def retrieve(self, request, pk=None):
        question = Question.objects.filter(id=pk).first()
        if not question:
            return Response({"error": "Question not found"}, status=status.HTTP_404_NOT_FOUND)
        serializer = QuestionSerializer(question)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def listQuestions(self, request):
        category = request.query_params.get('category', 'npd_without')
        questions = Question.objects.filter(category=category, starting_question=True)
        if not questions.exists():
            return Response({"error": "No starting questions found for this category."}, status=status.HTTP_404_NOT_FOUND)
        serialized_questions = QuestionSerializer(questions, many=True)
        return Response({"questions": serialized_questions.data}, status=status.HTTP_200_OK)
    

    def submitAnswers(self, request):
        category = request.data.get('category', 'npd_without')
        answers_json = request.data.get('answers', '[]')

        try:
            answers = json.loads(answers_json)
        except json.JSONDecodeError:
            return Response({"error": "Invalid answers data"}, status=status.HTTP_400_BAD_REQUEST)

        # Create the new case
        start_date = datetime.now()
        default_stage = Stage.objects.filter(order=0).first()
        if not default_stage:
            return Response({"error": "Initial stage not found."}, status=status.HTTP_404_NOT_FOUND)

        # Create the new case
        new_case = Case.objects.create(
            brand_owner=request.user.brandowner,
            start_date=start_date,
            eta=None,
            quantity=None,
            formulation=None,
            category=category
        )

        # Process the answers in the order they were received
        for index, answer_data in enumerate(answers):  # Maintain order using `enumerate`
            question_id = answer_data.get('question')
            question_type = answer_data.get('question_type')
            question = Question.objects.filter(id=question_id).first()

            if not question:
                return Response({"error": f"Question {question_id} not found."}, status=status.HTTP_400_BAD_REQUEST)

            # Store the answer with the assigned order index
            chosen_answer = ChosenAnswer.objects.create(
                brand_owner=request.user.brandowner,
                case=new_case,
                question=question,
                order_index=index  # Maintain the order of processing
            )

            if question_type in ['SA', 'LA', 'DS', 'YN']:
                chosen_answer.answer_text = answer_data.get('answer_text')
                chosen_answer.save()

            elif question_type == 'FU':
                file = request.FILES.get(f'answer_file_{question_id}')
                if file:
                    chosen_answer.answer_file = file
                    chosen_answer.save()

            elif question_type == 'MC':
                selected_option_ids = answer_data.get('selected_options', [])
                for option_id in selected_option_ids:
                    option = AnswerOption.objects.filter(id=option_id).first()
                    if option:
                        chosen_answer.selected_options.add(option)
                chosen_answer.save()

        # Retrieve answers in the correct order
        ordered_answers = ChosenAnswer.objects.filter(case=new_case).order_by('order_index')

        # Serialize the answers in the correct order
        serialized_answers = [
            {
                "id": ans.id,
                "question": ans.question.id,
                "question_text": ans.question.question_text,
                "question_type": ans.question.question_type,
                "answer_text": ans.answer_text,
                "selected_options": list(ans.selected_options.values('id', 'option_text')),
                "answer_file": ans.answer_file.url if ans.answer_file else None,
                "order_index": ans.order_index
            }
            for ans in ordered_answers
        ]
        # ensure post_save receivers run (force a save to trigger post_save handlers)
        try:
            new_case.save()
        except Exception:
            # fallback: emit the post_save signal manually if save fails for some reason
            post_save.send(sender=Case, instance=new_case, created=False)

        # Tag the corresponding lead with creator
        try:
            ct = ContentType.objects.get_for_model(Case)
            LeadItem.objects.filter(source_ct=ct, source_id=new_case.id).update(created_by=request.user)
        except Exception:
            pass
        return Response({
            "message": "Case created successfully",
            "case_id": new_case.id,
            "answers": serialized_answers  # Ordered answers
        }, status=status.HTTP_201_CREATED)




    def chooseAnswer(self, request):
        question_id = request.data.get('question')
        question = Question.objects.filter(id=question_id).first()
        if not question:
            return Response({"error": "Question not found"}, status=status.HTTP_404_NOT_FOUND)

        case_id = request.data.get('case')
        case = Case.objects.filter(id=case_id).first()
        if not case:
            return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)

        chosen_answer = ChosenAnswer.objects.create(
            brand_owner=request.user.brandowner,
            case=case,
            question=question,
        )

        next_question = None

        if question.question_type in ['SA', 'LA', 'DS']:
            chosen_answer.answer_text = request.data.get('answer_text')
            chosen_answer.save()
            next_question = question.next_question

        elif question.question_type == 'FU':
            file = request.FILES.get('answer_file')
            if file:
                chosen_answer.answer_file = file
                chosen_answer.save()
            next_question = question.next_question

        elif question.question_type == 'MC':
            selected_options = request.data.get('selected_options', [])
            for option_id in selected_options:
                option = AnswerOption.objects.filter(id=option_id).first()
                if option:
                    chosen_answer.selected_options.add(option)
                    if option.next_question:
                        next_question = option.next_question  # Next question varies based on selected option
            chosen_answer.save()

        elif question.question_type == 'YN':
            yes_no_answer = request.data.get('answer_text')
            chosen_answer.answer_text = yes_no_answer
            chosen_answer.save()
            next_question = question.next_question

        if next_question:
            nq_serializer = QuestionSerializer(next_question)
            return Response({"next_question": nq_serializer.data}, status=status.HTTP_201_CREATED)
        else:
            return Response({"message": "No more questions"}, status=status.HTTP_200_OK)

    def continueCase(self, request):
        case_id = request.GET.get("case")
        case = Case.objects.filter(id=case_id).first()
        if not case:
            return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)
        if case.brand_owner != request.user.brandowner:
            return Response({"error": "This case does not belong to you"}, status=status.HTTP_403_FORBIDDEN)

        last_answer = case.answers.last()
        next_question = None

        if last_answer:
            if last_answer.question.question_type == 'MC':
                next_question = last_answer.selected_options.first().next_question
            else:
                next_question = last_answer.question.next_question
        else:
            next_questions = Question.objects.filter(prev_answer=None).order_by('id')
            if next_questions.exists():
                serialized_questions = QuestionSerializer(next_questions, many=True)
                return Response({"questions": serialized_questions.data}, status=status.HTTP_200_OK)

        if not next_question:
            services = Service.objects.all()
            serv_ser = ServiceSerializer(services, many=True)
            return Response({"services": serv_ser.data}, status=status.HTTP_201_CREATED)

        serialized_next_question = QuestionSerializer(next_question)
        return Response({"questions": serialized_next_question.data}, status=status.HTTP_200_OK)

    def chooseService(self, request):
        case_id = request.data.get("case")
        case = Case.objects.filter(id=case_id).first()
        if not case:
            return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)
        if case.brand_owner != request.user.brandowner:
            return Response({"error": "This case does not belong to you"}, status=status.HTTP_403_FORBIDDEN)

        service_ids = request.data.get("services", [])
        services = Service.objects.filter(id__in=service_ids)
        if not services.exists():
            return Response({"error": "Service not found"}, status=status.HTTP_404_NOT_FOUND)

        case.services.add(*services)
        return Response({"message": "Services added to case"}, status=status.HTTP_200_OK)



class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAccountManager]

    def create(self, request, *args, **kwargs):
        # Handle file upload and form factor in the request data
        picture = request.FILES.get('picture', None)
        category_id = request.data.get('category')
        subcategory_id = request.data.get('subcategory')
        case_id = request.data.get('case_id')
        case = Case.objects.get(id=case_id)
        if not case:
            return Response({"error": "Case not found."}, status=status.HTTP_404_NOT_FOUND)

        brandOwner = case.brand_owner
        brand = brandOwner.brands.first() # to be changed after addition of multiple brands


        if not category_id or not subcategory_id:
            return Response({"error": "Category and subcategory are required."}, status=status.HTTP_400_BAD_REQUEST)

        category = Category.objects.filter(id=category_id).first()
        subcategory = Subcategory.objects.filter(id=subcategory_id, category=category).first()

        if not category or not subcategory:
            return Response({"error": "Invalid category or subcategory."}, status=status.HTTP_400_BAD_REQUEST)

        # Prepare the serializer
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        # Save the new product, passing the picture and form_factor
        product = serializer.save(picture=picture, category=category, subcategory=subcategory, brand = brand)


        documents_data = request.data.get('documents', '[]')
        try:
            documents_data = json.loads(documents_data)  # Convert the stringified array to a list
        except json.JSONDecodeError:
            documents_data = []  # Default to empty list if parsing fails

        if documents_data:
            for document in documents_data:
                document_name = document.get('name')
                document_file = document.get('link')  # Ensure files are passed with the document name as key
                if document_name and document_file:
                    ProductDocument.objects.create(
                        product=product,
                        name=document_name,
                        file=document_file
                    )

        # Handle briefs, cases, raw materials, and packaging materials
         # Parse 'briefs' from string to list
        brief_ids = request.data.get('briefs', '[]')
        try:
            brief_ids = json.loads(brief_ids)  # Convert the stringified array to a list
        except json.JSONDecodeError:
            brief_ids = []  # Default to empty list if parsing fails

        if brief_ids and isinstance(brief_ids, list):  # Ensure it's a list
            briefs = Brief.objects.filter(id__in=brief_ids)
            product.briefs.set(briefs)

        case.product = product
        case.quantity = request.data.get('quantity', None)
        case.eta = request.data.get('eta', None)  # Associate or update product
        case.save()
        product.cases.set([case])

        raw_material_ids = request.data.get('raw_material_ids', [])
        raw_material_prices = request.data.get('raw_material_prices', [])
        for rm_id, price in zip(raw_material_ids, raw_material_prices):
            raw_material = RawMaterial.objects.get(id=rm_id)
            ProductRawMaterial.objects.create(product=product, raw_material=raw_material, price=price)

        packaging_material_ids = request.data.get('packaging_material_ids', [])
        packaging_material_prices = request.data.get('packaging_material_prices', [])
        for pm_id, price in zip(packaging_material_ids, packaging_material_prices):
            packaging_material = PackagingMaterial.objects.get(id=pm_id)
            ProductPackagingMaterial.objects.create(product=product, packaging_material=packaging_material, price=price)

        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
    
    def update(self, request, *args, **kwargs):
            partial = kwargs.pop('partial', False)
            instance = self.get_object()
            serializer = self.get_serializer(instance, data=request.data, partial=partial)
            serializer.is_valid(raise_exception=True)
            product = serializer.save()

            # Update raw materials associated with the product
            raw_material_ids = request.data.get('raw_material_ids', [])
            raw_material_prices = request.data.get('raw_material_prices', [])

            # Clear existing raw materials and add the updated ones
            ProductRawMaterial.objects.filter(product=product).delete()
            for rm_id, price in zip(raw_material_ids, raw_material_prices):
                raw_material = RawMaterial.objects.get(id=rm_id)
                ProductRawMaterial.objects.create(product=product, raw_material=raw_material, price=price)

            # Update packaging materials associated with the product
            packaging_material_ids = request.data.get('packaging_material_ids', [])
            packaging_material_prices = request.data.get('packaging_material_prices', [])


            documents_data = request.data.get('documents', '[]')
            try:
                documents_data = json.loads(documents_data)  # Convert the stringified array to a list
            except json.JSONDecodeError:
                documents_data = []  # Default to empty list if parsing fails

            if documents_data:
                for document in documents_data:
                    document_name = document.get('name')
                    document_file = request.FILES.get(f"file_{document_name}")  # Ensure files are passed with the document name as key
                    if document_name and document_file:
                        ProductDocument.objects.create(
                            product=product,
                            name=document_name,
                            file=document_file
                        )

            # Clear existing packaging materials and add the updated ones
            ProductPackagingMaterial.objects.filter(product=product).delete()
            for pm_id, price in zip(packaging_material_ids, packaging_material_prices):
                packaging_material = PackagingMaterial.objects.get(id=pm_id)
                ProductPackagingMaterial.objects.create(product=product, packaging_material=packaging_material, price=price)

            return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def documents(self, request, pk=None):
        product = self.get_object()
        documents = product.documents.all()
        serializer = ProductDocumentSerializer(documents, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['post'], url_path='create-case', permission_classes=[IsBrandOwner])
    def create_case(self, request):
        product_id = request.data.get('product_id')
        quantity = request.data.get('quantity')
        eta = request.data.get('eta')
        case_name = request.data.get('case_name')

        if not (product_id and quantity and eta):
            return Response({"error": "Missing product_id, quantity, or turnaround_time"}, status=400)
        try:
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return Response({"error": "Product not found"}, status=404)

        # By default use the provided product for the case
        product_for_case = product

        # If the product is a Faoud marketplace product, clone it for the requesting brand owner
        try:
            if getattr(product, 'isFaoud_Product', False):
                brand_owner = getattr(request.user, 'brandowner', None)
                brand = None
                if brand_owner:
                    brand = brand_owner.brands.first()

                brand_name = brand.name if brand and getattr(brand, 'name', None) else (getattr(brand_owner, 'name', None) if brand_owner else None)
                if not brand_name:
                    # fallback to user's username when brand name isn't available
                    brand_name = getattr(request.user, 'username', 'Brand')

                # Build new product name by appending ' - BrandName'
                new_name = f"{product.name} - {brand_name}"

                # Create or reuse ProductGroup and create the clone inside a transaction so the
                # cloned product belongs to the group immediately (avoids race conditions)
                try:
                    with transaction.atomic():
                        group = product.product_group
                        if not group:
                            group = ProductGroup.objects.create(
                                name=f"{product.name} Group",
                                original_product=product,
                                created_by=(request.user if getattr(request.user, 'id', None) else None)
                            )
                            product.product_group = group
                            product.save(update_fields=['product_group'])

                        # determine next version number
                        next_version = (group.get_latest_version_number() or 0) + 1

                        # Create a shallow clone: copy safe fields and relations and attach group/parent/version
                        clone_kwargs = {
                            'name': new_name,
                            'category': product.category,
                            'subcategory': product.subcategory,
                            'picture': getattr(product, 'picture', None),
                            'brand': brand,
                            # Ensure this cloned product is not marked as an original Faoud product
                            'isFaoud_Product': False,
                            'is_original': False,
                            'product_group': group,
                            'benchmark': product.benchmark,
                            'parent_product': product,
                            'sku_and_pm': product.sku_and_pm,
                            'version_number': next_version,
                            'version_created_at': timezone.now(),
                        }

                        # Only set description if attribute exists on model
                        if hasattr(product, 'description'):
                            clone_kwargs['description'] = getattr(product, 'description')

                        # Create the cloned product (belongs to group from creation)
                        cloned_product = Product.objects.create(**{k: v for k, v in clone_kwargs.items() if v is not None})

                        # update group's last_version_number
                        group.last_version_number = next_version
                        group.save(update_fields=['last_version_number'])
                except Exception:
                    # best-effort: do not break case creation if group operations fail
                    cloned_product = Product.objects.create(name=new_name, category=product.category, subcategory=product.subcategory, picture=getattr(product, 'picture', None), brand=brand, isFaoud_Product=False, is_original=False)
                 
                 # Copy related raw materials, packaging materials and documents (best-effort)
                try:
                    for prm in product.productrawmaterial_set.all():
                        ProductRawMaterial.objects.create(
                            product=cloned_product,
                            raw_material=prm.raw_material,
                            price=getattr(prm, 'price', None),
                            supplier=getattr(prm, 'supplier', None) if hasattr(prm, 'supplier') else None
                        )
                except Exception:
                    # ignore errors copying raw materials
                    pass

                try:
                    for ppm in product.productpackagingmaterial_set.all():
                        ProductPackagingMaterial.objects.create(
                            product=cloned_product,
                            packaging_material=ppm.packaging_material,
                            price=getattr(ppm, 'price', None),
                            supplier=getattr(ppm, 'supplier', None) if hasattr(ppm, 'supplier') else None
                        )
                except Exception:
                    # ignore errors copying packaging materials
                    pass

                try:
                    for doc in product.documents.all():
                        ProductDocument.objects.create(
                            product=cloned_product,
                            name=getattr(doc, 'name', None) or '',
                            file=getattr(doc, 'file', None)
                        )
                except Exception:
                    # ignore errors copying documents
                    pass

                # Use the cloned product for the new case
                product_for_case = cloned_product
                # Ensure cloned_product is attached to a ProductGroup even if the creation fell
                # back to the simple except-path above.
                try:
                    if cloned_product and not getattr(cloned_product, 'product_group', None):
                        g = product.product_group
                        if not g:
                            g = ProductGroup.objects.create(
                                name=f"{product.name} Group",
                                original_product=product,
                                created_by=(request.user if getattr(request.user, 'id', None) else None)
                            )
                            product.product_group = g
                            product.save(update_fields=['product_group'])

                        # set version metadata on the cloned product
                        try:
                            next_v = (g.get_latest_version_number() or 0) + 1
                        except Exception:
                            next_v = 2
                        cloned_product.product_group = g
                        cloned_product.parent_product = product
                        cloned_product.version_number = next_v
                        cloned_product.version_created_at = timezone.now()
                        cloned_product.save(update_fields=['product_group', 'parent_product', 'version_number', 'version_created_at'])

                        g.last_version_number = cloned_product.version_number
                        g.save(update_fields=['last_version_number'])
                except Exception:
                    # do not block case creation for group attach failures
                    pass
        except Exception:
            # Do not block case creation if cloning fails; proceed with original product
            product_for_case = product

        new_case = Case.objects.create(
            brand_owner=request.user.brandowner,
            product=product_for_case,
            quantity=quantity,
            eta=eta,
            name=case_name,
            category='npd_without'  # or any default category
        )

        # Tag the lead created for this case with the creator
        try:
            ct_case = ContentType.objects.get_for_model(Case)
            LeadItem.objects.filter(source_ct=ct_case, source_id=new_case.id).update(created_by=request.user)
        except Exception:
            pass

        # If we created a cloned product, set its created_from_case pointer now that the case exists
        try:
            if product_for_case and product_for_case.parent_product:
                product_for_case.created_from_case = new_case
                product_for_case.save(update_fields=['created_from_case'])
        except Exception:
            pass
        return Response({"case_id": new_case.id}, status=201)

    @action(detail=False, methods=['get'], url_path='my-products', permission_classes=[IsBrandOwner])
    def my_products(self, request):
        brandowner = getattr(request.user, 'brandowner', None)
        if not brandowner:
            return Response({"error": "Not a brand owner"}, status=403)
        brands = request.user.brandowner.brands.all()
        products = Product.objects.filter(brand__in=brands)
        serializer = ProductSerializer(products, many=True)
        return Response(serializer.data, status=200)


    @action(detail=True, methods=['post'])
    def add_packaging_material(self, request, pk=None):
        print(f"Product ID received: {pk}")
        product = Product.objects.filter(id=pk).first()
        packaging_material_id = request.data.get('packaging_material_id')
        price = request.data.get('price', None)

        if not packaging_material_id:
            return Response({"error": "Packaging material ID is required."}, status=status.HTTP_400_BAD_REQUEST)

        # Fetch packaging material
        packaging_material = PackagingMaterial.objects.filter(id=packaging_material_id).first()
        supplier_id = request.data.get('supplier_ids')

        if isinstance(supplier_id, list):
            supplier_id = supplier_id[0]

        supplier = PMSupplier.objects.filter(id=supplier_id).first() if supplier_id else None
        # Create new packaging material if it doesn't exist
        if not packaging_material:
            packaging_material_data = request.data.get('packaging_material_data')
            packaging_material_serializer = PackagingMaterialSerializer(data=packaging_material_data)
            if packaging_material_serializer.is_valid():
                packaging_material = packaging_material_serializer.save()
            else:
                return Response(packaging_material_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # If price is not specified, use old price if available
        if not price:
            price = packaging_material.price

        # Add packaging material to the product with the price
        ProductPackagingMaterial.objects.create(product=product, packaging_material=packaging_material, price=price, supplier=supplier)

        return Response({"message": "Packaging material added to product successfully."}, status=status.HTTP_200_OK)
    
    @action(detail=True, methods=['post'])
    def add_raw_material(self, request, pk=None):
        print(f"Product ID received: {pk}")
        queryset = Product.objects.all() 
        product = Product.objects.filter(id=pk).first()
        raw_material_id = request.data.get('raw_material_id')
        price = request.data.get('price', None)

        if not raw_material_id:
            return Response({"error": "Raw material ID is required."}, status=status.HTTP_400_BAD_REQUEST)

        # Fetch raw material
        raw_material = RawMaterial.objects.filter(id=raw_material_id).first()
        supplier_id = request.data.get('supplier_ids')

        if isinstance(supplier_id, list):
            supplier_id = supplier_id[0]
        supplier = RMSupplier.objects.filter(id=supplier_id).first() if supplier_id else None
        # Create new raw material if it doesn't exist
        if not raw_material:
            raw_material_data = request.data.get('raw_material_data')
            raw_material_serializer = RawMaterialSerializer(data=raw_material_data)
            if raw_material_serializer.is_valid():
                raw_material = raw_material_serializer.save()
            else:
                return Response(raw_material_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # If price is not specified, use old price if available
        if not price:
            price = raw_material.price

        # Add raw material to the product with the price
        ProductRawMaterial.objects.create(product=product, raw_material=raw_material, price=price, supplier=supplier)

        return Response({"message": "Raw material added to product successfully."}, status=status.HTTP_200_OK)

    def get_queryset(self):
        user = self.request.user
        case_id = self.request.query_params.get('case_id')
        if case_id:
            case = Case.objects.get(id=case_id)
            return Product.objects.filter(cases=case).distinct()

        return Product.objects.none()



    

class ProductListView(APIView):
    permission_classes = [IsAccountManager | IsBrandOwner]

    def get(self, request, case_id):
        try:
            if hasattr(request.user, 'brandowner'):
                case = Case.objects.get(id=case_id, brand_owner=request.user.brandowner)
                if case.product is None:
                    return Response(None, status=status.HTTP_200_OK)

                serializer = ProductSerializer(case.product, many=False)
            elif hasattr(request.user, 'am'):
                case = Case.objects.get(id=case_id)
                products = [case.product] if case.product is not None else []
                serializer = ProductSerializer(products, many=True)
            else:
                return Response({"error": "User role not supported"}, status=status.HTTP_403_FORBIDDEN)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Case.DoesNotExist:
            return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)



class CaseAnswersView(APIView):
    permission_classes = [IsAccountManager | IsBrandOwner]

    def get(self, request, case_id):
        try:
            # Fetch the case
            case = Case.objects.get(id=case_id)
            
            # Fetch all relevant questions
            questions = Question.objects.filter(is_case_specific=False, category=case.category)
            questions = questions | Question.objects.filter(case=case, is_case_specific=True, created_by_am=True)
            questions = questions.order_by('id')  # Ensure consistent ordering of questions

            # Fetch answers associated with the case, ordered by `order_index`
            answers = ChosenAnswer.objects.filter(case=case).order_by('order_index')

            # Serialize the questions and answers
            question_serializer = QuestionSerializer(questions, many=True)
            answer_serializer = ChosenAnswerSerializer(answers, many=True)

            # Combine questions and answers into a single structure
            combined_response = []
            for question in questions:
                # Find the corresponding answer for this question, if it exists
                answer = next((a for a in answers if a.question_id == question.id), None)

                # Add both question and answer to the response
                combined_response.append({
                    "question": {
                        "id": question.id,
                        "question_text": question.question_text,
                        "question_type": question.question_type,
                        "options": question.options.values("id", "option_text"),
                        "next_question": question.next_question_id
                    },
                    "answer": {
                        "id": answer.id if answer else None,
                        "answer_text": answer.answer_text if answer else None,
                        "selected_options": answer.selected_options.values("id", "option_text") if answer else [],
                        "answer_file": answer.answer_file.url if answer and answer.answer_file else None,
                        "order_index": answer.order_index if answer else None
                    }
                })

            return Response({"data": combined_response}, status=status.HTTP_200_OK)

        except Case.DoesNotExist:
            return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)


class SubmitAnswerView(APIView):
    def post(self, request, case_id):
        question_id = request.data.get('question_id')
        answer_text = request.data.get('answer_text')

        case = Case.objects.filter(id=case_id).first()
        if not case:
            return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)

        question = Question.objects.filter(id=question_id, case=case).first()
        if not question:
            return Response({"error": "Question not found"}, status=status.HTTP_404_NOT_FOUND)

        # Store the answer
        ChosenAnswer.objects.create(
            case=case,
            question=question,
            answer_text=answer_text
        )

        return Response({"message": "Answer submitted successfully"}, status=status.HTTP_201_CREATED)
    

# class CaseSpecificQuestionsView(APIView):
#     def get(self, request, case_id):
#         case = Case.objects.filter(id=case_id).first()
#         if not case:
#             return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)

#         # Fetch questions specific to the case
#         case_specific_questions = Question.objects.filter(case=case, is_case_specific=True, created_by_am=True)
#         serializer = QuestionSerializer(case_specific_questions, many=True)
        
#         return Response({"questions": serializer.data}, status=status.HTTP_200_OK)


class CaseSpecificQuestionsView(APIView):
    """
    Returns all unanswered case-specific questions added by an Account Manager for the given case.
    """
    def get(self, request, case_id):


        if hasattr(request.user,'am'):
            case = Case.objects.filter(id=case_id).first()
            if not case:
                return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)

            # Fetch questions specific to the case
            case_specific_questions = Question.objects.filter(case=case, is_case_specific=True, created_by_am=True)
            serializer = QuestionSerializer(case_specific_questions, many=True)
            
            return Response({"questions": serializer.data}, status=status.HTTP_200_OK)



        elif hasattr(request.user,'brandowner'):

            # 1. Validate the case
            case = Case.objects.filter(id=case_id).first()
            if not case:
                return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)

            # 2. Fetch IDs of questions that have already been answered by this brand owner for this case
            answered_question_ids = ChosenAnswer.objects.filter(
                case=case,
                brand_owner=request.user.brandowner
            ).values_list('question_id', flat=True)

            # 3. Fetch only the questions that are:
            #    - specific to this case,
            #    - created by AM,
            #    - NOT already answered by the brand owner
            unanswered_case_specific_questions = Question.objects.filter(
                case=case,
                is_case_specific=True,
                created_by_am=True
            ).exclude(id__in=answered_question_ids)

            # 4. Serialize and return
            serializer = QuestionSerializer(unanswered_case_specific_questions, many=True)
            return Response({"questions": serializer.data}, status=status.HTTP_200_OK)

    

class SubmitCaseSpecificAnswerView(APIView):
    permission_classes = [IsBrandOwner]

    def post(self, request):
        case_id = request.data.get("case_id")
        question_id = request.data.get("question_id")
        answer_text = request.data.get("answer_text")

        case = Case.objects.filter(id=case_id).first()
        if not case:
            return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)

        question = Question.objects.filter(id=question_id, case=case, is_case_specific=True, created_by_am=True).first()
        if not question:
            return Response({"error": "Question not found"}, status=status.HTTP_404_NOT_FOUND)

        # Save the answer
        chosen_answer = ChosenAnswer.objects.create(
            brand_owner=request.user.brandowner,
            case=case,
            question=question,
            answer_text=answer_text,
            is_case_specific=True
        )
        chosen_answer.save()

        return Response({"message": "Answer submitted successfully."}, status=status.HTTP_201_CREATED)

    
class AddCaseSpecificQuestionView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request):
        case_id = request.data.get("case_id")
        question_text = request.data.get("question_text")
        question_type = request.data.get("question_type", "SA")  # Default to Short Answer (SA)

        case = Case.objects.filter(id=case_id).first()
        if not case:
            return Response({"error": "Case not found"}, status=status.HTTP_404_NOT_FOUND)

        # Create the case-specific question added by Account Manager
        question = Question.objects.create(
            question_text=question_text,
            question_type=question_type,
            is_case_specific=True,
            created_by_am=True,
            case=case,
            category=case.category
        )
        question.save()

        serializer = QuestionSerializer(question)
        return Response({"question": serializer.data}, status=status.HTTP_201_CREATED)
    
from rest_framework.permissions import AllowAny
    
class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]



class SubcategoryViewSet(viewsets.ModelViewSet):
    permission_classes = [AllowAny]
    queryset = Subcategory.objects.all()
    serializer_class = SubcategorySerializer

    def get_queryset(self):
        queryset = self.queryset
        request = self.request

        # 1. Multiple categories via ?categories=1,2,3
        categories_param = request.query_params.get('categories')
        if categories_param:
            try:
                category_ids = [int(cid.strip()) for cid in categories_param.split(',')]
                return queryset.filter(category_id__in=category_ids)
            except ValueError:
                return Subcategory.objects.none()

        # 2. Single category via ?category= (id or slug or name)
        category_param = request.query_params.get('category')
        if category_param:
            try:
                category_id = int(category_param)
                return queryset.filter(category_id=category_id)
            except ValueError:
                category = Category.objects.filter(slug__iexact=category_param).first() \
                        or Category.objects.filter(name__iexact=category_param).first()

                if category:
                    return queryset.filter(category_id=category.id)
                else:
                    return Subcategory.objects.none()

        # 3. Default: return all
        return queryset



class SubcategoryFactoriesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, slug):
        try:
            subcat = Subcategory.objects.get(slug=slug)
        except Subcategory.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)

        factories = subcat.factories.all()
        category_name = subcat.category.name if subcat.category else 'Unknown Category'
        
        return Response({
            'id': subcat.id,
            'name': subcat.name,
            'slug': subcat.slug,
            'description': subcat.description,
            'image': subcat.image.url if subcat.image else None,
            'category_name': category_name,
            'keywords': subcat.keywords,
            'factories': PublicFactorySerializer(factories, many=True).data
        })
  

class SubcategoryCasesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, slug):
        try:
            subcat = Subcategory.objects.get(slug=slug)
        except Subcategory.DoesNotExist:
            return Response({'error': 'Subcategory not found'}, status=404)

        # Step 1: Get all products with this subcategory
        products = Product.objects.filter(subcategory=subcat).prefetch_related('cases')

        # Step 2: Collect all unique cases linked to those products
        case_set = set()
        for product in products:
            case_set.update(product.cases.all())

        cases = list(case_set)  # Convert back to list for serialization
        factory_selection_stage = Stage.objects.filter(order=0).first()
                # Start from a queryset built from the collected IDs
        cases_qs = Case.objects.filter(id__in=[c.id for c in case_set])

        if factory_selection_stage:
            cases_qs = cases_qs.filter(
                progress_stages__stage=factory_selection_stage,
                progress_stages__completion_date__isnull=False,
                factory__isnull=True,
            ).distinct()
        else:
            # If stage not configured, avoid failing the page; return none
            cases_qs = Case.objects.none()
        category_name = subcat.category.name if subcat.category else 'Unknown Category'

        return Response({
            'id': subcat.id,
            'name': subcat.name,
            'slug': subcat.slug,
            'description': subcat.description,
            'category_name': category_name,
            'keywords': subcat.keywords,
            'image': subcat.image.url if subcat.image else None,
            'cases': PublicCaseSerializer(cases_qs, many=True).data
        })
    
class CategoryFactoriesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, slug):
        try:
            category = Category.objects.get(slug=slug)
        except Category.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)

        subcats = Subcategory.objects.filter(category=category)
        factory_set = set()
        for subcat in subcats:
            factory_set.update(subcat.factories.all())

        return Response({
            'id': category.id,
            'name': category.name,
            'slug': category.slug,
            'description': category.description,
            'keywords': category.keywords,
            'image': category.image.url if category.image else None,
            'factories': PublicFactorySerializer(factory_set, many=True).data
        })

class CategoryCasesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, slug):
        try:
            category = Category.objects.get(slug=slug)
        except Category.DoesNotExist:
            return Response({'error': 'Category not found'}, status=404)

        # Step 1: Get all subcategories under this category
        subcategories = Subcategory.objects.filter(category=category)

        # Step 2: Get all products under these subcategories
        products = Product.objects.filter(subcategory__in=subcategories).prefetch_related('cases')

        # Step 3: Aggregate all unique cases from those products
        case_set = set()
        for product in products:
            case_set.update(product.cases.all())
        factory_selection_stage = Stage.objects.filter(order=0).first()
                # Start from a queryset built from the collected IDs
        cases_qs = Case.objects.filter(id__in=[c.id for c in case_set])

        if factory_selection_stage:
            cases_qs = cases_qs.filter(
                progress_stages__stage=factory_selection_stage,
                progress_stages__completion_date__isnull=False,
                factory__isnull=True,
            ).distinct()
        else:
            # If stage not configured, avoid failing the page; return none
            cases_qs = Case.objects.none()
        return Response({
            'id': category.id,
            'name': category.name,
            'slug': category.slug,
            'description': category.description,
            'keywords': category.keywords,
            'image': category.image.url if category.image else None,
            'cases': PublicCaseSerializer(cases_qs, many=True).data
        })

class PublicSubcategoryListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        subcategories = Subcategory.objects.all()
        serializer = PublicSubcategorySerializer(subcategories, many=True)
        return Response(serializer.data)
    

class AllFactoriesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        from supply.models import Factory  # replace with actual path
        from supply.serializers_public import PublicFactorySerializer  # replace with actual path

        factories = Factory.objects.all()
        serializer = PublicFactorySerializer(factories, many=True)
        return Response(serializer.data)
    
class AllCasesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        from case.models import Case  # replace with actual path
        from case.serializers_public import PublicCaseSerializer  # replace with actual path

        cases = Case.objects.all()
        serializer = PublicCaseSerializer(cases, many=True)
        return Response(serializer.data)


class PublicFaoudProductsView(APIView):
    """
    Public endpoint to fetch all Faoud marketplace products.
    No authentication required.
    """
    permission_classes = [AllowAny]

    def get(self, request):
        # Get all original Faoud products
        products = Product.objects.filter(
            isFaoud_Product=True,
            is_original=True
        ).select_related('category', 'subcategory').order_by('-created_at')
        
        # Filter by category if provided
        category_slug = request.query_params.get('category')
        if category_slug:
            products = products.filter(category__slug=category_slug)
        
        # Filter by subcategory if provided
        subcategory_slug = request.query_params.get('subcategory')
        if subcategory_slug:
            products = products.filter(subcategory__slug=subcategory_slug)
        
        # Search by name
        search = request.query_params.get('search')
        if search:
            products = products.filter(name__icontains=search)
        
        serializer = PublicProductSerializer(products, many=True)
        return Response(serializer.data)



from collections import defaultdict
from django.db.models import Count
from django.db.models.signals import post_save

class PublicCategoryTreeView(APIView):
    """
    Returns:
    [
      {
        "id": ...,
        "name": ...,
        "slug": ...,
        "description": ...,
        "image": ...,
        "factoryCount": <int>,         # factories linked to this category
        "orderCount": <int>,           # cases linked to any subcategory in this category
        "subcategories": [
          {
            "id": ...,
            "name": ...,
            "slug": ...,
            "image": ...,
            "factoryCount": <int>,     # factories linked to this subcategory
            "orderCount": <int>        # cases linked to this subcategory
          },
          ...
        ]
      },
      ...
    ]
    """
    permission_classes = [AllowAny]

    def get(self, request):
        # ---- BASE DATA ----
        categories = list(
            Category.objects.only("id", "name", "slug", "description", "image")
        )
        subcats = list(
            Subcategory.objects.select_related("category")
                .only("id", "name", "slug", "image", "category_id")
        )

        # ---- AGGREGATIONS (done in bulk; no N+1) ----
        # Factories per Category (via Factory.categories M2M)
        cat_factory_counts = {
            row["categories"]: row["cnt"]
            for row in Factory.objects.values("categories").annotate(cnt=Count("id", distinct=True))
            if row["categories"] is not None
        }

        # Factories per Subcategory (via Factory.subcategories M2M)
        subcat_factory_counts = {
            row["subcategories"]: row["cnt"]
            for row in Factory.objects.values("subcategories").annotate(cnt=Count("id", distinct=True))
            if row["subcategories"] is not None
        }

        # Orders (live Cases) per Category/Subcategory using real product links (FK + M2M)
        # Build de-duplicated pairs of (bucket_id, case_id) in Python to avoid double counting.
        # --- Subcategory pairs ---
        subcat_pairs = list(Case.objects.filter(
            active=0,  # only live cases
            product__subcategory__isnull=False,
        ).values_list("product__subcategory", "id"))

        subcat_pairs += list(Case.objects.filter(
            active=0,
            products__subcategory__isnull=False,
        ).values_list("products__subcategory", "id"))

        subcat_to_cases = defaultdict(set)
        for sc_id, case_id in subcat_pairs:
            if sc_id is not None and case_id is not None:
                subcat_to_cases[sc_id].add(case_id)

        subcat_order_counts = {sc_id: len(case_ids) for sc_id, case_ids in subcat_to_cases.items()}

        # --- Category pairs ---
        cat_pairs = list(Case.objects.filter(
            active=0,
            product__subcategory__category__isnull=False,
        ).values_list("product__subcategory__category", "id"))

        cat_pairs += list(Case.objects.filter(
            active=0,
            products__subcategory__category__isnull=False,
        ).values_list("products__subcategory__category", "id"))

        cat_to_cases = defaultdict(set)
        for cat_id, case_id in cat_pairs:
            if cat_id is not None and case_id is not None:
                cat_to_cases[cat_id].add(case_id)

        cat_order_counts = {cat_id: len(case_ids) for cat_id, case_ids in cat_to_cases.items()}

        # ---- GROUP SUBCATS BY CATEGORY ----
        subcats_by_cat = defaultdict(list)
        for sc in subcats:
            subcats_by_cat[sc.category_id].append(sc)

        # ---- SHAPE RESPONSE ----
        payload = []
        for c in categories:
            subcat_items = []
            for sc in subcats_by_cat.get(c.id, []):
                subcat_items.append({
                    "id": sc.id,
                    "name": sc.name,
                    "slug": sc.slug,
                    "image": (sc.image.url if getattr(sc, "image", None) else None),
                    "factoryCount": int(subcat_factory_counts.get(sc.id, 0)),
                    "orderCount": int(subcat_order_counts.get(sc.id, 0)),
                })

            payload.append({
                "id": c.id,
                "name": c.name,
                "slug": c.slug,
                "description": c.description if c.description else "",
                "image": (c.image.url if getattr(c, "image", None) else None),
                "factoryCount": int(cat_factory_counts.get(c.id, 0)),
                "orderCount": int(cat_order_counts.get(c.id, 0)),
                "subcategories": subcat_items,
            })
        # --- Sort logic (default: highest factoryCount first) ---
        sort_key = request.query_params.get("sort", "factory").lower()
        if sort_key == "orders":
            payload.sort(key=lambda x: x["orderCount"], reverse=True)
        elif sort_key == "combined":
            payload.sort(key=lambda x: (x["factoryCount"] + x["orderCount"]), reverse=True)
        else:  # "factory" or unknown
            payload.sort(key=lambda x: x["factoryCount"], reverse=True)

        return Response(payload)


class FaoudProductViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing Faoud marketplace products.
    Brand Owners can view (list, retrieve).
    Only Account Managers can create, update, and delete Faoud products.
    """
    serializer_class = None  # Will be set dynamically
    permission_classes = [IsAuthenticated]

    def get_permissions(self):
        """
        Brand Owners can only read (list, retrieve).
        Account Managers can perform all actions.
        """
        from user.permissions import IsAccountManager
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsAccountManager()]
        return [IsAuthenticated()]

    def get_queryset(self):
        """
        Return only Faoud products (isFaoud_Product=True).
        By default, only show original products (is_original=True) for marketplace.
        Use ?show_all=true to see all Faoud products including copies.
        """
        # Base filter: only Faoud products
        queryset = Product.objects.filter(isFaoud_Product=True).select_related(
            'category', 'subcategory', 'product_group'
        ).prefetch_related(
            'productrawmaterial_set__raw_material',
            'productpackagingmaterial_set__packaging_material',
            'documents'
        )

        # By default, show only original marketplace products
        show_all = self.request.query_params.get('show_all', 'false').lower() == 'true'
        if not show_all:
            queryset = queryset.filter(is_original=True)
        
        queryset = queryset.order_by('-created_at')

        # Filter by category if provided
        category_id = self.request.query_params.get('category')
        if category_id:
            queryset = queryset.filter(category_id=category_id)

        # Filter by subcategory if provided
        subcategory_id = self.request.query_params.get('subcategory')
        if subcategory_id:
            queryset = queryset.filter(subcategory_id=subcategory_id)

        # Search by name
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(name__icontains=search)

        return queryset

    def get_serializer_class(self):
        """
        Use FaoudProductSerializer for all actions.
        """
        from .serializers import FaoudProductSerializer
        return FaoudProductSerializer

    def create(self, request, *args, **kwargs):
        """
        Create a new Faoud product.
        """
        try:
            # Handle file upload
            picture = request.FILES.get('picture', None)
            
            # Prepare data
            data = request.data.copy()
            
            # Get category and subcategory
            category_id = data.get('category')
            subcategory_id = data.get('subcategory')

            if not category_id or not subcategory_id:
                return Response(
                    {"error": "Category and subcategory are required."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Validate category and subcategory exist
            from .models import Category, Subcategory
            category = Category.objects.filter(id=category_id).first()
            subcategory = Subcategory.objects.filter(id=subcategory_id, category=category).first()

            if not category or not subcategory:
                return Response(
                    {"error": "Invalid category or subcategory."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Create serializer
            serializer = self.get_serializer(data=data)
            serializer.is_valid(raise_exception=True)
            
            # Save the product
            product = serializer.save(picture=picture)

            # Handle document uploads if provided
            documents_data = request.data.get('documents', '[]')
            if isinstance(documents_data, str):
                try:
                    import json
                    documents_data = json.loads(documents_data)
                except json.JSONDecodeError:
                    documents_data = []

            if documents_data:
                for document in documents_data:
                    document_name = document.get('name')
                    document_file = document.get('link')
                    if document_name and document_file:
                        ProductDocument.objects.create(
                            product=product,
                            name=document_name,
                            file=document_file
                        )

            headers = self.get_success_headers(serializer.data)
            return Response(
                {
                    "message": "Faoud product created successfully.",
                    "product": serializer.data
                },
                status=status.HTTP_201_CREATED,
                headers=headers
            )
        except Exception as e:
            return Response(
                {"error": f"Failed to create product: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def update(self, request, *args, **kwargs):
        """
        Update an existing Faoud product.
        """
        partial = kwargs.pop('partial', False)
        instance = self.get_object()

        # Ensure it's a Faoud product
        if not instance.isFaoud_Product:
            return Response(
                {"error": "This is not a Faoud product. Cannot update using this endpoint."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Handle picture update
        picture = request.FILES.get('picture', None)
        
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        
        # Save with picture if provided
        if picture:
            product = serializer.save(picture=picture)
        else:
            product = serializer.save()

        # Handle document updates if provided
        documents_data = request.data.get('documents', '[]')
        if isinstance(documents_data, str):
            try:
                import json
                documents_data = json.loads(documents_data)
            except json.JSONDecodeError:
                documents_data = []

        if documents_data:
            for document in documents_data:
                document_name = document.get('name')
                document_file = request.FILES.get(f"file_{document_name}")
                if document_name and document_file:
                    ProductDocument.objects.create(
                        product=product,
                        name=document_name,
                        file=document_file
                    )

        return Response({
            "message": "Faoud product updated successfully.",
            "product": serializer.data
        })

    def destroy(self, request, *args, **kwargs):
        """
        Delete a Faoud product.
        Check if it's linked to any cases before deleting.
        """
        instance = self.get_object()

        # Ensure it's a Faoud product
        if not instance.isFaoud_Product:
            return Response(
                {"error": "This is not a Faoud product. Cannot delete using this endpoint."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Check if product is linked to any cases
        if instance.cases.exists():
            return Response(
                {
                    "error": "Cannot delete this Faoud product as it is linked to one or more cases.",
                    "linked_cases": list(instance.cases.values_list('id', flat=True))
                },
                status=status.HTTP_400_BAD_REQUEST
            )

        # Delete the product
        product_name = instance.name
        instance.delete()

        return Response(
            {"message": f"Faoud product '{product_name}' deleted successfully."},
            status=status.HTTP_204_NO_CONTENT
        )

    def list(self, request, *args, **kwargs):
        """
        List all Faoud products with optional filtering.
        """
        queryset = self.get_queryset()
        page = self.paginate_queryset(queryset)
        
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = self.get_serializer(queryset, many=True)
        return Response({
            "count": queryset.count(),
            "results": serializer.data
        })

    def retrieve(self, request, *args, **kwargs):
        """
        Retrieve a specific Faoud product.
        """
        instance = self.get_object()
        
        if not instance.isFaoud_Product:
            return Response(
                {"error": "This is not a Faoud product."},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = self.get_serializer(instance)
        return Response(serializer.data)


class ProductGroupViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for viewing product groups and their versions.
    Read-only - groups are managed automatically through product operations.
    """
    from .serializers import ProductGroupSerializer
    serializer_class = ProductGroupSerializer
    permission_classes = [IsAuthenticated]
    lookup_field = 'group_identifier'

    def get_queryset(self):
        from .models import ProductGroup
        return ProductGroup.objects.all().select_related(
            'original_product__category',
            'original_product__subcategory'
        ).prefetch_related(
            'products__category',
            'products__subcategory',
            'products__created_from_case'
        ).order_by('-created_at')
    
    def get_serializer_class(self):
        from .serializers import ProductGroupSerializer
        return ProductGroupSerializer
