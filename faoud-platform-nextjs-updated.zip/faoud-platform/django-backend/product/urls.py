from django.urls import include, path
from .views import (
    AddCaseSpecificQuestionView, AllCasesView, AllFactoriesView, CaseAnswersView,
    CaseSpecificQuestionsView, CategoryCasesView, CategoryFactoriesView, CategoryViewSet,
    FaoudProductViewSet, ProductGroupViewSet, ProductListView, ProductViewSet, 
    PublicCategoryTreeView, PublicFaoudProductsView, PublicSubcategoryListView, QuestionView, SubcategoryCasesView, 
    SubcategoryFactoriesView, SubcategoryViewSet, SubmitAnswerView, SubmitCaseSpecificAnswerView
)
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r'products', ProductViewSet, basename='product')
router.register(r'categories', CategoryViewSet)
router.register(r'subcategories', SubcategoryViewSet)
router.register(r'faoud-products', FaoudProductViewSet, basename='faoud-product')
router.register(r'product-groups', ProductGroupViewSet, basename='product-group')

urlpatterns = [
    path("question/newcase/", QuestionView.as_view({"post": "newCase"})),
    path("question/chooseanswer/", QuestionView.as_view({"post": "chooseAnswer"})),
    path("question/continuecase/", QuestionView.as_view({"get": "continueCase"})),
    path("question/chooseservice/", QuestionView.as_view({"post": "chooseService"})),
    path("product/create/", ProductViewSet.as_view({"post": "create"}), name="product-create"),
    path('cases/<int:case_id>/products/', ProductListView.as_view(), name='product-list'),
    path('cases/<int:case_id>/answers/', CaseAnswersView.as_view(), name='case-answers'),
    path('cases/add-specific-question/', AddCaseSpecificQuestionView.as_view(), name='add-case-specific-question'),

    path("question/list/", QuestionView.as_view({"get": "listQuestions"})),
    path("question/<int:pk>/", QuestionView.as_view({"get": "retrieve"})),
    path("question/submitanswers/", QuestionView.as_view({"post": "submitAnswers"})),


    # API to fetch case-specific questions
    path('cases/<int:case_id>/specific-questions/', CaseSpecificQuestionsView.as_view(), name='case-specific-questions'),

    # API to submit answers for case-specific questions
    path('cases/submit-specific-answer/', SubmitCaseSpecificAnswerView.as_view(), name='submit-case-specific-answer'),

    path('', include(router.urls)),
    path('subcategory/<slug:slug>/factories/', SubcategoryFactoriesView.as_view(), name='subcategory-factories'),
    path('subcategory/<slug:slug>/cases/', SubcategoryCasesView.as_view(), name='subcategory-cases'),
    path('category/<slug:slug>/factories/', CategoryFactoriesView.as_view(), name='category-factories'),
    path('category/<slug:slug>/cases/', CategoryCasesView.as_view(), name='category-cases'),
    path("public-subcategories/", PublicSubcategoryListView.as_view(), name="public-subcategories"),


    path('public-factories/', AllFactoriesView.as_view(), name='all-factories'),
    path('public-cases/', AllCasesView.as_view(), name='all-cases'),
    path("public/categories/", PublicCategoryTreeView.as_view(), name="public-categories"),
    path("public/products/", PublicFaoudProductsView.as_view(), name="public-products"),
]

