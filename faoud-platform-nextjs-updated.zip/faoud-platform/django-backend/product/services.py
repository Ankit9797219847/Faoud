"""
Product Cloning and Versioning Services

This module handles the core business logic for:
- Creating product groups
- Cloning Faoud products for cases
- Managing product versions
- Handling product relationships (materials, documents)
"""

from django.db import transaction
from django.core.files.base import ContentFile
from .models import (
    Product, ProductGroup, ProductRawMaterial, 
    ProductPackagingMaterial, ProductDocument
)
import logging

logger = logging.getLogger(__name__)


class ProductGroupService:
    """Service for managing product groups"""
    
    @staticmethod
    def create_product_group(original_product):
        """
        Create a new ProductGroup for an original Faoud product.
        
        Args:
            original_product (Product): The original Faoud marketplace product
            
        Returns:
            ProductGroup: The created product group
        """
        if not original_product.isFaoud_Product:
            raise ValueError("Only Faoud products can have product groups created")
        
        # Check if product already has a group
        if original_product.product_group:
            return original_product.product_group

        product_type = None
        if getattr(original_product, "category", None):
            product_type = original_product.category.name

        group = ProductGroup.objects.create(
            name=original_product.name,
            product_type=product_type,
            last_version_number=1,
            original_product=original_product,
        )
        
        # Link the original product to the group
        original_product.product_group = group
        original_product.is_original = True
        original_product.version_number = 1
        original_product.save(update_fields=['product_group', 'is_original', 'version_number'])
        
        logger.info(f"Created ProductGroup {group.id} for product {original_product.id}")
        return group

    @staticmethod
    def create_group_for_product(product, created_by=None):
        """
        Create a ProductGroup for any product that currently has no group.
        Naming follows the internal nomenclature: "<product.name> - PG-<product.id>".
        The created group will link back to the product when appropriate.
        """
        if product.product_group:
            return product.product_group

        # Build a sensible name following nomenclature
        group_name = f"{product.name} - PG-{product.id}"

        product_type = None
        try:
            if getattr(product, 'category', None):
                product_type = product.category.name
        except Exception:
            product_type = None

        group = ProductGroup.objects.create(
            name=group_name,
            product_type=product_type,
            last_version_number=product.version_number or 1,
            original_product=product if getattr(product, 'isFaoud_Product', False) else None,
            created_by=created_by
        )

        # Link the product to the newly created group and ensure version fields
        product.product_group = group
        # If this product looks like an original (faoud), mark as original, otherwise keep current flag
        if getattr(product, 'isFaoud_Product', False):
            product.is_original = True
        if not getattr(product, 'version_number', None):
            product.version_number = 1
        product.save(update_fields=['product_group', 'is_original', 'version_number'])

        logger.info(f"Auto-created ProductGroup {group.id} for product {product.id}")
        return group
    
    @staticmethod
    def get_products_in_group(product_group_id):
        """
        Fetch all products belonging to a group.
        
        Args:
            product_group_id (int): ID of the product group
            
        Returns:
            QuerySet: Products ordered by version_number
        """
        return Product.objects.filter(
            product_group_id=product_group_id
        ).select_related(
            'category', 'subcategory', 'parent_product', 'created_from_case'
        ).order_by('version_number')
    
    @staticmethod
    def get_next_version_number(product_group):
        """
        Calculate the next version number in a group.
        
        Args:
            product_group (ProductGroup): The product group
            
        Returns:
            int: Next version number
        """
        return product_group.get_latest_version_number() + 1


class ProductCloningService:
    """Service for cloning products"""
    
    @staticmethod
    @transaction.atomic
    def clone_product_for_case(original_product, case, created_by_user=None):
        """
        Create a deep copy of a Faoud product for case assignment.
        
        This function:
        - Copies all product fields
        - Copies raw materials with prices and suppliers
        - Copies packaging materials with prices and suppliers
        - Copies product documents
        - Sets isFaoud_Product=False (not a marketplace product)
        - Links to ProductGroup
        - Sets appropriate version number
        
        Args:
            original_product (Product): The Faoud product to clone
            case (Case): The case to assign the clone to
            created_by_user (User, optional): The user creating the clone
            
        Returns:
            Product: The cloned product instance
        """
        # Validation
        if not original_product.isFaoud_Product:
            raise ValueError("Only Faoud products can be cloned for cases")
        
        # Ensure the original product has a group
        if not original_product.product_group:
            product_group = ProductGroupService.create_product_group(original_product)
        else:
            product_group = original_product.product_group
        
        # Get next version number
        next_version = ProductGroupService.get_next_version_number(product_group)
        
        # Clone the product
        cloned_product = Product(
            name=original_product.name,
            sku_and_pm=original_product.sku_and_pm,
            quantity=original_product.quantity,
            eta=original_product.eta,
            stages=original_product.stages,
            brand=original_product.brand,
            category=original_product.category,
            subcategory=original_product.subcategory,
            benchmark=original_product.benchmark,
            # Versioning fields
            product_group=product_group,
            version_number=next_version,
            is_original=False,
            isFaoud_Product=False,  # Case-specific product, not marketplace
            parent_product=original_product,
            created_from_case=case,
            modification_notes=f"Cloned from {original_product.name} for case {case.id}"
        )
        
        # Handle picture cloning
        if original_product.picture:
            try:
                cloned_product.picture.save(
                    original_product.picture.name,
                    ContentFile(original_product.picture.read()),
                    save=False
                )
            except Exception as e:
                logger.warning(f"Failed to clone picture for product {original_product.id}: {e}")
        
        cloned_product.save()

        if product_group.last_version_number < next_version:
            product_group.last_version_number = next_version
            product_group.save(update_fields=["last_version_number"])

        logger.info(f"Cloned product {original_product.id} -> {cloned_product.id} for case {case.id}")
        
        # Copy raw materials with prices
        ProductCloningService._copy_raw_materials(original_product, cloned_product)
        
        # Copy packaging materials with prices
        ProductCloningService._copy_packaging_materials(original_product, cloned_product)
        
        # Copy documents
        ProductCloningService._copy_documents(original_product, cloned_product)
        
        # Copy many-to-many relationships (briefs, formulations)
        cloned_product.briefs.set(original_product.briefs.all())
        cloned_product.formulations.set(original_product.formulations.all())
        
        return cloned_product
    
    @staticmethod
    def _copy_raw_materials(source_product, target_product):
        """Copy raw materials with their prices and suppliers"""
        raw_materials = ProductRawMaterial.objects.filter(product=source_product)
        
        for rm in raw_materials:
            ProductRawMaterial.objects.create(
                product=target_product,
                raw_material=rm.raw_material,
                price=rm.price,
                supplier=rm.supplier
            )
        
        logger.info(f"Copied {raw_materials.count()} raw materials to product {target_product.id}")
    
    @staticmethod
    def _copy_packaging_materials(source_product, target_product):
        """Copy packaging materials with their prices and suppliers"""
        packaging_materials = ProductPackagingMaterial.objects.filter(product=source_product)
        
        for pm in packaging_materials:
            ProductPackagingMaterial.objects.create(
                product=target_product,
                packaging_material=pm.packaging_material,
                price=pm.price,
                supplier=pm.supplier
            )
        
        logger.info(f"Copied {packaging_materials.count()} packaging materials to product {target_product.id}")
    
    @staticmethod
    def _copy_documents(source_product, target_product):
        """Copy product documents"""
        documents = ProductDocument.objects.filter(product=source_product)
        
        for doc in documents:
            try:
                ProductDocument.objects.create(
                    product=target_product,
                    name=doc.name,
                    file=doc.file  # This will reference the same file
                )
            except Exception as e:
                logger.warning(f"Failed to copy document {doc.id}: {e}")
        
        logger.info(f"Copied {documents.count()} documents to product {target_product.id}")
    
    @staticmethod
    @transaction.atomic
    def create_edited_version(existing_product, case, updated_data, user=None):
        """
        Create a new version when an Account Manager edits an assigned product.
        
        This maintains the product group lineage while allowing modifications.
        
        Args:
            existing_product (Product): The current product to edit
            case (Case): The case this product belongs to
            updated_data (dict): Fields to update in the new version
            user (User, optional): The user making the edit
            
        Returns:
            Product: New product version with updates applied
        """
        # Validation
        if existing_product.is_original and existing_product.isFaoud_Product:
            raise ValueError("Cannot edit original Faoud marketplace products. Clone first.")
        
        # Ensure the product belongs to a group; create one on-demand if missing
        if not existing_product.product_group:
            product_group = ProductGroupService.create_group_for_product(existing_product, created_by=user)
        else:
            product_group = existing_product.product_group
        
        # Get next version number
        next_version = ProductGroupService.get_next_version_number(product_group)
        
        # Create new version
        new_version = Product(
            name=updated_data.get('name', existing_product.name),
            sku_and_pm=updated_data.get('sku_and_pm', existing_product.sku_and_pm),
            quantity=updated_data.get('quantity', existing_product.quantity),
            eta=updated_data.get('eta', existing_product.eta),
            stages=updated_data.get('stages', existing_product.stages),
            brand=existing_product.brand,
            category=updated_data.get('category', existing_product.category),
            subcategory=updated_data.get('subcategory', existing_product.subcategory),
            benchmark=updated_data.get('benchmark', existing_product.benchmark),
            # Versioning fields
            product_group=product_group,
            version_number=next_version,
            is_original=False,
            isFaoud_Product=False,
            parent_product=existing_product,
            created_from_case=case,
            modification_notes=updated_data.get('modification_notes', f"Edited version of v{existing_product.version_number}")
        )
        
        # Handle picture update
        if 'picture' in updated_data and updated_data['picture']:
            new_version.picture = updated_data['picture']
        elif existing_product.picture:
            try:
                new_version.picture.save(
                    existing_product.picture.name,
                    ContentFile(existing_product.picture.read()),
                    save=False
                )
            except Exception as e:
                logger.warning(f"Failed to clone picture: {e}")
        
        new_version.save()
        logger.info(f"Created edited version {new_version.id} (v{next_version}) from product {existing_product.id}")
        
        # Copy materials (or use updated ones if provided)
        if 'raw_materials' in updated_data:
            # Handle custom raw materials update
            for rm_data in updated_data['raw_materials']:
                ProductRawMaterial.objects.create(
                    product=new_version,
                    raw_material_id=rm_data['raw_material_id'],
                    price=rm_data['price'],
                    supplier_id=rm_data.get('supplier_id')
                )
        else:
            ProductCloningService._copy_raw_materials(existing_product, new_version)
        
        if 'packaging_materials' in updated_data:
            # Handle custom packaging materials update
            for pm_data in updated_data['packaging_materials']:
                ProductPackagingMaterial.objects.create(
                    product=new_version,
                    packaging_material_id=pm_data['packaging_material_id'],
                    price=pm_data['price'],
                    supplier_id=pm_data.get('supplier_id')
                )
        else:
            ProductCloningService._copy_packaging_materials(existing_product, new_version)
        
        # Copy documents
        ProductCloningService._copy_documents(existing_product, new_version)
        
        # Copy many-to-many relationships
        new_version.briefs.set(existing_product.briefs.all())
        new_version.formulations.set(existing_product.formulations.all())
        
        return new_version


class ProductVersionValidator:
    """Validation utilities for product versioning"""
    
    @staticmethod
    def validate_product_for_cloning(product):
        """
        Ensure product can be cloned.
        
        Args:
            product (Product): Product to validate
            
        Returns:
            tuple: (is_valid, error_message)
        """
        if not product.isFaoud_Product:
            return False, "Only Faoud marketplace products can be cloned"
        
        if not product.category or not product.subcategory:
            return False, "Product must have category and subcategory"
        
        return True, None
    
    @staticmethod
    def validate_product_for_editing(product):
        """
        Ensure product can be edited to create a new version.

        Note: product groups are now created on-demand when needed, so lack of
        a product_group is no longer a hard validation failure here.
        """
        if product.is_original and product.isFaoud_Product:
            return False, "Cannot edit original Faoud marketplace products directly"
        
        # Allow editing even if product.product_group is None; service will create a group when necessary
        return True, None
