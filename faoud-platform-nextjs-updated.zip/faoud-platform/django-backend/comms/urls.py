from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ChatMessageViewSet, ChatPermissionUpdateView

router = DefaultRouter()
router.register(r'chat', ChatMessageViewSet, basename='chat')

urlpatterns = [
    # ... other URLs ...
    path('', include(router.urls)),
    path('cases/<int:case_id>/chat-permission/', ChatPermissionUpdateView.as_view(), name='chat-permission-update'),

]
