from django.contrib import admin

from comms.models import ChatMessage, ChatPermission


admin.site.register(ChatMessage)
admin.site.register(ChatPermission)

