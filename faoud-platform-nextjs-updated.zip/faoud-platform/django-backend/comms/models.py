from django.db import models
from django.contrib.auth.models import User

from case.models import Case



class ChatMessage(models.Model):
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    recipients = models.ManyToManyField(User, related_name='received_messages', blank=True)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Message from {self.sender} in Case {self.case.id}"

class ChatMessageReadReceipt(models.Model):
    message = models.ForeignKey(ChatMessage, on_delete=models.CASCADE, related_name='read_receipts')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='read_receipts')
    read_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Read Receipt: {self.user} read message {self.message.id} at {self.read_at}"

class ChatPermission(models.Model):
    case = models.OneToOneField(Case, on_delete=models.CASCADE, related_name='chat_permission')
    bo_can_message_fo = models.BooleanField(default=True)

    def __str__(self):
        return f"Chat Permission for Case {self.case.id}"
