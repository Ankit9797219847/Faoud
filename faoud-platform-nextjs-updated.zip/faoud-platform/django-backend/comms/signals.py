# In your comms/signals.py
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Case, ChatPermission

@receiver(post_save, sender=Case)
def create_chat_permission(sender, instance, created, **kwargs):
    if created:
        ChatPermission.objects.create(case=instance)
