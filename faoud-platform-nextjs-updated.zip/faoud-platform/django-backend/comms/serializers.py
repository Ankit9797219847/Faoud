from rest_framework import serializers

from comms.models import ChatMessage

# comms/serializers.py
from rest_framework import serializers
from .models import ChatMessage
from django.contrib.auth.models import User


class UserSerializer(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'role']

    def get_role(self, obj):
        return obj.groups.first().name if obj.groups.exists() else 'User'

class ChatMessageSerializer(serializers.ModelSerializer):
    sender_name = serializers.CharField(source='sender.username', read_only=True)
    recipient_ids = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(),
        many=True,
        source='recipients',
        write_only=True,
        required=False,
    )
    recipients = UserSerializer(many=True, read_only=True)

    class Meta:
        model = ChatMessage
        fields = [
            'id',
            'case',
            'sender',
            'sender_name',
            'recipients',
            'recipient_ids',
            'message',
            'timestamp',
        ]
        read_only_fields = ['id', 'timestamp', 'sender', 'sender_name', 'recipients']
