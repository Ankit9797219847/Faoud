from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response

from case.models import Case
from comms.models import ChatMessage, ChatMessageReadReceipt, ChatPermission
from comms.serializers import ChatMessageSerializer
from user import models
from user.models import AM, BrandOwner, FactoryOwner
from user.permissions import IsAccountManager, IsBrandOwner, IsFactoryOwner

from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.exceptions import PermissionDenied
from django.core.exceptions import ObjectDoesNotExist

from case.models import Case
from comms.models import ChatMessage, ChatPermission
from comms.serializers import ChatMessageSerializer
from user.permissions import IsAccountManager
from django.db.models import Q

# comms/views.py
from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.exceptions import PermissionDenied
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.models import User

from case.models import Case
from comms.models import ChatMessage, ChatPermission
from comms.serializers import ChatMessageSerializer
from user.permissions import IsAccountManager

class ChatMessageViewSet(viewsets.ModelViewSet):
    queryset = ChatMessage.objects.all()
    serializer_class = ChatMessageSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        case_id = self.request.query_params.get('case_id')
        if case_id:
            user = self.request.user
            try:
                case = Case.objects.get(id=case_id)
            except Case.DoesNotExist:
                return ChatMessage.objects.none()

            queryset = self.queryset.filter(case=case)

            if hasattr(user, 'am'):
                # Account Manager can see all messages
                return queryset
            else:
                # Other users can see messages they sent, received, or broadcast messages
                return queryset.filter(
                    Q(recipients=user) |
                    Q(sender=user) |
                    Q(recipients__isnull=True)
                ).distinct()
        return ChatMessage.objects.none()

    def perform_create(self, serializer):
        serializer.save(sender=self.request.user)

    def get_factory_owners_for_case(self, case):
    # Get the Factory associated with the case
        factory = case.factory

    # Get FactoryOwners associated with this factory
        return User.objects.filter(factoryowner__factories=factory).distinct()



    def get_am_users_for_case(self, case):
        # Get AM users associated with the case
        return User.objects.filter(am__cases_am=case).distinct()

    def get_bo_users_for_case(self, case):
        # Get BO users associated with the case
        return User.objects.filter(brandowner__cases=case).distinct()
    
    @action(detail=False, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def mark_as_read(self, request):
        message_ids = request.data.get('message_ids', [])
        user = request.user
        if not message_ids:
            return Response({'error': 'No message IDs provided.'}, status=400)

        # Create read receipts for the given messages
        messages = ChatMessage.objects.filter(id__in=message_ids, recipients=user)
        for message in messages:
            ChatMessageReadReceipt.objects.get_or_create(message=message, user=user)

        return Response({'status': 'Messages marked as read.'})

    @action(detail=False, methods=['get'], permission_classes=[permissions.IsAuthenticated])
    def unread_messages(self, request):
        case_id = request.query_params.get('case_id')
        user = request.user

        if not case_id:
            return Response({'error': 'Case ID is required.'}, status=400)

        try:
            case = Case.objects.get(id=case_id)
        except Case.DoesNotExist:
            return Response({'error': 'Case not found.'}, status=404)

        # Get unread messages for the user
        unread_messages = ChatMessage.objects.filter(
            case=case,
            recipients=user,
            read_receipts__user__isnull=True  # Check if read receipt does not exist
        ).count()

        return Response({'unread_count': unread_messages})

    def create(self, request, *args, **kwargs):
        case_id = request.data.get('case')
        if not case_id:
            return Response({'error': 'Case ID is required.'}, status=400)
        try:
            case = Case.objects.get(id=case_id)
        except Case.DoesNotExist:
            return Response({'error': 'Case not found.'}, status=404)

        # Ensure the ChatPermission exists
        chat_permission, created = ChatPermission.objects.get_or_create(case=case)

        # Permission checks
        user = request.user
        recipient_ids = request.data.get('recipient_ids', [])
        recipients = User.objects.filter(id__in=recipient_ids)

        if hasattr(user, 'am'):
            # Account Manager can send messages to anyone involved in the case
            pass
        elif hasattr(user, 'brandowner') or hasattr(user, 'factoryowner'):
            # BO and FO can always message the Account Manager
            am_users = self.get_am_users_for_case(case)
            valid_recipient_ids = set(am_users.values_list('id', flat=True))

            # If permission is enabled, BO and FO can message each other
            if chat_permission.bo_can_message_fo:
                if hasattr(user, 'brandowner'):
                    # BO can message FO
                    fo_users = self.get_factory_owners_for_case(case)
                    valid_recipient_ids.update(fo_users.values_list('id', flat=True))
                elif hasattr(user, 'factoryowner'):
                    # FO can message BO
                    bo_users = self.get_bo_users_for_case(case)
                    valid_recipient_ids.update(bo_users.values_list('id', flat=True))

            # Check if all recipients are valid
            invalid_recipients = recipients.exclude(id__in=valid_recipient_ids)
            if invalid_recipients.exists():
                raise PermissionDenied("You are not allowed to message the selected recipients.")
        else:
            raise PermissionDenied("You do not have permission to send messages in this chat.")

        return super().create(request, *args, **kwargs)








# comms/views.py (continued)
from rest_framework.views import APIView
from rest_framework.exceptions import PermissionDenied

class ChatPermissionUpdateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, case_id):
        try:
            case = Case.objects.get(id=case_id)
        except Case.DoesNotExist:
            return Response({'error': 'Case not found.'}, status=404)

        user = request.user
        if not hasattr(user, 'am'):
            raise PermissionDenied("Only Account Managers can update chat permissions.")

        bo_can_message_fo = request.data.get('bo_can_message_fo', True)

        # Ensure the ChatPermission exists
        chat_permission, created = ChatPermission.objects.get_or_create(case=case)
        chat_permission.bo_can_message_fo = bo_can_message_fo
        chat_permission.save()
        return Response({'status': 'Chat permissions updated.'})

    def get(self, request, case_id):
        try:
            case = Case.objects.get(id=case_id)
        except Case.DoesNotExist:
            return Response({'error': 'Case not found.'}, status=404)

        try:
            chat_permission = ChatPermission.objects.get(case=case)
        except ChatPermission.DoesNotExist:
            return Response({'bo_can_message_fo': False}, status=200)

        return Response({
            'bo_can_message_fo': chat_permission.bo_can_message_fo
        }, status=200)


