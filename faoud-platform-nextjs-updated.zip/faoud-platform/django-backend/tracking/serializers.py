from rest_framework import serializers
from .models import RM, PM, FDA, Artwork, Manufacturing, ManufacturingMedia
import mimetypes


# -------------------------------
# Dashboard serializers
# -------------------------------

class RMSerializer(serializers.ModelSerializer):
    class Meta:
        model = RM
        fields = '__all__'


class PMSerializer(serializers.ModelSerializer):
    class Meta:
        model = PM
        fields = '__all__'


class FDASerializer(serializers.ModelSerializer):
    class Meta:
        model = FDA
        fields = '__all__'


class ArtworkSerializer(serializers.ModelSerializer):
    class Meta:
        model = Artwork
        fields = '__all__'


# -------------------------------
# Manufacturing serializers
# -------------------------------

class ManufacturingMediaSerializer(serializers.ModelSerializer):
    class Meta:
        model = ManufacturingMedia
        fields = [
            "id", "case", "manufacturing", "file", "kind", "stage",
            "verification_status", "verified_by_am", "visible_to_bo",
            "note", "created_at", "verified_at",
        ]
        read_only_fields = ["manufacturing", "case", "created_at", "verified_at", "verified_by_am"]


class ManufacturingSerializer(serializers.ModelSerializer):
    media = ManufacturingMediaSerializer(many=True, read_only=True)
    media_summary = serializers.SerializerMethodField()

    class Meta:
        model = Manufacturing
        fields = [
            "id", "case", "start_date", "eta_date", "created_date",
            "started_by_factory", "started_verified_by_am", "production_started_for_bo",
            "finished_by_factory", "finished_verified_by_am", "production_finished_for_bo",
            "total_days", "days_elapsed", "progress_percentage", "time_remaining",
            "media", "media_summary", "last_status_update",
        ]
        read_only_fields = [
            "created_date", "total_days", "days_elapsed", "progress_percentage", "time_remaining",
            "last_status_update",
        ]

    def get_media_summary(self, obj):
        qs = obj.media.all()

        def counts(stage):
            s = qs.filter(stage=stage)
            return {
                "pending": s.filter(verification_status="pending").count(),
                "approved": s.filter(verification_status="approved").count(),
                "changes_requested": s.filter(verification_status="changes_requested").count(),
            }

        return {
            "start": counts("start"),
            "progress": counts("progress"),
            "finish": counts("finish"),
        }


class ManufacturingMediaPublicSerializer(serializers.ModelSerializer):
    mime = serializers.SerializerMethodField()

    class Meta:
        model = ManufacturingMedia
        fields = ["id", "file", "kind", "stage", "created_at", "mime"]  # minimal surface

    def get_mime(self, obj):
        # Prefer guessing from the stored file name; fall back to URL if needed
        name = getattr(obj.file, 'name', None) or str(getattr(obj, 'file', ''))
        mime, _ = mimetypes.guess_type(name)
        # Provide sensible defaults for common cases
        if not mime and obj.kind == 'video':
            return 'video/mp4'
        return mime


class ManufacturingPublicSerializer(serializers.ModelSerializer):
    media = serializers.SerializerMethodField()

    class Meta:
        model = Manufacturing
        fields = [
            "id",
            "case",
            "start_date",
            "eta_date",
            "started_verified_by_am",
            "finished_verified_by_am",
            "production_started_for_bo",
            "production_finished_for_bo",
            "progress_percentage",
            "time_remaining",
            "media",
        ]

    def get_media(self, obj):
        qs = obj.media.filter(visible_to_bo=True, verification_status="approved")
        return ManufacturingMediaPublicSerializer(qs, many=True).data