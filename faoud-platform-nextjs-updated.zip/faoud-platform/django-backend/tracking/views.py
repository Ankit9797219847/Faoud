from django.db.models import Q
from django.utils import timezone
from rest_framework import generics, status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.permissions import IsAuthenticated, BasePermission
from rest_framework.response import Response

from .models import (
    RM, PM, FDA, Artwork,
    Manufacturing, ManufacturingMedia
)
from .serializers import (
    RMSerializer, PMSerializer, FDASerializer, ArtworkSerializer,
    ManufacturingSerializer, ManufacturingMediaSerializer, ManufacturingPublicSerializer
)
from case.models import Case
from user.permissions import IsAccountManager, IsBrandOwner, IsFactoryOwner


# -------------------------------
# Permission combinators
# -------------------------------

class IsAccountManagerOrBrandOwner(BasePermission):
    def has_permission(self, request, view):
        return IsAccountManager().has_permission(request, view) or IsBrandOwner().has_permission(request, view)

class IsAccountManagerOrFactoryOwner(BasePermission):
    def has_permission(self, request, view):
        return IsAccountManager().has_permission(request, view) or IsFactoryOwner().has_permission(request, view)


# -------------------------------
# Case helpers
# -------------------------------

def _get_or_create_manufacturing(case_id: int) -> Manufacturing:
    m = Manufacturing.objects.filter(case_id=case_id).first()
    if not m:
        m = Manufacturing.objects.create(case_id=case_id)
    return m

def _is_brand_owner_of_case(user, case_id) -> bool:
    c = Case.objects.filter(id=case_id).select_related("brand_owner__user").first()
    if not c:
        return False
    bo_user = getattr(getattr(c, "brand_owner", None), "user", None)
    return bool(bo_user and user.id == bo_user.id)

def _is_factory_owner_of_case(user, case_id) -> bool:
    """
    A user is considered the Factory Owner of a case if:
    1) The case's `factory.factory_owner.user` matches the user, OR
    2) The user is a FactoryOwner linked to the case via the FactoryOwner.cases M2M.
    """
    # Try the direct Case -> Factory -> FactoryOwner -> User chain
    c = (
        Case.objects
        .filter(id=case_id)
        .select_related("factory__factory_owner__user")
        .first()
    )
    if not c:
        return False

    fo_user = getattr(getattr(getattr(c, "factory", None), "factory_owner", None), "user", None)
    if fo_user and getattr(fo_user, "id", None) == user.id:
        return True

    # Fallback: FactoryOwner linked to this case via M2M (FactoryOwner.cases)
    from user.models import FactoryOwner as _FactoryOwner
    if _FactoryOwner.objects.filter(user=user, cases__id=case_id).exists():
        return True

    # Fallback 2: Check if there is an accepted bid for this case from a factory owned by the user
    from supply.models import Bid
    return Bid.objects.filter(case_id=case_id, status='accepted', factory__factory_owner__user=user).exists()

def _require_brand_owner_of_case(request, case_id):
    if not _is_brand_owner_of_case(request.user, case_id):
        raise PermissionDenied("Not allowed.")

def _require_factory_owner_of_case(request, case_id):
    if not _is_factory_owner_of_case(request.user, case_id):
        raise PermissionDenied("Not allowed.")


# -------------------------------
# Filter mixin
# -------------------------------

class CaseFilteredMixin:
    def get_queryset(self):
        case_id = self.request.query_params.get("case_id")
        if not case_id:
            return self.queryset.none()
        return self.queryset.filter(case_id=case_id)


# -------------------------------
# Dashboard views
# -------------------------------

class RMListCreateView(CaseFilteredMixin, generics.ListCreateAPIView):
    queryset = RM.objects.all()
    serializer_class = RMSerializer
    permission_classes = [IsAuthenticated, IsAccountManagerOrBrandOwner]

    def perform_create(self, serializer):
        case_id = self.request.data.get("case_id")
        serializer.save(case_id=case_id)


class RMDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = RM.objects.all()
    serializer_class = RMSerializer
    permission_classes = [IsAuthenticated, IsAccountManagerOrBrandOwner]


class PMListCreateView(CaseFilteredMixin, generics.ListCreateAPIView):
    queryset = PM.objects.all()
    serializer_class = PMSerializer
    permission_classes = [IsAuthenticated, IsAccountManagerOrBrandOwner]

    def perform_create(self, serializer):
        case_id = self.request.data.get("case_id")
        serializer.save(case_id=case_id)


class PMDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = PM.objects.all()
    serializer_class = PMSerializer
    permission_classes = [IsAuthenticated, IsAccountManagerOrBrandOwner]


class FDAListCreateView(CaseFilteredMixin, generics.ListCreateAPIView):
    queryset = FDA.objects.all()
    serializer_class = FDASerializer
    permission_classes = [IsAuthenticated, IsAccountManagerOrBrandOwner]

    def perform_create(self, serializer):
        case_id = self.request.data.get("case_id")
        serializer.save(case_id=case_id)


class FDADetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = FDA.objects.all()
    serializer_class = FDASerializer
    permission_classes = [IsAuthenticated, IsAccountManagerOrBrandOwner]


class ArtworkListCreateView(CaseFilteredMixin, generics.ListCreateAPIView):
    queryset = Artwork.objects.all()
    serializer_class = ArtworkSerializer
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    permission_classes = [IsAuthenticated, IsAccountManagerOrBrandOwner]

    def perform_create(self, serializer):
        case_id = self.request.data.get("case_id")
        serializer.save(case_id=case_id)


class ArtworkDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Artwork.objects.all()
    serializer_class = ArtworkSerializer
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    permission_classes = [IsAuthenticated, IsAccountManagerOrBrandOwner]

    def perform_update(self, serializer):
        """
        Disallow approving the artwork if no image is present.
        Supports "true"/"false"/1/0 etc.
        """
        def _to_bool(v):
            if isinstance(v, bool):
                return v
            if v is None:
                return None
            return str(v).lower() in ("1", "true", "t", "yes", "y")

        approved_in_request = _to_bool(self.request.data.get("approved"))
        if approved_in_request is True:
            artwork_instance = serializer.instance
            if not artwork_instance.artwork_image and not self.request.data.get("artwork_image"):
                from django.forms import ValidationError
                raise ValidationError({"detail": "Cannot approve without an artwork image."})

        serializer.save()


# -------------------------------
# Manufacturing ViewSet
# -------------------------------

class ManufacturingViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    def get_permissions(self):
        action = getattr(self, 'action', None)
        if action in ('am_verify', 'partial_update'):
            perms = [IsAuthenticated, IsAccountManager]
        elif action in ('start', 'finish', 'media'):
            if self.request.method.lower() == 'get':
                perms = [ IsAccountManager | IsFactoryOwner]
            else:
                perms = [IsAuthenticated, IsFactoryOwner]
        elif action in ('retrieve',):
            perms = [ IsAccountManager | IsFactoryOwner]
        elif action in ('public',):
            perms = [IsAuthenticated, IsBrandOwner]
        else:
            perms = [IsAuthenticated]
        return [p() for p in perms]

    def retrieve(self, request, pk=None):
        """
        GET /manufacturing/{case_id}/
        FO (must own the case) or AM can read.
        """
        m = _get_or_create_manufacturing(pk)
        # If FO is calling, ensure they own the case
        if IsFactoryOwner().has_permission(request, self):
            _require_factory_owner_of_case(request, pk)
        return Response(ManufacturingSerializer(m).data)

    def partial_update(self, request, pk=None):
        """
        PATCH /manufacturing/{case_id}/
        AM may adjust fields like eta_date/start_date or BO visibility flags if needed.
        """
        m = _get_or_create_manufacturing(pk)
        s = ManufacturingSerializer(m, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return Response(s.data)

    @action(detail=True, methods=["get", "post"], url_path="media")
    def media(self, request, pk=None):
        """
        GET: AM or FO (FO must own the case) can list all media for the case.
        POST: FO (must own the case) uploads media; resets phase approvals for that stage.
        """
        m = _get_or_create_manufacturing(pk)

        if request.method.lower() == "get":
            if IsFactoryOwner().has_permission(request, self):
                _require_factory_owner_of_case(request, pk)
            qs = m.media.all()
            return Response(ManufacturingMediaSerializer(qs, many=True).data)

        # POST (upload) — FO only and must own the case
        _require_factory_owner_of_case(request, pk)

        files = request.FILES.getlist("files") or (
            [request.FILES.get("file")] if request.FILES.get("file") else []
        )
        kind = request.data.get("kind", "image")  # 'image'|'video'
        stage = request.data.get("stage", "progress")

        created = []
        for f in files:
            media = ManufacturingMedia.objects.create(
                manufacturing=m,
                case_id=pk,
                file=f,
                kind=kind,
                stage=stage,
                uploaded_by=getattr(request, "user", None),
                verification_status="pending",
                visible_to_bo=False,
            )
            created.append(media)

        # If FO adds new media in a stage, force re-approval for that phase + hide from BO
        dirty_fields = []
        if stage in ("start", "progress"):
            if m.started_verified_by_am or m.production_started_for_bo:
                m.started_verified_by_am = False
                m.production_started_for_bo = False
                dirty_fields += ["started_verified_by_am", "production_started_for_bo"]
        elif stage == "finish":
            if m.finished_verified_by_am or m.production_finished_for_bo:
                m.finished_verified_by_am = False
                m.production_finished_for_bo = False
                dirty_fields += ["finished_verified_by_am", "production_finished_for_bo"]

        if dirty_fields:
            m.save(update_fields=dirty_fields + ["last_status_update"])

        return Response(ManufacturingMediaSerializer(created, many=True).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"], url_path="start")
    def start(self, request, pk=None):
        """
        POST /manufacturing/{case_id}/start/
        FO marks production started (requires ETA + >= 4 start/progress media).
        """
        _require_factory_owner_of_case(request, pk)
        m = _get_or_create_manufacturing(pk)

        # Optionally accept eta_date on first start
        eta = request.data.get("eta_date")
        if eta and not m.eta_date:
            m.eta_date = eta  # Expecting YYYY-MM-DD string; DRF serializer handles validation elsewhere

        start_media_count = m.media.filter(Q(stage="start") | Q(stage="progress")).count()
        if start_media_count < 4 or not m.eta_date:
            return Response(
                {"detail": "Need at least 4 photos/videos and an ETA date to mark as started."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if not m.start_date:
            m.start_date = timezone.now().date()
        m.started_by_factory = True
        m.started_verified_by_am = False
        m.production_started_for_bo = False
        m.save()
        return Response(ManufacturingSerializer(m).data)

    @action(detail=True, methods=["post"], url_path="finish")
    def finish(self, request, pk=None):
        """
        POST /manufacturing/{case_id}/finish/
        FO marks production finished (requires >= 1 finish media).
        """
        _require_factory_owner_of_case(request, pk)
        m = _get_or_create_manufacturing(pk)

        finish_media_count = m.media.filter(stage="finish").count()
        if finish_media_count < 1:
            return Response({"detail": "Upload at least one finish photo/video."}, status=status.HTTP_400_BAD_REQUEST)

        m.finished_by_factory = True
        m.finished_verified_by_am = False
        m.production_finished_for_bo = False
        m.save()
        return Response(ManufacturingSerializer(m).data)

    @action(detail=True, methods=["post"], url_path="am-verify")
    def am_verify(self, request, pk=None):
        """
        POST /manufacturing/{case_id}/am-verify/
        body: {
          "phase": "start"|"finish",
          "decision": "approve"|"request_changes",
          "note": "optional",
          "visible_to_bo": true|false
        }
        Bulk approve/request changes for the phase; toggles BO visibility of phase status.
        """
        m = _get_or_create_manufacturing(pk)
        phase = request.data.get("phase")
        decision = request.data.get("decision")
        note = request.data.get("note", "")
        visible_to_bo = bool(request.data.get("visible_to_bo", False))

        if phase not in ("start", "finish") or decision not in ("approve", "request_changes"):
            return Response({"detail": "Invalid payload."}, status=status.HTTP_400_BAD_REQUEST)

        if phase == "start":
            qs = m.media.filter(Q(stage="start") | Q(stage="progress"), verification_status="pending")
            if decision == "approve":
                m.started_verified_by_am = True
                m.production_started_for_bo = visible_to_bo
                qs.update(
                    verification_status="approved",
                    verified_by_am=True,
                    verified_at=timezone.now(),
                    note=note,
                    visible_to_bo=visible_to_bo,
                )
            else:
                m.started_verified_by_am = False
                m.production_started_for_bo = False
                qs.update(verification_status="changes_requested", verified_by_am=False, note=note)
        else:
            qs = m.media.filter(stage="finish", verification_status="pending")
            if decision == "approve":
                m.finished_verified_by_am = True
                m.production_finished_for_bo = visible_to_bo
                qs.update(
                    verification_status="approved",
                    verified_by_am=True,
                    verified_at=timezone.now(),
                    note=note,
                    visible_to_bo=visible_to_bo,
                )
            else:
                m.finished_verified_by_am = False
                m.production_finished_for_bo = False
                qs.update(verification_status="changes_requested", verified_by_am=False, note=note)

        m.save()
        return Response(ManufacturingSerializer(m).data)

    @action(detail=True, methods=["get"], url_path="public")
    def public(self, request, pk=None):
        """
        GET /manufacturing/{case_id}/public/
        BO-only public view: only approved & visible_to_bo media + computed fields.
        """
        _require_brand_owner_of_case(request, pk)
        m = _get_or_create_manufacturing(pk)
        data = ManufacturingPublicSerializer(m).data
        return Response(data)