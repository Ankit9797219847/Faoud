from rest_framework import generics
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import IsAuthenticated
from .models import ManufacturingMedia
from .serializers import ManufacturingMediaSerializer
from user.permissions import IsAccountManager, IsFactoryOwner
from .views import _require_factory_owner_of_case  # reuse helper


class ManufacturingMediaDetailView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: AM or FO (FO must own the case)
    PATCH/PUT/DELETE: AM only
    Allows AM to approve/request changes, toggle visible_to_bo, and write notes.
    """
    queryset = ManufacturingMedia.objects.select_related("manufacturing", "case").all()
    serializer_class = ManufacturingMediaSerializer

    def get_permissions(self):
        if self.request.method.lower() in ("patch", "put", "delete"):
            perms = [IsAuthenticated, IsAccountManager]
        else:
            perms = [ IsAccountManager | IsFactoryOwner]
        return [p() for p in perms]

    def get_object(self):
        obj = super().get_object()
        # If FO is reading, must own the case
        if IsFactoryOwner().has_permission(self.request, self) and self.request.method.lower() == "get":
            _require_factory_owner_of_case(self.request, obj.case_id)
        return obj

    def perform_update(self, serializer):
        if not IsAccountManager().has_permission(self.request, self):
            raise PermissionDenied("Only Account Managers can update a media item.")
        serializer.save()