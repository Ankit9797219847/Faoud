from django.urls import path
from .views import (
    ManufacturingViewSet,
    RMListCreateView, RMDetailView,
    PMListCreateView, PMDetailView,
    FDAListCreateView, FDADetailView,
    ArtworkListCreateView, ArtworkDetailView,
)
from .views_media import ManufacturingMediaDetailView

# Manufacturing ViewSet bindings
manufacturing_detail = ManufacturingViewSet.as_view({"get": "retrieve", "patch": "partial_update"})
manufacturing_media = ManufacturingViewSet.as_view({"get": "media", "post": "media"})
manufacturing_start = ManufacturingViewSet.as_view({"post": "start"})
manufacturing_finish = ManufacturingViewSet.as_view({"post": "finish"})
manufacturing_am_verify = ManufacturingViewSet.as_view({"post": "am_verify"})
manufacturing_public = ManufacturingViewSet.as_view({"get": "public"})

urlpatterns = [
    # Dashboard endpoints
    path('rm/', RMListCreateView.as_view(), name='rm-list-create'),
    path('rm/<int:pk>/', RMDetailView.as_view(), name='rm-detail'),
    path('pm/', PMListCreateView.as_view(), name='pm-list-create'),
    path('pm/<int:pk>/', PMDetailView.as_view(), name='pm-detail'),
    path('fda/', FDAListCreateView.as_view(), name='fda-list-create'),
    path('fda/<int:pk>/', FDADetailView.as_view(), name='fda-detail'),
    path('artwork/', ArtworkListCreateView.as_view(), name='artwork-list-create'),
    path('artwork/<int:pk>/', ArtworkDetailView.as_view(), name='artwork-detail'),

    # Manufacturing case-scoped endpoints (pk == case_id)
    path("manufacturing/<int:pk>/", manufacturing_detail, name="manufacturing-detail"),
    path("manufacturing/<int:pk>/media/", manufacturing_media, name="manufacturing-media"),
    path("manufacturing/<int:pk>/start/", manufacturing_start, name="manufacturing-start"),
    path("manufacturing/<int:pk>/finish/", manufacturing_finish, name="manufacturing-finish"),
    path("manufacturing/<int:pk>/am-verify/", manufacturing_am_verify, name="manufacturing-am-verify"),
    path("manufacturing/<int:pk>/public/", manufacturing_public, name="manufacturing-public"),

    # Per-media AM review
    path("manufacturing/media/<int:pk>/", ManufacturingMediaDetailView.as_view(), name="manufacturing-media-detail"),
]