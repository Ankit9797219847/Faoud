from django.db.models.signals import post_save
from django.dispatch import receiver

from utils.models import QCEntry
from .models import Manufacturing

@receiver(post_save, sender=Manufacturing)
def create_qc_entries_on_finish(sender, instance, created, **kwargs):
    if not created and instance.finished_verified_by_am:
        case = instance.case
        if case:
            default_descriptions = [
                "Certificate of Analysis for the finished goods",
                "Material Safety Data Sheet for the shipped finished product",
                "Packing List for the shipment"
            ]
            for desc in default_descriptions:
                QCEntry.objects.get_or_create(case=case, description=desc)