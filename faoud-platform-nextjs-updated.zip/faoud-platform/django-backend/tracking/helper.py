from tracking.models import FDA, PM, RM


def hasProcurementStarted(case):
    """
    Check if the procurement process has started for a given case.
    
    Args:
        case (dict): A dictionary representing the case, which should contain
                     a 'procurement' key with a boolean value.
    
    
    Returns:
        bool: True if procurement has started, False otherwise.
    """

    rm_tracker = RM.objects.filter(case=case).first()
    pm_tracker = PM.objects.filter(case=case).first()
    fda_tracker = FDA.objects.filter(case=case).first()

    # return true when only one of them is in_progress and false if either all are not started or even two are in progress
    if rm_tracker and pm_tracker and fda_tracker:
        rm_status = rm_tracker.status == 'in_progress'
        pm_status = pm_tracker.status == 'in_progress'
        fda_status = fda_tracker.status == 'in_progress'

        return (rm_status + pm_status + fda_status) == 1
    return False


def hasManufacturingStarted(case):
    """
    Check if the manufacturing process has started for a given case.
    
    Args:
        case (dict): A dictionary representing the case, which should contain
                     a 'manufacturing' key with a boolean value.
    
    Returns:
        bool: True if manufacturing has started, False otherwise.
    """

    #return true, if all rm, pm and fda are done
    rm_tracker = RM.objects.filter(case=case).first()
    pm_tracker = PM.objects.filter(case=case).first()
    fda_tracker = FDA.objects.filter(case=case).first() 
    if rm_tracker and pm_tracker and fda_tracker:
        rm_status = rm_tracker.status == 'done'
        pm_status = pm_tracker.status == 'done'
        fda_status = fda_tracker.status == 'done'

        return rm_status and pm_status and fda_status
    return False