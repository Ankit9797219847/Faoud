from django.contrib import admin
from .models import RM, PM, FDA, Artwork, Manufacturing, ManufacturingMedia

@admin.register(RM)
class RMAdmin(admin.ModelAdmin):
    list_display = ('id', 'status', 'message', 'time_taken', 'approved')
    search_fields = ('status', 'message')
    list_filter = ('approved', 'status')
    ordering = ('-time_taken',)


@admin.register(PM)
class PMAdmin(admin.ModelAdmin):
    list_display = ('id', 'status', 'message', 'time_taken', 'approved')
    search_fields = ('status', 'message')
    list_filter = ('approved', 'status')
    ordering = ('-time_taken',)


@admin.register(FDA)
class FDAAdmin(admin.ModelAdmin):
    list_display = ('id', 'status','time_taken', 'message', 'greyout')
    search_fields = ('message',)
    list_filter = ('greyout', 'status')
    ordering = ('-time_taken',)


@admin.register(Artwork)
class ArtworkAdmin(admin.ModelAdmin):
    list_display = ('id', 'artwork_image', 'feedback', 'approved')
    search_fields = ('feedback',)
    list_filter = ('approved',)
    ordering = ('-id',)


@admin.register(Manufacturing)
class ManufacturingAdmin(admin.ModelAdmin):
    list_display = ('id',)
    ordering = ('-id',)

@admin.register(ManufacturingMedia)
class ManufacturingMediaAdmin(admin.ModelAdmin):
    list_display = ('id', 'case', 'manufacturing', 'kind', 'stage', 'verification_status', 'visible_to_bo', 'created_at')
    list_filter = ('kind', 'stage', 'verification_status', 'visible_to_bo')
    ordering = ('-id',)