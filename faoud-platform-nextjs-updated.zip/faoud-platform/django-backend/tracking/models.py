
from datetime import datetime
from django.db import models
from case.models import Case  # Import the Case model from the case app

class RM(models.Model):
    case = models.ForeignKey(
        Case,
        on_delete=models.CASCADE,
        related_name="dashboard_rm",  # Use unique related_name
        null=True,
        blank=True,
    )
    STATUS_CHOICES = [
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('done', 'Done'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_started')
    message = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='rm_images/', blank=True, null=True)
    time_taken = models.DurationField(null=True, blank=True)
    address = models.TextField(blank=True, null=True)
    approved = models.BooleanField(default=False)

    # New field
    greyout = models.BooleanField(default=False)  # <-- Mark if user didn't purchase RM

    def __str__(self):
        return f"RM - {self.id}"


class PM(models.Model):
    case = models.ForeignKey(
        Case,
        on_delete=models.CASCADE,
        related_name="dashboard_pm",  # Use unique related_name
        null=True,
        blank=True,
    )
    STATUS_CHOICES = [
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('done', 'Done'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_started')
    message = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='pm_images/', blank=True, null=True)
    time_taken = models.DurationField(null=True, blank=True)
    address = models.TextField(blank=True, null=True)
    approved = models.BooleanField(default=False)

    # New field
    greyout = models.BooleanField(default=False)  # <-- Mark if user didn't purchase RM

    def __str__(self):
        return f"PM - {self.id}"


class FDA(models.Model):
    case = models.ForeignKey(
        Case,
        on_delete=models.CASCADE,
        related_name="dashboard_fda",  # Use unique related_name
        null=True,
        blank=True,
    )
    STATUS_CHOICES = [
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('done', 'Done'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_started')
    time_taken = models.DurationField(null=True, blank=True)
    message = models.TextField(blank=True, null=True)
    
    greyout = models.BooleanField(default=False)

    def __str__(self):
        return f"FDA - {self.id}"


class Artwork(models.Model):
    case = models.ForeignKey(
        Case,
        on_delete=models.CASCADE,
        related_name="dashboard_artwork",  # Use unique related_name
        null=True,
        blank=True,
    )
    artwork_image = models.ImageField(upload_to='artwork_images/', blank=True, null=True)
    feedback = models.TextField(blank=True, null=True)
    approved = models.BooleanField(default=False)

    # New field
    greyout = models.BooleanField(default=False)  # <-- Mark if user didn't purchase RM

    def __str__(self):
        return f"Artwork - {self.id}"

from django.db import models
from django.utils import timezone

# manufacturing/models.py
from django.db import models
from django.utils import timezone
from django.conf import settings
from case.models import Case

class Manufacturing(models.Model):
    case = models.ForeignKey(
        Case,
        on_delete=models.CASCADE,
        related_name="dashboard_manufacturing",
        null=True,
        blank=True,
    )
    start_date = models.DateField(null=True, blank=True)
    eta_date = models.DateField(null=True, blank=True)
    created_date = models.DateField(default=timezone.now)

    # --- New status flags ---
    started_by_factory = models.BooleanField(default=False)
    started_verified_by_am = models.BooleanField(default=False)
    production_started_for_bo = models.BooleanField(default=False)

    finished_by_factory = models.BooleanField(default=False)
    finished_verified_by_am = models.BooleanField(default=False)
    production_finished_for_bo = models.BooleanField(default=False)

    # audit
    last_status_update = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Manufacturing for Case {self.case.id if self.case else 'N/A'}"

    @property
    def total_days(self):
        if self.start_date and self.eta_date:
            return (self.eta_date - self.start_date).days
        return 0

    @property
    def days_elapsed(self):
        if self.start_date:
            return (timezone.now().date() - self.start_date).days
        return 0

    @property
    def progress_percentage(self):
        total = self.total_days
        if total > 0:
            return min((self.days_elapsed / total) * 100, 100)
        return 0

    @property
    def time_remaining(self):
        if self.eta_date:
            remaining = (self.eta_date - timezone.now().date()).days
            return max(remaining, 0)
        return 0


def manufacturing_media_upload_to(instance, filename):
    # e.g. manufacturing/case_123/start/IMG_0001.jpg
    stage = instance.stage or "progress"
    return f"manufacturing/case_{instance.case_id}/{stage}/{filename}"


class ManufacturingMedia(models.Model):
    STAGE_CHOICES = (
        ("start", "Start"),
        ("progress", "Progress"),
        ("finish", "Finish"),
    )
    KIND_CHOICES = (
        ("image", "Image"),
        ("video", "Video"),
    )

    manufacturing = models.ForeignKey(Manufacturing, on_delete=models.CASCADE, related_name="media")
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name="manufacturing_media")
    file = models.FileField(upload_to=manufacturing_media_upload_to, max_length=1024)
    kind = models.CharField(max_length=16, choices=KIND_CHOICES)
    stage = models.CharField(max_length=16, choices=STAGE_CHOICES, default="progress")

    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )

    # AM review lifecycle
    verification_status = models.CharField(
        max_length=32,
        choices=(("pending", "Pending"), ("approved", "Approved"), ("changes_requested", "Changes Requested")),
        default="pending",
    )
    verified_by_am = models.BooleanField(default=False)
    visible_to_bo = models.BooleanField(default=False)
    note = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    verified_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]