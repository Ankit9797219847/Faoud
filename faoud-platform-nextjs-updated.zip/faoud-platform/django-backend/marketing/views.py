import json

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.db import transaction
from django.http import JsonResponse, HttpResponseGone
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views.decorators.http import require_GET
from django_ratelimit.decorators import ratelimit

from rest_framework import status
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from marketing.tasks import send_delayed_onboarding_alert_task
from notifications.tasks import send_email
from user.models import AM
from utils.captcha import (
    is_valid_captcha_proof,
    make_captcha_proof,
    verify_captcha_or_raise,
)

from .models import (
    CampaignLink,
    ClickEvent,
    ContactSubmission,
    OnboardingAttachment,
    OnboardingData,
    Toggle,
    WaitlistEntry,
)
from .serializers import (
    ContactSubmissionSerializer,
    OnboardingAttachmentSerializer,
    WaitlistEntrySerializer,
)

User = get_user_model()


class WaitlistEntryView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(ratelimit(key="ip", rate="3/m", block=True))
    def post(self, request, *args, **kwargs):
        """
        Save a waitlist entry.
        """
        verify_captcha_or_raise(request)

        ip_address = self.get_client_ip(request)
        data = request.data.copy()
        data["ip_address"] = ip_address

        serializer = WaitlistEntrySerializer(data=data)
        if serializer.is_valid():
            saved_entry = serializer.save()
            return Response(
                {
                    "message": "Thank you for joining the waitlist!",
                    "data": {
                        "id": saved_entry.id,
                        "email": saved_entry.email,
                        "contact_number": saved_entry.contact_number,
                        "ip_address": saved_entry.ip_address,
                        "created_at": saved_entry.created_at,
                    },
                },
                status=status.HTTP_201_CREATED,
            )

        return Response(
            {
                "message": "Failed to join the waitlist. Please correct the errors below.",
                "errors": serializer.errors,
            },
            status=status.HTTP_400_BAD_REQUEST,
        )

    @staticmethod
    def get_client_ip(request):
        x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
        if x_forwarded_for:
            return x_forwarded_for.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR")


class ToggleStatusView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(ratelimit(key="ip", rate="50/m", block=True))
    def get(self, request, *args, **kwargs):
        """
        Check whether the "coming soon" toggle is enabled.
        """
        is_enabled = cache.get("toggle_status")
        if is_enabled is None:
            toggle = Toggle.objects.first()
            is_enabled = toggle.is_enabled if toggle else False
            cache.set("toggle_status", is_enabled, timeout=60)

        return Response({"is_enabled": is_enabled}, status=status.HTTP_200_OK)


class ContactSubmissionView(APIView):
    permission_classes = [AllowAny]

    @method_decorator(ratelimit(key="ip", rate="3/m", block=True))
    def post(self, request, *args, **kwargs):
        verify_captcha_or_raise(request)

        serializer = ContactSubmissionSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()

            send_email(
                "Some query was submitted in Contact Us on homepage",
                serializer.validated_data.get("message", ""),
                "sales@faoud.com",
            )

            return Response(
                {"message": "Your message has been received. Thank you!"},
                status=status.HTTP_201_CREATED,
            )

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class OnboardingDataView(APIView):
    permission_classes = [AllowAny]

    @staticmethod
    def _envelope_seconds() -> int:
        return int(getattr(settings, "ONBOARDING_ALERT_DELAY_SECONDS", 600))

    @staticmethod
    def _should_rollover(record: OnboardingData | None, *, now, envelope_seconds: int) -> bool:
        """
        Start a new onboarding "envelope" when:
          - no record exists
          - the onboarding alert email has already been sent for the record
          - inactivity exceeds the envelope window (updated_at older than threshold or missing)
        """
        if not record:
            return True
        if record.onboarding_alert_sent:
            return True
        last_activity = getattr(record, "updated_at", None)
        if not last_activity:
            return True
        return (now - last_activity).total_seconds() > envelope_seconds

    @staticmethod
    def _normalize_text(value) -> str:
        return (value or "").strip().lower()

    @staticmethod
    def _stable_json(value) -> str:
        if not value:
            return ""
        try:
            return json.dumps(value, sort_keys=True, separators=(",", ":"))
        except (TypeError, ValueError):
            return str(value)

    @staticmethod
    def _compute_history_fingerprint(record: OnboardingData) -> str:
        """
        Lightweight fingerprint to detect "new requirement entry" vs edits.
        Only uses the fields that define a requirement at a high level.
        """
        import hashlib

        parts = [
            OnboardingDataView._normalize_text(getattr(record, "flow_type", "")),
            OnboardingDataView._normalize_text(getattr(record, "product_category", "")),
            OnboardingDataView._normalize_text(getattr(record, "product_name", "")),
            OnboardingDataView._stable_json(getattr(record, "configurator_answers", {})),
        ]
        if not any(parts):
            return ""

        raw = "|".join(parts).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    @staticmethod
    def _append_history_if_needed(record: OnboardingData) -> None:
        """
        Append a history entry when the requirement fingerprint changes.
        Keeps existing flat fields as the "latest" snapshot.
        """
        fingerprint = OnboardingDataView._compute_history_fingerprint(record)
        if not fingerprint:
            return

        with transaction.atomic():
            latest = (
                OnboardingData.objects.select_for_update()
                .filter(id=record.id)
                .first()
            )
            if not latest:
                return

            if fingerprint == (latest.last_history_fingerprint or ""):
                return

            entry = {
                "captured_at": timezone.now().isoformat(),
                "flow_type": latest.flow_type,
                "product_category": latest.product_category,
                "product_name": latest.product_name,
                "quantity": latest.quantity,
                "timeline": latest.timeline,
                "budget": latest.budget,
                "requires_formulation": bool(latest.requires_formulation),
                "instructions": latest.instructions,
                "location": latest.location,
                "company_name": latest.company_name,
                "email": latest.email,
                "mobile": latest.mobile,
                "origination_source": latest.origination_source,
                "source_route": latest.source_route,
                "configurator_answers": latest.configurator_answers,
                "utm_params": latest.utm_params,
            }

            history = list(latest.requirements_history or [])
            history.append(entry)
            latest.requirements_history = history
            latest.last_history_fingerprint = fingerprint
            latest.save(update_fields=["requirements_history", "last_history_fingerprint"])

    @staticmethod
    def _to_bool(value):
        if isinstance(value, bool):
            return value
        if value is None:
            return False
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "yes", "on"}
        return bool(value)

    @staticmethod
    def _int_list(value):
        if value in (None, ""):
            return []
        if not isinstance(value, list):
            value = [value]

        ids = []
        for item in value:
            try:
                ids.append(int(item))
            except (TypeError, ValueError):
                continue
        return ids

    @staticmethod
    def _dict_value(value):
        if isinstance(value, dict):
            return value
        if isinstance(value, str) and value.strip():
            try:
                parsed = json.loads(value)
            except json.JSONDecodeError:
                return {}
            return parsed if isinstance(parsed, dict) else {}
        return {}

    @staticmethod
    def _resolve_existing_record(pk=None, client_id=None):
        if pk:
            return OnboardingData.objects.filter(id=pk).first()
        if client_id:
            return (
                OnboardingData.objects.filter(client_id=client_id)
                .order_by("-updated_at", "-id")
                .first()
            )
        return None

    @staticmethod
    def _schedule_onboarding_alert(record):
        delay_seconds = OnboardingDataView._envelope_seconds()
        scheduled_at = timezone.now() + timezone.timedelta(seconds=delay_seconds)

        if record.onboarding_alert_sent:
            return

        first_schedule = OnboardingData.objects.filter(
            id=record.id,
            onboarding_alert_scheduled=False,
            onboarding_alert_sent=False,
        ).update(
            onboarding_alert_scheduled=True,
            onboarding_alert_scheduled_at=scheduled_at,
        )

        if not first_schedule:
            OnboardingData.objects.filter(
                id=record.id,
                onboarding_alert_sent=False,
            ).update(
                onboarding_alert_scheduled=True,
                onboarding_alert_scheduled_at=scheduled_at,
            )
            return

        transaction.on_commit(
            lambda: OnboardingDataView._send_alert_task(record.id, delay_seconds)
        )

    @staticmethod
    def _send_alert_task(onboarding_id, delay_seconds):
        """Send the delayed onboarding alert task."""
        send_delayed_onboarding_alert_task.apply_async(
            args=[onboarding_id],
            countdown=delay_seconds,
        )

    @staticmethod
    def _get_onboarding_payload(request, ip_address, user_for_email):
        return {
            "ip_address": ip_address,
            "client_id": request.data.get("client_id"),
            "flow_type": request.data.get("flowType"),
            "step": request.data.get("step"),
            "product_category": request.data.get("productCategory", ""),
            "product_name": request.data.get("productName", ""),
            "quantity": request.data.get("quantity", ""),
            "instructions": request.data.get("instructions", ""),
            "requires_formulation": OnboardingDataView._to_bool(
                request.data.get("requiresFormulation", False)
            ),
            "selected_factory": request.data.get("selectedFactory"),
            "factory_title": request.data.get("factoryTitle"),
            "factory_items": request.data.get("factoryItems"),
            "selected_category_ids": OnboardingDataView._int_list(
                request.data.get("selectedCategoryIds")
            ),
            "selected_subcategory_ids": OnboardingDataView._int_list(
                request.data.get("selectedSubcategoryIds")
            ),
            "custom_category_text": request.data.get("customCategoryText"),
            "custom_subcategory_text": request.data.get("customSubcategoryText"),
            "email": request.data.get("email"),
            "mobile": request.data.get("mobile"),
            "timeline": request.data.get("timeline"),
            "budget": request.data.get("budget"),
            "company_name": request.data.get("companyName"),
            "location": request.data.get("location"),
            "origination_source": request.data.get("originationSource"),
            "source_route": request.data.get("sourceRoute"),
            "configurator_answers": OnboardingDataView._dict_value(
                request.data.get("configuratorAnswers")
            ),
            "utm_params": OnboardingDataView._dict_value(
                request.data.get("utmParams")
            ),
            "user": user_for_email,
        }

    @staticmethod
    def get_client_ip(request):
        x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
        if x_forwarded_for:
            return x_forwarded_for.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR")

    @method_decorator(ratelimit(key="ip", rate="30/m", block=True))
    def post(self, request, format=None):
        now = timezone.now()
        envelope_seconds = self._envelope_seconds()
        ip = self.get_client_ip(request)

        email = (request.data.get("email") or "").strip()
        user_for_email = None
        if email:
            user_for_email = User.objects.filter(email__iexact=email).only("id").first()

        captcha_proof = request.data.get("captcha_proof")
        proof_is_valid = is_valid_captcha_proof(captcha_proof, email=email, client_id=request.data.get("client_id"))
        if not proof_is_valid:
            verify_captcha_or_raise(request)
            captcha_proof = make_captcha_proof(email=email, client_id=request.data.get("client_id"))
            proof_is_valid = True

        payload = self._get_onboarding_payload(request, ip, user_for_email)
        existing = self._resolve_existing_record(client_id=payload.get("client_id"))

        if existing and not self._should_rollover(existing, now=now, envelope_seconds=envelope_seconds):
            for field, value in payload.items():
                setattr(existing, field, value)
            existing.captcha_verified_at = timezone.now() if proof_is_valid else None
            existing.save()
            record = existing
            response_status = status.HTTP_200_OK
            message = "Onboarding data updated"
        else:
            record = OnboardingData.objects.create(
                **payload,
                captcha_verified_at=timezone.now() if proof_is_valid else None,
            )
            response_status = status.HTTP_201_CREATED
            message = "Onboarding data saved"

        self._append_history_if_needed(record)
        self._schedule_onboarding_alert(record)

        return Response(
            {"success": True, "message": message, "id": record.id, "captcha_proof": captcha_proof},
            status=response_status,
        )

    @method_decorator(ratelimit(key="ip", rate="30/m", block=True))
    def patch(self, request, *args, **kwargs):
        now = timezone.now()
        envelope_seconds = self._envelope_seconds()
        ip = self.get_client_ip(request)
        existing = self._resolve_existing_record(
            pk=kwargs.get("pk") or request.data.get("onboarding_id"),
            client_id=request.data.get("client_id"),
        )
        if not existing:
            return Response(
                {"success": False, "message": "Onboarding record not found"},
                status=status.HTTP_404_NOT_FOUND,
            )

        email = (request.data.get("email") or "").strip()
        user_for_email = None
        if email:
            user_for_email = User.objects.filter(email__iexact=email).only("id").first()

        captcha_proof = request.data.get("captcha_proof")
        proof_is_valid = is_valid_captcha_proof(captcha_proof, email=email, client_id=request.data.get("client_id"))
        if not proof_is_valid:
            verify_captcha_or_raise(request)
            captcha_proof = make_captcha_proof(email=email, client_id=request.data.get("client_id"))
            proof_is_valid = True

        payload = self._get_onboarding_payload(request, ip, user_for_email)
        rollover = self._should_rollover(existing, now=now, envelope_seconds=envelope_seconds)
        if rollover:
            create_payload = dict(payload)
            if not create_payload.get("client_id"):
                create_payload["client_id"] = existing.client_id
            if not create_payload.get("user"):
                create_payload["user"] = existing.user
            record = OnboardingData.objects.create(
                **create_payload,
                captcha_verified_at=timezone.now() if proof_is_valid else None,
            )
        else:
            for field, value in payload.items():
                setattr(existing, field, value)
            existing.captcha_verified_at = timezone.now() if proof_is_valid else None
            existing.save()
            record = existing

        self._append_history_if_needed(record)
        self._schedule_onboarding_alert(record)

        return Response(
            {"success": True, "message": "Onboarding data updated", "id": record.id, "captcha_proof": captcha_proof},
            status=status.HTTP_200_OK,
        )


@require_GET
def resolve_and_click(request, token: str):
    link = get_object_or_404(CampaignLink, token=token)
    if not link.is_active:
        return HttpResponseGone("Link inactive")

    xff = request.META.get("HTTP_X_FORWARDED_FOR")
    ip = xff.split(",")[0].strip() if xff else request.META.get("REMOTE_ADDR")

    ClickEvent.objects.create(
        link=link,
        clicked_at=timezone.now(),
        ip=ip,
        user_agent=(request.META.get("HTTP_USER_AGENT", "") or "")[:5000],
        referrer=(request.META.get("HTTP_REFERER", "") or "")[:2000],
    )

    return JsonResponse(
        {
            "ok": True,
            "destination_url": link.destination_url,
            "campaign_id": link.campaign_id,
            "label": link.label,
        }
    )


class OnboardingAttachmentUploadView(APIView):
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, FormParser]

    @method_decorator(ratelimit(key="ip", rate="10/m", block=True))
    def post(self, request, *args, **kwargs):
        onboarding_id = request.data.get("onboarding_id")
        kind = (request.data.get("kind") or "").strip()

        if not onboarding_id:
            return Response(
                {"detail": "onboarding_id is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            onboarding = OnboardingData.objects.get(pk=onboarding_id)
        except OnboardingData.DoesNotExist:
            return Response(
                {"detail": "Onboarding record not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        files = request.FILES.getlist("files")
        if not files:
            return Response(
                {"detail": "No files uploaded."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        created = []
        for uploaded in files:
            attachment = OnboardingAttachment(
                onboarding=onboarding,
                file=uploaded,
                original_name=uploaded.name,
                kind=kind,
            )
            attachment.save()
            created.append(attachment)

        serializer = OnboardingAttachmentSerializer(created, many=True, context={"request": request})
        return Response(
            {"success": True, "attachments": serializer.data},
            status=status.HTTP_201_CREATED,
        )
