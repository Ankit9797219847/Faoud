from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("marketing", "0014_onboardingdata_requirements_history"),
    ]

    operations = [
        migrations.AddField(
            model_name="onboardingdata",
            name="updated_at",
            field=models.DateTimeField(auto_now=True),
        ),
    ]

