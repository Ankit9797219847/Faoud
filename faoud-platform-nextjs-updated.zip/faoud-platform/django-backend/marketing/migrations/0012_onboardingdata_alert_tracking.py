from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("marketing", "0011_onboardingdata_captcha_verified_at"),
    ]

    operations = [
        migrations.AddField(
            model_name="onboardingdata",
            name="onboarding_alert_scheduled",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="onboardingdata",
            name="onboarding_alert_scheduled_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="onboardingdata",
            name="onboarding_alert_sent",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="onboardingdata",
            name="onboarding_alert_sent_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
