from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("marketing", "0012_onboardingdata_alert_tracking"),
    ]

    operations = [
        migrations.RunSQL(
            sql="""
                ALTER TABLE marketing_onboardingdata
                ADD COLUMN IF NOT EXISTS onboarding_alert_scheduled boolean NOT NULL DEFAULT false,
                ADD COLUMN IF NOT EXISTS onboarding_alert_scheduled_at timestamp with time zone NULL,
                ADD COLUMN IF NOT EXISTS onboarding_alert_sent boolean NOT NULL DEFAULT false,
                ADD COLUMN IF NOT EXISTS onboarding_alert_sent_at timestamp with time zone NULL;
            """,
            reverse_sql=migrations.RunSQL.noop,
        ),
    ]
