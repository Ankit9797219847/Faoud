from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("marketing", "0009_onboardingattachment"),
    ]

    operations = [
        migrations.AddField(
            model_name="onboardingdata",
            name="selected_category_ids",
            field=models.JSONField(blank=True, default=list),
        ),
        migrations.AddField(
            model_name="onboardingdata",
            name="selected_subcategory_ids",
            field=models.JSONField(blank=True, default=list),
        ),
        migrations.AddField(
            model_name="onboardingdata",
            name="custom_category_text",
            field=models.TextField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="onboardingdata",
            name="custom_subcategory_text",
            field=models.TextField(blank=True, null=True),
        ),
    ]
