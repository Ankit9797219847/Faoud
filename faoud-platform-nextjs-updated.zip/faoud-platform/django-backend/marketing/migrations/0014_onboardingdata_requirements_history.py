from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("marketing", "0013_ensure_onboarding_alert_columns"),
    ]

    operations = [
        migrations.AddField(
            model_name="onboardingdata",
            name="requirements_history",
            field=models.JSONField(blank=True, default=list),
        ),
        migrations.AddField(
            model_name="onboardingdata",
            name="last_history_fingerprint",
            field=models.CharField(blank=True, default="", max_length=64),
        ),
    ]

