from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("marketing", "0010_onboardingdata_taxonomy_selection"),
    ]

    operations = [
        migrations.AddField(
            model_name="onboardingdata",
            name="captcha_verified_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
