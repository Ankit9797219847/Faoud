from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("marketing", "0015_onboardingdata_updated_at"),
    ]

    operations = [
        migrations.AddField(
            model_name="onboardingdata",
            name="configurator_answers",
            field=models.JSONField(blank=True, default=dict),
        ),
        migrations.AddField(
            model_name="onboardingdata",
            name="source_route",
            field=models.CharField(blank=True, max_length=512, null=True),
        ),
        migrations.AddField(
            model_name="onboardingdata",
            name="utm_params",
            field=models.JSONField(blank=True, default=dict),
        ),
    ]
