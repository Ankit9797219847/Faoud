from celery import shared_task
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone

from notifications.notif import send_html_email
from user.models import AM

from .models import OnboardingData

User = get_user_model()

ONBOARDING_ALERT_RECIPIENTS = [
    "sales@faoud.com",
    "rutuja@faoud.com",
    "vash@faoud.com",
    "jha@faoud.com",
]


def get_onboarding_recipients():
    am_recipients = list(
        AM.objects.select_related("user")
        .filter(user__email__isnull=False)
        .exclude(user__email="")
        .values_list("user__email", flat=True)
    )

    seen = set()
    recipients = []
    for email in ONBOARDING_ALERT_RECIPIENTS + am_recipients:
        normalized = (email or "").strip()
        if not normalized or normalized in seen:
            continue
        recipients.append(normalized)
        seen.add(normalized)
    return recipients


def build_onboarding_subject(onboarding):
    flow_type = (onboarding.flow_type or "").strip().lower()
    if flow_type == "brand":
        route_type = "BO"
    elif flow_type in {"manufacturer", "factory"}:
        route_type = "FO"
    else:
        route_type = "GEN"

    flow_label = onboarding.flow_type.title() if onboarding.flow_type else "New"
    return f"[{route_type} Requirement Alert] {flow_label} Inquiry - {onboarding.product_name or 'Unnamed Product'}"


def build_onboarding_context(onboarding):
    attachments = [
        {
            "name": attachment.original_name or attachment.file.name.rsplit("/", 1)[-1],
            "kind": attachment.kind or "",
        }
        for attachment in onboarding.attachments.all()
    ]
    history = list(getattr(onboarding, "requirements_history", []) or [])
    configurator_answers = getattr(onboarding, "configurator_answers", {}) or {}
    utm_params = getattr(onboarding, "utm_params", {}) or {}
    configurator_answer_rows = [
        {"label": str(key).replace("_", " ").title(), "value": value}
        for key, value in configurator_answers.items()
        if value not in (None, "", [], {})
    ]
    utm_rows = [
        {"label": str(key), "value": value}
        for key, value in utm_params.items()
        if value not in (None, "", [], {})
    ]

    return {
        "onboarding": onboarding,
        "attachments": attachments,
        "requirements_history": history,
        "requirements_entries_count": len(history),
        "flow_type": onboarding.flow_type or "N/A",
        "step": onboarding.step if onboarding.step is not None else "N/A",
        "product_category": onboarding.product_category or "N/A",
        "product_name": onboarding.product_name or "N/A",
        "quantity": onboarding.quantity or "N/A",
        "requires_formulation": "Yes" if onboarding.requires_formulation else "No",
        "timeline": onboarding.timeline or "N/A",
        "budget": onboarding.budget or "N/A",
        "instructions": onboarding.instructions or "None",
        "selected_factory": onboarding.selected_factory or "N/A",
        "factory_title": onboarding.factory_title or "N/A",
        "factory_items": onboarding.factory_items or "N/A",
        "email": onboarding.email or "N/A",
        "mobile": onboarding.mobile or "N/A",
        "company_name": onboarding.company_name or "N/A",
        "location": onboarding.location or "N/A",
        "ip_address": onboarding.ip_address or "N/A",
        "client_id": onboarding.client_id or "N/A",
        "origination_source": onboarding.origination_source or "N/A",
        "source_route": onboarding.source_route or "N/A",
        "configurator_answer_rows": configurator_answer_rows,
        "utm_rows": utm_rows,
        "created_at": onboarding.created_at,
    }


@shared_task(bind=True)
def send_delayed_onboarding_alert_task(self, onboarding_id):
    """
    Debounced sender: will retry until onboarding_alert_scheduled_at is reached.
    Sends at most once per OnboardingData row.
    """
    now = timezone.now()
    recipients = get_onboarding_recipients()
    if not recipients:
        return

    try:
        with transaction.atomic():
            latest = (
                OnboardingData.objects.select_for_update()
                .prefetch_related("attachments")
                .filter(id=onboarding_id)
                .first()
            )
            if not latest or latest.onboarding_alert_sent:
                return

            scheduled_at = latest.onboarding_alert_scheduled_at
            if scheduled_at and now < scheduled_at:
                remaining = int((scheduled_at - now).total_seconds())
                raise self.retry(countdown=max(5, remaining))

            # Mark as sent before sending to guarantee "at most once" even under concurrency.
            latest.onboarding_alert_sent = True
            latest.onboarding_alert_sent_at = now
            latest.save(update_fields=["onboarding_alert_sent", "onboarding_alert_sent_at"])

        context = build_onboarding_context(latest)
        subject = build_onboarding_subject(latest)
        send_html_email(subject, "documents/onboarding_requirement_alert.html", context, recipients)
    except Exception:
        # If sending fails, revert the sent flag so it can be retried.
        with transaction.atomic():
            rollback = OnboardingData.objects.select_for_update().filter(id=onboarding_id).first()
            if rollback:
                rollback.onboarding_alert_sent = False
                rollback.onboarding_alert_sent_at = None
                rollback.save(update_fields=["onboarding_alert_sent", "onboarding_alert_sent_at"])
        raise
