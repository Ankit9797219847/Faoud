from django.contrib import admin
from .models import EventCampaign, OnboardingData, WaitlistEntry, Toggle, ContactSubmission
from datetime import timedelta
from django.contrib import messages
from django.db.models.functions import TruncDate
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import path
from django.utils import timezone
from django.utils.html import escape


@admin.register(WaitlistEntry)
class WaitlistEntryAdmin(admin.ModelAdmin):
    list_display = ('contact_number', 'email', 'ip_address', 'created_at')


@admin.register(Toggle)
class ToggleAdmin(admin.ModelAdmin):
    list_display = ('is_enabled', 'updated_at')  # Fields to display in the admin list view
    list_display_links = ('updated_at',)  # Make 'updated_at' the clickable link
    list_editable = ('is_enabled',)  # Allow editing 'is_enabled' directly in the list view


@admin.register(ContactSubmission)
class ContactSubmissionAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'submitted_at')




from django.contrib import admin
from django.db.models import Count
from django.utils.html import format_html
from django.urls import reverse

from .models import CampaignLink, ClickEvent


@admin.register(EventCampaign)
class CampaignAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "created_at", "links_count", "clicks_count")
    search_fields = ("name",)
    readonly_fields = ("created_at",)
    ordering = ("-created_at",)
    actions = ("compare_campaigns_graph",)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.annotate(
            _links_count=Count("links", distinct=True),
            _clicks_count=Count("links__clicks", distinct=True),
        )

    @admin.display(description="Links", ordering="_links_count")
    def links_count(self, obj):
        return getattr(obj, "_links_count", 0)

    @admin.display(description="Clicks", ordering="_clicks_count")
    def clicks_count(self, obj):
        return getattr(obj, "_clicks_count", 0)

    # -------- Action (select 2 campaigns -> graph) --------
    @admin.action(description="Compare selected campaigns (graph)")
    def compare_campaigns_graph(self, request, queryset):
        ids = list(queryset.values_list("id", flat=True))
        if len(ids) != 2:
            self.message_user(request, "Select exactly 2 campaigns to compare.", level=messages.ERROR)
            return
        url = reverse("admin:eventcampaign_compare_graph")
        return HttpResponseRedirect(f"{url}?c1={ids[0]}&c2={ids[1]}&days=30")  # Corrected f-string

    # -------- Add admin URL: /admin/<app>/eventcampaign/compare-graph/ --------
    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path(
                "compare-graph/",
                self.admin_site.admin_view(self.compare_graph_view),
                name="eventcampaign_compare_graph",
            )
        ]
        return custom + urls

    # -------- No-template view: returns HTML + inline SVG --------
    def compare_graph_view(self, request):
        try:
            c1_id = int(request.GET.get("c1"))
            c2_id = int(request.GET.get("c2"))
        except (TypeError, ValueError):
            return HttpResponse("Missing/invalid c1,c2", status=400)

        try:
            days = int(request.GET.get("days", "30"))
        except ValueError:
            days = 30
        days = max(1, min(days, 180))

        c1 = EventCampaign.objects.filter(id=c1_id).first()
        c2 = EventCampaign.objects.filter(id=c2_id).first()
        if not c1 or not c2:
            return HttpResponse("Campaign not found", status=404)

        end = timezone.now()
        start = end - timedelta(days=days)

        def clicks_by_day(campaign_id: int):
            qs = (
                ClickEvent.objects
                .filter(link__campaign_id=campaign_id, clicked_at__gte=start, clicked_at__lte=end)
                .annotate(day=TruncDate("clicked_at"))
                .values("day")
                .annotate(count=Count("id"))
                .order_by("day")
            )
            return {row["day"]: row["count"] for row in qs}

        m1 = clicks_by_day(c1_id)
        m2 = clicks_by_day(c2_id)

        labels, s1, s2 = [], [], []
        cur = start.date()
        end_date = end.date()
        while cur <= end_date:
            labels.append(cur)
            s1.append(int(m1.get(cur, 0)))
            s2.append(int(m2.get(cur, 0)))
            cur += timedelta(days=1)

        total1, total2 = sum(s1), sum(s2)
        ymax = max(1, max(s1 + s2))

        # ---- inline SVG chart (no templates, no JS) ----
        W, H = 980, 260
        pad_l, pad_r, pad_t, pad_b = 55, 20, 22, 35
        inner_w = W - pad_l - pad_r
        inner_h = H - pad_t - pad_b

        def xy(i, v):
            x = pad_l + (inner_w * i / max(1, (len(labels) - 1)))
            y = pad_t + inner_h - (inner_h * (v / ymax))
            return x, y

        def polyline(series):
            pts = []
            for i, v in enumerate(series):
                x, y = xy(i, v)
                pts.append(f"{x:.2f},{y:.2f}")
            return " ".join(pts)

        def fmt(d): return d.strftime("%Y-%m-%d")

        p1 = polyline(s1)
        p2 = polyline(s2)

        grid = []
        for k in range(0, 5):
            y = pad_t + inner_h * (k / 4)
            grid.append(f'<line x1="{pad_l}" y1="{y:.2f}" x2="{W-pad_r}" y2="{y:.2f}" stroke="#ddd" />')

        mid = labels[len(labels)//2]
        svg = f"""
        <svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">
          <rect x="0" y="0" width="{W}" height="{H}" fill="#fff"/>
          {''.join(grid)}
          <line x1="{pad_l}" y1="{pad_t}" x2="{pad_l}" y2="{H-pad_b}" stroke="#333"/>
          <line x1="{pad_l}" y1="{H-pad_b}" x2="{W-pad_r}" y2="{H-pad_b}" stroke="#333"/>

          <polyline points="{p1}" fill="none" stroke="#1f77b4" stroke-width="2"/>
          <polyline points="{p2}" fill="none" stroke="#ff7f0e" stroke-width="2"/>

          <text x="{pad_l}" y="16" font-size="12" fill="#1f77b4">{escape(c1.name)} (total {total1})</text>
          <text x="{pad_l+320}" y="16" font-size="12" fill="#ff7f0e">{escape(c2.name)} (total {total2})</text>

          <text x="10" y="{pad_t+12}" font-size="11" fill="#333">{ymax}</text>
          <text x="10" y="{H-pad_b}" font-size="11" fill="#333">0</text>

          <text x="{pad_l}" y="{H-10}" font-size="11" fill="#333">{fmt(labels[0])}</text>
          <text x="{W/2-40}" y="{H-10}" font-size="11" fill="#333">{fmt(mid)}</text>
          <text x="{W-130}" y="{H-10}" font-size="11" fill="#333">{fmt(labels[-1])}</text>
        </svg>
        """

        back_url = "javascript:history.back()"
        html = f"""
        <!doctype html>
        <html>
          <head>
            <meta charset="utf-8"/>
            <title>Compare Campaigns</title>
            <style>
              body {{ font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; padding: 16px; }}
              .row {{ display:flex; gap:12px; align-items:center; margin: 8px 0 14px; flex-wrap: wrap; }}
              .pill {{ padding:6px 10px; border:1px solid #ddd; border-radius:999px; }}
              a {{ color:#0b57d0; text-decoration:none; }}
            </style>
          </head>
          <body>
            <div class="row">
              <a href="{back_url}">← Back</a>
              <span class="pill">Last {days} days</span>
              <span class="pill">C1: {escape(c1.name)} (ID {c1.id})</span>
              <span class="pill">C2: {escape(c2.name)} (ID {c2.id})</span>
            </div>
            {svg}
          </body>
        </html>
        """
        return HttpResponse(html)


class ClickEventInline(admin.TabularInline):
    model = ClickEvent
    extra = 0
    fields = ("clicked_at", "ip", "user_agent")
    readonly_fields = ("clicked_at", "ip", "user_agent")
    can_delete = False
    show_change_link = True
    ordering = ("-clicked_at",)

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(CampaignLink)
class CampaignLinkAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "campaign",
        "label",
        "short_destination",
        "tracking_url",
        "clicks_count",
        "is_active",
        "created_at",
    )
    list_filter = ("campaign", "is_active", "created_at")
    search_fields = ("token", "label", "destination_url", "campaign__name")
    readonly_fields = ("token", "created_at")
    ordering = ("-created_at",)
    inlines = (ClickEventInline,)
    actions = ("deactivate_links", "activate_links", "export_tokens")

    fieldsets = (
        ("Campaign Link", {"fields": ("campaign", "label", "destination_url", "is_active")}),
        ("System", {"fields": ("token", "created_at")}),
    )

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.annotate(_clicks_count=Count("clicks", distinct=True))

    @admin.display(description="Clicks", ordering="_clicks_count")
    def clicks_count(self, obj):
        return getattr(obj, "_clicks_count", 0)

    @admin.display(description="Destination")
    def short_destination(self, obj):
        url = obj.destination_url
        return url if len(url) <= 60 else url[:57] + "..."

    @admin.display(description="Tracking URL")
    def tracking_url(self, obj):
        # Put faoud.com because you are using Option B
        url = f"https://faoud.com/r/{obj.token}"
        # show a clickable link in admin
        return format_html('<a href="{}" target="_blank">{}</a>', url, url)

    @admin.action(description="Deactivate selected links")
    def deactivate_links(self, request, queryset):
        updated = queryset.update(is_active=False)
        self.message_user(request, f"Deactivated {updated} link(s).")

    @admin.action(description="Activate selected links")
    def activate_links(self, request, queryset):
        updated = queryset.update(is_active=True)
        self.message_user(request, f"Activated {updated} link(s).")

    @admin.action(description="Export tokens (CSV-ish)")
    def export_tokens(self, request, queryset):
        # Quick-and-dirty export to the response as text.
        # If you want a real CSV file download, tell me and I’ll convert this.
        lines = ["id,campaign_id,label,token,destination_url,is_active"]
        for l in queryset.select_related("campaign"):
            label_escaped = (l.label or "").replace('"', '""')
            lines.append(
                f'{l.id},{l.campaign_id},"{label_escaped}","{l.token}","{l.destination_url}",{l.is_active}'
            )
        text = "\n".join(lines)
        from django.http import HttpResponse
        resp = HttpResponse(text, content_type="text/plain; charset=utf-8")
        resp["Content-Disposition"] = "attachment; filename=campaign_links_export.txt"
        return resp


@admin.register(ClickEvent)
class ClickEventAdmin(admin.ModelAdmin):
    list_display = ("id", "link", "campaign", "clicked_at", "ip", "ua_short")
    list_filter = ("clicked_at", "link__campaign")
    search_fields = ("ip", "user_agent", "link__token", "link__label", "link__destination_url")
    readonly_fields = ("link", "clicked_at", "ip", "user_agent", "referrer")
    ordering = ("-clicked_at",)

    def has_add_permission(self, request):
        return False

    @admin.display(description="Campaign")
    def campaign(self, obj):
        return obj.link.campaign

    @admin.display(description="User Agent")
    def ua_short(self, obj):
        ua = obj.user_agent or ""
        return ua if len(ua) <= 60 else ua[:57] + "..."
    
# marketing/admin.py
from django.contrib import admin
from .models import OnboardingData, OnboardingAttachment


class OnboardingAttachmentInline(admin.TabularInline):
    model = OnboardingAttachment
    extra = 0
    fields = ("file", "original_name", "kind", "uploaded_at")
    readonly_fields = ("uploaded_at",)
    show_change_link = True


@admin.register(OnboardingData)
class OnboardingDataAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "created_at",
        "flow_type",
        "product_name",
        "product_category",
        "company_name",
        "email",
        "mobile",
        "user",
        "origination_source",
        "source_route",
    )
    list_filter = ("flow_type", "created_at", "origination_source")
    search_fields = (
        "product_name",
        "product_category",
        "company_name",
        "email",
        "mobile",
        "client_id",
        "location",
        "source_route",
    )
    date_hierarchy = "created_at"
    inlines = [OnboardingAttachmentInline]


@admin.register(OnboardingAttachment)
class OnboardingAttachmentAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "onboarding",
        "original_name",
        "kind",
        "uploaded_at",
    )
    list_filter = ("kind", "uploaded_at")
    search_fields = ("original_name", "file")
    raw_id_fields = ("onboarding",)
    date_hierarchy = "uploaded_at"
