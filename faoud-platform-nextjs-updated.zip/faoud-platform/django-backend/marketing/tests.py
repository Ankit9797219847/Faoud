from unittest.mock import patch

from django.core import mail
from django.test import override_settings
from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from leads.models import LeadItem
from marketing.models import OnboardingData
from marketing.tasks import send_delayed_onboarding_alert_task
from user.models import AM
from django.contrib.auth.models import User


@override_settings(ROOT_URLCONF="shadow.urls", CAPTCHA_ENABLED=False)
class OnboardingAlertFlowTests(APITestCase):
    def setUp(self):
        self.am_user = User.objects.create_user(
            username="am-user",
            email="am@example.com",
            password="secret123",
            is_active=True,
        )
        AM.objects.create(user=self.am_user, name="AM User", contact_email="am@example.com")

    def test_first_post_schedules_delayed_alert_and_patch_updates_same_row(self):
        payload = {
            "client_id": "client-123",
            "flowType": "brand",
            "step": 0,
            "productCategory": "Skin Care",
            "productName": "Initial Product",
            "quantity": "1000",
            "email": "lead@example.com",
            "mobile": "+911234567890",
        }

        with patch("marketing.views.send_delayed_onboarding_alert_task.apply_async") as mocked_apply_async:
            with self.captureOnCommitCallbacks(execute=True):
                post_response = self.client.post(reverse("onboarding"), payload, format="json")

        self.assertEqual(post_response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(OnboardingData.objects.count(), 1)
        onboarding = OnboardingData.objects.get()
        self.assertTrue(onboarding.onboarding_alert_scheduled)
        self.assertFalse(onboarding.onboarding_alert_sent)
        self.assertIsNotNone(onboarding.onboarding_alert_scheduled_at)
        self.assertEqual(len(onboarding.requirements_history or []), 1)
        mocked_apply_async.assert_called_once()
        self.assertEqual(mocked_apply_async.call_args.kwargs["countdown"], 600)

        previous_scheduled_at = onboarding.onboarding_alert_scheduled_at

        patch_payload = {
            **payload,
            "step": 1,
            "productName": "Updated Product",
            "quantity": "2500",
        }
        with patch("marketing.views.send_delayed_onboarding_alert_task.apply_async") as mocked_apply_async:
            patch_response = self.client.patch(
                reverse("onboarding-detail", args=[onboarding.id]),
                patch_payload,
                format="json",
            )

        self.assertEqual(patch_response.status_code, status.HTTP_200_OK)
        self.assertEqual(OnboardingData.objects.count(), 1)
        onboarding.refresh_from_db()
        self.assertEqual(onboarding.product_name, "Updated Product")
        self.assertEqual(onboarding.quantity, "2500")
        self.assertIsNotNone(onboarding.onboarding_alert_scheduled_at)
        self.assertGreaterEqual(onboarding.onboarding_alert_scheduled_at, previous_scheduled_at)
        self.assertEqual(len(onboarding.requirements_history or []), 2)
        mocked_apply_async.assert_not_called()

    def test_delayed_task_uses_latest_saved_onboarding_values(self):
        onboarding = OnboardingData.objects.create(
            client_id="client-456",
            flow_type="brand",
            step=0,
            product_category="Hair Care",
            product_name="Draft Product",
            quantity="500",
            email="draft@example.com",
            source_route="/launch/solid-perfume",
            configurator_answers={
                "fragrance_family": "Woody",
                "launch_quantity": "1,000 - 5,000 units",
            },
            utm_params={"utm_source": "google"},
            onboarding_alert_scheduled=True,
            onboarding_alert_scheduled_at=timezone.now(),
        )

        onboarding.product_name = "Final Product"
        onboarding.quantity = "2500"
        onboarding.instructions = "Latest saved notes"
        onboarding.save()

        send_delayed_onboarding_alert_task.run(onboarding.id)

        onboarding.refresh_from_db()
        self.assertTrue(onboarding.onboarding_alert_sent)
        self.assertIsNotNone(onboarding.onboarding_alert_sent_at)
        self.assertEqual(len(mail.outbox), 1)
        message = mail.outbox[0]
        self.assertIn("Final Product", message.subject)
        self.assertIn("Final Product", message.body)
        self.assertIn("2500", message.body)
        self.assertIn("Latest saved notes", message.body)
        self.assertIn("am@example.com", message.to)
        self.assertEqual(len(message.alternatives), 1)
        html_content, mimetype = message.alternatives[0]
        self.assertEqual(mimetype, "text/html")
        self.assertIn("Onboarding Requirement Alert", html_content)
        self.assertIn("Final Product", html_content)
        self.assertIn("Latest saved notes", html_content)
        self.assertIn("/launch/solid-perfume", html_content)
        self.assertIn("Woody", html_content)
        self.assertIn("utm_source", html_content)

    def test_launch_context_is_saved_and_added_to_lead_notes(self):
        payload = {
            "client_id": "launch-client-123",
            "flowType": "brand",
            "step": 2,
            "productCategory": "solid perfume",
            "productName": "Solid Perfume",
            "quantity": "1,000 - 5,000 units",
            "instructions": "Launch page requirement.",
            "email": "launch@example.com",
            "mobile": "+911234567890",
            "companyName": "Launch Brand",
            "originationSource": "launch_page",
            "sourceRoute": "/launch/solid-perfume",
            "configuratorAnswers": {
                "fragrance_family": "Woody",
                "format": "Tin",
                "launch_quantity": "1,000 - 5,000 units",
            },
            "utmParams": {
                "utm_source": "google",
                "utm_campaign": "solid_perfume",
            },
        }

        with patch("marketing.views.send_delayed_onboarding_alert_task.apply_async"):
            response = self.client.post(reverse("onboarding"), payload, format="json")

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        onboarding = OnboardingData.objects.get(client_id="launch-client-123")
        self.assertEqual(onboarding.source_route, "/launch/solid-perfume")
        self.assertEqual(onboarding.configurator_answers["fragrance_family"], "Woody")
        self.assertEqual(onboarding.utm_params["utm_source"], "google")

        lead = LeadItem.objects.get(source_id=onboarding.id, tag="onboarding")
        self.assertIn("source_route: /launch/solid-perfume", lead.notes)
        self.assertIn("Fragrance Family: Woody", lead.notes)
        self.assertIn("Format: Tin", lead.notes)
        self.assertIn("UTM:", lead.notes)

    def test_post_after_inactivity_creates_new_onboarding_envelope(self):
        payload = {
            "client_id": "client-env-1",
            "flowType": "brand",
            "step": 0,
            "productCategory": "Skin Care",
            "productName": "Envelope One",
            "quantity": "1000",
            "email": "lead@example.com",
            "mobile": "+911234567890",
        }

        with patch("marketing.views.send_delayed_onboarding_alert_task.apply_async"):
            post_response = self.client.post(reverse("onboarding"), payload, format="json")
        self.assertEqual(post_response.status_code, status.HTTP_201_CREATED)
        first_id = post_response.data["id"]

        stale_at = timezone.now() - timezone.timedelta(seconds=601)
        OnboardingData.objects.filter(id=first_id).update(updated_at=stale_at)

        with patch("marketing.views.send_delayed_onboarding_alert_task.apply_async") as mocked_apply_async:
            with self.captureOnCommitCallbacks(execute=True):
                post_response_2 = self.client.post(
                    reverse("onboarding"),
                    {**payload, "productName": "Envelope Two"},
                    format="json",
                )

        self.assertEqual(post_response_2.status_code, status.HTTP_201_CREATED)
        self.assertEqual(OnboardingData.objects.count(), 2)
        self.assertNotEqual(post_response_2.data["id"], first_id)
        mocked_apply_async.assert_called_once()

    def test_patch_after_inactivity_rolls_over_to_new_envelope(self):
        payload = {
            "client_id": "client-env-2",
            "flowType": "brand",
            "step": 0,
            "productCategory": "Skin Care",
            "productName": "Envelope One",
            "quantity": "1000",
            "email": "lead@example.com",
            "mobile": "+911234567890",
        }

        with patch("marketing.views.send_delayed_onboarding_alert_task.apply_async"):
            post_response = self.client.post(reverse("onboarding"), payload, format="json")
        self.assertEqual(post_response.status_code, status.HTTP_201_CREATED)
        first_id = post_response.data["id"]

        stale_at = timezone.now() - timezone.timedelta(seconds=601)
        OnboardingData.objects.filter(id=first_id).update(updated_at=stale_at)

        with patch("marketing.views.send_delayed_onboarding_alert_task.apply_async") as mocked_apply_async:
            with self.captureOnCommitCallbacks(execute=True):
                patch_response = self.client.patch(
                    reverse("onboarding-detail", args=[first_id]),
                    {**payload, "step": 1, "productName": "Envelope Two"},
                    format="json",
                )

        self.assertEqual(patch_response.status_code, status.HTTP_200_OK)
        self.assertEqual(OnboardingData.objects.count(), 2)
        self.assertNotEqual(patch_response.data["id"], first_id)
        mocked_apply_async.assert_called_once()
