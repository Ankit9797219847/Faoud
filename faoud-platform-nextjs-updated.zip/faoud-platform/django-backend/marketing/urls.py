from django.urls import path
from .views import ContactSubmissionView, OnboardingAttachmentUploadView, OnboardingDataView, WaitlistEntryView, ToggleStatusView, resolve_and_click

urlpatterns = [
    path('marketing/waitlist/', WaitlistEntryView.as_view(), name='waitlist'),
    path('toggle-status/', ToggleStatusView.as_view(), name='toggle_status'),
    path('marketing/contact/', ContactSubmissionView.as_view(), name='contact_submission'),
    path('onboarding/', OnboardingDataView.as_view(), name='onboarding'),
    path('onboarding/<int:pk>/', OnboardingDataView.as_view(), name='onboarding-detail'),
    path("onboarding/attachments/", OnboardingAttachmentUploadView.as_view(), name="onboarding-attachments"),
    path("track/resolve-and-click/<str:token>/", resolve_and_click, name="resolve_and_click"),
]