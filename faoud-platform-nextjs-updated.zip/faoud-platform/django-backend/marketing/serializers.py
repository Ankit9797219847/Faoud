from rest_framework import serializers
from .models import WaitlistEntry, ContactSubmission

class WaitlistEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = WaitlistEntry
        fields = ['email', 'contact_number', 'created_at','ip_address']

    def validate_email(self, value):
        restricted_domains = [
            'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com',
            'aol.com', 'icloud.com', 'protonmail.com', 'zoho.com', 'mail.com'
        ]
        domain = value.split('@')[1].lower()
        if domain in restricted_domains:
            raise serializers.ValidationError("Please use your company email address.")
        return value


class ContactSubmissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContactSubmission
        fields = ['first_name', 'last_name', 'email', 'message', 'submitted_at']


from .models import OnboardingAttachment

class OnboardingAttachmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = OnboardingAttachment
        fields = ["id", "file", "original_name", "uploaded_at", "kind"]
        read_only_fields = ["id", "uploaded_at"]

    def create(self, validated_data):
        # original_name fallback if not explicitly set
        if not validated_data.get("original_name") and "file" in validated_data:
            validated_data["original_name"] = validated_data["file"].name
        return super().create(validated_data)