import secrets

from django.contrib.auth import get_user_model
from django.db import models
from django.utils import timezone

User = get_user_model()


class WaitlistEntry(models.Model):
    contact_number = models.CharField(max_length=15)
    ip_address = models.GenericIPAddressField()
    created_at = models.DateTimeField(auto_now_add=True)
    email = models.EmailField(null=True, blank=True)

    def __str__(self):
        return self.contact_number


class Toggle(models.Model):
    is_enabled = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return "ComingSoon Active" if self.is_enabled else "ComingSoon Inactive"


class ContactSubmission(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField()
    message = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.email}"


class OnboardingData(models.Model):
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    flow_type = models.CharField(max_length=32, null=True, blank=True)  # 'brand' | 'manufacturer'
    step = models.IntegerField(null=True, blank=True)
    product_category = models.CharField(max_length=128, null=True, blank=True)
    product_name = models.CharField(max_length=256, null=True, blank=True)
    quantity = models.CharField(max_length=64, null=True, blank=True)
    instructions = models.TextField(null=True, blank=True)
    requires_formulation = models.BooleanField(default=False)
    selected_factory = models.CharField(max_length=256, null=True, blank=True)
    factory_title = models.CharField(max_length=256, null=True, blank=True)
    factory_items = models.TextField(null=True, blank=True)
    selected_category_ids = models.JSONField(default=list, blank=True)
    selected_subcategory_ids = models.JSONField(default=list, blank=True)
    custom_category_text = models.TextField(null=True, blank=True)
    custom_subcategory_text = models.TextField(null=True, blank=True)
    email = models.EmailField(null=True, blank=True)
    mobile = models.CharField(max_length=32, null=True, blank=True)

    client_id = models.CharField(max_length=64, db_index=True, null=True, blank=True)
    timeline = models.CharField(max_length=50, null=True, blank=True)
    budget = models.CharField(max_length=50, null=True, blank=True)
    company_name = models.CharField(max_length=255, null=True, blank=True)
    location = models.CharField(max_length=255, null=True, blank=True)
    origination_source = models.CharField(max_length=255, null=True, blank=True)
    source_route = models.CharField(max_length=512, null=True, blank=True)
    configurator_answers = models.JSONField(default=dict, blank=True)
    utm_params = models.JSONField(default=dict, blank=True)

    user = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="onboarding_records",
    )

    captcha_verified_at = models.DateTimeField(null=True, blank=True)

    onboarding_alert_scheduled = models.BooleanField(default=False)
    onboarding_alert_scheduled_at = models.DateTimeField(null=True, blank=True)
    onboarding_alert_sent = models.BooleanField(default=False)
    onboarding_alert_sent_at = models.DateTimeField(null=True, blank=True)

    requirements_history = models.JSONField(default=list, blank=True)
    last_history_fingerprint = models.CharField(max_length=64, blank=True, default="")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"OnboardingData#{self.pk} - {self.email or self.product_name or ''}"


def generate_token(nbytes=18):
    return secrets.token_urlsafe(nbytes)


class EventCampaign(models.Model):
    name = models.CharField(max_length=200)
    created_at = models.DateTimeField(default=timezone.now)


class CampaignLink(models.Model):
    token = models.CharField(max_length=64, unique=True, db_index=True, default=generate_token)
    campaign = models.ForeignKey(EventCampaign, on_delete=models.CASCADE, related_name="links")
    destination_url = models.URLField(max_length=2000)
    label = models.CharField(max_length=120, blank=True, default="")
    created_at = models.DateTimeField(default=timezone.now)
    is_active = models.BooleanField(default=True)


class ClickEvent(models.Model):
    link = models.ForeignKey(CampaignLink, on_delete=models.CASCADE, related_name="clicks")
    clicked_at = models.DateTimeField(default=timezone.now)
    ip = models.GenericIPAddressField(null=True, blank=True)
    referrer = models.URLField(max_length=2000, blank=True, default="")
    user_agent = models.TextField(blank=True, default="")


class OnboardingAttachment(models.Model):
    onboarding = models.ForeignKey(
        OnboardingData,
        related_name="attachments",
        on_delete=models.CASCADE,
    )
    file = models.FileField(upload_to="onboarding_attachments/%Y/%m/")
    original_name = models.CharField(max_length=255, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    kind = models.CharField(
        max_length=50,
        blank=True,
        help_text="e.g. 'brand_brief', 'factory_catalog', 'certification'",
    )

    def __str__(self):
        return f"{self.onboarding_id}: {self.original_name or self.file.name}"
