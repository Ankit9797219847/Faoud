"""
Service Request Tests

Tests for the Service Requests system covering:
- ServiceRequest + ServicePayment creation
- Webhook payment status updates
- User list/view own requests
"""

from decimal import Decimal
from unittest.mock import patch, MagicMock

from django.test import TestCase, override_settings
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from django.db import connections
from rest_framework.test import APITestCase, APIClient
from rest_framework import status

from services.models import (
    FeedbackReport,
    ServiceOffering,
    ServiceReview,
    ServiceRequest,
    ServiceRequestStatusHistory,
)
from payments.models import ServicePayment
from user.models import BrandOwner, AM

User = get_user_model()


class NotificationPatchMixin:
    """
    Prevent notification/template failures from breaking service request tests.
    Patch the most likely import locations used in signals/views/models.
    """

    def start_notification_patchers(self):
        self._notification_patchers = [
            patch("services.signals.send_notification", create=True),
            patch("services.views.send_notification", create=True),
            patch("services.models.send_notification", create=True),
        ]
        self._mocked_notifications = []
        for patcher in self._notification_patchers:
            self._mocked_notifications.append(patcher.start())
            self.addCleanup(patcher.stop)

    @classmethod
    def tearDownClass(cls):
        """
        Close DB connections explicitly to reduce teardown issues in CI
        where PostgreSQL complains that test DB is still in use.
        """
        try:
            for conn in connections.all():
                conn.close()
        finally:
            super().tearDownClass()


class ServiceOfferingModelTest(NotificationPatchMixin, TestCase):
    """Tests for ServiceOffering model."""

    def setUp(self):
        self.start_notification_patchers()

    def test_create_offering(self):
        """Test creating a service offering."""
        offering = ServiceOffering.objects.create(
            code="TEST_SERVICE",
            name="Test Service",
            service_type="CONSULTING",
            base_price=Decimal("5000.00"),
            currency="INR",
            is_active=True,
        )

        self.assertEqual(offering.code, "TEST_SERVICE")
        self.assertEqual(offering.base_price, Decimal("5000.00"))
        self.assertTrue(offering.is_active)

    def test_offering_str(self):
        """Test string representation."""
        offering = ServiceOffering.objects.create(
            code="NPD_BASIC",
            name="Basic NPD",
            service_type="NPD",
        )
        self.assertIn("Basic NPD", str(offering))
        self.assertIn("NPD_BASIC", str(offering))


class ServiceRequestModelTest(NotificationPatchMixin, TestCase):
    """Tests for ServiceRequest model."""

    def setUp(self):
        self.start_notification_patchers()

        self.user = User.objects.create_user(
            username="testuser",
            email="test@example.com",
            password="testpass123",
        )
        self.offering = ServiceOffering.objects.create(
            code="PACKAGING_BASIC",
            name="Basic Packaging Design",
            service_type="PACKAGING_DESIGN",
            base_price=Decimal("10000.00"),
        )

    def test_create_service_request(self):
        """Test creating a service request."""
        sr = ServiceRequest.objects.create(
            user=self.user,
            offering=self.offering,
            title="My Packaging Request",
            description="Need packaging design for skincare product",
            status="AWAITING_PAYMENT",
            list_price=self.offering.base_price,
            final_price=self.offering.base_price,
        )

        self.assertEqual(sr.user, self.user)
        self.assertEqual(sr.offering, self.offering)
        self.assertEqual(sr.status, "AWAITING_PAYMENT")

        # Keep this flexible in case your model uses either UUID pk or separate reference_id
        self.assertIsNotNone(sr.pk)
        if hasattr(sr, "reference_id"):
            self.assertIsNotNone(sr.reference_id)

    def test_status_transition(self):
        """Test status transition and history logging."""
        sr = ServiceRequest.objects.create(
            user=self.user,
            offering=self.offering,
            title="Test Request",
            status="AWAITING_PAYMENT",
            list_price=Decimal("10000.00"),
            final_price=Decimal("10000.00"),
        )

        sr.transition_to("PAID", note="Payment received")

        self.assertEqual(sr.status, "PAID")

        history = ServiceRequestStatusHistory.objects.filter(request=sr)
        self.assertEqual(history.count(), 1)
        self.assertEqual(history.first().to_status, "PAID")


class ServiceReviewModelTest(NotificationPatchMixin, TestCase):
    def setUp(self):
        self.start_notification_patchers()
        self.admin_user = User.objects.create_user(
            username="review-admin",
            email="review-admin@example.com",
            password="testpass123",
        )

    def test_approve_review_sets_status_and_audit_fields(self):
        review = ServiceReview.objects.create(
            rating=5,
            review="Faoud helped us move clearly from requirement to factory discussions.",
            display_name="Asha",
            brand_name="Asha Naturals",
            email="asha@example.com",
        )

        review.approve(self.admin_user)

        self.assertEqual(review.status, ServiceReview.STATUS_APPROVED)
        self.assertEqual(review.approved_by, self.admin_user)
        self.assertIsNotNone(review.approved_at)

    def test_reject_review_removes_featured_flag(self):
        review = ServiceReview.objects.create(
            rating=4,
            review="The team was direct, practical, and clear throughout the process.",
            display_name="Rahul",
            brand_name="North Labs",
            email="rahul@example.com",
            is_featured=True,
        )

        review.reject()

        self.assertEqual(review.status, ServiceReview.STATUS_REJECTED)
        self.assertFalse(review.is_featured)


class ServicePaymentModelTest(NotificationPatchMixin, TestCase):
    """Tests for ServicePayment model."""

    def setUp(self):
        self.start_notification_patchers()

        self.user = User.objects.create_user(
            username="testuser",
            email="test@example.com",
            password="testpass123",
        )
        self.offering = ServiceOffering.objects.create(
            code="CONSULTING_BASIC",
            name="Basic Consulting",
            service_type="CONSULTING",
            base_price=Decimal("15000.00"),
        )
        self.service_request = ServiceRequest.objects.create(
            user=self.user,
            offering=self.offering,
            title="Consulting Request",
            status="AWAITING_PAYMENT",
            list_price=Decimal("15000.00"),
            final_price=Decimal("15000.00"),
        )

    def test_create_payment(self):
        """Test creating a service payment."""
        payment = ServicePayment.objects.create(
            service_request=self.service_request,
            user=self.user,
            amount=Decimal("15000.00"),
            currency="INR",
            status="CREATED",
        )

        self.assertEqual(payment.service_request, self.service_request)
        self.assertEqual(payment.amount, Decimal("15000.00"))
        self.assertEqual(payment.status, "CREATED")

    def test_mark_succeeded(self):
        """Test marking payment as succeeded."""
        payment = ServicePayment.objects.create(
            service_request=self.service_request,
            user=self.user,
            amount=Decimal("15000.00"),
            currency="INR",
            status="PENDING",
        )

        payment.mark_succeeded(
            payment_id="pay_test123",
            signature="sig_test123",
        )

        self.assertEqual(payment.status, "SUCCEEDED")
        self.assertEqual(payment.provider_payment_id, "pay_test123")
        self.assertIsNotNone(payment.paid_at)


class ServiceRequestAPITest(NotificationPatchMixin, APITestCase):
    """Tests for Service Request API endpoints."""

    def setUp(self):
        self.start_notification_patchers()

        self.user = User.objects.create_user(
            username="testuser",
            email="test@example.com",
            password="testpass123",
        )
        BrandOwner.objects.create(
            user=self.user,
            name="Test User",
            contact_email="test@example.com",
        )

        self.offering = ServiceOffering.objects.create(
            code="NPD_BASIC",
            name="Basic NPD Service",
            service_type="NPD",
            base_price=Decimal("25000.00"),
            is_active=True,
        )

        self.client = APIClient()

    def test_list_offerings_public(self):
        """Test listing service offerings (public endpoint)."""
        url = reverse("services:offering-list")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["code"], "NPD_BASIC")

    def test_offering_detail_public(self):
        """Test getting offering detail (public endpoint)."""
        url = reverse("services:offering-detail", kwargs={"code": "NPD_BASIC"})
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["name"], "Basic NPD Service")

    @override_settings(CAPTCHA_ENABLED=True, CAPTCHA_SECRET_KEY="test-secret")
    def test_create_service_review_requires_captcha(self):
        url = reverse("services:service-review-create")
        payload = {
            "rating": 5,
            "review": "Faoud gave us clear service and practical manufacturing guidance.",
            "display_name": "Meera Shah",
            "brand_name": "Meera Labs",
            "role_label": "Brand Owner",
            "email": "meera@example.com",
        }

        response = self.client.post(url, payload, format="json")

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(ServiceReview.objects.count(), 0)

    @override_settings(CAPTCHA_ENABLED=False)
    def test_create_service_review_with_local_test_token(self):
        url = reverse("services:service-review-create")
        payload = {
            "rating": 5,
            "review": "Faoud gave us clear service and practical manufacturing guidance.",
            "display_name": "Meera Shah",
            "brand_name": "Meera Labs",
            "role_label": "Brand Owner",
            "email": "MEERA@example.com",
            "captcha_token": "test-token",
        }

        response = self.client.post(url, payload, format="json")

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        review = ServiceReview.objects.get()
        self.assertEqual(review.status, ServiceReview.STATUS_PENDING)
        self.assertEqual(review.email, "meera@example.com")

    def test_public_service_reviews_only_returns_approved_featured_reviews(self):
        ServiceReview.objects.create(
            rating=5,
            review="Faoud helped us make progress without confusion or wasted calls.",
            display_name="Public Review",
            brand_name="Visible Brand",
            email="public@example.com",
            status=ServiceReview.STATUS_APPROVED,
            is_featured=True,
            display_order=1,
        )
        ServiceReview.objects.create(
            rating=5,
            review="This should not be visible because it is still pending.",
            display_name="Pending Review",
            brand_name="Hidden Brand",
            email="pending@example.com",
            status=ServiceReview.STATUS_PENDING,
            is_featured=True,
        )
        ServiceReview.objects.create(
            rating=5,
            review="This should not be visible because it is not featured.",
            display_name="Unfeatured Review",
            brand_name="Hidden Brand",
            email="hidden@example.com",
            status=ServiceReview.STATUS_APPROVED,
            is_featured=False,
        )

        response = self.client.get(reverse("services:service-review-public-list"))

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]["display_name"], "Public Review")
        self.assertNotIn("email", response.data[0])
        self.assertNotIn("phone", response.data[0])

    @patch("services.views.razorpay.Client")
    def test_create_service_request_authenticated(self, mock_razorpay):
        """Test creating a service request (authenticated user)."""
        mock_client = MagicMock()
        mock_razorpay.return_value = mock_client
        mock_client.order.create.return_value = {
            "id": "order_test123",
            "amount": 2500000,
            "currency": "INR",
        }

        self.client.force_authenticate(user=self.user)

        url = reverse("services:service-request-create")
        data = {
            "offering_code": "NPD_BASIC",
            "title": "My NPD Request",
            "description": "Need help with new product development",
            "desired_timeline": "2 weeks",
        }

        response = self.client.post(url, data, format="json")

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertIn("service_request_id", response.data)
        self.assertIn("razorpay_order_id", response.data)

        sr = ServiceRequest.objects.get(pk=response.data["service_request_id"])
        self.assertEqual(sr.user, self.user)
        self.assertEqual(sr.title, "My NPD Request")
        self.assertEqual(sr.status, "AWAITING_PAYMENT")

        self.assertTrue(hasattr(sr, "payment"))
        self.assertEqual(sr.payment.status, "PENDING")

    @patch("services.views.razorpay.Client")
    def test_create_service_request_public(self, mock_razorpay):
        """Test creating a service request (public form)."""
        mock_client = MagicMock()
        mock_razorpay.return_value = mock_client
        mock_client.order.create.return_value = {
            "id": "order_public123",
            "amount": 2500000,
            "currency": "INR",
        }

        url = reverse("services:service-request-public-create")
        data = {
            "email": "newuser@example.com",
            "name": "New User",
            "phone": "+919876543210",
            "offering_code": "NPD_BASIC",
            "title": "Public NPD Request",
            "description": "From public form",
        }

        response = self.client.post(url, data, format="json")

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertIn("service_request_id", response.data)
        self.assertIn("user_id", response.data)

        new_user = User.objects.get(email="newuser@example.com")
        self.assertTrue(hasattr(new_user, "brandowner"))

    def test_list_own_service_requests(self):
        """Test listing own service requests."""
        sr = ServiceRequest.objects.create(
            user=self.user,
            offering=self.offering,
            title="Test Request",
            status="IN_REVIEW",
            list_price=Decimal("25000.00"),
            final_price=Decimal("25000.00"),
        )

        self.client.force_authenticate(user=self.user)

        url = reverse("services:service-request-list")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

        returned_id = str(response.data["results"][0]["id"])
        self.assertEqual(returned_id, str(sr.id))

    def test_cannot_see_others_requests(self):
        """Test that users cannot see other users' requests."""
        other_user = User.objects.create_user(
            username="otheruser",
            email="other@example.com",
            password="otherpass123",
        )

        ServiceRequest.objects.create(
            user=other_user,
            offering=self.offering,
            title="Other User Request",
            status="IN_REVIEW",
            list_price=Decimal("25000.00"),
            final_price=Decimal("25000.00"),
        )

        self.client.force_authenticate(user=self.user)

        url = reverse("services:service-request-list")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 0)

    def test_get_service_request_detail(self):
        """Test getting service request detail."""
        sr = ServiceRequest.objects.create(
            user=self.user,
            offering=self.offering,
            title="Detail Test Request",
            status="IN_PROGRESS",
            list_price=Decimal("25000.00"),
            final_price=Decimal("25000.00"),
        )
        ServicePayment.objects.create(
            service_request=sr,
            user=self.user,
            amount=Decimal("25000.00"),
            status="SUCCEEDED",
        )

        self.client.force_authenticate(user=self.user)

        url = reverse("services:service-request-detail", kwargs={"pk": sr.id})
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["title"], "Detail Test Request")
        self.assertIn("payment", response.data)
        self.assertIn("offering", response.data)


@override_settings(MEDIA_ROOT="/tmp/shadow-api-test-media")
class FeedbackReportAPITest(NotificationPatchMixin, APITestCase):
    def setUp(self):
        self.start_notification_patchers()
        self.user = User.objects.create_user(
            username="feedbackuser",
            email="feedback@example.com",
            password="testpass123",
            first_name="Feed",
            last_name="Back",
        )
        BrandOwner.objects.create(
            user=self.user,
            name="Feedback User",
            contact_email="feedback@example.com",
        )
        self.client = APIClient()
        self.url = reverse("services:feedback-report-create")

    def test_feedback_report_requires_authentication(self):
        response = self.client.post(
            self.url,
            {"category": "bug", "page_path": "/dashboard", "message": "Broken CTA"},
            format="multipart",
        )
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_feedback_report_requires_message_or_screenshot(self):
        self.client.force_authenticate(user=self.user)
        response = self.client.post(
            self.url,
            {"category": "bug", "page_path": "/dashboard"},
            format="multipart",
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("non_field_errors", response.data)

    def test_feedback_report_uses_authenticated_user_as_source_of_truth(self):
        self.client.force_authenticate(user=self.user)
        screenshot = SimpleUploadedFile(
            "feedback.png",
            b"fake-image-bytes",
            content_type="image/png",
        )

        response = self.client.post(
            self.url,
            {
                "category": "feature",
                "page_path": "/cases/123",
                "page_url": "https://app.example.com/cases/123",
                "case_id": "CASE-123",
                "query_params": "tab=summary",
                "viewport_width": 1440,
                "viewport_height": 900,
                "browser_user_agent": "pytest-agent",
                "message": "Would like bulk actions here",
                "screenshot": screenshot,
                "user_id": 99999,
                "user_role": "spoofed",
                "user_name": "Spoofed Name",
                "user_email": "spoofed@example.com",
            },
            format="multipart",
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["status"], "submitted")
        self.assertIn("id", response.data)
        self.assertIn("created_at", response.data)

        report = FeedbackReport.objects.get(pk=response.data["id"])
        self.assertEqual(report.user, self.user)
        self.assertEqual(report.user_role, "brand_owner")
        self.assertEqual(report.user_name, "Feed Back")
        self.assertEqual(report.user_email, "feedback@example.com")
        self.assertEqual(report.category, "feature")
        self.assertTrue(report.screenshot.name.startswith("feedback_reports/"))

    @patch("services.signals.send_mail")
    @override_settings(DISABLE_NOTIFICATIONS=False)
    def test_feedback_report_sends_notification_email(self, mock_send_mail):
        self.client.force_authenticate(user=self.user)

        response = self.client.post(
            self.url,
            {
                "category": "bug",
                "page_path": "/dashboard",
                "message": "The save action is failing",
            },
            format="multipart",
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        mock_send_mail.assert_called_once()
        subject, body, from_email, recipients = mock_send_mail.call_args.args
        self.assertIn("bug", subject)
        self.assertIn("The save action is failing", body)
        self.assertEqual(from_email, "no-reply@faoud.com")
        self.assertEqual(recipients, ["jha@faoud.com"])


class PaymentWebhookTest(NotificationPatchMixin, APITestCase):
    """Tests for payment webhook handling."""

    def setUp(self):
        self.start_notification_patchers()

        self.user = User.objects.create_user(
            username="testuser",
            email="test@example.com",
            password="testpass123",
        )
        self.offering = ServiceOffering.objects.create(
            code="TEST_SERVICE",
            name="Test Service",
            base_price=Decimal("10000.00"),
        )
        self.service_request = ServiceRequest.objects.create(
            user=self.user,
            offering=self.offering,
            title="Webhook Test Request",
            status="AWAITING_PAYMENT",
            list_price=Decimal("10000.00"),
            final_price=Decimal("10000.00"),
        )
        self.payment = ServicePayment.objects.create(
            service_request=self.service_request,
            user=self.user,
            amount=Decimal("10000.00"),
            status="PENDING",
            provider_order_id="order_webhook_test",
        )

    @patch("payments.views.hmac")
    @override_settings(RAZORPAY_WEBHOOK_SECRET="test_secret")
    def test_webhook_payment_captured(self, mock_hmac):
        """Test webhook handles payment.captured event."""
        mock_hmac.new.return_value.hexdigest.return_value = "test_sig"
        mock_hmac.compare_digest.return_value = True

        url = reverse("payment_webhook")
        data = {
            "event": "payment.captured",
            "payload": {
                "payment": {
                    "entity": {
                        "order_id": "order_webhook_test",
                        "id": "pay_captured_123",
                    }
                }
            },
        }

        response = self.client.post(
            url,
            data,
            format="json",
            HTTP_X_RAZORPAY_SIGNATURE="test_sig",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.payment.refresh_from_db()
        self.service_request.refresh_from_db()

        self.assertEqual(self.payment.status, "SUCCEEDED")
        self.assertEqual(self.service_request.status, "IN_REVIEW")


class VerifyPaymentFallbackTest(NotificationPatchMixin, APITestCase):
    """Tests /api/verify-payment/ for service request payments."""

    def setUp(self):
        self.start_notification_patchers()

        self.user = User.objects.create_user(
            username="verifyuser",
            email="verify@example.com",
            password="testpass123",
        )
        self.offering = ServiceOffering.objects.create(
            code="VERIFY_SERVICE",
            name="Verify Service",
            base_price=Decimal("12000.00"),
        )
        self.service_request = ServiceRequest.objects.create(
            user=self.user,
            offering=self.offering,
            title="Verify Payment Request",
            status="AWAITING_PAYMENT",
            list_price=Decimal("12000.00"),
            final_price=Decimal("12000.00"),
        )
        self.payment = ServicePayment.objects.create(
            service_request=self.service_request,
            user=self.user,
            amount=Decimal("12000.00"),
            status="PENDING",
            provider_order_id="order_verify_service_1",
        )

    @patch("payments.views.razorpay.Client")
    def test_verify_payment_updates_service_payment(self, mock_client_cls):
        """Fallback verify endpoint should update ServicePayment fields."""
        mock_client = MagicMock()
        mock_client.utility.verify_payment_signature.return_value = None
        mock_client_cls.return_value = mock_client

        url = reverse("verify_payment")
        payload = {
            "razorpay_order_id": "order_verify_service_1",
            "razorpay_payment_id": "pay_service_123",
            "razorpay_signature": "sig_service_123",
        }

        response = self.client.post(url, payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.payment.refresh_from_db()
        self.service_request.refresh_from_db()

        self.assertEqual(self.payment.status, "SUCCEEDED")
        self.assertEqual(self.payment.provider_payment_id, "pay_service_123")
        self.assertEqual(self.payment.provider_signature, "sig_service_123")
        self.assertEqual(self.service_request.status, "IN_REVIEW")


class AdminAPITest(NotificationPatchMixin, APITestCase):
    """Tests for admin/internal API endpoints."""

    def setUp(self):
        self.start_notification_patchers()

        self.am_user = User.objects.create_user(
            username="amuser",
            email="am@example.com",
            password="ampass123",
        )
        self.am = AM.objects.create(
            user=self.am_user,
            name="Account Manager",
        )

        self.user = User.objects.create_user(
            username="testuser",
            email="test@example.com",
            password="testpass123",
        )
        BrandOwner.objects.create(
            user=self.user,
            name="Test User",
        )

        self.offering = ServiceOffering.objects.create(
            code="ADMIN_TEST",
            name="Admin Test Service",
            base_price=Decimal("5000.00"),
        )

        self.service_request = ServiceRequest.objects.create(
            user=self.user,
            offering=self.offering,
            title="Admin Test Request",
            status="IN_REVIEW",
            list_price=Decimal("5000.00"),
            final_price=Decimal("5000.00"),
        )

        self.client = APIClient()

    def test_admin_list_all_requests(self):
        """Test admin can list all service requests."""
        self.client.force_authenticate(user=self.am_user)

        url = reverse("services:service-request-admin-list")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    def test_admin_update_status(self):
        """Test admin can update service request status."""
        self.client.force_authenticate(user=self.am_user)

        url = reverse(
            "services:service-request-status-update",
            kwargs={"pk": self.service_request.id},
        )
        data = {
            "status": "IN_PROGRESS",
            "note": "Starting work on this request",
        }

        response = self.client.post(url, data, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.service_request.refresh_from_db()
        self.assertEqual(self.service_request.status, "IN_PROGRESS")

    def test_admin_assign_owner(self):
        """Test admin can assign internal owner."""
        self.client.force_authenticate(user=self.am_user)

        url = reverse(
            "services:service-request-assign-owner",
            kwargs={"pk": self.service_request.id},
        )
        data = {
            "internal_owner_id": self.am.id,
        }

        response = self.client.post(url, data, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.service_request.refresh_from_db()

        # If internal_owner is FK to AM, this is correct.
        self.assertEqual(self.service_request.internal_owner, self.am)

        # If internal_owner is FK to User instead, replace with:
        # self.assertEqual(self.service_request.internal_owner, self.am_user)

    def test_regular_user_cannot_access_admin(self):
        """Test regular user cannot access admin endpoints."""
        self.client.force_authenticate(user=self.user)

        url = reverse("services:service-request-admin-list")
        response = self.client.get(url)

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
