from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("services", "0002_feedbackreport"),
    ]

    operations = [
        migrations.CreateModel(
            name="ServiceReview",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("rating", models.PositiveSmallIntegerField(db_index=True)),
                ("review", models.TextField()),
                ("display_name", models.CharField(max_length=120)),
                ("brand_name", models.CharField(max_length=160)),
                ("role_label", models.CharField(blank=True, default="Brand Owner", max_length=80)),
                ("email", models.EmailField(max_length=254)),
                ("phone", models.CharField(blank=True, default="", max_length=30)),
                (
                    "status",
                    models.CharField(
                        choices=[
                            ("PENDING", "Pending"),
                            ("APPROVED", "Approved"),
                            ("REJECTED", "Rejected"),
                        ],
                        db_index=True,
                        default="PENDING",
                        max_length=20,
                    ),
                ),
                ("is_featured", models.BooleanField(db_index=True, default=False)),
                ("display_order", models.PositiveIntegerField(db_index=True, default=0)),
                ("source_page", models.CharField(blank=True, default="", max_length=255)),
                ("ip_address", models.GenericIPAddressField(blank=True, null=True)),
                ("user_agent", models.TextField(blank=True, default="")),
                ("admin_notes", models.TextField(blank=True, default="")),
                ("approved_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "approved_by",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="approved_service_reviews",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                "ordering": ["display_order", "-created_at"],
            },
        ),
        migrations.AddIndex(
            model_name="servicereview",
            index=models.Index(fields=["status", "is_featured", "display_order"], name="services_se_status_0864ce_idx"),
        ),
    ]
