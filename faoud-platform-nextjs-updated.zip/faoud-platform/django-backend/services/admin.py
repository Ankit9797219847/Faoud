"""
Service Request Admin Configuration

Follows existing admin patterns from case/admin.py and payments/admin.py
"""
from django.contrib import admin
from django.utils import timezone
from django.utils.html import format_html

from .models import (
    FeedbackReport,
    ServiceOffering,
    ServiceReview,
    ServiceRequest,
    ServiceRequestAttachment,
    ServiceRequestComment,
    ServiceRequestStatusHistory,
)


@admin.register(FeedbackReport)
class FeedbackReportAdmin(admin.ModelAdmin):
    list_display = [
        "id",
        "category",
        "user",
        "user_role",
        "page_path",
        "has_screenshot",
        "created_at",
    ]
    list_filter = ["category", "user_role", "created_at"]
    search_fields = [
        "user__username",
        "user__email",
        "user_name",
        "user_email",
        "page_path",
        "page_url",
        "case_id",
        "message",
    ]
    readonly_fields = [
        "user",
        "user_role",
        "user_name",
        "user_email",
        "created_at",
        "updated_at",
    ]
    raw_id_fields = ["user"]
    date_hierarchy = "created_at"

    def has_screenshot(self, obj):
        return bool(obj.screenshot)
    has_screenshot.boolean = True
    has_screenshot.short_description = "Screenshot"


@admin.register(ServiceReview)
class ServiceReviewAdmin(admin.ModelAdmin):
    list_display = [
        "id",
        "display_name",
        "brand_name",
        "rating",
        "status",
        "is_featured",
        "display_order",
        "created_at",
        "approved_at",
    ]
    list_filter = ["status", "is_featured", "rating", "created_at"]
    search_fields = ["display_name", "brand_name", "email", "phone", "review"]
    list_editable = ["is_featured", "display_order"]
    readonly_fields = [
        "ip_address",
        "user_agent",
        "created_at",
        "updated_at",
        "approved_by",
        "approved_at",
    ]
    actions = ["approve_reviews", "reject_reviews", "feature_reviews", "unfeature_reviews"]
    date_hierarchy = "created_at"
    fieldsets = (
        ("Public Review", {
            "fields": (
                "rating",
                "review",
                "display_name",
                "brand_name",
                "role_label",
                "status",
                "is_featured",
                "display_order",
            )
        }),
        ("Verification", {
            "fields": ("email", "phone", "source_page", "ip_address", "user_agent")
        }),
        ("Admin", {
            "fields": ("admin_notes", "approved_by", "approved_at", "created_at", "updated_at")
        }),
    )

    @admin.action(description="Approve selected reviews")
    def approve_reviews(self, request, queryset):
        updated = 0
        for review in queryset:
            review.approve(request.user)
            updated += 1
        self.message_user(request, f"{updated} review(s) approved.")

    def save_model(self, request, obj, form, change):
        if obj.status == ServiceReview.STATUS_APPROVED and not obj.approved_at:
            obj.approved_at = timezone.now()
            obj.approved_by = request.user
        if obj.status != ServiceReview.STATUS_APPROVED:
            obj.is_featured = False
        super().save_model(request, obj, form, change)

    @admin.action(description="Reject selected reviews")
    def reject_reviews(self, request, queryset):
        updated = 0
        for review in queryset:
            review.reject()
            updated += 1
        self.message_user(request, f"{updated} review(s) rejected.")

    @admin.action(description="Feature selected reviews")
    def feature_reviews(self, request, queryset):
        updated = queryset.filter(status=ServiceReview.STATUS_APPROVED).update(is_featured=True)
        self.message_user(request, f"{updated} approved review(s) featured.")

    @admin.action(description="Unfeature selected reviews")
    def unfeature_reviews(self, request, queryset):
        updated = queryset.update(is_featured=False)
        self.message_user(request, f"{updated} review(s) unfeatured.")


@admin.register(ServiceOffering)
class ServiceOfferingAdmin(admin.ModelAdmin):
    list_display = [
        'code',
        'name',
        'service_type',
        'base_price',
        'currency',
        'is_active',
        'sort_order',
    ]
    list_filter = ['service_type', 'is_active', 'currency']
    search_fields = ['code', 'name', 'description']
    ordering = ['sort_order', 'name']
    list_editable = ['is_active', 'sort_order', 'base_price']
    
    fieldsets = (
        (None, {
            'fields': ('code', 'name', 'service_type', 'description')
        }),
        ('Pricing', {
            'fields': ('base_price', 'currency')
        }),
        ('Settings', {
            'fields': ('is_active', 'estimated_timeline_days', 'sort_order')
        }),
    )


class ServiceRequestAttachmentInline(admin.TabularInline):
    model = ServiceRequestAttachment
    extra = 0
    readonly_fields = ['uploaded_by', 'created_at']


class ServiceRequestCommentInline(admin.TabularInline):
    model = ServiceRequestComment
    extra = 0
    readonly_fields = ['author', 'author_type', 'created_at']


class ServiceRequestStatusHistoryInline(admin.TabularInline):
    model = ServiceRequestStatusHistory
    extra = 0
    readonly_fields = ['from_status', 'to_status', 'changed_by', 'note', 'created_at']
    ordering = ['-created_at']


@admin.register(ServiceRequest)
class ServiceRequestAdmin(admin.ModelAdmin):
    list_display = [
        'id',
        'reference_id_short',
        'title',
        'user_email',
        'offering_name',
        'status_badge',
        'final_price',
        'internal_owner',
        'created_at',
    ]
    list_filter = ['status', 'offering', 'created_from', 'created_at']
    search_fields = [
        'title',
        'reference_id',
        'user__email',
        'user__username',
        'description',
    ]
    ordering = ['-created_at']
    date_hierarchy = 'created_at'
    raw_id_fields = ['user', 'internal_owner']
    readonly_fields = [
        'reference_id',
        'list_price',
        'final_price',
        'created_at',
        'updated_at',
        'delivered_at',
        'closed_at',
    ]
    
    inlines = [
        ServiceRequestStatusHistoryInline,
        ServiceRequestAttachmentInline,
        ServiceRequestCommentInline,
    ]
    
    fieldsets = (
        ('Basic Info', {
            'fields': (
                'reference_id',
                'user',
                'offering',
                'title',
                'description',
                'category',
            )
        }),
        ('Status & Assignment', {
            'fields': (
                'status',
                'internal_owner',
                'created_from',
            )
        }),
        ('Budget & Timeline', {
            'fields': (
                'budget_min',
                'budget_max',
                'desired_timeline',
            )
        }),
        ('Pricing', {
            'fields': (
                'currency',
                'list_price',
                'final_price',
                'promo_code',
            )
        }),
        ('Dates', {
            'fields': (
                'created_at',
                'updated_at',
                'delivered_at',
                'closed_at',
            ),
            'classes': ['collapse']
        }),
        ('Internal Notes', {
            'fields': ('notes',),
            'classes': ['collapse']
        }),
    )
    
    def reference_id_short(self, obj):
        return str(obj.reference_id)[:8] + '...'
    reference_id_short.short_description = 'Reference'
    
    def user_email(self, obj):
        return obj.user.email
    user_email.short_description = 'User'
    
    def offering_name(self, obj):
        return obj.offering.name if obj.offering else '-'
    offering_name.short_description = 'Offering'
    
    def status_badge(self, obj):
        colors = {
            'DRAFT': 'gray',
            'AWAITING_PAYMENT': 'orange',
            'PAID': 'blue',
            'IN_REVIEW': 'purple',
            'IN_PROGRESS': 'teal',
            'DELIVERED': 'green',
            'CLOSED': 'darkgreen',
            'CANCELLED': 'red',
        }
        color = colors.get(obj.status, 'gray')
        return format_html(
            '<span style="color: {}; font-weight: bold;">{}</span>',
            color,
            obj.get_status_display()
        )
    status_badge.short_description = 'Status'
    
    actions = ['mark_in_progress', 'mark_delivered']
    
    @admin.action(description="Mark selected as In Progress")
    def mark_in_progress(self, request, queryset):
        updated = 0
        for sr in queryset.filter(status__in=['PAID', 'IN_REVIEW']):
            sr.transition_to('IN_PROGRESS', changed_by=request.user, note='Bulk action from admin')
            updated += 1
        self.message_user(request, f"{updated} service request(s) marked as In Progress.")
    
    @admin.action(description="Mark selected as Delivered")
    def mark_delivered(self, request, queryset):
        updated = 0
        for sr in queryset.filter(status='IN_PROGRESS'):
            sr.transition_to('DELIVERED', changed_by=request.user, note='Bulk action from admin')
            updated += 1
        self.message_user(request, f"{updated} service request(s) marked as Delivered.")


@admin.register(ServiceRequestAttachment)
class ServiceRequestAttachmentAdmin(admin.ModelAdmin):
    list_display = ['id', 'request', 'original_filename', 'uploaded_by', 'created_at']
    list_filter = ['created_at']
    search_fields = ['original_filename', 'request__title']
    raw_id_fields = ['request', 'uploaded_by']


@admin.register(ServiceRequestComment)
class ServiceRequestCommentAdmin(admin.ModelAdmin):
    list_display = ['id', 'request', 'author', 'author_type', 'message_preview', 'created_at']
    list_filter = ['author_type', 'created_at']
    search_fields = ['message', 'request__title']
    raw_id_fields = ['request', 'author']
    
    def message_preview(self, obj):
        return obj.message[:50] + '...' if len(obj.message) > 50 else obj.message
    message_preview.short_description = 'Message'


@admin.register(ServiceRequestStatusHistory)
class ServiceRequestStatusHistoryAdmin(admin.ModelAdmin):
    list_display = ['id', 'request', 'from_status', 'to_status', 'changed_by', 'created_at']
    list_filter = ['to_status', 'created_at']
    search_fields = ['request__title', 'note']
    raw_id_fields = ['request', 'changed_by']
    ordering = ['-created_at']
