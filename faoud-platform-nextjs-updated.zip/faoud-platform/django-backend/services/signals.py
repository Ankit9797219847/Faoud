# services/signals.py
"""
Signals for Service Requests:
- Creates LeadItem entries for new ServiceRequest instances
- Sends notifications to brand owners and internal staff on key events
"""

import logging
from decimal import Decimal, InvalidOperation
from datetime import timedelta

from django.conf import settings
from django.core.mail import send_mail
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
from django.utils.text import Truncator
from django.contrib.contenttypes.models import ContentType

from services.models import FeedbackReport, ServiceRequest, ServiceRequestStatusHistory
from leads.models import LeadItem
from user.models import AM
from notifications.notif import send_notification

logger = logging.getLogger(__name__)


def _as_decimal(value):
    if value in (None, ""):
        return None
    if isinstance(value, Decimal):
        return value
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None


def _trunc(text: str, n=255) -> str:
    """Truncate text to n characters."""
    return Truncator(text or '').chars(n)


def get_am_name(service_request):
    """Return the internal owner's name or a default."""
    try:
        if service_request.internal_owner:
            return service_request.internal_owner.name or "Rutuja"
    except Exception:
        pass
    return "Rutuja"


def get_am_phone(service_request):
    """Return the internal owner's phone or a default."""
    try:
        if service_request.internal_owner:
            phone = getattr(service_request.internal_owner, 'contact_phone', None)
            if phone:
                return phone
    except Exception:
        pass
    return "+91 8999292034"


def schedule_notification(scheduled_time, channels, template_name, context, users, notification_type):
    """
    Schedules a call to send_notification at the given scheduled_time.
    Uses threading.Timer for delayed execution.
    """
    import threading
    if getattr(settings, "DISABLE_NOTIFICATIONS", False):
        return

    try:
        delay = (scheduled_time - timezone.now()).total_seconds()
        if delay < 0:
            delay = 0


        def safe_send():
            try:
                send_notification(
                    channels=channels,
                    template_name=template_name,
                    context=context,
                    users=users,
                    notification_type=notification_type,
                    whatsapp_params=context.get('whatsapp_params', None)
                )
            except Exception as e:
                logger.error(f"[Error in send_notification for ServiceRequest] {str(e)}")

        threading.Timer(delay, safe_send).start()

    except Exception as e:
        logger.error(f"[Error in schedule_notification for ServiceRequest] {str(e)}")


def upsert_lead_for_service_request(
    source_obj,
    *,
    tag: str,
    title: str,
    subtitle: str,
    contact_email=None,
    contact_phone=None,
    default_status='new',
    default_priority=2,
    notes="",
    created_by=None,
):
    """
    Idempotent creation/update of a LeadItem for a ServiceRequest.
    """
    ct = ContentType.objects.get_for_model(source_obj.__class__)
    li, created = LeadItem.objects.get_or_create(
        source_ct=ct,
        source_id=source_obj.pk,
        defaults=dict(
            tag=tag,
            title=_trunc(title),
            subtitle=_trunc(subtitle),
            contact_email=contact_email,
            contact_phone=contact_phone,
            status=default_status,
            priority=default_priority,
            active=True,
            notes=notes if isinstance(notes, str) else "\n".join(notes) if notes else "",
            created_by=created_by if created_by else None,
        ),
    )
    if not created:
        changed = False
        # Opportunistically set created_by if provided and not already set
        if created_by and getattr(li, 'created_by_id', None) is None:
            li.created_by = created_by
            changed = True
        for fld, val in [
            ('tag', tag),
            ('title', _trunc(title)),
            ('subtitle', _trunc(subtitle)),
            ('contact_email', contact_email),
            ('contact_phone', contact_phone),
            ('notes', notes if isinstance(notes, str) else "\n".join(notes) if notes else ""),
        ]:
            if getattr(li, fld) != val:
                setattr(li, fld, val)
                changed = True
        if not li.active:
            li.active = True
            changed = True
        if changed:
            li.save(update_fields=[
                'tag', 'title', 'subtitle', 'contact_email', 
                'contact_phone', 'active', 'updated_at', 'notes', 'created_by'
            ])
    return li


# -------------------------
# ServiceRequest -> Lead
# -------------------------
@receiver(post_save, sender=ServiceRequest, dispatch_uid="services.lead_from_service_request.v1")
def lead_from_service_request(sender, instance: ServiceRequest, created, **kwargs):
    """
    Create/update a LeadItem when a ServiceRequest is created or updated.
    """
    try:
        user = instance.user
        offering = instance.offering

        title = f"Service Request: {instance.title or 'Unnamed Request'}"
        
        bits = []
        if offering:
            bits.append(offering.name)
        if user:
            user_name = getattr(user, 'first_name', '') or getattr(user, 'email', 'User')
            bits.append(user_name)
        if instance.status:
            bits.append(instance.status)
        if instance.final_price:
            bits.append(f"₹{instance.final_price}")

        subtitle = " · ".join(bits)

        # Build notes with request details
        notes_parts = []
        if offering:
            notes_parts.append(f"Service: {offering.name} ({offering.service_type})")
        if instance.description:
            notes_parts.append(f"Description: {_trunc(instance.description, 200)}")
        if instance.budget_min or instance.budget_max:
            budget_str = f"Budget: ₹{instance.budget_min or 0} - ₹{instance.budget_max or 'N/A'}"
            notes_parts.append(budget_str)
        if instance.desired_timeline:
            notes_parts.append(f"Timeline: {instance.desired_timeline}")
        if instance.created_from:
            notes_parts.append(f"Source: {instance.created_from}")

        # Get contact info from user's profile
        contact_email = getattr(user, 'email', None)
        contact_phone = None
        try:
            if hasattr(user, 'brandowner'):
                contact_phone = getattr(user.brandowner, 'contact_phone', None)
            elif hasattr(user, 'factoryowner'):
                contact_phone = getattr(user.factoryowner, 'contact_phone', None)
        except Exception:
            pass

        # Determine priority based on price
        priority = 2
        final_price = _as_decimal(instance.final_price)
        if final_price is not None and final_price > Decimal("50000"):
            priority = 1
        elif final_price is not None and final_price < Decimal("10000"):
            priority = 3

        upsert_lead_for_service_request(
            instance,
            tag='service_request',
            title=title,
            subtitle=subtitle,
            contact_email=contact_email,
            contact_phone=contact_phone,
            default_priority=priority,
            notes=notes_parts if notes_parts else "",
            created_by=user,
        )

    except Exception as e:
        logger.exception(f"[lead_from_service_request] Error creating lead for ServiceRequest {instance.pk}: {str(e)}")


@receiver(post_save, sender=FeedbackReport, dispatch_uid="services.email_on_feedback_report.v1")
def email_on_feedback_report(sender, instance: FeedbackReport, created, **kwargs):
    if not created or getattr(settings, "DISABLE_NOTIFICATIONS", False):
        return

    recipient_email = getattr(
        settings,
        "FEEDBACK_REPORT_NOTIFICATION_EMAIL",
        "jha@faoud.com",
    )
    if not recipient_email:
        return

    screenshot_ref = ""
    if instance.screenshot:
        try:
            screenshot_ref = instance.screenshot.url
        except Exception:
            screenshot_ref = instance.screenshot.name

    subject = f"[Faoud] New {instance.category} feedback report #{instance.pk}"
    lines = [
        f"Feedback report #{instance.pk} was submitted.",
        f"Category: {instance.category}",
        f"Created at: {instance.created_at.isoformat()}",
        f"User: {instance.user_name or instance.user.username} ({instance.user_email or instance.user.email})",
        f"User role: {instance.user_role or 'unknown'}",
        f"Page path: {instance.page_path}",
        f"Page URL: {instance.page_url or '-'}",
        f"Case ID: {instance.case_id or '-'}",
        f"Query params: {instance.query_params or '-'}",
        f"Viewport: {instance.viewport_width or '-'} x {instance.viewport_height or '-'}",
        f"Browser user agent: {instance.browser_user_agent or '-'}",
        f"Message: {instance.message or '-'}",
        f"Screenshot: {screenshot_ref or '-'}",
    ]
    message = "\n".join(lines)

    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [recipient_email],
            fail_silently=False,
        )
    except Exception:
        logger.exception(
            "[email_on_feedback_report] Failed to send feedback notification for FeedbackReport %s",
            instance.pk,
        )


# -------------------------
# ServiceRequest -> Notifications
# -------------------------
@receiver(post_save, sender=ServiceRequest, dispatch_uid="services.notify_service_request.v1")
def notify_on_service_request(sender, instance: ServiceRequest, created, **kwargs):
    """
    Send notifications when a ServiceRequest is created.
    - Notify the user (brand owner) about their request
    - Notify internal staff (AMs) about the new request
    """
    try:
        if created:
            now = timezone.now()
            user = instance.user
            offering = instance.offering

            # 1. Notify the user who created the request
            if user:
                scheduled_time = now + timedelta(seconds=5)
                context = {
                    'user': getattr(user, 'first_name', '') or 'Valued Customer',
                    'service_name': offering.name if offering else 'Service',
                    'request_title': instance.title or 'Your Request',
                    'reference_id': str(instance.reference_id),
                    'am_name': get_am_name(instance),
                    'am_phone': get_am_phone(instance),
                    'whatsapp_params': [
                        instance.title or "Your Service Request",
                        offering.name if offering else "Service",
                        str(instance.reference_id),
                        get_am_name(instance),
                    ],
                }
                schedule_notification(
                    scheduled_time=scheduled_time,
                    channels=['email'],
                    template_name='service_request_received',
                    context=context,
                    users=[user],
                    notification_type='operational'
                )

            # 2. Notify all AMs about the new service request
            account_manager_users = [am.user for am in AM.objects.filter(is_active=True) if am.user]
            if account_manager_users:
                user_name = getattr(user, 'first_name', '') or getattr(user, 'email', 'Unknown') if user else 'Unknown'
                message = (
                    f"A new service request has been created:\n"
                    f"• Reference ID: {instance.reference_id}\n"
                    f"• Title: {instance.title or 'Unnamed'}\n"
                    f"• Service: {offering.name if offering else 'N/A'}\n"
                    f"• User: {user_name}\n"
                    f"• Price: ₹{instance.final_price}\n"
                    f"• Status: {instance.status}\n"
                    f"Please review and take necessary action."
                )
                schedule_notification(
                    scheduled_time=now,
                    channels=['email'],
                    template_name='default_body_email',
                    context={'message': message, 'subject': 'New Service Request Created'},
                    users=account_manager_users,
                    notification_type='operational'
                )

    except Exception as e:
        logger.exception(f"[notify_on_service_request] Error sending notification for ServiceRequest {instance.pk}: {str(e)}")


# -------------------------
# ServiceRequestStatusHistory -> Status Change Notifications
# -------------------------
@receiver(post_save, sender=ServiceRequestStatusHistory, dispatch_uid="services.notify_status_change.v1")
def notify_on_status_change(sender, instance: ServiceRequestStatusHistory, created, **kwargs):
    """
    Send notifications when a ServiceRequest status changes.
    """
    try:
        if created:
            request = instance.request
            user = request.user
            now = timezone.now()

            # Only notify on significant status changes
            notify_statuses = ['PAID', 'IN_PROGRESS', 'DELIVERED', 'CANCELLED']
            
            if instance.to_status in notify_statuses and user:
                status_messages = {
                    'PAID': 'Your payment has been received! Our team will begin working on your request shortly.',
                    'IN_PROGRESS': 'Great news! Work has started on your service request.',
                    'DELIVERED': 'Your service request has been completed and delivered!',
                    'CANCELLED': 'Your service request has been cancelled. If you have questions, please contact us.',
                }

                context = {
                    'user': getattr(user, 'first_name', '') or 'Valued Customer',
                    'request_title': request.title or 'Your Request',
                    'reference_id': str(request.reference_id),
                    'status': instance.to_status,
                    'status_message': status_messages.get(instance.to_status, f'Status updated to {instance.to_status}'),
                    'am_name': get_am_name(request),
                    'am_phone': get_am_phone(request),
                    'whatsapp_params': [
                        request.title or "Your Service Request",
                        instance.to_status,
                        str(request.reference_id),
                    ],
                }

                schedule_notification(
                    scheduled_time=now + timedelta(seconds=5),
                    channels=['email'],
                    template_name='service_request_status_update',
                    context=context,
                    users=[user],
                    notification_type='operational'
                )

                # Log the notification
                logger.info(
                    f"[notify_on_status_change] Sent status update notification for ServiceRequest "
                    f"{request.pk} - {instance.from_status} -> {instance.to_status}"
                )

    except Exception as e:
        logger.exception(f"[notify_on_status_change] Error sending status change notification: {str(e)}")
