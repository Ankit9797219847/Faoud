"""
Service Requests Models

This module defines models for the Service Requests system for paid services
(consulting, NPD, packaging design, compliance, etc.) with upfront payment
and dashboard tracking.

Patterns reused from existing codebase:
- Status choices pattern from Case, Order models
- User FK pattern from BrandOwner, FactoryOwner
- UUID pattern (optional, keeping int PK for consistency with Case)
- Internal owner/assignee from Case.am pattern
"""
import uuid
from decimal import Decimal
from django.db import models
from django.conf import settings
from django.utils import timezone

from user.utils import get_role


def feedback_screenshot_upload_to(instance, filename):
    return f"feedback_reports/{timezone.now():%Y/%m}/{filename}"


class ServiceOffering(models.Model):
    """
    Catalog of available services (NPD, Packaging Design, Consulting, etc.)
    Similar pattern to Feature model in payments app.
    """
    SERVICE_TYPE_CHOICES = [
        ('NPD', 'New Product Development'),
        ('PACKAGING_DESIGN', 'Packaging Design'),
        ('CONSULTING', 'Consulting'),
        ('COMPLIANCE', 'Compliance'),
        ('CUSTOM', 'Custom Service'),
    ]

    code = models.CharField(
        max_length=50, 
        unique=True, 
        db_index=True,
        help_text="Unique code e.g. PACKAGING_BASIC"
    )
    name = models.CharField(max_length=255)
    service_type = models.CharField(
        max_length=30, 
        choices=SERVICE_TYPE_CHOICES, 
        default='CUSTOM'
    )
    description = models.TextField(blank=True, default='')
    currency = models.CharField(max_length=10, default='INR')
    base_price = models.DecimalField(
        max_digits=15, 
        decimal_places=2, 
        default=Decimal('0.00')
    )
    is_active = models.BooleanField(default=True, db_index=True)
    estimated_timeline_days = models.PositiveIntegerField(
        null=True, 
        blank=True,
        help_text="Estimated days to deliver"
    )
    sort_order = models.PositiveIntegerField(
        default=0, 
        help_text="Order for UI display"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['sort_order', 'name']
        verbose_name = 'Service Offering'
        verbose_name_plural = 'Service Offerings'

    def __str__(self):
        return f"{self.name} ({self.code})"


class ServiceRequest(models.Model):
    """
    Represents one user's request for a specific ServiceOffering.
    Modeled after Case patterns: status, timestamps, internal owner (AM).
    """
    STATUS_CHOICES = [
        ('DRAFT', 'Draft'),
        ('AWAITING_PAYMENT', 'Awaiting Payment'),
        ('PAID', 'Paid'),
        ('IN_REVIEW', 'In Review'),
        ('IN_PROGRESS', 'In Progress'),
        ('DELIVERED', 'Delivered'),
        ('CLOSED', 'Closed'),
        ('CANCELLED', 'Cancelled'),
    ]

    CREATED_FROM_CHOICES = [
        ('WEB', 'Website Public Form'),
        ('DASHBOARD', 'User Dashboard'),
        ('ADMIN', 'Admin Panel'),
    ]

    # UUID for external reference (similar to Order.order_id pattern)
    reference_id = models.UUIDField(
        default=uuid.uuid4, 
        editable=False, 
        unique=True,
        help_text="Public reference ID"
    )
    
    # User and offering links
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='service_requests'
    )
    offering = models.ForeignKey(
        ServiceOffering,
        on_delete=models.PROTECT,
        related_name='requests'
    )
    
    # Request details
    title = models.CharField(max_length=255, help_text="Short label for the request")
    description = models.TextField(blank=True, default='')
    category = models.CharField(
        max_length=100, 
        blank=True, 
        default='',
        help_text="Simple category string"
    )
    
    # Budget and timeline
    budget_min = models.DecimalField(
        max_digits=15, 
        decimal_places=2, 
        null=True, 
        blank=True
    )
    budget_max = models.DecimalField(
        max_digits=15, 
        decimal_places=2, 
        null=True, 
        blank=True
    )
    desired_timeline = models.CharField(
        max_length=100, 
        blank=True, 
        default='',
        help_text="e.g. 'ASAP', '2 weeks', '1 month'"
    )
    
    # Status
    status = models.CharField(
        max_length=20, 
        choices=STATUS_CHOICES, 
        default='AWAITING_PAYMENT',
        db_index=True
    )
    
    # Pricing snapshot
    currency = models.CharField(max_length=10, default='INR')
    list_price = models.DecimalField(
        max_digits=15, 
        decimal_places=2, 
        default=Decimal('0.00'),
        help_text="Original price from offering"
    )
    final_price = models.DecimalField(
        max_digits=15, 
        decimal_places=2, 
        default=Decimal('0.00'),
        help_text="Price after promo"
    )
    promo_code = models.CharField(
        max_length=50, 
        blank=True, 
        null=True,
        help_text="Applied promo code"
    )
    
    # Internal management (similar to Case.am pattern)
    internal_owner = models.ForeignKey(
        'user.AM',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_service_requests',
        help_text="Internal staff owner"
    )
    
    # Important dates
    delivered_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    
    # Metadata
    created_from = models.CharField(
        max_length=20,
        choices=CREATED_FROM_CHOICES,
        default='DASHBOARD'
    )
    notes = models.TextField(blank=True, default='', help_text="Internal notes")
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Service Request'
        verbose_name_plural = 'Service Requests'
        indexes = [
            models.Index(fields=['user', 'status']),
            models.Index(fields=['status', 'created_at']),
        ]

    def __str__(self):
        return f"ServiceRequest#{self.pk} - {self.title} ({self.status})"

    def transition_to(self, new_status, changed_by=None, note=''):
        """
        Transition to a new status and log the change.
        """
        old_status = self.status
        self.status = new_status
        
        # Update related timestamps
        if new_status == 'DELIVERED':
            self.delivered_at = timezone.now()
        elif new_status in ('CLOSED', 'CANCELLED'):
            self.closed_at = timezone.now()
        
        self.save()
        
        # Log status change
        ServiceRequestStatusHistory.objects.create(
            request=self,
            from_status=old_status,
            to_status=new_status,
            changed_by=changed_by,
            note=note
        )
        return self


class ServiceRequestAttachment(models.Model):
    """
    Attachments for service requests.
    Similar pattern to document uploads elsewhere in codebase.
    """
    request = models.ForeignKey(
        ServiceRequest,
        on_delete=models.CASCADE,
        related_name='attachments'
    )
    file = models.FileField(upload_to='service_request_attachments/%Y/%m/')
    original_filename = models.CharField(max_length=255, blank=True, default='')
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='uploaded_service_attachments'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Service Request Attachment'
        verbose_name_plural = 'Service Request Attachments'

    def __str__(self):
        return f"Attachment for ServiceRequest#{self.request_id}"

    def save(self, *args, **kwargs):
        if not self.original_filename and self.file:
            self.original_filename = self.file.name
        super().save(*args, **kwargs)


class ServiceRequestComment(models.Model):
    """
    Comment thread between user and internal team.
    Similar to Alert model pattern in case app.
    """
    AUTHOR_TYPE_CHOICES = [
        ('USER', 'User'),
        ('INTERNAL', 'Internal Team'),
    ]

    request = models.ForeignKey(
        ServiceRequest,
        on_delete=models.CASCADE,
        related_name='comments'
    )
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='service_request_comments'
    )
    author_type = models.CharField(
        max_length=20,
        choices=AUTHOR_TYPE_CHOICES,
        default='USER'
    )
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']
        verbose_name = 'Service Request Comment'
        verbose_name_plural = 'Service Request Comments'

    def __str__(self):
        return f"Comment on ServiceRequest#{self.request_id} by {self.author_type}"


class ServiceRequestStatusHistory(models.Model):
    """
    Status change history for audit trail.
    Similar to ProgressStage pattern in case app.
    """
    request = models.ForeignKey(
        ServiceRequest,
        on_delete=models.CASCADE,
        related_name='status_history'
    )
    from_status = models.CharField(max_length=20, blank=True, default='')
    to_status = models.CharField(max_length=20)
    changed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='service_status_changes'
    )
    note = models.TextField(blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Service Request Status History'
        verbose_name_plural = 'Service Request Status Histories'

    def __str__(self):
        return f"Status change: {self.from_status} → {self.to_status} for ServiceRequest#{self.request_id}"


class FeedbackReport(models.Model):
    CATEGORY_BUG = "bug"
    CATEGORY_FEATURE = "feature"
    CATEGORY_CHOICES = [
        (CATEGORY_BUG, "Bug"),
        (CATEGORY_FEATURE, "Feature"),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="feedback_reports",
    )
    user_role = models.CharField(max_length=50, blank=True, default="", db_index=True)
    user_name = models.CharField(max_length=255, blank=True, default="")
    user_email = models.EmailField(blank=True, default="")
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, db_index=True)
    message = models.TextField(blank=True, default="")
    page_path = models.CharField(max_length=1024)
    page_url = models.CharField(max_length=2048, blank=True, default="")
    case_id = models.CharField(max_length=255, blank=True, default="")
    query_params = models.TextField(blank=True, default="")
    viewport_width = models.PositiveIntegerField(null=True, blank=True)
    viewport_height = models.PositiveIntegerField(null=True, blank=True)
    browser_user_agent = models.TextField(blank=True, default="")
    screenshot = models.FileField(
        upload_to=feedback_screenshot_upload_to,
        null=True,
        blank=True,
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["category", "created_at"]),
        ]

    def __str__(self):
        return f"FeedbackReport#{self.pk} {self.category} by {self.user_id}"

    def save(self, *args, **kwargs):
        if self.user_id:
            self.user_role = get_role(self.user)
            self.user_name = self.user.get_full_name() or self.user.username or ""
            self.user_email = self.user.email or ""
        super().save(*args, **kwargs)


class ServiceReview(models.Model):
    STATUS_PENDING = "PENDING"
    STATUS_APPROVED = "APPROVED"
    STATUS_REJECTED = "REJECTED"
    STATUS_CHOICES = [
        (STATUS_PENDING, "Pending"),
        (STATUS_APPROVED, "Approved"),
        (STATUS_REJECTED, "Rejected"),
    ]

    rating = models.PositiveSmallIntegerField(db_index=True)
    review = models.TextField()
    display_name = models.CharField(max_length=120)
    brand_name = models.CharField(max_length=160)
    role_label = models.CharField(max_length=80, blank=True, default="Brand Owner")
    email = models.EmailField()
    phone = models.CharField(max_length=30, blank=True, default="")
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_PENDING,
        db_index=True,
    )
    is_featured = models.BooleanField(default=False, db_index=True)
    display_order = models.PositiveIntegerField(default=0, db_index=True)
    source_page = models.CharField(max_length=255, blank=True, default="")
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True, default="")
    admin_notes = models.TextField(blank=True, default="")
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="approved_service_reviews",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["display_order", "-created_at"]
        indexes = [
            models.Index(fields=["status", "is_featured", "display_order"]),
        ]

    def __str__(self):
        return f"{self.display_name} - {self.brand_name} ({self.rating}/5)"

    def approve(self, user=None):
        self.status = self.STATUS_APPROVED
        self.approved_by = user
        self.approved_at = timezone.now()
        self.save(update_fields=["status", "approved_by", "approved_at", "updated_at"])

    def reject(self):
        self.status = self.STATUS_REJECTED
        self.is_featured = False
        self.save(update_fields=["status", "is_featured", "updated_at"])
