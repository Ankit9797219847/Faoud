"""
Service Request URL Configuration

Follows existing URL patterns from case/urls.py and payments/urls.py.
"""
from django.urls import path

from .views import (
    FeedbackReportCreateView,
    ServiceReviewCreateView,
    ServiceReviewPublicListView,
    # Service Offerings
    ServiceOfferingListView,
    ServiceOfferingDetailView,
    # Service Requests - User
    ServiceRequestListView,
    ServiceRequestDetailView,
    ServiceRequestCreateView,
    # Service Requests - Public
    ServiceRequestPublicCreateView,
    # Payment
    ServicePaymentVerifyView,
    ServicePaymentStatusView,
    ServiceRetryPaymentView,
    # Admin/Internal
    ServiceRequestAdminListView,
    ServiceRequestAdminDetailView,
    ServiceRequestStatusUpdateView,
    ServiceRequestAssignOwnerView,
    ServiceRequestBrandOwnerView,
    # Attachments & Comments
    ServiceRequestAttachmentUploadView,
    ServiceRequestCommentCreateView,
    ServiceRequestCommentListView,
)

app_name = 'services'

urlpatterns = [
    path(
        'feedback-reports/',
        FeedbackReportCreateView.as_view(),
        name='feedback-report-create'
    ),
    path(
        'service-reviews/',
        ServiceReviewCreateView.as_view(),
        name='service-review-create'
    ),
    path(
        'service-reviews/public/',
        ServiceReviewPublicListView.as_view(),
        name='service-review-public-list'
    ),
    # -------------------------------------------------------------------------
    # Service Offerings (Public)
    # -------------------------------------------------------------------------
    path(
        'service-offerings/',
        ServiceOfferingListView.as_view(),
        name='offering-list'
    ),
    path(
        'service-offerings/<str:code>/',
        ServiceOfferingDetailView.as_view(),
        name='offering-detail'
    ),
    
    # -------------------------------------------------------------------------
    # Service Requests - Public
    # -------------------------------------------------------------------------
    path(
        'service-requests/public/',
        ServiceRequestPublicCreateView.as_view(),
        name='service-request-public-create'
    ),
    
    # -------------------------------------------------------------------------
    # Service Requests - Authenticated User
    # -------------------------------------------------------------------------
    path(
        'service-requests/',
        ServiceRequestListView.as_view(),
        name='service-request-list'
    ),
    path(
        'service-requests/create/',
        ServiceRequestCreateView.as_view(),
        name='service-request-create'
    ),
    path(
        'service-requests/<int:pk>/',
        ServiceRequestDetailView.as_view(),
        name='service-request-detail'
    ),
    
    # -------------------------------------------------------------------------
    # Payment
    # -------------------------------------------------------------------------
    path(
        'service-requests/verify-payment/',
        ServicePaymentVerifyView.as_view(),
        name='service-payment-verify'
    ),
    path(
        'service-requests/<int:pk>/payment-status/',
        ServicePaymentStatusView.as_view(),
        name='service-payment-status'
    ),
    path(
        'service-requests/<int:pk>/retry-payment/',
        ServiceRetryPaymentView.as_view(),
        name='service-retry-payment'
    ),
    
    # -------------------------------------------------------------------------
    # Attachments & Comments
    # -------------------------------------------------------------------------
    path(
        'service-requests/<int:pk>/attachments/',
        ServiceRequestAttachmentUploadView.as_view(),
        name='service-request-attachment-upload'
    ),
    path(
        'service-requests/<int:pk>/comments/',
        ServiceRequestCommentListView.as_view(),
        name='service-request-comment-list'
    ),
    path(
        'service-requests/<int:pk>/comments/create/',
        ServiceRequestCommentCreateView.as_view(),
        name='service-request-comment-create'
    ),
    
    # -------------------------------------------------------------------------
    # Admin/Internal Endpoints
    # -------------------------------------------------------------------------
    path(
        'service-requests/admin/',
        ServiceRequestAdminListView.as_view(),
        name='service-request-admin-list'
    ),
    path(
        'service-requests/admin/<int:pk>/',
        ServiceRequestAdminDetailView.as_view(),
        name='service-request-admin-detail'
    ),
    path(
        'service-requests/admin/<int:pk>/status/',
        ServiceRequestStatusUpdateView.as_view(),
        name='service-request-status-update'
    ),
    path(
        'service-requests/admin/<int:pk>/assign/',
        ServiceRequestAssignOwnerView.as_view(),
        name='service-request-assign-owner'
    ),
    path(
        'service-requests/admin/<int:pk>/brand-owner/',
        ServiceRequestBrandOwnerView.as_view(),
        name='service-request-brand-owner'
    ),
]
