"""
Service Request Views

Follows existing DRF patterns from case/views.py and payments/views.py.
Implements public and authenticated endpoints for service requests.
"""
import razorpay
from django.conf import settings
from django.shortcuts import get_object_or_404
from django.utils import timezone
from rest_framework import status, generics
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.pagination import PageNumberPagination

from user.permissions import IsAccountManager, IsBrandOwner, IsPrivilegedAccountManager
from user.models import BrandOwner
from utils.captcha import verify_captcha_or_raise

from .models import (
    FeedbackReport,
    ServiceOffering,
    ServiceReview,
    ServiceRequest,
    ServiceRequestAttachment,
    ServiceRequestComment,
)
from .serializers import (
    FeedbackReportCreateSerializer,
    ServiceReviewCreateSerializer,
    ServiceReviewPublicSerializer,
    ServiceOfferingSerializer,
    ServiceOfferingListSerializer,
    ServiceRequestListSerializer,
    ServiceRequestDetailSerializer,
    ServiceRequestCreateSerializer,
    ServiceRequestPublicCreateSerializer,
    ServiceRequestUpdateSerializer,
    ServiceRequestStatusUpdateSerializer,
    ServiceRequestAttachmentCreateSerializer,
    ServiceRequestCommentCreateSerializer,
    ServicePaymentDetailSerializer,
)
from payments.models import ServicePayment


class FeedbackReportCreateView(generics.CreateAPIView):
    """
    Create a feedback report for the authenticated user.
    POST /api/feedback-reports/
    """

    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]
    serializer_class = FeedbackReportCreateSerializer
    queryset = FeedbackReport.objects.none()

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        feedback_report = serializer.save()
        return Response(
            {
                "id": feedback_report.id,
                "status": "submitted",
                "created_at": feedback_report.created_at,
            },
            status=status.HTTP_201_CREATED,
        )


class ServiceReviewCreateView(generics.CreateAPIView):
    """
    Create a public service review.
    POST /api/service-reviews/
    """
    permission_classes = [AllowAny]
    serializer_class = ServiceReviewCreateSerializer
    queryset = ServiceReview.objects.none()

    def create(self, request, *args, **kwargs):
        verify_captcha_or_raise(request)

        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        service_review = serializer.save()
        return Response(
            {
                "id": service_review.id,
                "status": "received",
                "message": "Thank you. Your review has been received.",
            },
            status=status.HTTP_201_CREATED,
        )


class ServiceReviewPublicListView(generics.ListAPIView):
    """
    List approved featured reviews for public display.
    GET /api/service-reviews/public/
    """
    permission_classes = [AllowAny]
    serializer_class = ServiceReviewPublicSerializer

    def get_queryset(self):
        limit = self.request.query_params.get("limit", "6")
        try:
            limit_value = min(max(int(limit), 1), 12)
        except ValueError:
            limit_value = 6

        return ServiceReview.objects.filter(
            status=ServiceReview.STATUS_APPROVED,
            is_featured=True,
        ).order_by("display_order", "-created_at")[:limit_value]


# ------------------------------------------------------------------------------
# Pagination
# ------------------------------------------------------------------------------
class ServiceRequestPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100


# ------------------------------------------------------------------------------
# ServiceOffering Views
# ------------------------------------------------------------------------------
class ServiceOfferingListView(generics.ListAPIView):
    """
    List all active service offerings.
    Public endpoint - no auth required.
    """
    permission_classes = [AllowAny]
    serializer_class = ServiceOfferingSerializer
    
    def get_queryset(self):
        return ServiceOffering.objects.filter(is_active=True).order_by('sort_order', 'name')


class ServiceOfferingDetailView(generics.RetrieveAPIView):
    """
    Get details of a specific service offering.
    Public endpoint - no auth required.
    """
    permission_classes = [AllowAny]
    serializer_class = ServiceOfferingSerializer
    lookup_field = 'code'
    
    def get_queryset(self):
        return ServiceOffering.objects.filter(is_active=True)


# ------------------------------------------------------------------------------
# ServiceRequest Views - Authenticated
# ------------------------------------------------------------------------------
class ServiceRequestListView(generics.ListAPIView):
    """
    List service requests for the authenticated user.
    GET /api/service-requests/
    """
    permission_classes = [IsAuthenticated]
    serializer_class = ServiceRequestListSerializer
    pagination_class = ServiceRequestPagination

    def get_queryset(self):
        user = self.request.user
        qs = ServiceRequest.objects.filter(user=user)
        
        # Optional status filter
        status_filter = self.request.query_params.get('status')
        if status_filter:
            qs = qs.filter(status=status_filter)
        
        return qs.select_related('offering').order_by('-created_at')


class ServiceRequestDetailView(generics.RetrieveAPIView):
    """
    Get details of a specific service request.
    GET /api/service-requests/<id>/
    """
    permission_classes = [IsAuthenticated]
    serializer_class = ServiceRequestDetailSerializer

    def get_queryset(self):
        user = self.request.user
        # Account managers can see all, users see their own
        if hasattr(user, 'am'):
            return ServiceRequest.objects.all()
        return ServiceRequest.objects.filter(user=user)


class ServiceRequestCreateView(APIView):
    """
    Create a new service request (authenticated user).
    POST /api/service-requests/
    
    Creates ServiceRequest + Payment + Razorpay order.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = ServiceRequestCreateSerializer(
            data=request.data,
            context={'request': request}
        )
        
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        service_request = serializer.save()
        
        # Create Razorpay order for payment
        payment_data = self._create_razorpay_order(service_request)
        
        if payment_data.get('error'):
            return Response(
                {'error': payment_data['error']},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        # Return service request info + payment info
        response_data = {
            'service_request_id': service_request.id,
            'reference_id': str(service_request.reference_id),
            'title': service_request.title,
            'status': service_request.status,
            'amount': str(service_request.final_price),
            'currency': service_request.currency,
            **payment_data
        }
        
        return Response(response_data, status=status.HTTP_201_CREATED)

    def _create_razorpay_order(self, service_request):
        """Create Razorpay order for the service request payment."""
        try:
            payment = service_request.payment
            
            client = razorpay.Client(
                auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
            )
            
            razorpay_order = client.order.create({
                'amount': int(float(payment.amount) * 100),  # Amount in paisa
                'currency': payment.currency,
                'receipt': f'sr_{service_request.id}',
                'payment_capture': '1',
                'notes': {
                    'service_request_id': str(service_request.id),
                    'reference_id': str(service_request.reference_id),
                }
            })
            
            # Update payment with Razorpay order ID
            payment.provider_order_id = razorpay_order['id']
            payment.status = 'PENDING'
            payment.save()
            
            return {
                'razorpay_order_id': razorpay_order['id'],
                'razorpay_key_id': settings.RAZORPAY_KEY_ID,
                'payment_id': payment.id,
            }
        except Exception as e:
            return {'error': f'Failed to create payment order: {str(e)}'}


# ------------------------------------------------------------------------------
# ServiceRequest Views - Public
# ------------------------------------------------------------------------------
class ServiceRequestPublicCreateView(APIView):
    """
    Create a new service request from public form (no auth required).
    POST /api/service-requests/public/
    
    Creates/finds user, ServiceRequest + Payment + Razorpay order.
    Sends activation/set-password email for new users.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        verify_captcha_or_raise(request)

        serializer = ServiceRequestPublicCreateSerializer(
            data=request.data,
            context={'request': request}
        )
        
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        service_request = serializer.save()
        
        # Send activation/set-password email for new users
        # The _is_new_user flag is set by the serializer
        if getattr(service_request, '_is_new_user', False):
            try:
                from user.utils import send_confirm_set_password_email
                send_confirm_set_password_email(service_request.user)
            except Exception:
                # Non-fatal: continue even if email sending fails
                pass
        
        # Create Razorpay order for payment
        payment_data = self._create_razorpay_order(service_request)
        
        if payment_data.get('error'):
            return Response(
                {'error': payment_data['error']},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        # Return service request info + payment info
        response_data = {
            'service_request_id': service_request.id,
            'reference_id': str(service_request.reference_id),
            'title': service_request.title,
            'status': service_request.status,
            'amount': str(service_request.final_price),
            'currency': service_request.currency,
            'user_id': service_request.user.id,
            **payment_data
        }
        
        return Response(response_data, status=status.HTTP_201_CREATED)

    def _create_razorpay_order(self, service_request):
        """Create Razorpay order for the service request payment."""
        try:
            payment = service_request.payment
            
            client = razorpay.Client(
                auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
            )
            
            razorpay_order = client.order.create({
                'amount': int(float(payment.amount) * 100),
                'currency': payment.currency,
                'receipt': f'sr_{service_request.id}',
                'payment_capture': '1',
                'notes': {
                    'service_request_id': str(service_request.id),
                    'reference_id': str(service_request.reference_id),
                }
            })
            
            payment.provider_order_id = razorpay_order['id']
            payment.status = 'PENDING'
            payment.save()
            
            return {
                'razorpay_order_id': razorpay_order['id'],
                'razorpay_key_id': settings.RAZORPAY_KEY_ID,
                'payment_id': payment.id,
            }
        except Exception as e:
            return {'error': f'Failed to create payment order: {str(e)}'}


# ------------------------------------------------------------------------------
# Payment Verification Views
# ------------------------------------------------------------------------------
class ServicePaymentVerifyView(APIView):
    """
    Verify payment from frontend callback.
    POST /api/service-requests/verify-payment/
    
    This is for frontend redirect verification.
    The actual payment confirmation should come from webhook.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        razorpay_order_id = request.data.get('razorpay_order_id')
        razorpay_payment_id = request.data.get('razorpay_payment_id')
        razorpay_signature = request.data.get('razorpay_signature')
        
        if not all([razorpay_order_id, razorpay_payment_id, razorpay_signature]):
            return Response(
                {'error': 'Missing payment verification parameters'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            payment = ServicePayment.objects.get(provider_order_id=razorpay_order_id)
        except ServicePayment.DoesNotExist:
            return Response(
                {'error': 'Payment not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Verify signature
        try:
            client = razorpay.Client(
                auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
            )
            client.utility.verify_payment_signature({
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': razorpay_payment_id,
                'razorpay_signature': razorpay_signature,
            })
        except Exception:
            return Response(
                {'error': 'Payment verification failed'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Update payment (webhook may have already done this)
        if payment.status != 'SUCCEEDED':
            payment.mark_succeeded(
                payment_id=razorpay_payment_id,
                signature=razorpay_signature
            )
            
            # Update service request status
            service_request = payment.service_request
            if service_request.status == 'AWAITING_PAYMENT':
                service_request.transition_to(
                    'PAID',
                    note='Payment verified via frontend callback'
                )
                # Auto-transition to IN_REVIEW
                service_request.transition_to(
                    'IN_REVIEW',
                    note='Auto-transitioned after payment'
                )
        
        return Response({
            'status': 'success',
            'service_request_id': payment.service_request.id,
            'service_request_status': payment.service_request.status,
        })


class ServicePaymentStatusView(APIView):
    """
    Get payment status for a service request.
    GET /api/service-requests/<id>/payment-status/
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        
        # Check permissions
        if not (service_request.user == request.user or hasattr(request.user, 'am')):
            return Response(
                {'error': 'Permission denied'},
                status=status.HTTP_403_FORBIDDEN
            )
        
        try:
            payment = service_request.payment
            serializer = ServicePaymentDetailSerializer(payment)
            return Response(serializer.data)
        except ServicePayment.DoesNotExist:
            return Response(
                {'error': 'Payment not found'},
                status=status.HTTP_404_NOT_FOUND
            )


# ------------------------------------------------------------------------------
# Internal/Admin Views
# ------------------------------------------------------------------------------
class ServiceRequestAdminListView(generics.ListAPIView):
    """
    List all service requests (for account managers).
    GET /api/service-requests/admin/
    """
    permission_classes = [IsAccountManager]
    serializer_class = ServiceRequestListSerializer
    pagination_class = ServiceRequestPagination

    def get_queryset(self):
        qs = ServiceRequest.objects.all()
        
        # Filters
        status_filter = self.request.query_params.get('status')
        if status_filter:
            qs = qs.filter(status=status_filter)
        
        user_filter = self.request.query_params.get('user_id')
        if user_filter:
            qs = qs.filter(user_id=user_filter)
        
        return qs.select_related('offering', 'user').order_by('-created_at')


class ServiceRequestAdminDetailView(generics.RetrieveUpdateAPIView):
    """
    Get/update a service request (for account managers).
    GET/PATCH /api/service-requests/admin/<id>/
    """
    permission_classes = [IsAccountManager]
    queryset = ServiceRequest.objects.all()

    def get_serializer_class(self):
        if self.request.method in ['PATCH', 'PUT']:
            return ServiceRequestUpdateSerializer
        return ServiceRequestDetailSerializer


class ServiceRequestStatusUpdateView(APIView):
    """
    Update service request status (for account managers).
    POST /api/service-requests/admin/<id>/status/
    """
    permission_classes = [IsAccountManager]

    def post(self, request, pk):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        
        serializer = ServiceRequestStatusUpdateSerializer(
            data=request.data,
            context={'instance': service_request, 'request': request}
        )
        
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        new_status = serializer.validated_data['status']
        note = serializer.validated_data.get('note', '')
        
        service_request.transition_to(
            new_status,
            changed_by=request.user,
            note=note
        )
        
        return Response({
            'status': 'success',
            'new_status': service_request.status,
        })


class ServiceRequestAssignOwnerView(APIView):
    """
    Assign internal owner to a service request.
    POST /api/service-requests/admin/<id>/assign/
    """
    permission_classes = [IsAccountManager]

    def post(self, request, pk):
        from user.models import AM
        
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        owner_id = request.data.get('internal_owner_id')
        
        if owner_id:
            try:
                owner = AM.objects.get(pk=owner_id)
                service_request.internal_owner = owner
            except AM.DoesNotExist:
                return Response(
                    {'error': 'Invalid owner ID'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        else:
            service_request.internal_owner = None
        
        service_request.save()
        
        return Response({
            'status': 'success',
            'internal_owner': owner_id,
        })


# ------------------------------------------------------------------------------
# Attachment Views
# ------------------------------------------------------------------------------
class ServiceRequestAttachmentUploadView(APIView):
    """
    Upload attachment to a service request.
    POST /api/service-requests/<id>/attachments/
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        
        # Check permissions
        if not (service_request.user == request.user or hasattr(request.user, 'am')):
            return Response(
                {'error': 'Permission denied'},
                status=status.HTTP_403_FORBIDDEN
            )
        
        serializer = ServiceRequestAttachmentCreateSerializer(
            data=request.data,
            context={'request': request, 'service_request': service_request}
        )
        
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        attachment = serializer.save()
        
        return Response({
            'id': attachment.id,
            'file': attachment.file.url,
            'original_filename': attachment.original_filename,
        }, status=status.HTTP_201_CREATED)


# ------------------------------------------------------------------------------
# Comment Views
# ------------------------------------------------------------------------------
class ServiceRequestCommentCreateView(APIView):
    """
    Add comment to a service request.
    POST /api/service-requests/<id>/comments/
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        
        # Check permissions
        if not (service_request.user == request.user or hasattr(request.user, 'am')):
            return Response(
                {'error': 'Permission denied'},
                status=status.HTTP_403_FORBIDDEN
            )
        
        serializer = ServiceRequestCommentCreateSerializer(
            data=request.data,
            context={'request': request, 'service_request': service_request}
        )
        
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        comment = serializer.save()
        
        return Response({
            'id': comment.id,
            'message': comment.message,
            'author_type': comment.author_type,
            'created_at': comment.created_at,
        }, status=status.HTTP_201_CREATED)


class ServiceRequestCommentListView(generics.ListAPIView):
    """
    List comments for a service request.
    GET /api/service-requests/<id>/comments/
    """
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        pk = self.kwargs.get('pk')
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        
        # Check permissions
        user = self.request.user
        if not (service_request.user == user or hasattr(user, 'am')):
            return ServiceRequestComment.objects.none()
        
        return service_request.comments.all()

    def get_serializer_class(self):
        from .serializers import ServiceRequestCommentSerializer
        return ServiceRequestCommentSerializer


class ServiceRetryPaymentView(APIView):
    """
    Retry payment for a service request with failed/pending payment.
    POST /api/service-requests/<id>/retry-payment/
    
    Creates a new Razorpay order for retrying payment.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        
        # Check permissions - only owner can retry payment
        if service_request.user != request.user:
            return Response(
                {'error': 'Permission denied'},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Only allow retry for AWAITING_PAYMENT status
        if service_request.status != 'AWAITING_PAYMENT':
            return Response(
                {'error': f'Cannot retry payment for status: {service_request.status}'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            payment = service_request.payment
        except ServicePayment.DoesNotExist:
            return Response(
                {'error': 'Payment record not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Only allow retry if payment is not already succeeded
        if payment.status == 'SUCCEEDED':
            return Response(
                {'error': 'Payment already succeeded'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Create new Razorpay order
        payment_data = self._create_razorpay_order(service_request, payment)
        
        if payment_data.get('error'):
            return Response(
                {'error': payment_data['error']},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        response_data = {
            'service_request_id': service_request.id,
            'reference_id': str(service_request.reference_id),
            'title': service_request.title,
            'status': service_request.status,
            'amount': str(service_request.final_price),
            'currency': service_request.currency,
            **payment_data
        }
        
        return Response(response_data, status=status.HTTP_200_OK)

    def _create_razorpay_order(self, service_request, payment):
        """Create a new Razorpay order for retry payment."""
        try:
            client = razorpay.Client(
                auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
            )
            
            razorpay_order = client.order.create({
                'amount': int(float(payment.amount) * 100),  # Amount in paisa
                'currency': payment.currency,
                'receipt': f'sr_{service_request.id}_retry',
                'payment_capture': '1',
                'notes': {
                    'service_request_id': str(service_request.id),
                    'reference_id': str(service_request.reference_id),
                    'retry': 'true',
                }
            })
            
            # Update payment with new Razorpay order ID
            payment.provider_order_id = razorpay_order['id']
            payment.status = 'PENDING'
            payment.save()
            
            return {
                'razorpay_order_id': razorpay_order['id'],
                'razorpay_key_id': settings.RAZORPAY_KEY_ID,
                'payment_id': payment.id,
            }
        except Exception as e:
            return {'error': f'Failed to create payment order: {str(e)}'}


class ServiceRequestBrandOwnerView(APIView):
    """
    Get brand owner details for a service request.
    GET /api/service-requests/admin/<id>/brand-owner/
    
    Only accessible by SuperAM and Management AM.
    Returns: id, name, phone number, email.
    """
    permission_classes = [IsPrivilegedAccountManager]

    def get(self, request, pk):
        service_request = get_object_or_404(ServiceRequest, pk=pk)
        user = service_request.user
        
        # Get BrandOwner linked to the user
        try:
            brand_owner = BrandOwner.objects.get(user=user)
            return Response({
                'id': brand_owner.id,
                'name': brand_owner.name,
                'phone': brand_owner.contact_phone,
                'email': brand_owner.contact_email or user.email,
            })
        except BrandOwner.DoesNotExist:
            # Fallback to user details if no BrandOwner profile
            return Response({
                'id': user.id,
                'name': user.get_full_name() or user.username,
                'phone': None,
                'email': user.email,
            })
