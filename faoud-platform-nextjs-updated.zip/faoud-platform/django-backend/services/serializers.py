"""
Service Request Serializers

Follows existing DRF patterns from case/serializers.py and payments/serializers.py
"""
from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.db import transaction

from .models import (
    FeedbackReport,
    ServiceOffering,
    ServiceReview,
    ServiceRequest,
    ServiceRequestAttachment,
    ServiceRequestComment,
    ServiceRequestStatusHistory,
)
from payments.models import ServicePayment

User = get_user_model()


class FeedbackReportCreateSerializer(serializers.ModelSerializer):
    user_id = serializers.IntegerField(write_only=True, required=False)
    user_role = serializers.CharField(write_only=True, required=False, allow_blank=True)
    user_name = serializers.CharField(write_only=True, required=False, allow_blank=True)
    user_email = serializers.CharField(write_only=True, required=False, allow_blank=True)
    status = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = FeedbackReport
        fields = [
            "id",
            "status",
            "created_at",
            "category",
            "message",
            "page_path",
            "page_url",
            "case_id",
            "query_params",
            "viewport_width",
            "viewport_height",
            "browser_user_agent",
            "screenshot",
            "user_id",
            "user_role",
            "user_name",
            "user_email",
        ]
        read_only_fields = ["id", "status", "created_at"]

    def get_status(self, obj):
        return "submitted"

    def validate(self, attrs):
        message = (attrs.get("message") or "").strip()
        screenshot = attrs.get("screenshot")
        if not message and not screenshot:
            raise serializers.ValidationError(
                {"non_field_errors": ["Either message or screenshot is required."]}
            )
        attrs["message"] = message
        return attrs

    def create(self, validated_data):
        validated_data.pop("user_id", None)
        validated_data.pop("user_role", None)
        validated_data.pop("user_name", None)
        validated_data.pop("user_email", None)
        validated_data["user"] = self.context["request"].user
        return super().create(validated_data)


class ServiceReviewCreateSerializer(serializers.ModelSerializer):
    captcha_token = serializers.CharField(write_only=True, required=False, allow_blank=True)

    class Meta:
        model = ServiceReview
        fields = [
            "id",
            "rating",
            "review",
            "display_name",
            "brand_name",
            "role_label",
            "email",
            "phone",
            "source_page",
            "captcha_token",
            "created_at",
        ]
        read_only_fields = ["id", "created_at"]

    def validate_rating(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("Choose a rating from 1 to 5.")
        return value

    def validate_review(self, value):
        value = (value or "").strip()
        if len(value) < 20:
            raise serializers.ValidationError("Please write at least 20 characters.")
        if len(value) > 1000:
            raise serializers.ValidationError("Please keep the review under 1000 characters.")
        return value

    def validate_display_name(self, value):
        value = (value or "").strip()
        if not value:
            raise serializers.ValidationError("Enter your name.")
        return value

    def validate_brand_name(self, value):
        value = (value or "").strip()
        if not value:
            raise serializers.ValidationError("Enter your brand or company name.")
        return value

    def validate_role_label(self, value):
        return (value or "Brand Owner").strip()[:80]

    def validate_email(self, value):
        return value.lower().strip()

    def create(self, validated_data):
        validated_data.pop("captcha_token", None)
        request = self.context.get("request")
        if request:
            forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR", "")
            ip_address = forwarded_for.split(",")[0].strip() if forwarded_for else request.META.get("REMOTE_ADDR")
            validated_data["ip_address"] = ip_address or None
            validated_data["user_agent"] = request.META.get("HTTP_USER_AGENT", "")[:2000]
        return super().create(validated_data)


class ServiceReviewPublicSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceReview
        fields = [
            "id",
            "rating",
            "review",
            "display_name",
            "brand_name",
            "role_label",
        ]
        read_only_fields = fields


# ------------------------------------------------------------------------------
# ServiceOffering Serializers
# ------------------------------------------------------------------------------
class ServiceOfferingSerializer(serializers.ModelSerializer):
    """Read-only serializer for service offerings catalog."""
    
    class Meta:
        model = ServiceOffering
        fields = [
            'id',
            'code',
            'name',
            'service_type',
            'description',
            'currency',
            'base_price',
            'is_active',
            'estimated_timeline_days',
            'sort_order',
        ]
        read_only_fields = fields


class ServiceOfferingListSerializer(serializers.ModelSerializer):
    """Minimal serializer for listing offerings."""
    
    class Meta:
        model = ServiceOffering
        fields = ['id', 'code', 'name', 'service_type', 'base_price', 'currency']


# ------------------------------------------------------------------------------
# ServicePayment Serializers
# ------------------------------------------------------------------------------
class ServicePaymentSerializer(serializers.ModelSerializer):
    """Read serializer for payment status."""
    
    class Meta:
        model = ServicePayment
        fields = [
            'id',
            'amount',
            'currency',
            'status',
            'provider',
            'provider_order_id',
            'created_at',
            'paid_at',
        ]
        read_only_fields = fields


class ServicePaymentDetailSerializer(serializers.ModelSerializer):
    """Detailed payment info for checkout."""
    
    class Meta:
        model = ServicePayment
        fields = [
            'id',
            'amount',
            'currency',
            'status',
            'provider',
            'provider_order_id',
            'provider_payment_id',
            'created_at',
            'paid_at',
        ]
        read_only_fields = fields


# ------------------------------------------------------------------------------
# ServiceRequestAttachment Serializers
# ------------------------------------------------------------------------------
class ServiceRequestAttachmentSerializer(serializers.ModelSerializer):
    """Serializer for attachments."""
    uploaded_by_name = serializers.SerializerMethodField()
    
    class Meta:
        model = ServiceRequestAttachment
        fields = [
            'id',
            'file',
            'original_filename',
            'uploaded_by',
            'uploaded_by_name',
            'created_at',
        ]
        read_only_fields = ['id', 'uploaded_by', 'uploaded_by_name', 'created_at']

    def get_uploaded_by_name(self, obj):
        if obj.uploaded_by:
            return obj.uploaded_by.get_full_name() or obj.uploaded_by.username
        return None


class ServiceRequestAttachmentCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating attachments."""
    
    class Meta:
        model = ServiceRequestAttachment
        fields = ['file', 'original_filename']

    def create(self, validated_data):
        request = self.context.get('request')
        service_request = self.context.get('service_request')
        validated_data['uploaded_by'] = request.user if request else None
        validated_data['request'] = service_request
        return super().create(validated_data)


# ------------------------------------------------------------------------------
# ServiceRequestComment Serializers
# ------------------------------------------------------------------------------
class ServiceRequestCommentSerializer(serializers.ModelSerializer):
    """Serializer for comments."""
    author_name = serializers.SerializerMethodField()
    
    class Meta:
        model = ServiceRequestComment
        fields = [
            'id',
            'author',
            'author_name',
            'author_type',
            'message',
            'created_at',
        ]
        read_only_fields = ['id', 'author', 'author_name', 'author_type', 'created_at']

    def get_author_name(self, obj):
        if obj.author:
            if obj.author_type == 'INTERNAL':
                # Don't expose internal user names to customers
                return "Support Team"
            return obj.author.get_full_name() or obj.author.username
        return "Anonymous"


class ServiceRequestCommentCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating comments."""
    
    class Meta:
        model = ServiceRequestComment
        fields = ['message']

    def create(self, validated_data):
        request = self.context.get('request')
        service_request = self.context.get('service_request')
        user = request.user if request else None
        
        # Determine author type based on user role
        author_type = 'USER'
        if user and hasattr(user, 'am'):
            author_type = 'INTERNAL'
        
        validated_data['author'] = user
        validated_data['author_type'] = author_type
        validated_data['request'] = service_request
        return super().create(validated_data)


# ------------------------------------------------------------------------------
# ServiceRequestStatusHistory Serializers
# ------------------------------------------------------------------------------
class ServiceRequestStatusHistorySerializer(serializers.ModelSerializer):
    """Serializer for status history."""
    changed_by_name = serializers.SerializerMethodField()
    
    class Meta:
        model = ServiceRequestStatusHistory
        fields = [
            'id',
            'from_status',
            'to_status',
            'changed_by_name',
            'note',
            'created_at',
        ]
        read_only_fields = fields

    def get_changed_by_name(self, obj):
        if obj.changed_by:
            return obj.changed_by.get_full_name() or obj.changed_by.username
        return "System"


# ------------------------------------------------------------------------------
# ServiceRequest Serializers
# ------------------------------------------------------------------------------
class ServiceRequestListSerializer(serializers.ModelSerializer):
    """Minimal serializer for listing service requests."""
    offering_name = serializers.CharField(source='offering.name', read_only=True)
    offering_code = serializers.CharField(source='offering.code', read_only=True)
    payment_status = serializers.SerializerMethodField()
    
    class Meta:
        model = ServiceRequest
        fields = [
            'id',
            'reference_id',
            'title',
            'offering_name',
            'offering_code',
            'status',
            'final_price',
            'currency',
            'payment_status',
            'created_at',
        ]
        read_only_fields = fields

    def get_payment_status(self, obj):
        try:
            return obj.payment.status
        except ServicePayment.DoesNotExist:
            return None


class ServiceRequestDetailSerializer(serializers.ModelSerializer):
    """Full detail serializer for service requests."""
    offering = ServiceOfferingSerializer(read_only=True)
    payment = ServicePaymentSerializer(read_only=True)
    attachments = ServiceRequestAttachmentSerializer(many=True, read_only=True)
    comments = ServiceRequestCommentSerializer(many=True, read_only=True)
    status_history = ServiceRequestStatusHistorySerializer(many=True, read_only=True)
    internal_owner_name = serializers.SerializerMethodField()
    
    class Meta:
        model = ServiceRequest
        fields = [
            'id',
            'reference_id',
            'user',
            'offering',
            'title',
            'description',
            'category',
            'budget_min',
            'budget_max',
            'desired_timeline',
            'status',
            'currency',
            'list_price',
            'final_price',
            'promo_code',
            'internal_owner',
            'internal_owner_name',
            'delivered_at',
            'closed_at',
            'created_from',
            'created_at',
            'updated_at',
            'payment',
            'attachments',
            'comments',
            'status_history',
        ]
        read_only_fields = fields

    def get_internal_owner_name(self, obj):
        if obj.internal_owner:
            return obj.internal_owner.name
        return None


class ServiceRequestCreateSerializer(serializers.Serializer):
    """
    Serializer for creating a service request (authenticated user).
    Creates ServiceRequest and ServicePayment atomically.
    NOTE: This serializer should ONLY be used for authenticated users.
    It does NOT require email, phone, or name - uses request.user directly.
    """
    offering_code = serializers.CharField(max_length=50)
    title = serializers.CharField(max_length=255)
    description = serializers.CharField(required=False, allow_blank=True, default='')
    category = serializers.CharField(max_length=100, required=False, allow_blank=True, default='')
    budget_min = serializers.DecimalField(max_digits=15, decimal_places=2, required=False, allow_null=True)
    budget_max = serializers.DecimalField(max_digits=15, decimal_places=2, required=False, allow_null=True)
    desired_timeline = serializers.CharField(max_length=100, required=False, allow_blank=True, default='')
    promo_code = serializers.CharField(max_length=50, required=False, allow_blank=True, allow_null=True)

    def validate_offering_code(self, value):
        try:
            offering = ServiceOffering.objects.get(code=value, is_active=True)
        except ServiceOffering.DoesNotExist:
            raise serializers.ValidationError("Invalid or inactive service offering code.")
        return value

    def validate_promo_code(self, value):
        # Simple validation - in future could validate against a Promo model
        if value and len(value) > 50:
            raise serializers.ValidationError("Promo code is too long.")
        return value

    def validate(self, attrs):
        """Ensure user is authenticated."""
        request = self.context.get('request')
        if not request or not request.user or not request.user.is_authenticated:
            raise serializers.ValidationError(
                "Authentication required. Use public endpoint for unauthenticated requests."
            )
        return attrs

    def create(self, validated_data):
        user = self.context['request'].user
        offering_code = validated_data.pop('offering_code')
        promo_code = validated_data.pop('promo_code', None)
        
        offering = ServiceOffering.objects.get(code=offering_code, is_active=True)
        
        # Calculate pricing (simple for now, can add promo logic later)
        list_price = offering.base_price
        final_price = list_price  # Apply promo discount here if needed
        
        with transaction.atomic():
            # Create ServiceRequest
            service_request = ServiceRequest.objects.create(
                user=user,
                offering=offering,
                title=validated_data.get('title'),
                description=validated_data.get('description', ''),
                category=validated_data.get('category', ''),
                budget_min=validated_data.get('budget_min'),
                budget_max=validated_data.get('budget_max'),
                desired_timeline=validated_data.get('desired_timeline', ''),
                status='AWAITING_PAYMENT',
                currency=offering.currency,
                list_price=list_price,
                final_price=final_price,
                promo_code=promo_code or '',
                created_from='DASHBOARD',
            )
            
            # Log initial status
            ServiceRequestStatusHistory.objects.create(
                request=service_request,
                from_status='',
                to_status='AWAITING_PAYMENT',
                changed_by=user,
                note='Service request created'
            )
            
            # Create ServicePayment
            ServicePayment.objects.create(
                service_request=service_request,
                user=user,
                amount=final_price,
                currency=offering.currency,
                status='CREATED',
            )
        
        return service_request


class ServiceRequestPublicCreateSerializer(serializers.Serializer):
    """
    Serializer for creating a service request from public form (not logged in).
    Creates or finds user, then creates ServiceRequest and ServicePayment.
    NOTE: This serializer is for UNAUTHENTICATED users only (public landing pages).
    """
    # User identification - REQUIRED for public/unauthenticated requests
    email = serializers.EmailField()
    phone = serializers.CharField(max_length=20, required=False, allow_blank=True)
    name = serializers.CharField(max_length=100, required=False, allow_blank=True)
    
    # Service request fields
    offering_code = serializers.CharField(max_length=50)
    title = serializers.CharField(max_length=255)
    description = serializers.CharField(required=False, allow_blank=True, default='')
    category = serializers.CharField(max_length=100, required=False, allow_blank=True, default='')
    budget_min = serializers.DecimalField(max_digits=15, decimal_places=2, required=False, allow_null=True)
    budget_max = serializers.DecimalField(max_digits=15, decimal_places=2, required=False, allow_null=True)
    desired_timeline = serializers.CharField(max_length=100, required=False, allow_blank=True, default='')
    promo_code = serializers.CharField(max_length=50, required=False, allow_blank=True, allow_null=True)

    def validate_offering_code(self, value):
        try:
            ServiceOffering.objects.get(code=value, is_active=True)
        except ServiceOffering.DoesNotExist:
            raise serializers.ValidationError("Invalid or inactive service offering code.")
        return value

    def validate_email(self, value):
        # Normalize email
        return value.lower().strip()

    def _get_or_create_user(self, email, name='', phone=''):
        """
        Get existing user by email or create a new one.
        Follows existing OnboardingData → User pattern in marketing app.
        Returns tuple: (user, is_new_user)
        """
        from user.models import BrandOwner
        import secrets
        
        user = User.objects.filter(email__iexact=email).first()
        is_new_user = False
        
        if not user:
            is_new_user = True
            # Create new user with random password (they'll reset later)
            username = email.split('@')[0][:30]
            # Ensure unique username
            base_username = username
            counter = 1
            while User.objects.filter(username=username).exists():
                username = f"{base_username}{counter}"
                counter += 1
            
            user = User.objects.create_user(
                username=username,
                email=email,
                password=secrets.token_urlsafe(16),
                first_name=name.split()[0] if name else '',
                last_name=' '.join(name.split()[1:]) if name and len(name.split()) > 1 else '',
            )
            
            # Create BrandOwner profile (consistent with existing pattern)
            BrandOwner.objects.create(
                user=user,
                name=name or username,
                contact_email=email,
                contact_phone=phone or '',
            )
        
        return user, is_new_user

    def create(self, validated_data):
        email = validated_data.pop('email')
        phone = validated_data.pop('phone', '')
        name = validated_data.pop('name', '')
        offering_code = validated_data.pop('offering_code')
        promo_code = validated_data.pop('promo_code', None)
        
        offering = ServiceOffering.objects.get(code=offering_code, is_active=True)
        
        # Calculate pricing
        list_price = offering.base_price
        final_price = list_price  # Apply promo discount here if needed
        
        with transaction.atomic():
            # Get or create user - only for public/unauthenticated requests
            user, is_new_user = self._get_or_create_user(email, name, phone)
            
            # Create ServiceRequest
            service_request = ServiceRequest.objects.create(
                user=user,
                offering=offering,
                title=validated_data.get('title'),
                description=validated_data.get('description', ''),
                category=validated_data.get('category', ''),
                budget_min=validated_data.get('budget_min'),
                budget_max=validated_data.get('budget_max'),
                desired_timeline=validated_data.get('desired_timeline', ''),
                status='AWAITING_PAYMENT',
                currency=offering.currency,
                list_price=list_price,
                final_price=final_price,
                promo_code=promo_code or '',
                created_from='WEB',
            )
            
            # Log initial status
            ServiceRequestStatusHistory.objects.create(
                request=service_request,
                from_status='',
                to_status='AWAITING_PAYMENT',
                note='Service request created from public form'
            )
            
            # Create ServicePayment
            ServicePayment.objects.create(
                service_request=service_request,
                user=user,
                amount=final_price,
                currency=offering.currency,
                status='CREATED',
            )
            
            # Store is_new_user flag for view to handle password reset email
            service_request._is_new_user = is_new_user
        
        return service_request


class ServiceRequestUpdateSerializer(serializers.ModelSerializer):
    """Serializer for updating service request (internal use)."""
    
    class Meta:
        model = ServiceRequest
        fields = [
            'title',
            'description',
            'category',
            'internal_owner',
            'notes',
        ]


class ServiceRequestStatusUpdateSerializer(serializers.Serializer):
    """Serializer for status transitions."""
    status = serializers.ChoiceField(choices=ServiceRequest.STATUS_CHOICES)
    note = serializers.CharField(required=False, allow_blank=True, default='')

    def validate_status(self, value):
        instance = self.context.get('instance')
        if not instance:
            return value
        
        # Define valid transitions
        valid_transitions = {
            'AWAITING_PAYMENT': ['PAID', 'CANCELLED'],
            'PAID': ['IN_REVIEW', 'CANCELLED'],
            'IN_REVIEW': ['IN_PROGRESS', 'CANCELLED'],
            'IN_PROGRESS': ['DELIVERED', 'CANCELLED'],
            'DELIVERED': ['CLOSED'],
            'CLOSED': [],
            'CANCELLED': [],
            'DRAFT': ['AWAITING_PAYMENT', 'CANCELLED'],
        }
        
        current_status = instance.status
        allowed = valid_transitions.get(current_status, [])
        
        if value not in allowed:
            raise serializers.ValidationError(
                f"Cannot transition from {current_status} to {value}. "
                f"Allowed transitions: {allowed}"
            )
        
        return value
