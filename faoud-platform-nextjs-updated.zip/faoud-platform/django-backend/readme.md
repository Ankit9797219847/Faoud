# Notice

We rewrote history to remove secrets. Action required:

1) Reclone (recommended):
   git clone git@github.com:Brown-Tree/shadow-api.git

   OR, if you must keep unpushed work:
   git fetch --all --prune
   git checkout main
   git reset --hard origin/main
   git for-each-ref --format='delete %(refname)' refs/original | git update-ref --stdin
   git reflog expire --expire=now --all
   git gc --prune=now --aggressive

2) Delete and recreate any local feature branches from fresh remotes.
3) Do NOT cherry-pick or merge from old local commits (they may reintroduce secrets).


# Configure pipenv

Use the following steps to activate the virtual environment

- `pip install pipenv` - Install pipenv
- `pipenv sync` - Install required packages
- `pipenv shell` - Activate the environment

# Setup postgres

Setting up a local PostgreSQL database for your Django project involves several steps. Here’s a detailed guide to get you started:

## Step 1: Install PostgreSQL

### On Ubuntu/Debian:

bash

- `sudo apt update`
- `sudo apt install postgresql postgresql-contrib`

### On macOS (using Homebrew):

bash

- `brew update`
- `brew install postgresql`
- `brew services start postgresql`

### On Windows:

Download the installer from the official PostgreSQL website.
Follow the installation wizard and remember the password you set for the postgres user.

## Step 2: Create a Database and User

### Switch to the PostgreSQL User (if on Linux/macOS):

bash

- `sudo -i -u postgres`

### Access the PostgreSQL Prompt:

bash

- `psql`

### Create a New Database:

sql

- `CREATE DATABASE thecatnip;`

### Create a New User:

sql

- `CREATE USER thecatnipuser WITH PASSWORD 'catnippass';`

### Grant Privileges to the User:

sql

- `GRANT ALL PRIVILEGES ON DATABASE thecatnip TO thecatnipuser;`

### Exit the PostgreSQL Prompt:

sql

- `\q`

## Step 3: Install psycopg2

In your virtual environment, install psycopg2, which is the PostgreSQL adapter for Python:

bash

- `pip install psycopg2-binary`

## Step 4: Apply Migrations

After configuring the database, apply migrations to set up the database schema:

bash

- `python manage.py makemigrations`
- `python manage.py migrate`

## Step 5: Run Your Development Server

Start your Django development server to ensure everything is working correctly:

bash

- `python manage.py runserver`

https://chatgpt.com/share/50ec1b90-14ea-439a-84a6-625583feff8a

# .env file

```
# .env

DEBUG=True
SECRET_KEY=your_secret_key

# PostgreSQL Database

DB_NAME=your_db_name
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_HOST=127.0.0.1 # or your database host
DB_PORT=5432 # default port for PostgreSQL
```

# Swagger Custom Docs

[https://chatgpt.com/share/54999247-dce5-4820-b6d4-557c7f03a7cb](https://chatgpt.com/share/54999247-dce5-4820-b6d4-557c7f03a7cb)
