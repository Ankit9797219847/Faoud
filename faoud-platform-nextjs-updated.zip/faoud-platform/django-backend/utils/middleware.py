# utils/middleware.py

import threading

_request_storage = threading.local()

def get_current_request():
    return getattr(_request_storage, "request", None)

class ThreadLocalMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        _request_storage.request = request
        return self.get_response(request)
