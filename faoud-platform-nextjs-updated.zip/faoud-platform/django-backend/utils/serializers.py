from rest_framework import serializers

from user.models import BrandOwner
from user.utils import has_no_brand_info, is_plain_am, redact_fields
from .models import Brand, Brief, Dispatch, QCEntry, PickupSlot

from rest_framework import serializers
from .models import Brand, Address
from user.models import BrandOwner


class BrandSerializer(serializers.ModelSerializer):
    completion = serializers.SerializerMethodField()
    registration_certificate = serializers.FileField(required=False)
    gst_certificate = serializers.FileField(required=False)
    tm_certificate = serializers.FileField(required=False)
    logo = serializers.ImageField(required=False)

    class Meta:
        model  = Brand
        fields = [
            'id', 'name', 'website', 'director_name', 'director_number', 'director_email',
            'office_address', 'poc_name', 'poc_number', 'poc_email', 'gst_number',
            'tm_certificate', 'gst_certificate', 'registration_certificate', 'logo',
            'legal_entity', 'completion', 'country', 'notes',
        ]
        read_only_fields = ['completion']

    def to_representation(self, instance):
        data = super().to_representation(instance)
        req = self.context.get("request")
        allow_plain_am_edit_view = bool(self.context.get("allow_plain_am_edit_view"))
        if req and has_no_brand_info(req.user):
            return {
                "id": data["id"],
                "has_gst_certificate": bool(getattr(instance, "gst_certificate", None)),
                "has_tm_certificate": bool(getattr(instance, "tm_certificate", None)),
                "has_registration_certificate": bool(getattr(instance, "registration_certificate", None)),
            }
        if req and is_plain_am(req.user) and not allow_plain_am_edit_view:
            redact_fields(
                data,
                fields=["director_number","director_email","poc_number","poc_email"],
                strategy="mask",  # change to "drop" if you prefer removing keys
            )
        return data
    
    def get_completion(self, obj):
        filled = 0
        total  = 11  # update if you add / remove fields
        simple_fields = [
            'name','gst_number','legal_entity','office_address','website',
            'director_name','director_number','director_email',
            'poc_name','poc_number','poc_email'
        ]
        for f in simple_fields:
            if getattr(obj, f):
                filled += 1
        file_fields = ['logo','tm_certificate','gst_certificate',
                       'registration_certificate']
        for f in file_fields:
            if getattr(obj, f):
                filled += 1
        return round(filled / (len(simple_fields)+len(file_fields)) * 100)


def brand_completion_percent(obj):
    filled = 0
    simple_fields = [
        'name', 'gst_number', 'legal_entity', 'office_address', 'website',
        'director_name', 'director_number', 'director_email',
        'poc_name', 'poc_number', 'poc_email'
    ]
    for field in simple_fields:
        if getattr(obj, field):
            filled += 1

    file_fields = ['logo', 'tm_certificate', 'gst_certificate', 'registration_certificate']
    for field in file_fields:
        value = getattr(obj, field)
        if value:
            filled += 1

    return round(filled / (len(simple_fields) + len(file_fields)) * 100)

class ManagementBrandActiveCaseSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField(allow_null=True)
    category = serializers.CharField()
    color = serializers.CharField(allow_blank=True)
    created_at = serializers.DateTimeField()
    updated_at = serializers.DateTimeField()
    eta = serializers.DateField(allow_null=True)
    assigned_am_names = serializers.ListField(child=serializers.CharField())
    current_stage = serializers.CharField()
    operations_stage = serializers.CharField(allow_null=True)
    is_stale = serializers.BooleanField()


class ManagementBrandListSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()
    country = serializers.CharField(allow_null=True)
    website = serializers.CharField(allow_blank=True, allow_null=True)
    legal_entity = serializers.CharField(allow_blank=True, allow_null=True)
    created_at = serializers.DateTimeField()
    updated_at = serializers.DateTimeField()
    completion = serializers.IntegerField()
    has_gst_certificate = serializers.BooleanField()
    has_tm_certificate = serializers.BooleanField()
    has_registration_certificate = serializers.BooleanField()
    active_case_count = serializers.IntegerField()
    archived_case_count = serializers.IntegerField()
    total_non_deleted_case_count = serializers.IntegerField()
    stale_active_case_count = serializers.IntegerField()
    unassigned_active_case_count = serializers.IntegerField()
    latest_case_update_at = serializers.DateTimeField(allow_null=True)
    health_flags = serializers.ListField(child=serializers.CharField())


class ManagementBrandDetailSerializer(serializers.Serializer):
    brand = ManagementBrandListSerializer()
    analysis_summary = serializers.DictField()
    active_cases = ManagementBrandActiveCaseSerializer(many=True)
    archived_cases_count = serializers.IntegerField()


class AMWorkspaceBrandOwnerSerializer(serializers.ModelSerializer):
    class Meta:
        model = BrandOwner
        fields = ("id", "name", "contact_phone", "contact_email", "self_onboarded")


class AMWorkspaceBrandOwnerOptionSerializer(serializers.ModelSerializer):
    brand_count = serializers.IntegerField(read_only=True)
    can_add_brand = serializers.BooleanField(read_only=True)

    class Meta:
        model = BrandOwner
        fields = ("id", "name", "contact_phone", "contact_email", "self_onboarded", "brand_count", "can_add_brand")


class AMWorkspaceBrandListSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField(allow_blank=True, allow_null=True)
    owner_name = serializers.CharField(allow_blank=True, allow_null=True)
    legal_entity = serializers.CharField(allow_blank=True, allow_null=True)
    compliance = serializers.DictField()
    country = serializers.CharField(allow_blank=True, allow_null=True)
    last_interacted_at = serializers.DateTimeField(allow_null=True)
    brand_owner_last_login_at = serializers.DateTimeField(allow_null=True)
    last_case_opened_by_am_at = serializers.DateTimeField(allow_null=True)
    active_case_count = serializers.IntegerField()
    archived_case_count = serializers.IntegerField()
    total_case_count = serializers.IntegerField()
    service_request_count = serializers.IntegerField()
    service_request_status_summary = serializers.DictField()
    self_onboarded = serializers.BooleanField()
    health_flags = serializers.ListField(child=serializers.CharField())
    hidden_case_count = serializers.IntegerField()
    hidden_cases = serializers.ListField(child=serializers.DictField())


class BriefSerializer(serializers.ModelSerializer):
    class Meta:
        model = Brief
        fields = '__all__'

from rest_framework import serializers
from .models import Document

class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['id', 'case', 'document_type', 'file', 'uploaded_at','bid_id']


class QCEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = QCEntry
        fields = ['id', 'case', 'description', 'is_done', 'document', 'created_at', 'updated_at','verified_by_am']
        read_only_fields = ['created_at', 'updated_at', 'is_done', 'document']  # Factory owner fields are initially read-only


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ['id', 'street', 'city', 'state', 'zip_code', 'country', 'brand', 
                 'phone_number', 'alternate_phone', 'email', 'landmark']


class DispatchSerializer(serializers.ModelSerializer):
    address = AddressSerializer(read_only=True)
    class Meta:
        model = Dispatch
        fields = [
            'case', 'address', 'manufacturing_status', 'dispatch_date', 'tracking_number',
            'delivery_type', 'delivery_datetime', 'delivery_initiated', 'packing_details',
            'picked_up', 'picked_up_marked_by', 'selected_pickup_slot'
        ]
        read_only_fields = ['picked_up_marked_by']


class DispatchDeliveryTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dispatch
        fields = ['delivery_type', 'address']

    def validate(self, attrs):
        instance = self.instance
        # Ensure delivery_type provided on first set
        if instance and instance.delivery_type is None:
            if 'delivery_type' not in attrs or attrs.get('delivery_type') is None:
                raise serializers.ValidationError({'delivery_type': 'This field is required on first set.'})
        # Prevent changing delivery_type once it has been set
        if instance and instance.delivery_type is not None and 'delivery_type' in attrs:
            incoming = attrs.get('delivery_type')
            if incoming is not None and incoming != instance.delivery_type:
                raise serializers.ValidationError({'delivery_type': 'Delivery type cannot be changed once set.'})
        # Address remains optional and can be provided later.
        return attrs


class DispatchPackingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dispatch
        fields = ['packing_details']

    def validate(self, attrs):
        instance = self.instance
        # Allow packing details for both Faoud-delivers and Self-delivery
        if instance.delivery_type not in ('faoud_delivers', 'self_delivery'):
            raise serializers.ValidationError('Packing details can only be updated after a delivery type is selected.')
        return attrs


class DispatchDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dispatch
        fields = ['manufacturing_status', 'dispatch_date', 'tracking_number', 'delivery_datetime', 'delivery_initiated']

    def validate(self, attrs):
        instance = self.instance
        # Enforce sequence: packing_details must be set first for Faoud Delivers
        if instance.delivery_type == 'faoud_delivers' and not instance.packing_details:
            raise serializers.ValidationError('Factory Owner must provide packing details before updating dispatch details.')
        return attrs


class DispatchPickupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dispatch
        fields = ['picked_up']

    def validate(self, attrs):
        instance = self.instance
        # Allow marking pickup for both faoud_delivers and self_delivery
        if instance.delivery_type not in ('faoud_delivers', 'self_delivery'):
            raise serializers.ValidationError('Pickup can only be marked for valid delivery types.')
        if not instance.tracking_number:
            raise serializers.ValidationError('Tracking number must be set before marking pickup.')
        return attrs


class PickupSlotSerializer(serializers.ModelSerializer):
    class Meta:
        model = PickupSlot
        fields = ['id', 'dispatch', 'start_time', 'end_time', 'created_by', 'notes', 'is_active']
        read_only_fields = ['id', 'created_by', 'dispatch']

    def validate(self, attrs):
        start = attrs.get('start_time') or getattr(self.instance, 'start_time', None)
        end = attrs.get('end_time') or getattr(self.instance, 'end_time', None)
        if start and end and end <= start:
            raise serializers.ValidationError({'end_time': 'End time must be after start time.'})
        return attrs


from django import forms
from .models import Address

class AddressForm(forms.ModelForm):
    class Meta:
        model = Address
        fields = ['street', 'city', 'state', 'zip_code', 'country', 'brand',
                 'phone_number', 'alternate_phone', 'email', 'landmark']
