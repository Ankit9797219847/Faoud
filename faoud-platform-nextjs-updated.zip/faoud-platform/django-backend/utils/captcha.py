import logging
from typing import Any

import requests
from django.conf import settings
from django.core import signing
from rest_framework import status
from rest_framework.exceptions import APIException

logger = logging.getLogger(__name__)
CAPTCHA_PROOF_SALT = "faoud.onboarding.captcha"


class CaptchaValidationError(APIException):
    status_code = status.HTTP_400_BAD_REQUEST
    default_detail = "Please complete the captcha and try again."
    default_code = "captcha_required"


def _get_captcha_token(request) -> str:
    return (
        request.data.get("captcha_token")
        or request.data.get("cf_turnstile_response")
        or request.data.get("cf-turnstile-response")
        or request.headers.get("X-Captcha-Token")
        or ""
    ).strip()


def verify_captcha_or_raise(request) -> None:
    """
    Verify Cloudflare Turnstile for public write endpoints.

    Local and test environments stay unblocked unless CAPTCHA_ENABLED=true and
    CAPTCHA_SECRET_KEY is configured.
    """
    if not getattr(settings, "CAPTCHA_ENABLED", False):
        return
    if getattr(request, "user", None) and request.user.is_authenticated:
        return

    token = _get_captcha_token(request)
    if not token:
        raise CaptchaValidationError()

    payload: dict[str, Any] = {
        "secret": settings.CAPTCHA_SECRET_KEY,
        "response": token,
    }
    remote_ip = _client_ip(request)
    if remote_ip:
        payload["remoteip"] = remote_ip

    try:
        response = requests.post(
            settings.CAPTCHA_VERIFY_URL,
            data=payload,
            timeout=settings.CAPTCHA_VERIFY_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        result = response.json()
    except requests.RequestException:
        logger.exception("Captcha verification request failed")
        raise CaptchaValidationError("Please complete the captcha and try again.")
    except ValueError:
        logger.exception("Captcha verification returned invalid JSON")
        raise CaptchaValidationError("Please complete the captcha and try again.")

    if not result.get("success"):
        error_codes = result.get("error-codes") or []
        logger.warning("Captcha verification failed: %s", error_codes)
        raise CaptchaValidationError(_human_message_for_error_codes(error_codes))


def make_captcha_proof(*, email: str, client_id: str) -> str:
    return signing.dumps(
        {
            "email": _normal_email(email),
            "client_id": str(client_id or ""),
        },
        salt=CAPTCHA_PROOF_SALT,
        compress=True,
    )


def is_valid_captcha_proof(proof: str | None, *, email: str, client_id: str) -> bool:
    if not getattr(settings, "CAPTCHA_ENABLED", False):
        return True
    if not proof:
        return False
    try:
        data = signing.loads(
            proof,
            salt=CAPTCHA_PROOF_SALT,
            max_age=getattr(settings, "CAPTCHA_PROOF_MAX_AGE_SECONDS", 7200),
        )
    except signing.BadSignature:
        return False
    return (
        data.get("email") == _normal_email(email)
        and data.get("client_id") == str(client_id or "")
    )


def _normal_email(email: str) -> str:
    return (email or "").strip().lower()


def _human_message_for_error_codes(error_codes: list[str]) -> str:
    """
    Convert Cloudflare Turnstile error codes into calm, actionable messages.
    """
    codes = {code.strip() for code in error_codes if isinstance(code, str)}
    if "timeout-or-duplicate" in codes:
        return "Please complete the captcha and try again."
    if "invalid-input-response" in codes:
        return "Please complete the captcha and try again."
    if "missing-input-response" in codes:
        return "Please complete the captcha and try again."
    if "missing-input-secret" in codes or "invalid-input-secret" in codes:
        return "Please complete the captcha and try again."
    if "internal-error" in codes:
        return "Please complete the captcha and try again."
    return "Please complete the captcha and try again."


def _client_ip(request) -> str | None:
    forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR")
