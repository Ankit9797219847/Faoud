from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("utils", "0028_dispatch_delivery_datetime_and_more"),
    ]

    operations = [
        migrations.AddField(
            model_name="brand",
            name="notes",
            field=models.TextField(blank=True, default=""),
        ),
    ]
