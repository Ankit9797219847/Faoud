from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
import json

from case.models import Case
from core.help import is_case_ready_for_autobid, is_case_ready_for_bid
from core.review import build_review_summary, get_publish_plan, publish_case, take_case_offline
from supply.models import Factory
from user.permissions import IsAccountManager, IsFactoryOwner, IsSuperAccountManager
from utils.models import Brief
from utils.serializers import BriefSerializer
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser

from .models import ParameterDefinition
from .serializers import ParameterDefinitionSerializer

class ParameterDefinitionListView(APIView):
    """
    GET /api/parameter-definitions?subcategory=<id>
    Lists ParameterDefinitions for a given subcategory or all if no filter.
    """
    def get(self, request, *args, **kwargs):
        subcat_id = request.query_params.get('subcategory', None)
        qs = ParameterDefinition.objects.all()
        if subcat_id:
            qs = qs.filter(subcategory_id=subcat_id)
        serializer = ParameterDefinitionSerializer(qs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ParameterDefinitionDetailView(APIView):
    """
    GET /api/parameter-definitions/<id>/
    Retrieves a single ParameterDefinition by ID.
    """
    def get(self, request, pk, *args, **kwargs):
        try:
            param_def = ParameterDefinition.objects.get(pk=pk)
        except ParameterDefinition.DoesNotExist:
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = ParameterDefinitionSerializer(param_def)
        return Response(serializer.data, status=status.HTTP_200_OK)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import CaseParameterValue
from .serializers import CaseParameterValueSerializer
# from user.permissions import IsAccountManager, IsBrandOwner
from rest_framework.permissions import IsAuthenticated

class CaseParameterValueAPIView(APIView):
    """
    POST /api/cases/<case_id>/parameters/

    Body: 
    {
      "parameters": [
        { "parameter_definition": <id>, "decimal_value": 123.45 },
        { "parameter_definition": <id>, "text_value": "foobar" },
        ...
      ]
    }

    This updates or creates each parameter for the specified Case.
    """

    permission_classes = [IsSuperAccountManager]  # or custom perms (IsAccountManager | IsBrandOwner)

    def post(self, request, case_id):
        # You may want to confirm user is brand owner or AM with this case
        try:
            case_obj = Case.objects.get(pk=case_id)
        except Case.DoesNotExist:
            return Response({"detail": "Case not found."}, status=status.HTTP_404_NOT_FOUND)

        # Optional: check ownership/assignment
        # e.g. if request.user is brandowner => ensure they match the case's brand_owner
        # or if request.user is AM => ensure they're assigned to the case, etc.

        data_list = request.data.get('parameters', [])
        if not isinstance(data_list, list):
            return Response({"detail": "'parameters' should be a list."}, status=status.HTTP_400_BAD_REQUEST)

        results = []
        for param_data in data_list:
            # Build data for serialization
            param_data['case'] = case_obj.id
            serializer = CaseParameterValueSerializer(data=param_data)
            if serializer.is_valid():
                pdef_id = serializer.validated_data['parameter_definition'].id

                # upsert
                obj, created = CaseParameterValue.objects.update_or_create(
                    case=case_obj,
                    parameter_definition_id=pdef_id,
                    defaults={
                        "decimal_value": serializer.validated_data.get('decimal_value'),
                        "text_value": serializer.validated_data.get('text_value'),
                        "bool_value": serializer.validated_data.get('bool_value'),
                    }
                )
                results.append({
                    "parameter_definition_id": pdef_id,
                    "created": created
                })
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            "detail": "Parameters saved.",
            "results": results
        }, status=status.HTTP_200_OK)


class CaseReviewSummaryAPIView(APIView):
    permission_classes = [IsAccountManager]

    def get(self, request, case_id):
        case = get_object_or_404(Case.objects.select_related("product__category", "product__subcategory"), pk=case_id)
        return Response(build_review_summary(case), status=status.HTTP_200_OK)


class CaseReviewBriefAPIView(APIView):
    permission_classes = [IsAccountManager]

    def put(self, request, case_id):
        case = get_object_or_404(Case, pk=case_id)
        brief_text = request.data.get("brief")
        if not isinstance(brief_text, str) or not brief_text.strip():
            return Response({"detail": "brief is required."}, status=status.HTTP_400_BAD_REQUEST)

        brief = Brief.objects.filter(case=case).order_by("-date", "-id").first()
        if brief:
            serializer = BriefSerializer(
                brief,
                data={
                    "brief": brief_text,
                    "case": case.id,
                    "added_by": request.data.get("added_by") or "Account Manager",
                },
                partial=True,
            )
        else:
            serializer = BriefSerializer(
                data={
                    "brief": brief_text,
                    "case": case.id,
                    "added_by": request.data.get("added_by") or "Account Manager",
                }
            )

        serializer.is_valid(raise_exception=True)
        saved = serializer.save(case=case)
        return Response(
            {
                "detail": "Final brief saved.",
                "final_brief": BriefSerializer(saved).data,
                "summary": build_review_summary(case),
            },
            status=status.HTTP_200_OK,
        )


class CaseReviewProductAPIView(APIView):
    permission_classes = [IsAccountManager]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def put(self, request, case_id):
        case = get_object_or_404(Case, pk=case_id)
        source = request.data.get("source", "custom")
        product_id = request.data.get("product_id")

        if source == "marketplace":
            if not product_id:
                return Response({"detail": "product_id is required."}, status=status.HTTP_400_BAD_REQUEST)

            from case.views import AssignFaoudProductToCaseView

            delegate_view = AssignFaoudProductToCaseView()
            delegate_view.request = request
            response = delegate_view.patch(request, case_id)
            if response.status_code >= 400:
                return response

            case.refresh_from_db()
            return Response(
                {
                    "detail": "Active product updated.",
                    "product": response.data.get("product"),
                    "summary": build_review_summary(case),
                },
                status=status.HTTP_200_OK,
            )

        if product_id:
            from case.views import EditCaseProductView

            delegate_view = EditCaseProductView()
            delegate_view.request = request
            response = delegate_view.patch(request, case_id, int(product_id))
            if response.status_code >= 400:
                return response

            case.refresh_from_db()
            current_product = case.product
            return Response(
                {
                    "detail": response.data.get("message", "Active product updated."),
                    "product": {
                        "id": current_product.id,
                        "name": current_product.name,
                        "sku_and_pm": current_product.sku_and_pm,
                        "quantity": current_product.quantity,
                        "eta": current_product.eta,
                        "benchmark": current_product.benchmark,
                        "picture": current_product.picture.url if getattr(current_product, "picture", None) else None,
                    }
                    if current_product
                    else None,
                    "summary": build_review_summary(case),
                },
                status=status.HTTP_200_OK,
            )

        from product.models import Category, Product, ProductDocument, Subcategory
        from product.serializers import ProductSerializer

        category_id = request.data.get("category")
        subcategory_id = request.data.get("subcategory")
        if not category_id or not subcategory_id:
            return Response({"detail": "category and subcategory are required."}, status=status.HTTP_400_BAD_REQUEST)

        category = Category.objects.filter(id=category_id).first()
        subcategory = Subcategory.objects.filter(id=subcategory_id, category=category).first()
        if not category or not subcategory:
            return Response({"detail": "Invalid category or subcategory."}, status=status.HTTP_400_BAD_REQUEST)

        brand_owner = case.brand_owner
        brand = brand_owner.brands.first() if brand_owner else None
        picture = request.FILES.get("picture")

        serializer_data = {
            "name": request.data.get("name"),
            "sku_and_pm": request.data.get("sku_and_pm"),
            "quantity": request.data.get("quantity"),
            "eta": request.data.get("eta"),
            "benchmark": request.data.get("benchmark"),
            "category": category.id,
            "subcategory": subcategory.id,
        }
        serializer = ProductSerializer(data=serializer_data)
        serializer.is_valid(raise_exception=True)
        product = serializer.save(picture=picture, category=category, subcategory=subcategory, brand=brand)

        brief_ids = request.data.get("briefs", "[]")
        try:
            brief_ids = json.loads(brief_ids) if isinstance(brief_ids, str) else brief_ids
        except json.JSONDecodeError:
            brief_ids = []
        if brief_ids and isinstance(brief_ids, list):
            briefs = Brief.objects.filter(id__in=brief_ids)
            product.briefs.set(briefs)

        documents_data = request.data.get("documents", "[]")
        try:
            documents_data = json.loads(documents_data) if isinstance(documents_data, str) else documents_data
        except json.JSONDecodeError:
            documents_data = []
        for document in documents_data or []:
            document_name = document.get("name")
            document_file = document.get("link")
            if document_name and document_file:
                ProductDocument.objects.create(product=product, name=document_name, file=document_file)

        case.product = product
        case.quantity = request.data.get("quantity", None)
        case.eta = request.data.get("eta", None)
        case.subcategory = subcategory
        case.save(update_fields=["product", "quantity", "eta", "subcategory"])
        product.cases.set([case])

        return Response(
            {
                "detail": "Active product created and attached.",
                "product": ProductSerializer(product).data,
                "summary": build_review_summary(case),
            },
            status=status.HTTP_200_OK,
        )


class CaseReviewParametersAPIView(APIView):
    permission_classes = [IsAccountManager]

    def put(self, request, case_id):
        case = get_object_or_404(Case, pk=case_id)
        data_list = request.data.get("parameters", [])
        if not isinstance(data_list, list):
            return Response({"detail": "'parameters' should be a list."}, status=status.HTTP_400_BAD_REQUEST)

        results = []
        for param_data in data_list:
            param_data["case"] = case.id
            serializer = CaseParameterValueSerializer(data=param_data)
            serializer.is_valid(raise_exception=True)
            pdef_id = serializer.validated_data["parameter_definition"].id
            _, created = CaseParameterValue.objects.update_or_create(
                case=case,
                parameter_definition_id=pdef_id,
                defaults={
                    "decimal_value": serializer.validated_data.get("decimal_value"),
                    "text_value": serializer.validated_data.get("text_value"),
                    "bool_value": serializer.validated_data.get("bool_value"),
                },
            )
            results.append({"parameter_definition_id": pdef_id, "created": created})

        return Response(
            {
                "detail": "Case parameters saved.",
                "results": results,
                "summary": build_review_summary(case),
            },
            status=status.HTTP_200_OK,
        )


class CaseReviewPreviewPublishAPIView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request, case_id):
        case = get_object_or_404(Case, pk=case_id)
        summary = build_review_summary(case)
        return Response(
            {
                "can_publish": summary["can_publish"],
                "checklist": summary["checklist"],
                "autobid_preview": summary["autobid_preview"],
                "publish_plan": get_publish_plan(case, summary),
                "is_live": summary["is_live"],
                "warnings": summary["warnings"],
                "blocking_issues": summary["blocking_issues"],
            },
            status=status.HTTP_200_OK,
        )


class CaseReviewPublishAPIView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request, case_id):
        case = get_object_or_404(Case, pk=case_id)
        try:
            publish_result = publish_case(case, request.user)
        except ValueError as exc:
            return Response(
                {
                    "detail": "Case is not ready to publish.",
                    "blocking_issues": str(exc).split("; "),
                    "summary": build_review_summary(case),
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        case.refresh_from_db()
        return Response(
            {
                "detail": "Case made live.",
                "publish_result": publish_result,
                "summary": build_review_summary(case),
            },
            status=status.HTTP_200_OK,
        )


class CaseReviewTakeOfflineAPIView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request, case_id):
        case = get_object_or_404(Case, pk=case_id)
        offline_result = take_case_offline(case, request.user)
        case.refresh_from_db()
        return Response(
            {
                "detail": "Case taken offline." if offline_result["offline"] else "Case is already offline.",
                "offline_result": offline_result,
                "summary": build_review_summary(case),
            },
            status=status.HTTP_200_OK,
        )


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import AutoBidConfig
from .serializers import AutoBidConfigSerializer
# from user.permissions import IsFactoryOwner
from rest_framework.permissions import IsAuthenticated

class AutoBidConfigAPIView(APIView):
    """
    GET: list all AutoBidConfigs for the authenticated factory owner
    POST: create a new AutoBidConfig
    """

    permission_classes = [IsFactoryOwner | IsAccountManager]

    def get(self, request):
        # Handle both Factory Owners and Account Managers
        factory_owner = getattr(request.user, 'factoryowner', None)
        am = getattr(request.user, 'am', None)
        
        if factory_owner:
            # Factory Owner: only show configs for their own factories
            factory_ids = factory_owner.factories.values_list('id', flat=True)
            configs = AutoBidConfig.objects.filter(factory_id__in=factory_ids)
        elif am:
            # Account Manager: show all AutoBid configs
            configs = AutoBidConfig.objects.all()
        else:
            return Response({"detail": "Access denied."}, status=status.HTTP_403_FORBIDDEN)

        serializer = AutoBidConfigSerializer(configs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        # Create a new AutoBidConfig
        # Body example:
        # {
        #   "factory": <factory_id>,
        #   "subcategory": <subcat_id>,
        #   "config_type": "FINISHED_GOOD"
        # }
        # We'll NOT handle parameter values here. We'll do it in another APIView or the same if you want.
        factory_owner = getattr(request.user, 'factoryowner', None)
        am = getattr(request.user, 'am', None)

        if not (factory_owner or am):
            return Response({"detail": "Access denied."}, status=status.HTTP_403_FORBIDDEN)

        # Validate factory access based on user type
        factory_id = request.data.get("factory")
        if factory_owner:
            # Factory Owner: validate factory belongs to them
            if not factory_owner.factories.filter(id=factory_id).exists():
                return Response({"detail": "Factory not owned by you."}, status=status.HTTP_403_FORBIDDEN)
        # Account Manager: has access to all factories, no validation needed

        serializer = AutoBidConfigSerializer(data=request.data)
        if serializer.is_valid():
            config = serializer.save()  # create
            return Response(AutoBidConfigSerializer(config).data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import AutoBidConfig, AutoBidConfigParameterValue
from .serializers import AutoBidConfigParameterValueSerializer
# from user.permissions import IsFactoryOwner
from rest_framework.permissions import IsAuthenticated


class AutoBidConfigParameterValueAPIView(APIView):
    """
    POST /api/auto-bid-configs/<config_id>/params/
    Body:
    {
      "parameters": [
         {
           "parameter_definition": <id>,
           "decimal_value": "123.45"
         },
         {
           "parameter_definition": <id>,
           "decimal_value": "40.00"
         }
      ]
    }
    This upserts parameter values for the given config.
    """

    permission_classes = [IsFactoryOwner | IsAccountManager]

    def get(self, request, config_id):
        try:
            config = AutoBidConfig.objects.get(id=config_id)
        except AutoBidConfig.DoesNotExist:
            return Response({"error": "AutoBidConfig not found"}, status=404)

        values = AutoBidConfigParameterValue.objects.filter(auto_bid_config=config)
        data = []
        for val in values:
            data.append({
                 "parameter_definition": {
                "id": val.parameter_definition.id,
                "name": val.parameter_definition.name,
                "data_type": val.parameter_definition.data_type,
                                 },
                "decimal_value": val.decimal_value,
                "text_value": val.text_value,
                "bool_value": val.bool_value,
            })
        return Response({"values": data}, status=status.HTTP_200_OK)

    def post(self, request, config_id):
        # 1. Validate config
        try:
            config_obj = AutoBidConfig.objects.get(pk=config_id)
        except AutoBidConfig.DoesNotExist:
            return Response({"detail": "Config not found."}, status=status.HTTP_404_NOT_FOUND)

        # 2. Verify user is the factory owner for that config
        factory_owner = getattr(request.user, 'factoryowner', None)
        if not factory_owner:
            return Response({"detail": "Not a factory owner."}, status=status.HTTP_403_FORBIDDEN)
        factories_owned = Factory.objects.filter(factory_owner=factory_owner)
        if config_obj.factory not in factories_owned:
            return Response({"detail": "You do not own that factory."}, status=status.HTTP_403_FORBIDDEN)
        name_congic = config_obj.name
        # 3. Iterate over incoming parameters
        param_list = request.data.get('parameters', [])
        if not isinstance(param_list, list):
            return Response({"detail": "'parameters' must be a list."}, status=status.HTTP_400_BAD_REQUEST)

        results = []
        for item in param_list:
            item['auto_bid_config'] = config_obj.id
            serializer = AutoBidConfigParameterValueSerializer(data=item)
            if serializer.is_valid():
                param_def_id = serializer.validated_data['parameter_definition'].id
                # Upsert
                obj, created = AutoBidConfigParameterValue.objects.update_or_create(
                    auto_bid_config=config_obj,
                    parameter_definition_id=param_def_id,
                    defaults={
                        "decimal_value": serializer.validated_data.get('decimal_value'),
                        "text_value": serializer.validated_data.get('text_value'),
                        "bool_value": serializer.validated_data.get('bool_value'),
                    }
                )
                results.append({"param_def": param_def_id, "created": created})
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            "detail": "Parameters updated successfully.",
            "results": results
        }, status=status.HTTP_200_OK)


class CaseParameterValueList(APIView):
    permission_classes = [IsSuperAccountManager]

    def get(self, request, case_id):
        try:
            case = Case.objects.get(id=case_id)
        except Case.DoesNotExist:
            return Response({"error": "Case not found"}, status=404)

        values = CaseParameterValue.objects.filter(case=case)
        data = []
        for val in values:
            data.append({
                "parameter_definition": val.parameter_definition.id,  # <-- THIS is key
                "parameter": val.parameter_definition.name,
                "data_type": val.parameter_definition.data_type,
                "decimal_value": val.decimal_value,
                "text_value": val.text_value,
                "bool_value": val.bool_value,
            })
        return Response({"values": data}, status=status.HTTP_200_OK)


# views.py

class AutoBidConfigAPIView(APIView):
    """
    Create or list AutoBidConfigs. 
    We’ll auto-create parameter values for the relevant subcategory + config_type
    so the factory owner can fill them in the next step.
    """

    permission_classes = [IsFactoryOwner | IsAccountManager]

    def get(self, request):
        # Handle both Factory Owners and Account Managers
        factory_owner = getattr(request.user, 'factoryowner', None)
        am = getattr(request.user, 'am', None)
        
        if factory_owner:
            # Factory Owner: only show configs for their own factories
            factories = Factory.objects.filter(factory_owner=factory_owner)
            factory_ids = [factory.id for factory in factories]
            configs = AutoBidConfig.objects.filter(factory_id__in=factory_ids)
        elif am:
            # Account Manager: show all AutoBid configs
            configs = AutoBidConfig.objects.all()
        else:
            return Response({"detail": "Access denied."}, status=status.HTTP_403_FORBIDDEN)

        serializer = AutoBidConfigSerializer(configs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)   

    def post(self, request):
        factory_owner = getattr(request.user, 'factoryowner', None)
        am = getattr(request.user, 'am', None)

        if not (factory_owner or am):
            return Response({"detail": "Access denied."}, status=status.HTTP_403_FORBIDDEN)

        # Suppose the user’s posted data is:
        # { "factory": <id>, "subcategory": <id>, "config_type": "JUST_CONVERSION" }
        serializer = AutoBidConfigSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        config = serializer.save()

        # Validate factory access based on user type
        if factory_owner:
            # Factory Owner: check that factory belongs to them
            factories_by_owner = Factory.objects.filter(factory_owner=factory_owner)
            if config.factory not in factories_by_owner:
                config.delete()  # remove partial if not owned
                return Response({"detail": "You do not own that factory."}, status=status.HTTP_403_FORBIDDEN)
        # Account Manager: has access to all factories, no validation needed
        
        # Auto-create parameter placeholders from ParameterDefinition

        param_defs = ParameterDefinition.objects.filter(
            subcategory=config.subcategory,
            config_type=config.config_type
        )


        for pd in param_defs:
            # Create or skip if already exists
            AutoBidConfigParameterValue.objects.get_or_create(
                auto_bid_config=config,
                parameter_definition=pd
            )

        return Response(AutoBidConfigSerializer(config).data, status=status.HTTP_201_CREATED)


# views.py snippet
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status
from .models import AutoBidConfig
from .serializers import AutoBidConfigSerializer

class AutoBidConfigDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = AutoBidConfig.objects.all()
    serializer_class = AutoBidConfigSerializer
    permission_classes = [IsFactoryOwner | IsAccountManager]

    def patch(self, request, *args, **kwargs):
        response = self.partial_update(request, *args, **kwargs)

        return response



# is case ready for bidding?
class IsCaseReadyForAutoBid(APIView):
    """
    GET /api/isCaseReadyForBidding/<case_id>/
    Check if a case is ready for bidding.
    """
    permission_classes = [IsAccountManager]

    def get(self, request, case_id):
        try:
            case = Case.objects.get(id=case_id)
        except Case.DoesNotExist:
            return Response({"error": "Case not found"}, status=404)

        # Check if the case is ready for bidding
        # This is a placeholder. You should implement your own logic.
        is_ready = is_case_ready_for_autobid(case)  # Replace with actual logic

        return Response({"is_ready": is_ready}, status=status.HTTP_200_OK)
    

class IsCaseReadyForBid(APIView):
    """
    GET /api/isCaseReadyForBidding/<case_id>/
    Check if a case is ready for bidding.
    """
    permission_classes = [IsAccountManager]

    def get(self, request, case_id):
        try:
            case = Case.objects.get(id=case_id)
        except Case.DoesNotExist:
            return Response({"error": "Case not found"}, status=404)

        # Check if the case is ready for bidding
        # This is a placeholder. You should implement your own logic.
        is_ready = is_case_ready_for_bid(case)  # Replace with actual logic

        return Response({"is_ready": is_ready}, status=status.HTTP_200_OK)


class AutoBidVerificationAPIView(APIView):
    """
    PATCH /api/auto-bid-configs/<config_id>/verify/
    Account Manager-only endpoint to verify/unverify AutoBid configurations
    Body: { "approved_by_am": true/false }
    """
    permission_classes = [IsAccountManager]

    def patch(self, request, config_id):
        try:
            config = AutoBidConfig.objects.get(id=config_id)
        except AutoBidConfig.DoesNotExist:
            return Response({"error": "AutoBidConfig not found"}, status=status.HTTP_404_NOT_FOUND)

        # Get the verification status from request
        approved_by_am = request.data.get('approved_by_am')
        if approved_by_am is None:
            return Response(
                {"error": "approved_by_am field is required"}, 
                status=status.HTTP_400_BAD_REQUEST
            )

        # Update the verification status
        config.approved_by_am = approved_by_am
        config.save()

        # Return updated config data
        from .serializers import AutoBidConfigSerializer
        serializer = AutoBidConfigSerializer(config)
        
        return Response({
            "message": f"AutoBid configuration {'verified' if approved_by_am else 'unverified'} successfully",
            "config": serializer.data
        }, status=status.HTTP_200_OK)
