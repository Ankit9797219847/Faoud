from core.review import build_review_summary


def is_case_ready_for_autobid(case):
    summary = build_review_summary(case)
    return summary["case_parameters"]["all_required_present"] and bool(summary["active_product"])


def is_case_ready_for_finished_good_autobid(case):
    return is_case_ready_for_autobid(case)


def is_case_ready_for_bid(case):
    summary = build_review_summary(case)
    return summary["can_publish"]
