from django.contrib.auth.models import User
from django.test import override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient, APITestCase

from case.models import Case, ProgressStage, Stage
from core.models import AutoBidConfig, AutoBidConfigParameterValue, CaseParameterValue, ParameterDefinition
from product.models import Category, Product, Subcategory
from supply.models import Bid, Factory
from user.models import AM, BrandOwner
from utils.models import Brief


@override_settings(ROOT_URLCONF="shadow.urls")
class CaseReviewWorkflowAPITest(APITestCase):
    def setUp(self):
        self.client = APIClient()

        self.reviewed_stage = Stage.objects.create(name="Reviewed", order=2)
        self.factory_selection_stage = Stage.objects.create(name="Factory Selection", order=3)

        self.user = User.objects.create_user(username="am-review", password="pass")
        self.am = AM.objects.create(user=self.user, name="AM Review")
        self.client.force_authenticate(user=self.user)

        self.brand_user = User.objects.create_user(username="brand-review", password="pass")
        self.brand_owner = BrandOwner.objects.create(user=self.brand_user, name="Brand Review")

        self.category = Category.objects.create(name="Skin Care")
        self.subcategory = Subcategory.objects.create(name="Face Wash", category=self.category)

        self.margin_def = ParameterDefinition.objects.create(
            name="Faoud Margin",
            subcategory=self.subcategory,
            data_type="DECIMAL",
            is_required=True,
        )
        self.rm_def = ParameterDefinition.objects.create(
            name="RM Cost",
            subcategory=self.subcategory,
            data_type="DECIMAL",
            is_required=True,
        )
        self.pm_def = ParameterDefinition.objects.create(
            name="PM Cost",
            subcategory=self.subcategory,
            data_type="DECIMAL",
            is_required=True,
        )
        self.wastage_def = ParameterDefinition.objects.create(
            name="Wastage",
            subcategory=self.subcategory,
            data_type="DECIMAL",
            is_required=True,
        )
        self.conversion_def = ParameterDefinition.objects.create(
            name="Conversion Charge",
            subcategory=self.subcategory,
            config_type="JUST_CONVERSION",
            data_type="DECIMAL",
            is_required=True,
        )

        self.case = Case.objects.create(
            brand_owner=self.brand_owner,
            name="Review Case",
            category="npd_without",
            active=0,
        )
        self.case.am.add(self.am)

        self.preview_url = reverse("case-review-preview-publish", kwargs={"case_id": self.case.id})
        self.publish_url = reverse("case-review-publish", kwargs={"case_id": self.case.id})
        self.stage_preview_url = reverse("case-stage-preview", kwargs={"case_id": self.case.id})

    def _attach_ready_product_and_inputs(self):
        product = Product.objects.create(
            name="Ready Product",
            category=self.category,
            subcategory=self.subcategory,
            quantity=1000,
            sku_and_pm="SKU-1",
        )
        self.case.product = product
        self.case.save(update_fields=["product"])

        Brief.objects.create(case=self.case, brief="<p>Reviewed brief</p>", added_by="AM")
        CaseParameterValue.objects.create(case=self.case, parameter_definition=self.margin_def, decimal_value="10.00")
        CaseParameterValue.objects.create(case=self.case, parameter_definition=self.rm_def, decimal_value="11.00")
        CaseParameterValue.objects.create(case=self.case, parameter_definition=self.pm_def, decimal_value="12.00")
        CaseParameterValue.objects.create(case=self.case, parameter_definition=self.wastage_def, decimal_value="13.00")

        factory = Factory.objects.create(name="Ready Factory")
        config = AutoBidConfig.objects.create(
            name="Ready Config",
            factory=factory,
            subcategory=self.subcategory,
            config_type="JUST_CONVERSION",
            approved_by_am=True,
            enabled=True,
        )
        AutoBidConfigParameterValue.objects.create(
            auto_bid_config=config,
            parameter_definition=self.conversion_def,
            decimal_value="14.00",
        )

    def test_preview_publish_returns_blockers_when_final_brief_and_product_missing(self):
        response = self.client.post(self.preview_url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertFalse(response.data["can_publish"])
        self.assertIn("Save the final brief before making the case live.", response.data["blocking_issues"])
        self.assertIn("Attach an active product before making the case live.", response.data["blocking_issues"])

    def test_publish_creates_autobid_once_and_marks_reviewed(self):
        self._attach_ready_product_and_inputs()

        first_response = self.client.post(self.publish_url)
        self.assertEqual(first_response.status_code, status.HTTP_200_OK)
        self.assertEqual(first_response.data["publish_result"]["created_bid_count"], 1)
        self.assertEqual(first_response.data["publish_result"]["updated_bid_count"], 0)
        self.assertTrue(first_response.data["publish_result"]["reviewed_stage_synced"])
        self.assertEqual(Bid.objects.filter(case=self.case, tag="autobid").count(), 1)
        self.assertTrue(
            ProgressStage.objects.filter(case=self.case, stage=self.reviewed_stage, completion_date__isnull=False).exists()
        )

        second_response = self.client.post(self.publish_url)
        self.assertEqual(second_response.status_code, status.HTTP_200_OK)
        self.assertTrue(second_response.data["publish_result"]["already_published"])
        self.assertEqual(second_response.data["publish_result"]["created_bid_count"], 0)
        self.assertEqual(Bid.objects.filter(case=self.case, tag="autobid").count(), 1)

    def test_republish_updates_existing_autobid_without_creating_or_deleting(self):
        self._attach_ready_product_and_inputs()

        first_response = self.client.post(self.publish_url)
        self.assertEqual(first_response.status_code, status.HTTP_200_OK)

        bid = Bid.objects.get(case=self.case, tag="autobid")
        original_quote_bo = bid.quote_bo
        original_quote = bid.quote

        margin_value = CaseParameterValue.objects.get(case=self.case, parameter_definition=self.margin_def)
        margin_value.decimal_value = "30.00"
        margin_value.save(update_fields=["decimal_value"])

        second_response = self.client.post(self.publish_url)
        self.assertEqual(second_response.status_code, status.HTTP_200_OK)
        self.assertTrue(second_response.data["publish_result"]["already_published"])
        self.assertEqual(second_response.data["publish_result"]["created_bid_count"], 0)
        self.assertEqual(second_response.data["publish_result"]["updated_bid_count"], 1)
        self.assertEqual(Bid.objects.filter(case=self.case, tag="autobid").count(), 1)

        bid.refresh_from_db()
        self.assertEqual(bid.id, first_response.data["publish_result"]["created_bid_ids"][0])
        self.assertNotEqual(bid.quote_bo, original_quote_bo)
        self.assertEqual(bid.quote, original_quote)

    def test_republish_creates_newly_eligible_autobid_and_updates_existing_ones(self):
        self._attach_ready_product_and_inputs()
        first_response = self.client.post(self.publish_url)
        self.assertEqual(first_response.status_code, status.HTTP_200_OK)
        self.assertEqual(Bid.objects.filter(case=self.case, tag="autobid").count(), 1)

        second_factory = Factory.objects.create(name="Second Ready Factory")
        second_config = AutoBidConfig.objects.create(
            name="Second Ready Config",
            factory=second_factory,
            subcategory=self.subcategory,
            config_type="JUST_CONVERSION",
            approved_by_am=True,
            enabled=True,
        )
        AutoBidConfigParameterValue.objects.create(
            auto_bid_config=second_config,
            parameter_definition=self.conversion_def,
            decimal_value="20.00",
        )

        republish_response = self.client.post(self.publish_url)
        self.assertEqual(republish_response.status_code, status.HTTP_200_OK)
        self.assertTrue(republish_response.data["publish_result"]["already_published"])
        self.assertEqual(republish_response.data["publish_result"]["created_bid_count"], 1)
        self.assertEqual(republish_response.data["publish_result"]["updated_bid_count"], 0)
        self.assertEqual(Bid.objects.filter(case=self.case, tag="autobid").count(), 2)

    def test_stage_preview_for_reviewed_returns_backend_driven_impacts(self):
        response = self.client.post(self.stage_preview_url, {"stage_name": "Reviewed"}, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertFalse(response.data["allowed"])
        self.assertTrue(any(item["type"] == "automation" for item in response.data["impacts"]))
        self.assertIn("Save the final brief before making the case live.", response.data["blocking_issues"])

    def test_case_parameter_status_excludes_factory_config_parameters(self):
        self._attach_ready_product_and_inputs()

        summary_response = self.client.get(reverse("case-review-summary", kwargs={"case_id": self.case.id}))

        self.assertEqual(summary_response.status_code, status.HTTP_200_OK)
        parameter_names = [item["name"] for item in summary_response.data["case_parameters"]["items"]]
        self.assertNotIn("Conversion Charge", parameter_names)
        self.assertEqual(summary_response.data["autobid_preview"]["expected_bid_count"], 1)
