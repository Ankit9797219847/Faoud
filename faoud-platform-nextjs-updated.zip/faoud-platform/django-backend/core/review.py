from __future__ import annotations

from decimal import Decimal
from typing import Any

from django.db.models import Q

from case.models import Case, ProgressStage, Stage
from core.models import AutoBidConfig, CaseParameterValue, ParameterDefinition
from supply.models import Bid
from utils.models import Brief


FALLBACK_REQUIRED_PARAMETER_NAMES = {"RM Cost", "PM Cost", "Wastage", "Faoud Margin"}


def get_case_subcategory(case: Case):
    if getattr(case, "product", None) and getattr(case.product, "subcategory", None):
        return case.product.subcategory
    return getattr(case, "subcategory", None)


def get_case_final_brief(case: Case) -> Brief | None:
    return Brief.objects.filter(case=case).order_by("-date", "-id").first()


def get_case_parameter_definitions(case: Case):
    subcategory = get_case_subcategory(case)
    if not subcategory:
        return ParameterDefinition.objects.none()
    return ParameterDefinition.objects.filter(
        subcategory=subcategory
    ).filter(
        Q(config_type__isnull=True) | Q(config_type="")
    ).order_by("is_required", "id")


def serialize_parameter_value(value: CaseParameterValue | None) -> dict[str, Any] | None:
    if not value:
        return None
    return {
        "id": value.id,
        "parameter_definition": value.parameter_definition.id,
        "name": value.parameter_definition.name,
        "data_type": value.parameter_definition.data_type,
        "decimal_value": value.decimal_value,
        "text_value": value.text_value,
        "bool_value": value.bool_value,
        "value": value.get_value(),
    }


def serialize_parameter_definition(definition: ParameterDefinition, current_value: CaseParameterValue | None) -> dict[str, Any]:
    return {
        "id": definition.id,
        "name": definition.name,
        "data_type": definition.data_type,
        "is_required": definition.is_required or definition.name in FALLBACK_REQUIRED_PARAMETER_NAMES,
        "help_text": definition.help_text,
        "value": serialize_parameter_value(current_value),
        "is_missing": current_value is None or current_value.get_value() in (None, ""),
    }


def get_case_parameter_status(case: Case) -> dict[str, Any]:
    definitions = list(get_case_parameter_definitions(case))
    value_map = {
        value.parameter_definition_id: value
        for value in CaseParameterValue.objects.filter(case=case).select_related("parameter_definition")
    }
    items = [serialize_parameter_definition(definition, value_map.get(definition.id)) for definition in definitions]
    required_items = [item for item in items if item["is_required"]]
    missing_required = [item["name"] for item in required_items if item["is_missing"]]

    return {
        "items": items,
        "total_count": len(items),
        "required_count": len(required_items),
        "missing_required": missing_required,
        "all_required_present": not missing_required,
    }


def get_reviewed_progress_stage(case: Case) -> ProgressStage | None:
    return (
        case.progress_stages.select_related("stage")
        .filter(stage__name="Reviewed", completion_date__isnull=False)
        .order_by("-completion_date", "-id")
        .first()
    )


def build_review_checklist(case: Case) -> list[dict[str, Any]]:
    final_brief = get_case_final_brief(case)
    parameter_status = get_case_parameter_status(case)
    reviewed_stage = get_reviewed_progress_stage(case)

    return [
        {
            "key": "final_brief",
            "label": "Final brief saved",
            "status": "done" if final_brief and (final_brief.brief or "").strip() else "missing",
            "detail": "The reviewed brief will be shown as the final requirement for this case.",
        },
        {
            "key": "active_product",
            "label": "Active product attached",
            "status": "done" if case.product_id else "missing",
            "detail": "This product is what factories will bid against.",
        },
        {
            "key": "case_parameters",
            "label": "Required autobid inputs filled",
            "status": "done" if parameter_status["all_required_present"] else "warning",
            "detail": (
                "All required parameters are filled."
                if parameter_status["all_required_present"]
                else f"Missing: {', '.join(parameter_status['missing_required'])}"
            ),
        },
        {
            "key": "reviewed",
            "label": "Reviewed stage completed",
            "status": "done" if reviewed_stage else "pending",
            "detail": (
                f"Completed on {reviewed_stage.completion_date}" if reviewed_stage else "This will be marked when the case is made live."
            ),
        },
    ]


def _config_skip_reason(case: Case, config: AutoBidConfig, parameter_status: dict[str, Any]) -> tuple[str, str]:
    if not config.enabled:
        return ("skipped_not_enabled", "This autobid config is disabled.")
    if not config.approved_by_am:
        return ("skipped_not_approved", "This autobid config is not approved by an account manager.")
    if not case.product_id:
        return ("skipped_missing_product", "This case does not have an active product yet.")
    if parameter_status["missing_required"]:
        missing = ", ".join(parameter_status["missing_required"])
        return ("skipped_missing_case_parameter", f"Missing required case parameters: {missing}.")
    if config.config_type == "JUST_CONVERSION":
        required_factory_values = config.parameter_values.filter(parameter_definition__name="Conversion Charge")
        if required_factory_values.exists() and required_factory_values.first().get_value() in (None, ""):
            return ("skipped_config_incomplete", "Factory autobid config is missing Conversion Charge.")
    if config.config_type == "FINISHED_GOOD":
        required_factory_values = config.parameter_values.filter(parameter_definition__name="Final Cost")
        if required_factory_values.exists() and required_factory_values.first().get_value() in (None, ""):
            return ("skipped_config_incomplete", "Factory autobid config is missing Final Cost.")
    return ("will_create_bid", "This autobid config is ready and will create a bid.")


def get_autobid_preview(case: Case) -> dict[str, Any]:
    subcategory = get_case_subcategory(case)
    parameter_status = get_case_parameter_status(case)
    if not subcategory:
        return {
            "matching_config_count": 0,
            "expected_bid_count": 0,
            "ready_config_count": 0,
            "warnings": ["Select a product with a subcategory to evaluate autobids."],
            "items": [],
        }

    configs = (
        AutoBidConfig.objects.filter(subcategory=subcategory)
        .select_related("factory", "facility_line")
        .prefetch_related("parameter_values__parameter_definition")
        .order_by("id")
    )

    items: list[dict[str, Any]] = []
    warnings: list[str] = []
    expected_bid_count = 0
    ready_config_count = 0
    for config in configs:
        reason_code, reason_text = _config_skip_reason(case, config, parameter_status)
        will_create = reason_code == "will_create_bid"
        bid_preview = None
        if will_create:
            ready_config_count += 1
            expected_bid_count += 1
            quote_bo, quote = config.compute_bid(case)
            bid_preview = {
                "quote_bo": quote_bo,
                "quote": quote,
            }
        else:
            warnings.append(reason_text)

        items.append(
            {
                "config_id": config.id,
                "config_name": config.name,
                "factory_id": config.factory_id,
                "factory_name": config.factory.name if config.factory_id else None,
                "facility_line_id": config.facility_line_id,
                "facility_line_name": getattr(config.facility_line, "name", None),
                "status": reason_code,
                "reason": reason_text,
                "approved_by_am": config.approved_by_am,
                "enabled": config.enabled,
                "bid_preview": bid_preview,
            }
        )

    return {
        "matching_config_count": len(items),
        "expected_bid_count": expected_bid_count,
        "ready_config_count": ready_config_count,
        "warnings": list(dict.fromkeys(warnings)),
        "items": items,
    }


def build_review_summary(case: Case) -> dict[str, Any]:
    final_brief = get_case_final_brief(case)
    parameter_status = get_case_parameter_status(case)
    autobid_preview = get_autobid_preview(case)
    reviewed_stage = get_reviewed_progress_stage(case)
    checklist = build_review_checklist(case)
    active_product = None
    if case.product_id:
        active_product = {
            "id": case.product.id,
            "name": case.product.name,
            "sku_and_pm": case.product.sku_and_pm,
            "quantity": case.product.quantity,
            "eta": case.product.eta,
            "benchmark": case.product.benchmark,
            "category_id": case.product.category_id,
            "subcategory_id": case.product.subcategory_id,
            "picture": case.product.picture.url if getattr(case.product, "picture", None) else None,
        }

    blockers = []
    if not final_brief or not (final_brief.brief or "").strip():
        blockers.append("Save the final brief before making the case live.")
    if not case.product_id:
        blockers.append("Attach an active product before making the case live.")

    can_publish = not blockers
    if reviewed_stage:
        review_state = "live"
    elif can_publish:
        review_state = "ready_to_publish"
    elif final_brief or case.product_id or parameter_status["items"]:
        review_state = "review_in_progress"
    else:
        review_state = "draft"

    return {
        "case_id": case.id,
        "review_state": review_state,
        "is_live": bool(reviewed_stage),
        "published_at": reviewed_stage.completion_date if reviewed_stage else None,
        "can_publish": can_publish,
        "blocking_issues": blockers,
        "warnings": autobid_preview["warnings"],
        "checklist": checklist,
        "active_product": active_product,
        "final_brief": (
            {
                "id": final_brief.id,
                "brief": final_brief.brief,
                "added_by": final_brief.added_by,
                "date": final_brief.date,
            }
            if final_brief
            else None
        ),
        "case_parameters": parameter_status,
        "autobid_preview": autobid_preview,
        "publish_result": (
            {
                "published": True,
                "published_at": reviewed_stage.completion_date,
                "created_bid_count": Bid.objects.filter(case=case, tag="autobid").count(),
            }
            if reviewed_stage
            else None
        ),
    }


def get_publish_plan(case: Case, summary: dict[str, Any] | None = None) -> dict[str, Any]:
    summary = summary or build_review_summary(case)
    preview_items = summary["autobid_preview"]["items"]
    eligible_config_ids = [item["config_id"] for item in preview_items if item["status"] == "will_create_bid"]

    configs = {
        config.id: config
        for config in AutoBidConfig.objects.filter(id__in=eligible_config_ids).prefetch_related("parameter_values")
    }
    existing_bids = {
        (bid.factory_id, bid.facility_line_id): bid
        for bid in Bid.objects.filter(case=case, tag="autobid").prefetch_related("autobid_parameters")
    }

    items: list[dict[str, Any]] = []
    create_count = 0
    update_count = 0
    unchanged_count = 0
    skipped_count = 0

    for item in preview_items:
        if item["status"] != "will_create_bid":
            skipped_count += 1
            items.append(
                {
                    "config_id": item["config_id"],
                    "factory_name": item["factory_name"],
                    "action": "skip",
                    "reason": item["reason"],
                }
            )
            continue

        config = configs[item["config_id"]]
        bid = existing_bids.get((config.factory_id, config.facility_line_id))
        quote_bo, quote = config.compute_bid(case)
        new_quote = Decimal(str(quote or 0))
        new_quote_bo = Decimal(str(quote_bo or 0))

        if not bid:
            create_count += 1
            items.append(
                {
                    "config_id": item["config_id"],
                    "factory_name": item["factory_name"],
                    "action": "create",
                    "reason": "A new autobid will be created for this config.",
                }
            )
            continue

        current_parameter_ids = set(bid.autobid_parameters.values_list("id", flat=True))
        new_parameter_ids = set(config.parameter_values.values_list("id", flat=True))
        bid_changes = []
        if bid.quote != new_quote:
            bid_changes.append("factory quote")
        if bid.quote_bo != new_quote_bo:
            bid_changes.append("brand quote")
        if current_parameter_ids != new_parameter_ids:
            bid_changes.append("autobid parameters")

        if bid_changes:
            update_count += 1
            items.append(
                {
                    "config_id": item["config_id"],
                    "factory_name": item["factory_name"],
                    "action": "update",
                    "reason": f"This existing autobid will be updated: {', '.join(bid_changes)}.",
                    "bid_id": bid.id,
                }
            )
        else:
            unchanged_count += 1
            items.append(
                {
                    "config_id": item["config_id"],
                    "factory_name": item["factory_name"],
                    "action": "unchanged",
                    "reason": "This existing autobid is already up to date.",
                    "bid_id": bid.id,
                }
            )

    return {
        "create_count": create_count,
        "update_count": update_count,
        "unchanged_count": unchanged_count,
        "skipped_count": skipped_count,
        "items": items,
    }


def take_case_offline(case: Case, user) -> dict[str, Any]:
    reviewed_stage = get_reviewed_progress_stage(case)
    if not reviewed_stage:
        return {
            "offline": False,
            "already_offline": True,
            "removed_stage_count": 0,
            "reviewed_stage_removed": False,
            "taken_offline_by": getattr(user, "username", None),
        }

    removed_progress_stages = list(
        case.progress_stages.filter(order_in_timeline__gte=reviewed_stage.order_in_timeline).select_related("stage")
    )
    removed_stage_names = [progress.stage.name for progress in removed_progress_stages]
    removed_count = len(removed_progress_stages)
    case.progress_stages.filter(id__in=[progress.id for progress in removed_progress_stages]).delete()

    return {
        "offline": True,
        "already_offline": False,
        "removed_stage_count": removed_count,
        "removed_stage_names": removed_stage_names,
        "reviewed_stage_removed": True,
        "taken_offline_by": getattr(user, "username", None),
    }


def publish_case(case: Case, user) -> dict[str, Any]:
    summary = build_review_summary(case)
    publish_plan = get_publish_plan(case, summary)
    reviewed_stage = get_reviewed_progress_stage(case)
    if reviewed_stage:
        created_bid_ids: list[int] = []
        updated_bid_ids: list[int] = []
        existing_bids = {
            (bid.factory_id, bid.facility_line_id): bid
            for bid in Bid.objects.filter(case=case, tag="autobid").prefetch_related("autobid_parameters")
        }

        for item in summary["autobid_preview"]["items"]:
            if item["status"] != "will_create_bid":
                continue

            config = AutoBidConfig.objects.prefetch_related("parameter_values").get(id=item["config_id"])
            bid = existing_bids.get((config.factory_id, config.facility_line_id))
            quote_bo, quote = config.compute_bid(case)
            new_quote = Decimal(str(quote or 0))
            new_quote_bo = Decimal(str(quote_bo or 0))
            if not bid:
                bid = Bid.objects.create(
                    case=case,
                    factory=config.factory,
                    facility_line=config.facility_line,
                    tag="autobid",
                    quote=new_quote,
                    quote_bo=new_quote_bo,
                    status="in_review",
                )
                if config.parameter_values.exists():
                    bid.autobid_parameters.set(config.parameter_values.all())
                created_bid_ids.append(bid.id)
                continue

            fields_to_update: list[str] = []
            if bid.quote != new_quote:
                bid.quote = new_quote
                fields_to_update.append("quote")
            if bid.quote_bo != new_quote_bo:
                bid.quote_bo = new_quote_bo
                fields_to_update.append("quote_bo")

            current_parameter_ids = set(bid.autobid_parameters.values_list("id", flat=True))
            new_parameter_ids = set(config.parameter_values.values_list("id", flat=True))

            if fields_to_update:
                bid.save(update_fields=fields_to_update)
            if current_parameter_ids != new_parameter_ids:
                bid.autobid_parameters.set(config.parameter_values.all())

            if fields_to_update or current_parameter_ids != new_parameter_ids:
                updated_bid_ids.append(bid.id)

        existing_ids = list(existing_bids.values())
        return {
            "published": True,
            "already_published": True,
            "published_at": reviewed_stage.completion_date,
            "published_by": getattr(user, "username", None),
            "created_bid_count": len(created_bid_ids),
            "created_bid_ids": created_bid_ids,
            "updated_bid_count": len(updated_bid_ids),
            "updated_bid_ids": updated_bid_ids,
            "unchanged_bid_count": publish_plan["unchanged_count"],
            "skipped_bid_count": publish_plan["skipped_count"],
            "all_bid_ids": [bid.id for bid in existing_ids] + created_bid_ids,
            "reviewed_stage_synced": True,
        }

    if not summary["can_publish"]:
        raise ValueError("; ".join(summary["blocking_issues"]))

    created_bid_ids: list[int] = []
    updated_bid_ids: list[int] = []
    skipped_count = 0
    for item in summary["autobid_preview"]["items"]:
        if item["status"] != "will_create_bid":
            skipped_count += 1
            continue

        config = AutoBidConfig.objects.prefetch_related("parameter_values").get(id=item["config_id"])
        quote_bo, quote = config.compute_bid(case)
        bid, created = Bid.objects.get_or_create(
            case=case,
            factory=config.factory,
            facility_line=config.facility_line,
            tag="autobid",
            defaults={
                "quote": Decimal(str(quote or 0)),
                "quote_bo": Decimal(str(quote_bo or 0)),
                "status": "in_review",
            },
        )
        if created:
            if config.parameter_values.exists():
                bid.autobid_parameters.set(config.parameter_values.all())
            created_bid_ids.append(bid.id)
        else:
            new_quote = Decimal(str(quote or 0))
            new_quote_bo = Decimal(str(quote_bo or 0))
            fields_to_update: list[str] = []
            if bid.quote != new_quote:
                bid.quote = new_quote
                fields_to_update.append("quote")
            if bid.quote_bo != new_quote_bo:
                bid.quote_bo = new_quote_bo
                fields_to_update.append("quote_bo")
            if fields_to_update:
                bid.save(update_fields=fields_to_update)
            if config.parameter_values.exists():
                bid.autobid_parameters.set(config.parameter_values.all())
            updated_bid_ids.append(bid.id)

    autobid_ids_after_publish = list(Bid.objects.filter(case=case, tag="autobid").values_list("id", flat=True))

    reviewed_stage_obj = Stage.objects.filter(name="Reviewed").first()
    reviewed_stage_synced = False
    published_at = None
    if reviewed_stage_obj:
        progress_stage, _ = ProgressStage.objects.get_or_create(
            case=case,
            stage=reviewed_stage_obj,
            defaults={
                "order_in_timeline": reviewed_stage_obj.order,
                "completion_date": case.updated_at.date(),
            },
        )
        if not progress_stage.completion_date:
            progress_stage.completion_date = case.updated_at.date()
            progress_stage.order_in_timeline = reviewed_stage_obj.order
            progress_stage.save(update_fields=["completion_date", "order_in_timeline"])
        reviewed_stage_synced = True
        published_at = progress_stage.completion_date

    return {
        "published": True,
        "already_published": False,
        "published_at": published_at,
        "published_by": getattr(user, "username", None),
        "created_bid_count": len(created_bid_ids),
        "created_bid_ids": created_bid_ids or autobid_ids_after_publish,
        "updated_bid_count": len(updated_bid_ids),
        "updated_bid_ids": updated_bid_ids,
        "unchanged_bid_count": publish_plan["unchanged_count"],
        "skipped_bid_count": skipped_count,
        "reviewed_stage_synced": reviewed_stage_synced,
    }


def get_stage_summary(case: Case) -> dict[str, Any]:
    all_stages = list(Stage.objects.all().order_by("order"))
    completed = {
        progress.stage_id: progress
        for progress in case.progress_stages.filter(completion_date__isnull=False).select_related("stage")
    }
    current = None
    if completed:
        current_progress = sorted(completed.values(), key=lambda progress: progress.order_in_timeline)[-1]
        current = current_progress.stage.name

    available_transitions = []
    blocked_transitions = []
    review_summary = build_review_summary(case)
    reviewed_completed = get_reviewed_progress_stage(case) is not None
    has_selected_factory = case.factory_id is not None
    factory_selection_stage = next((stage for stage in all_stages if stage.name == "Factory Selection"), None)
    factory_selection_order = factory_selection_stage.order if factory_selection_stage else None
    for stage in all_stages:
        transition = {
            "id": stage.id,
            "stage_name": stage.name,
            "completed": stage.id in completed,
            "completion_date": completed[stage.id].completion_date if stage.id in completed else None,
        }
        if stage.name == "Reviewed" and not review_summary["can_publish"] and stage.id not in completed:
            transition["blocked_reason"] = "; ".join(review_summary["blocking_issues"])
            blocked_transitions.append(transition)
        elif stage.name == "Factory Selection" and not reviewed_completed and stage.id not in completed:
            transition["blocked_reason"] = "Make the case live first. Factory Selection only opens after Reviewed is complete."
            blocked_transitions.append(transition)
        elif (
            factory_selection_order is not None
            and stage.order > factory_selection_order
            and not has_selected_factory
            and stage.id not in completed
        ):
            transition["blocked_reason"] = "Select a factory before moving to the next order stage."
            blocked_transitions.append(transition)
        else:
            available_transitions.append(transition)

    descriptions = []
    for stage in all_stages:
        description = f"Move the case to {stage.name}."
        if stage.name == "Reviewed":
            description = "Make the case live for review completion and autobid creation preview."
        elif stage.name == "Factory Selection":
            description = "Factories can be matched and bids can be reviewed in this stage."
        descriptions.append({"stage_name": stage.name, "description": description})

    return {
        "current_stage": current,
        "available_transitions": available_transitions,
        "blocked_transitions": blocked_transitions,
        "stage_descriptions": descriptions,
        "case_state": {
            "is_live": reviewed_completed,
            "reviewed_completed": reviewed_completed,
            "has_selected_factory": has_selected_factory,
        },
    }


def get_stage_preview(case: Case, stage_name: str) -> dict[str, Any]:
    review_summary = build_review_summary(case)
    impacts: list[dict[str, str]] = []
    warnings: list[str] = []
    blocking_issues: list[str] = []

    if stage_name == "Reviewed":
        publish_plan = get_publish_plan(case, review_summary)
        impacts.append(
            {
                "type": "workflow",
                "severity": "info",
                "label": "Reviewed stage will be completed",
                "description": "This marks the case as reviewed and keeps the timeline in sync.",
            }
        )
        impacts.append(
            {
                "type": "automation",
                "severity": "info",
                "label": "Autobid preview",
                "description": (
                    f"{publish_plan['create_count']} autobids will be created, "
                    f"{publish_plan['update_count']} existing autobids will be updated, and "
                    f"{publish_plan['unchanged_count']} will stay unchanged."
                ),
            }
        )
        impacts.append(
            {
                "type": "data",
                "severity": "warning",
                "label": "Existing bids stay in place",
                "description": "Re-publishing will update matching autobids in place and add newly eligible autobids. Existing bids are not deleted.",
            }
        )
        warnings.extend(review_summary["warnings"])
        blocking_issues.extend(review_summary["blocking_issues"])
    elif stage_name == "Factory Selection":
        if not get_reviewed_progress_stage(case):
            blocking_issues.append("Make the case live first. Factory Selection only opens after Reviewed is complete.")
        impacts.append(
            {
                "type": "workflow",
                "severity": "info",
                "label": "Factory Selection becomes active",
                "description": "This stage is where AMs compare bids and select a factory.",
            }
        )
        impacts.append(
            {
                "type": "visibility",
                "severity": "info",
                "label": "Factory workflow is unlocked",
                "description": "Factories matching the case category and subcategory can see it in their queue.",
            }
        )
    else:
        factory_selection_stage = Stage.objects.filter(name="Factory Selection").first()
        target_stage = Stage.objects.filter(name=stage_name).first()
        if (
            factory_selection_stage
            and target_stage
            and target_stage.order > factory_selection_stage.order
            and case.factory_id is None
        ):
            blocking_issues.append("Select a factory before moving to the next order stage.")
        impacts.append(
            {
                "type": "workflow",
                "severity": "info",
                "label": f"Stage will change to {stage_name}",
                "description": f"The case timeline will move to {stage_name}.",
            }
        )

    return {
        "stage_name": stage_name,
        "allowed": not blocking_issues,
        "requires_confirmation": True,
        "blocking_issues": blocking_issues,
        "warnings": warnings,
        "impacts": impacts,
    }
