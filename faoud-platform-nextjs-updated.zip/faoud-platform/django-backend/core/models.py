from django.db import models

from product.models import Subcategory

# Create your models here.
class ParameterDefinition(models.Model):
    """
    Defines a single parameter (like 'RM Cost', 'PM Cost', 'Wastage', 'Conversion Charge', etc.) that can
    belong to a subcategory. Also includes the data_type so we can decide how to parse/store values.
    """
    DATA_TYPE_CHOICES = [
        ('DECIMAL', 'Decimal'),
        ('INT', 'Integer'),
        ('TEXT', 'Text'),
        ('BOOL', 'Boolean'),
        # Extend if you need date, file, etc.
    ]
    CONFIG_TYPE_CHOICES = [
        ('FINISHED_GOOD', 'Finished Good'),
        ('JUST_CONVERSION', 'Just Conversion'),
        # etc.
    ]

    name = models.CharField(max_length=200)
    subcategory = models.ForeignKey(
        Subcategory, on_delete=models.CASCADE,
        related_name='parameter_definitions'
    )
    config_type = models.CharField(
        max_length=50, choices=CONFIG_TYPE_CHOICES,
        blank=True, null=True,
        help_text="Which AutoBid config type does this parameter apply to?"
    )
    data_type = models.CharField(max_length=20, choices=DATA_TYPE_CHOICES, default='DECIMAL')

    # Some optional fields:
    is_required = models.BooleanField(default=False)
    help_text = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.subcategory.name})"
    



class CaseParameterValue(models.Model):
    """
    Stores the value of a ParameterDefinition for a particular Case.
    This is how the brand or AM sets the case-specific parameters (RM cost, PM cost, etc.).
    """
    case = models.ForeignKey(
        "case.Case", on_delete=models.CASCADE,
        related_name="parameter_values"
    )
    parameter_definition = models.ForeignKey(
        ParameterDefinition, on_delete=models.CASCADE
    )
    # Storing as Decimal or Text? Because data_type can vary, store as a generic Decimal or Text.
    # Alternatively, use a polymorphic approach or separate columns. 
    decimal_value = models.DecimalField(
        max_digits=15, decimal_places=4,
        blank=True, null=True
    )
    text_value = models.TextField(blank=True, null=True)
    bool_value = models.BooleanField(null=True, default=False)

    def __str__(self):
        return f"{self.case} - {self.parameter_definition.name}"

    def get_value(self):
        """Return the typed value depending on the parameter_definition.data_type."""
        dt = self.parameter_definition.data_type
        if dt == 'DECIMAL':
            return self.decimal_value
        elif dt == 'TEXT':
            return self.text_value
        elif dt == 'BOOL':
            return self.bool_value
        return None

# models.py
from django.db import models
from product.models import Subcategory

class AutoBidConfig(models.Model):
    name = models.CharField(max_length=200, default="Unnamed AutoBidConfig")
    CONFIG_TYPE_CHOICES = [
        ('FINISHED_GOOD', 'Finished Good'),
        ('JUST_CONVERSION', 'Just Conversion'),
        # add more if you like
    ]

    factory = models.ForeignKey(
        "supply.Factory", on_delete=models.CASCADE,
        related_name="auto_bid_configs"
    )
    facility_line = models.ForeignKey(
        'process.FacilityLine',
        on_delete=models.CASCADE,
        related_name='autobid_facility_lines',
        blank=True,
        null=True
    )
    subcategory = models.ForeignKey(
        "product.Subcategory", on_delete=models.CASCADE,
        related_name="auto_bid_configs"
    )
    config_type = models.CharField(
        max_length=50, choices=CONFIG_TYPE_CHOICES
    )
    approved_by_am = models.BooleanField(default=False)
    enabled = models.BooleanField(default=True)

    # ✅ Optional Enhancement #1: version for tracking changes
    version = models.PositiveIntegerField(default=1)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"AutoBidConfig[{self.id}]: {self.factory.name} / {self.subcategory.name} / {self.config_type} (v{self.version})"

    def compute_bid(self, case):
        """Sum brand side + factory side parameters, factoring config_type."""
        brand_params = {cpv.parameter_definition.name: cpv.get_value()
                        for cpv in case.parameter_values.all()}
        factory_params = {fpv.parameter_definition.name: fpv.get_value()
                          for fpv in self.parameter_values.all()}

        if self.config_type == 'FINISHED_GOOD':
            final_cost = factory_params.get('Final Cost', 0)
            faoud_margin = brand_params.get('Faoud Margin', 0)
            return (final_cost or 0) + (faoud_margin or 0) , final_cost or 0
        elif self.config_type == 'JUST_CONVERSION':
            rm_cost = brand_params.get('RM Cost', 0)
            pm_cost = brand_params.get('PM Cost', 0)
            wastage = brand_params.get('Wastage', 0)
            faoud_margin = brand_params.get('Faoud Margin', 0)
            conversion_cost = factory_params.get('Conversion Charge', 0)
            return (rm_cost or 0) + (pm_cost or 0) + (wastage or 0) + (faoud_margin or 0) + (conversion_cost or 0) , conversion_cost or 0
        return 0 , 0


class AutoBidConfigHistory(models.Model):
    """
    ✅ Optional Enhancement #1 (continued): Keep old snapshots whenever an AutoBidConfig updates
    """
    auto_bid_config = models.ForeignKey(AutoBidConfig, on_delete=models.CASCADE, related_name='history')
    version = models.PositiveIntegerField()
    snapshot_date = models.DateTimeField(auto_now_add=True)

    # You could store JSON of param values or replicate fields
    param_values_json = models.JSONField()

    def __str__(self):
        return f"History for Config {self.auto_bid_config_id}, version {self.version}"


class AutoBidConfigParameterValue(models.Model):
    auto_bid_config = models.ForeignKey(
        AutoBidConfig, on_delete=models.CASCADE,
        related_name="parameter_values"
    )
    parameter_definition = models.ForeignKey(
        ParameterDefinition, on_delete=models.CASCADE
    )
    decimal_value = models.DecimalField(
        max_digits=15, decimal_places=4,
        blank=True, null=True
    )
    text_value = models.TextField(blank=True, null=True)
    bool_value = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.auto_bid_config} - {self.parameter_definition.name}"

    def get_value(self):
        dt = self.parameter_definition.data_type
        if dt == 'DECIMAL':
            return self.decimal_value
        elif dt == 'TEXT':
            return self.text_value
        elif dt == 'BOOL':
            return self.bool_value
        return None
