from django.contrib import admin
from .models import AutoBidConfig, AutoBidConfigParameterValue, ParameterDefinition, CaseParameterValue
from case.models import Case
from product.models import Subcategory, Category, Product


# For filtering ParameterDefinition by data_type
class DataTypeFilter(admin.SimpleListFilter):
    title = 'Data Type'
    parameter_name = 'data_type'

    def lookups(self, request, model_admin):
        return ParameterDefinition.DATA_TYPE_CHOICES

    def queryset(self, request, queryset):
        if self.value():
            return queryset.filter(data_type=self.value())
        return queryset


class ParameterDefinitionAdmin(admin.ModelAdmin):
    list_display = ('name', 'subcategory', 'config_type', 'data_type', 'is_required')
    list_filter = ('subcategory', 'config_type', 'data_type', 'is_required')
    search_fields = ('name', 'help_text')
    ordering = ('subcategory', 'config_type', 'name')

    fieldsets = (
        ('Basic Info', {
            'fields': ('name', 'subcategory', 'config_type', 'data_type', 'is_required')
        }),
        ('Help & Guidance', {
            'fields': ('help_text',),
            'classes': ('collapse',)
        }),
    )

admin.site.register(ParameterDefinition, ParameterDefinitionAdmin)


@admin.register(CaseParameterValue)
class CaseParameterValueAdmin(admin.ModelAdmin):
    list_display = (
        'case',
        'get_parameter_name',
        'decimal_value',
        'text_value',
        'bool_value',
    )
    list_filter = (
        'parameter_definition__subcategory',
        'parameter_definition__data_type',
    )
    search_fields = (
        'case__id',
        'parameter_definition__name',
        'text_value',
    )

    def get_parameter_name(self, obj):
        return obj.parameter_definition.name
    get_parameter_name.short_description = 'Parameter'


# --- Extras for visibility: Inline on Case admin ---

class CaseParameterValueInline(admin.TabularInline):
    model = CaseParameterValue
    extra = 0
    show_change_link = True


class AutoBidConfigParameterValueInline(admin.TabularInline):
    model = AutoBidConfigParameterValue
    extra = 0
    readonly_fields = ('parameter_definition',)


@admin.register(AutoBidConfig)
class AutoBidConfigAdmin(admin.ModelAdmin):
    list_display = ('factory', 'subcategory', 'config_type', 'approved_by_am', 'enabled', 'created_at')
    list_filter = ('config_type', 'subcategory', 'approved_by_am', 'enabled')
    search_fields = ('factory__name',)
    inlines = [AutoBidConfigParameterValueInline]


@admin.register(AutoBidConfigParameterValue)
class AutoBidConfigParameterValueAdmin(admin.ModelAdmin):
    list_display = ('auto_bid_config', 'get_param_name', 'decimal_value', 'text_value', 'bool_value')
    list_filter = ('parameter_definition__subcategory', 'parameter_definition__data_type')
    search_fields = ('parameter_definition__name', 'auto_bid_config__factory__name')

    def get_param_name(self, obj):
        return obj.parameter_definition.name
    get_param_name.short_description = 'Parameter'