from requests import Response
from rest_framework import serializers

from case.models import Case
from process.models import FacilityLine
from process.serializers import FacilityLineSerializer
from .models import ParameterDefinition
from rest_framework import status


class ParameterDefinitionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ParameterDefinition
        fields = ['id', 'name', 'subcategory', 'data_type', 'is_required', 'help_text']
        read_only_fields = ['id']


from rest_framework import serializers
from .models import CaseParameterValue, ParameterDefinition
class CaseParameterValueSerializer(serializers.ModelSerializer):
    parameter_definition_name = serializers.ReadOnlyField(source='parameter_definition.name')
    data_type = serializers.ReadOnlyField(source='parameter_definition.data_type')

    class Meta:
        model = CaseParameterValue
        fields = [
            'id',
            'case',
            'parameter_definition',
            'parameter_definition_name',
            'data_type',
            'decimal_value',
            'text_value',
            'bool_value',
        ]
        read_only_fields = ['id', 'parameter_definition_name', 'data_type']


    def validate(self, data):
        param_def = data.get('parameter_definition')
        if not param_def:
            raise serializers.ValidationError("Parameter definition is required.")

        expected_type = param_def.data_type

        if expected_type == 'DECIMAL':
            if data.get('decimal_value') is None:
                raise serializers.ValidationError({"decimal_value": "Required for DECIMAL parameter."})
        elif expected_type == 'TEXT':
            if not data.get('text_value'):
                raise serializers.ValidationError({"text_value": "Required for TEXT parameter."})
        elif expected_type == 'BOOL':
            # Explicit check for None (because False is valid)
            if data.get('bool_value') is None:
                raise serializers.ValidationError({"bool_value": "Required for BOOL parameter."})
        else:
            raise serializers.ValidationError("Unsupported parameter data type.")

        return data




from rest_framework import serializers
from .models import AutoBidConfigParameterValue

class AutoBidConfigParameterValueSerializer(serializers.ModelSerializer):
    parameter_definition_name = serializers.ReadOnlyField(source='parameter_definition.name')

    class Meta:
        model = AutoBidConfigParameterValue
        fields = [
            'id',
            'auto_bid_config',
            'parameter_definition',
            'parameter_definition_name',
            'decimal_value',
            'text_value',
            'bool_value',
        ]
        read_only_fields = ['id', 'parameter_definition_name']


from rest_framework import serializers
from .models import AutoBidConfig, AutoBidConfigParameterValue
from .serializers import AutoBidConfigParameterValueSerializer

class AutoBidConfigSerializer(serializers.ModelSerializer):
    parameter_values = AutoBidConfigParameterValueSerializer(
        many=True,
        read_only=True,
    )
    facility_line = serializers.PrimaryKeyRelatedField(
    queryset=FacilityLine.objects.all(),
    write_only=True,
    required=False,
    allow_null=True
    )

    facility_line_detail = FacilityLineSerializer(
        source='facility_line', 
        read_only=True
    )
    class Meta:
        model = AutoBidConfig
        fields = [
            'name',
            'id',
            'factory',
            'subcategory',
            'config_type',
            'facility_line',
            'facility_line_detail',
            'approved_by_am',
            'enabled',
            'created_at',
            'updated_at',
            'parameter_values',
        ]

