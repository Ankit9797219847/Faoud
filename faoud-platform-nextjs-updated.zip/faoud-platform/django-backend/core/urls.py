from django.urls import path
from .views import (
    AutoBidConfigDetailAPIView,
    CaseReviewBriefAPIView,
    CaseReviewParametersAPIView,
    CaseReviewPreviewPublishAPIView,
    CaseReviewProductAPIView,
    CaseReviewPublishAPIView,
    CaseReviewTakeOfflineAPIView,
    CaseReviewSummaryAPIView,
    CaseParameterValueList,
    IsCaseReadyForAutoBid,
    IsCaseReadyForBid,
    ParameterDefinitionListView,
    ParameterDefinitionDetailView,
    CaseParameterValueAPIView,
    AutoBidConfigAPIView,
    AutoBidConfigParameterValueAPIView,
    AutoBidVerificationAPIView
)

urlpatterns = [
    # Parameter Definitions
    path('parameter-definitions', ParameterDefinitionListView.as_view(), name='param-def-list'),
    path('parameter-definitions/<int:pk>/', ParameterDefinitionDetailView.as_view(), name='param-def-detail'),

    # Case Parameters
    path('cases/<int:case_id>/parameters/', CaseParameterValueAPIView.as_view(), name='case-parameters'),
    path('cases/<int:case_id>/review/summary/', CaseReviewSummaryAPIView.as_view(), name='case-review-summary'),
    path('cases/<int:case_id>/review/brief/', CaseReviewBriefAPIView.as_view(), name='case-review-brief'),
    path('cases/<int:case_id>/review/product/', CaseReviewProductAPIView.as_view(), name='case-review-product'),
    path('cases/<int:case_id>/review/parameters/', CaseReviewParametersAPIView.as_view(), name='case-review-parameters'),
    path('cases/<int:case_id>/review/preview-publish/', CaseReviewPreviewPublishAPIView.as_view(), name='case-review-preview-publish'),
    path('cases/<int:case_id>/review/publish/', CaseReviewPublishAPIView.as_view(), name='case-review-publish'),
    path('cases/<int:case_id>/review/take-offline/', CaseReviewTakeOfflineAPIView.as_view(), name='case-review-take-offline'),

    # AutoBid Config
    path('auto-bid-configs/', AutoBidConfigAPIView.as_view(), name='auto-bid-config-list-create'),
    path('cases/<int:case_id>/parameters/values/', CaseParameterValueList.as_view(), name='case-parameter-values'),

    # If you want to retrieve or delete a specific config, you might add another path:
    path('auto-bid-configs/<int:pk>/', AutoBidConfigDetailAPIView.as_view()),
    
    # AutoBidConfig Parameter Values
    path('auto-bid-configs/<int:config_id>/params/', AutoBidConfigParameterValueAPIView.as_view(), name='auto-bid-param-values'),
    
    # AutoBid Verification (Account Manager only)
    path('auto-bid-configs/<int:config_id>/verify/', AutoBidVerificationAPIView.as_view(), name='auto-bid-verify'),
    
    path('isCaseReadyForBidding/<int:case_id>/', IsCaseReadyForBid.as_view(), name='is-case-ready-for-bidding'),
    path('isCaseReadyForAutoBidding/<int:case_id>/', IsCaseReadyForAutoBid.as_view(), name='is-case-ready-for-bidding'),
]
