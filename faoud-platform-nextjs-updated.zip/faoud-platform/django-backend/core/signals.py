# signals.py
from django.db.models.signals import post_save
from django.dispatch import receiver

from case.models import ProgressStage
from .models import AutoBidConfigParameterValue, AutoBidConfig, AutoBidConfigHistory

@receiver(post_save, sender=AutoBidConfigParameterValue)
def on_autobidconfigparam_change(sender, instance, created, **kwargs):
    """
    ✅ Whenever AutoBidConfigParameterValue is updated or created, 
    increment config.version and save a snapshot in AutoBidConfigHistory.
    """
    config = instance.auto_bid_config

    # increment version
    config.version += 1
    config.save()

    # store a new snapshot in the history table
    all_params = config.parameter_values.all()
    # convert them to a simple list/dict for JSON
    param_data = []
    for pv in all_params:
        param_data.append({
            "parameter_definition": pv.parameter_definition.id,
            "name": pv.parameter_definition.name,
            "decimal_value": str(pv.decimal_value) if pv.decimal_value else None,
            "text_value": pv.text_value,
            "bool_value": pv.bool_value
        })

    AutoBidConfigHistory.objects.create(
        auto_bid_config=config,
        version=config.version,
        param_values_json=param_data
    )


@receiver(post_save, sender=ProgressStage)
def noop_progress_stage_signal(sender, instance, created, **kwargs):
    """
    Autobids are created explicitly through the review publish flow.
    Keep the signal registered so older imports do not break, but do nothing.
    """
    return
