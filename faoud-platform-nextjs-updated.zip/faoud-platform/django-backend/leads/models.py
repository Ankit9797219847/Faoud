from django.db import models

# Create your models here.
# leads/models.py
from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.utils import timezone
from django.conf import settings

class LeadItem(models.Model):
    """
    Unified light-weight lead row for management preview/inbox.
    Denormalized summary keeps list queries fast.
    """
    # Source link (works with any model: Case, OnboardingData, BrandOwner, etc.)
    source_ct = models.ForeignKey(ContentType, on_delete=models.CASCADE,
                                  null=True, blank=True)              # <- allow null
    source_id = models.PositiveIntegerField(db_index=True,
                                            null=True, blank=True)
    source = GenericForeignKey('source_ct', 'source_id')

    # Governance / management
    owner = models.ForeignKey('user.AM', null=True, blank=True,
                              on_delete=models.SET_NULL, related_name='lead_items')
    created_by = models.ForeignKey(  # <- NEW
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name='created_leads'
    )
    STATUS_CHOICES = [
        ('new', 'New'),
        ('in_progress', 'In Progress'),
        ('won', 'Won'),
        ('lost', 'Lost'),
        ('archived', 'Archived'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new', db_index=True)

    PRIORITY_CHOICES = [
        (1, 'P1 - High'),
        (2, 'P2 - Medium'),
        (3, 'P3 - Low'),
    ]
    priority = models.PositiveSmallIntegerField(choices=PRIORITY_CHOICES, default=2, db_index=True)

    notes = models.TextField(blank=True, default="")

    # Denormalized summary for fast list rendering (keep short)
    tag = models.CharField(max_length=50, blank=True, null=True)  # e.g., case, onboarding, contact, waitlist, brand_owner_reg, factory_owner_reg, brand, factory
    title = models.CharField(max_length=255, blank=True, default='')     # e.g., "Case: Vitamin C Serum"
    subtitle = models.CharField(max_length=255, blank=True, default='')  # e.g., "Acme Co · qty 5000 · npd_with"
    contact_email = models.EmailField(blank=True, null=True)
    contact_phone = models.CharField(max_length=50, blank=True, null=True)

    # Visibility controls
    active = models.BooleanField(default=True, db_index=True)

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=['active', 'status', 'priority']),
            models.Index(fields=['tag']),
            models.Index(fields=['created_at']),
        ]
        ordering = ['-created_at']

    def __str__(self):
        return f"LeadItem#{self.pk} [{self.tag}] {self.title}"

    @property
    def age_days(self) -> int:
        return (timezone.now() - self.created_at).days