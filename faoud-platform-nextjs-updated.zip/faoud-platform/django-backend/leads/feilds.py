# leads/fields.py
from rest_framework import serializers
from user.models import AM

class OwnerRWField(serializers.Field):
    """
    Read: returns {"id": <int>, "name": <str>}
    Write: accepts <int> (AM id) OR {"id": <int>} OR null -> sets owner accordingly.
    """
    def to_representation(self, value):
        if not value:
            return None
        # value is an AM instance
        name = value.name or getattr(getattr(value, 'user', None), 'username', None) or f"AM #{value.id}"
        return {"id": value.id, "name": name}

    def to_internal_value(self, data):
        if data in (None, ''):
            return None
        if isinstance(data, dict):
            data = data.get('id')
        try:
            pk = int(data)
        except (TypeError, ValueError):
            raise serializers.ValidationError('Owner must be an AM id (int) or {"id": int} or null.')
        try:
            return AM.objects.only('id', 'name').get(pk=pk)
        except AM.DoesNotExist:
            raise serializers.ValidationError('AM not found.')