# leads/serializers.py
from rest_framework import serializers
from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from leads.feilds import OwnerRWField
from user.utils import is_plain_am, redact_fields
from user.models import AM
from .models import LeadItem
from user.utils import get_role


# ---------- READ (AM/FE) ----------
class LeadItemOwnerMiniSerializer(serializers.ModelSerializer):
    class Meta:
        model = AM
        fields = ('id', 'name',)

class LeadItemReadSerializer(serializers.ModelSerializer):
    owner = LeadItemOwnerMiniSerializer(read_only=True)
    age_days = serializers.IntegerField(read_only=True)
    is_new = serializers.SerializerMethodField()
    link = serializers.SerializerMethodField()
    created_by = serializers.SerializerMethodField()

    class Meta:
        model = LeadItem
        fields = [
            'id','tag','title','subtitle','owner','status','priority','notes',
            'contact_email','contact_phone','active','created_at','updated_at',
            'age_days','is_new','link','created_by'
        ]
        read_only_fields = ['active','created_at','updated_at','age_days','is_new','link']

    def to_representation(self, instance):
        data = super().to_representation(instance)
        req = self.context.get("request")
        if req and is_plain_am(req.user):
            redact_fields(data, fields=["contact_email","contact_phone"], strategy="mask")
        return data

    def get_is_new(self, obj):
        # prefer annotated .age_days; fallback if missing
        age = getattr(obj, "age_days", None)
        if age is None:
            from django.utils import timezone
            age = (timezone.now() - obj.created_at).days
        return obj.status == 'new' or age <= 7

    def get_link(self, obj):
        try:
            from case.models import Case
            ct = ContentType.objects.get_for_model(Case)
            if getattr(obj, 'source_ct_id', None) == ct.id and obj.source_id:
                case_obj = Case.objects.filter(id=obj.source_id)\
                                       .select_related('brand_owner').first()
                if case_obj and getattr(case_obj, 'brand_owner_id', None):
                    base = getattr(settings, 'FRONTEND_BASE_URL', '')
                    path = '/dashboard/account-manager/user-case'
                    return f"{base}{path}?caseId={case_obj.id}&brandOwner={case_obj.brand_owner_id}"
        except Exception:
            pass
        return None

    def get_created_by(self, obj):
        u = getattr(obj, 'created_by', None)
        if not u:
            return None
        # Resolve friendly name: prefer AM.name if exists, else first+last or username
        try:
            am = AM.objects.filter(user=u).first()
        except Exception:
            am = None
        if am and (am.name or getattr(am.user, 'username', None)):
            name = am.name or am.user.username
        else:
            name = f"{getattr(u, 'first_name', '')} {getattr(u, 'last_name', '')}".strip() or getattr(u, 'username', None) or getattr(u, 'email', None) or f"User#{u.id}"
        role = get_role(u) if hasattr(u, 'id') else 'other'
        return {"id": u.id, "name": name, "role": role}


# ---------- WRITE (RW for AM updates) ----------
class LeadItemWriteSerializer(serializers.ModelSerializer):
    owner = OwnerRWField(required=False, allow_null=True)

    age_days = serializers.SerializerMethodField()
    is_new = serializers.SerializerMethodField()
    link = serializers.SerializerMethodField()

    class Meta:
        model = LeadItem
        fields = [
            'id', 'tag', 'title', 'subtitle',
            'owner',
            'status', 'priority', 'notes',
            'contact_email', 'contact_phone',
            'active', 'created_at', 'updated_at',
            'age_days', 'is_new', 'link',
        ]
        read_only_fields = [
            'tag','title','subtitle','contact_email','contact_phone',
            'active','created_at','updated_at','age_days','is_new','link'
        ]

    def to_representation(self, instance):
        data = super().to_representation(instance)
        req = self.context.get("request")
        if req and is_plain_am(req.user):
            redact_fields(data, fields=["contact_email","contact_phone"], strategy="mask")
        return data

    def get_age_days(self, obj): return getattr(obj, "age_days", None)
    def get_is_new(self, obj):
        age = getattr(obj, "age_days", None)
        if age is None:
            from django.utils import timezone
            age = (timezone.now() - obj.created_at).days
        return obj.status == 'new' or age <= 7

    def get_link(self, obj):
        return LeadItemReadSerializer(context=self.context).get_link(obj)


# ---------- CREATE / UPDATE payload serializers ----------
class LeadItemCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeadItem
        fields = ['tag','title','subtitle','contact_email','contact_phone','notes']

    def validate_tag(self, v):
        allowed = {'case','onboarding','contact','waitlist',
                   'brand_owner_reg','factory_owner_reg','brand','factory', 'free_session'}
        if v and v not in allowed:
            raise serializers.ValidationError("Invalid tag.")
        return v

    def validate_contact_phone(self, v):
        if v:
            digits = ''.join(c for c in v if c.isdigit())
            if not (10 <= len(digits) <= 15):
                raise serializers.ValidationError("Phone number must contain 10 to 15 digits.")
        return v

    def validate(self, data):
        tag = data.get('tag')
        if tag == 'free_session':
            if not data.get('contact_email'):
                raise serializers.ValidationError({"contact_email": "Email is required for free session."})
            if not data.get('contact_phone'):
                raise serializers.ValidationError({"contact_phone": "Phone is required for free session."})
        return data

class LeadItemUpdateSerializer(serializers.ModelSerializer):
    owner = serializers.PrimaryKeyRelatedField(queryset=AM.objects.all(), required=False, allow_null=True)
    class Meta:
        model = LeadItem
        fields = ['owner','status','priority','notes','tag','active']


# ---------- CANONICAL EXPORTS ----------
# pick one read & one write for importers
LeadItemSerializer = LeadItemReadSerializer