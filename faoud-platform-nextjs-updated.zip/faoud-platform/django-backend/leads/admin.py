# leads/admin.py
from datetime import timedelta
from collections import defaultdict

from django.contrib import admin, messages
from django.db.models import (
    Count, Avg, F, Q, Case, When, IntegerField, DurationField, ExpressionWrapper
)
from django.db.models.functions import TruncDate, TruncWeek, TruncMonth, Now, Coalesce
from django.http import JsonResponse
from django.shortcuts import render
from django.urls import path, reverse
from django.utils import timezone

from .models import LeadItem


@admin.register(LeadItem)
class LeadItemAdmin(admin.ModelAdmin):
    list_display = (
        "id", "title", "tag", "status", "priority", "owner", "created_by",
        "contact_email", "contact_phone", "active", "created_at", "updated_at", "age_days",
    )
    list_filter = (
        "active",
        "status",
        "priority",
        "tag",
        ("owner", admin.RelatedOnlyFieldListFilter),
        ("created_by", admin.RelatedOnlyFieldListFilter),
        ("created_at", admin.DateFieldListFilter),
        ("updated_at", admin.DateFieldListFilter),
    )
    search_fields = (
        "title", "subtitle", "notes", "contact_email", "contact_phone", "tag",
        "owner__user__email", "owner__user__first_name", "owner__user__last_name",
        "created_by__email", "created_by__first_name", "created_by__last_name"
    )
    date_hierarchy = "created_at"
    autocomplete_fields = ("owner", "created_by")
    ordering = ("-created_at",)
    actions = ["export_csv_minimal"]

    # ---------- Insights Dashboard ----------
    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path(
                "insights/",
                self.admin_site.admin_view(self.insights_view),
                name="leads_leaditem_insights",
            ),
            path(
                "insights/data/",
                self.admin_site.admin_view(self.insights_data_view),
                name="leads_leaditem_insights_data",
            ),
        ]
        return custom + urls

    def changelist_view(self, request, extra_context=None):
        """
        Add a prominent link to the Insights dashboard from the changelist.
        """
        extra_context = extra_context or {}
        extra_context["insights_url"] = reverse("admin:leads_leaditem_insights")
        return super().changelist_view(request, extra_context=extra_context)

    def insights_view(self, request):
        """
        Renders the HTML shell; charts and tables fetch JSON from insights_data_view.
        """
        ctx = {
            "title": "Lead Insights",
            "data_url": reverse("admin:leads_leaditem_insights_data"),
            "model_opts": self.model._meta,
        }
        return render(request, "admin/leads/leaditem/insights.html", ctx)

    def _base_queryset(self, request):
        """
        Scoped queryset. If you later implement per-role data visibility, hook it here.
        """
        qs = LeadItem.objects.all().select_related("owner", "created_by")
        # Optional: filter by ?active=1/0, ?owner=<id>, etc.
        # You can read request.GET to scope data for managers.
        creator = request.GET.get("created_by")
        if creator:
            try:
                ids = [int(x) for x in str(creator).split(',') if x.strip()]
                if ids:
                    qs = qs.filter(created_by_id__in=ids)
            except ValueError:
                pass
        return qs

    def insights_data_view(self, request):
        """
        Returns a JSON payload with all KPI numbers, table aggregates, and time-series.
        Accepts optional GET parameters:
          - range: one of '7d','30d','90d','365d','all' (default '90d')
          - active: '1' or '0' (default all)
        """
        range_param = request.GET.get("range", "90d")
        active_param = request.GET.get("active")

        now = timezone.now()
        range_map = {
            "7d": now - timedelta(days=7),
            "30d": now - timedelta(days=30),
            "90d": now - timedelta(days=90),
            "365d": now - timedelta(days=365),
            "all": None,
        }
        since_dt = range_map.get(range_param, range_map["90d"])

        qs = self._base_queryset(request)
        if active_param in ("0", "1"):
            qs = qs.filter(active=(active_param == "1"))

        if since_dt:
            qs = qs.filter(created_at__gte=since_dt)

        # ---------- KPIs ----------
        total = qs.count()
        open_q = qs.exclude(status__in=["won", "lost", "archived"])
        open_count = open_q.count()

        won_q = qs.filter(status="won")
        won_count = won_q.count()

        lost_q = qs.filter(status="lost")
        lost_count = lost_q.count()

        # Conversion rates (guard zero division)
        close_attempts = won_count + lost_count
        win_rate = (won_count / close_attempts) * 100 if close_attempts else 0.0

        # Average age of open leads
        age_expr = ExpressionWrapper(Now() - F("created_at"), output_field=DurationField())
        avg_open_age = open_q.aggregate(avg_age=Avg(age_expr))["avg_age"]

        # Time to close (won) using updated_at - created_at as proxy
        cycle_expr = ExpressionWrapper(F("updated_at") - F("created_at"), output_field=DurationField())
        avg_cycle_won = won_q.aggregate(avg_cycle=Avg(cycle_expr))["avg_cycle"]

        # ---------- Distributions / Pivots ----------
        per_status = list(qs.values("status").annotate(count=Count("id")).order_by("status"))
        per_priority = list(qs.values("priority").annotate(count=Count("id")).order_by("priority"))
        per_tag = list(qs.values("tag").annotate(count=Count("id")).order_by("tag"))
        per_owner = list(
            qs.values("owner__id", "owner__user__first_name", "owner__user__last_name")
              .annotate(total=Count("id"),
                        won=Count("id", filter=Q(status="won")),
                        lost=Count("id", filter=Q(status="lost")),
                        open=Count("id", filter=~Q(status__in=["won", "lost", "archived"])))
              .order_by("-total")
        )
        per_creator = list(
            qs.values(
                "created_by__id",
                "created_by__first_name",
                "created_by__last_name",
                "created_by__username",
                "created_by__email",
            )
            .annotate(total=Count("id"))
            .order_by("-total")
        )

        # Aging buckets on OPEN items
        # <3d, 3-7, 8-14, 15-30, >30
        bucket_expr = Case(
            When(created_at__gte=Now() - timedelta(days=3), then=0),
            When(created_at__lt=Now() - timedelta(days=3), created_at__gte=Now() - timedelta(days=8), then=1),
            When(created_at__lt=Now() - timedelta(days=8), created_at__gte=Now() - timedelta(days=15), then=2),
            When(created_at__lt=Now() - timedelta(days=15), created_at__gte=Now() - timedelta(days=31), then=3),
            default=4,
            output_field=IntegerField(),
        )
        age_buckets = dict(open_q.annotate(b=bucket_expr).values("b").annotate(c=Count("id")).values_list("b", "c"))
        age_bucket_labels = ["<3d", "3–7d", "8–14d", "15–30d", ">30d"]
        age_bucket_series = [age_buckets.get(i, 0) for i in range(5)]

        # ---------- Time Series ----------
        # Weekly (use TruncWeek); monthly (TruncMonth) for longer ranges
        if range_param in ("365d", "all"):
            granularity = "month"
            trunc = TruncMonth
        else:
            granularity = "week"
            trunc = TruncWeek

        series_all = (
            qs.annotate(t=trunc("created_at"))
              .values("t")
              .annotate(created=Count("id"))
              .order_by("t")
        )
        series_won = (
            won_q.annotate(t=trunc("updated_at"))
                 .values("t")
                 .annotate(won=Count("id"))
                 .order_by("t")
        )
        series_lost = (
            lost_q.annotate(t=trunc("updated_at"))
                  .values("t")
                  .annotate(lost=Count("id"))
                  .order_by("t")
        )

        # Normalize time axis
        timeline = sorted({*[r["t"] for r in series_all],
                           *[r["t"] for r in series_won],
                           *[r["t"] for r in series_lost]})

        created_map = {r["t"]: r["created"] for r in series_all}
        won_map = {r["t"]: r["won"] for r in series_won}
        lost_map = {r["t"]: r["lost"] for r in series_lost}

        ts_labels = [t.date().isoformat() for t in timeline]
        ts_created = [created_map.get(t, 0) for t in timeline]
        ts_won = [won_map.get(t, 0) for t in timeline]
        ts_lost = [lost_map.get(t, 0) for t in timeline]

        # ---------- Top/Bottom tables ----------
        # Top tags by win rate (min 10 leads for stability)
        tag_rows = (
            qs.values("tag")
              .annotate(total=Count("id"),
                        won=Count("id", filter=Q(status="won")),
                        lost=Count("id", filter=Q(status="lost")))
              .order_by("-total")
        )
        top_tags = []
        for r in tag_rows:
            attempts = r["won"] + r["lost"]
            win_pct = (r["won"] / attempts) * 100 if attempts else 0.0
            if r["total"] >= 10:  # threshold
                top_tags.append({
                    "tag": r["tag"],
                    "total": r["total"],
                    "won": r["won"],
                    "lost": r["lost"],
                    "win_rate": round(win_pct, 1),
                })
        top_tags = sorted(top_tags, key=lambda x: x["win_rate"], reverse=True)[:10]

        # Owners leaderboard by wins (last 90d window by default)
        owners_leaderboard = sorted(
            [
                {
                    "owner_id": r["owner__id"],
                    "owner_name": f'{r["owner__user__first_name"] or ""} {r["owner__user__last_name"] or ""}'.strip() or f'AM #{r["owner__id"]}',
                    "total": r["total"],
                    "won": r["won"],
                    "lost": r["lost"],
                    "open": r["open"],
                    "win_rate": round((r["won"] / (r["won"] + r["lost"])) * 100, 1) if (r["won"] + r["lost"]) else 0.0,
                }
                for r in per_owner
            ],
            key=lambda x: (x["won"], x["win_rate"]),
            reverse=True
        )[:15]

        # ---------- Assemble payload ----------
        payload = {
            "filters": {
                "range": range_param,
                "active": active_param,
                "granularity": granularity,
                "created_by": request.GET.get("created_by") or "",
            },
            "kpis": {
                "total_leads": total,
                "open_leads": open_count,
                "won_leads": won_count,
                "lost_leads": lost_count,
                "win_rate_pct": round(win_rate, 1),
                "avg_open_age_days": round(avg_open_age.total_seconds() / 86400, 1) if avg_open_age else 0.0,
                "avg_cycle_to_win_days": round(avg_cycle_won.total_seconds() / 86400, 1) if avg_cycle_won else 0.0,
            },
            "distributions": {
                "by_status": per_status,
                "by_priority": per_priority,
                "by_tag": per_tag,
                "by_owner": per_owner,
                "by_creator": per_creator,
                "aging_open": {
                    "labels": age_bucket_labels,
                    "series": age_bucket_series,
                },
            },
            "series": {
                "labels": ts_labels,
                "created": ts_created,
                "won": ts_won,
                "lost": ts_lost,
            },
            "tables": {
                "top_tags_by_win_rate": top_tags,
                "owners_leaderboard": owners_leaderboard,
            },
        }
        return JsonResponse(payload, safe=False)

    # ---------- Actions ----------
    def export_csv_minimal(self, request, queryset):
        """
        Fast CSV export (minimal fields). Expand if needed.
        """
        import csv
        from django.http import HttpResponse

        response = HttpResponse(content_type="text/csv")
        response["Content-Disposition"] = 'attachment; filename="leaditems.csv"'
        writer = csv.writer(response)
        writer.writerow([
            "id", "created_at", "status", "priority", "tag", "title", "subtitle",
            "owner_id", "created_by_id", "contact_email", "contact_phone", "active"
        ])
        for li in queryset.iterator(chunk_size=2000):
            writer.writerow([
                li.id, li.created_at.isoformat(), li.status, li.priority, (li.tag or ""),
                li.title, li.subtitle, getattr(li.owner, "id", ""), getattr(li.created_by, "id", ""),
                li.contact_email or "", li.contact_phone or "", int(li.active)
            ])
        return response

    export_csv_minimal.short_description = "Export selected to CSV (minimal)"