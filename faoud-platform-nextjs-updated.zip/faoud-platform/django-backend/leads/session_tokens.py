import datetime
import jwt
from django.conf import settings
from django.utils.encoding import force_str  # <- add

ALGO = 'HS256'

def _jwt_secret() -> str:
    # Ensure we always return a plain str (no LazyObject/None/etc.)
    raw = getattr(settings, 'LEAD_PUBLIC_JWT_SECRET', None) or getattr(settings, 'SECRET_KEY', '')
    secret = force_str(raw)
    if not secret:
        # As a last resort (shouldn't happen), set a hard failure message
        raise RuntimeError("JWT secret missing. Set LEAD_PUBLIC_JWT_SECRET or SECRET_KEY.")
    return secret

def issue_lead_session_token(lead_id: int, minutes: int = 60) -> str:
    now = datetime.datetime.utcnow()
    payload = {
        "lid": int(lead_id),
        "iat": now,
        "exp": now + datetime.timedelta(minutes=minutes),
        "scope": "lead_session_v1",
    }
    secret = _jwt_secret()
    # PyJWT v2 returns str; if you’re on v1, wrap with .decode()
    return jwt.encode(payload, secret, algorithm=ALGO)

def verify_lead_session_token(token: str, lead_id: int) -> bool:
    try:
        secret = _jwt_secret()
        data = jwt.decode(token, secret, algorithms=[ALGO])
        return data.get("scope") == "lead_session_v1" and int(data.get("lid")) == int(lead_id)
    except Exception:
        return False