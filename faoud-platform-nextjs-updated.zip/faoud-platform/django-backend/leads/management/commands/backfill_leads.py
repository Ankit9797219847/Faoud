# leads/management/commands/backfill_leads.py
from __future__ import annotations

import sys
from datetime import timedelta
from typing import Iterable, Tuple

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone
from django.contrib.contenttypes.models import ContentType

# Reuse the exact upsert helper you already ship in signals
from leads.signals import upsert_lead_for_source  # noqa: F401
from leads.models import LeadItem

# Source models
from marketing.models import OnboardingData, ContactSubmission, WaitlistEntry
from case.models import Case
from user.models import BrandOwner, FactoryOwner
from utils.models import Brand
from supply.models import Factory


def _trunc(text: str, n: int = 255) -> str:
    from django.utils.text import Truncator
    return Truncator(text or '').chars(n)


def _recent_q(model, since):
    """
    Build a robust 'recent' Q filter using whichever timestamp fields exist.
    Preference order tries common conventions.
    """
    candidate_fields = [
        'updated_at', 'modified', 'last_modified',  # update-ish
        'created_at', 'created', 'timestamp', 'date_joined',  # create-ish
    ]
    fields = set(f.name for f in model._meta.get_fields() if hasattr(f, 'attname'))
    qs = Q()
    used = 0
    for name in candidate_fields:
        if name in fields:
            qs |= Q(**{f'{name}__gte': since})
            used += 1
    if not used:
        # Fallback: if no timestamp fields exist, do nothing (skip filter)
        return Q()
    return qs


def _iter_recent(queryset, chunk_size: int = 500) -> Iterable:
    """
    Memory-safe iteration over a queryset. Uses .iterator() if available.
    """
    return queryset.iterator(chunk_size=chunk_size)


class Command(BaseCommand):
    help = "Backfill LeadItem rows for recent source objects (default: last 15 days)."

    def add_arguments(self, parser):
        parser.add_argument(
            '--days', type=int, default=15,
            help='How many days back to consider (default: 15).'
        )
        parser.add_argument(
            '--dry-run', action='store_true', default=False,
            help='Do not write; only log what would happen.'
        )
        parser.add_argument(
            '--models', type=str, default='all',
            help='Comma-separated subset of models to process. '
                 'Options: all, onboarding, case, contact, waitlist, brand_owner, factory_owner, brand, factory'
        )
        parser.add_argument(
            '--chunk-size', type=int, default=500,
            help='DB iterator chunk size (default: 500).'
        )

    def handle(self, *args, **opts):
        since = timezone.now() - timedelta(days=opts['days'])
        dry = opts['dry_run']
        chunk = opts['chunk_size']
        sel = {m.strip().lower() for m in opts['models'].split(',')} if opts['models'] else {'all'}

        def sel_ok(name: str) -> bool:
            return 'all' in sel or name in sel

        self.stdout.write(self.style.NOTICE(
            f'Backfilling leads since {since.isoformat()} '
            f'({"DRY RUN" if dry else "WRITE MODE"})'
        ))

        totals = {}

        # 1) OnboardingData
        if sel_ok('onboarding'):
            totals['onboarding'] = self._run_onboarding(since, dry, chunk)

        # 2) Case (+ archive best matching OnboardingData)
        if sel_ok('case'):
            totals['case'] = self._run_case(since, dry, chunk)

        # 3) ContactSubmission
        if sel_ok('contact'):
            totals['contact'] = self._run_contact(since, dry, chunk)

        # 4) WaitlistEntry
        if sel_ok('waitlist'):
            totals['waitlist'] = self._run_waitlist(since, dry, chunk)

        # 5) BrandOwner
        if sel_ok('brand_owner'):
            totals['brand_owner'] = self._run_brand_owner(since, dry, chunk)

        # 6) FactoryOwner
        if sel_ok('factory_owner'):
            totals['factory_owner'] = self._run_factory_owner(since, dry, chunk)

        # 7) Brand
        if sel_ok('brand'):
            totals['brand'] = self._run_brand(since, dry, chunk)

        # 8) Factory
        if sel_ok('factory'):
            totals['factory'] = self._run_factory(since, dry, chunk)

        # Summary
        self.stdout.write(self.style.SUCCESS('--- Summary ---'))
        for k, (touched, archived) in totals.items():
            extra = f", archived={archived}" if archived else ""
            self.stdout.write(self.style.SUCCESS(f'{k}: touched={touched}{extra}'))

    # ---------- per-model runners (mirror your signal logic) ----------

    def _run_onboarding(self, since, dry, chunk) -> Tuple[int, int]:
        touched = 0
        qs = OnboardingData.objects.filter(_recent_q(OnboardingData, since))
        for od in _iter_recent(qs, chunk):
            title = f"BO Lead: {getattr(od, 'product_name', None) or 'Unnamed Product'}"
            bits = []
            if getattr(od, 'company_name', None): bits.append(od.company_name)
            if getattr(od, 'quantity', None): bits.append(f"qty {od.quantity}")
            if getattr(od, 'location', None): bits.append(od.location)
            subtitle = " · ".join(bits) or (getattr(od, 'product_category', None) or '')

            if dry:
                touched += 1
                continue

            upsert_lead_for_source(
                od,
                tag='onboarding',
                title=title,
                subtitle=subtitle,
                contact_email=getattr(od, 'email', None),
                contact_phone=getattr(od, 'mobile', None),
                default_priority=2
            )
            touched += 1
        return touched, 0

    def _run_case(self, since, dry, chunk) -> Tuple[int, int]:
        touched = 0
        archived = 0
        qs = Case.objects.filter(_recent_q(Case, since))
        for case in _iter_recent(qs, chunk):
            bo = getattr(case, 'brand_owner', None)
            title = f"Case: {getattr(case, 'name', None) or 'Unnamed Case'}"
            bits = []
            if bo and getattr(bo, 'name', None): bits.append(bo.name)
            if getattr(case, 'quantity', None): bits.append(f"qty {case.quantity}")
            if getattr(case, 'category', None): bits.append(case.category)
            subtitle = " · ".join(bits)

            if not dry:
                upsert_lead_for_source(
                    case,
                    tag='case',
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(bo, 'contact_email', None) if bo else None,
                    contact_phone=getattr(bo, 'contact_phone', None) if bo else None,
                    default_priority=1 if getattr(case, 'category', None) in ('npd_with', 'onboarding') else 2
                )

                # Archive latest OD lead for same user (same as your signal)
                try:
                    user_id = getattr(bo, 'user_id', None)
                    if user_id:
                        od = OnboardingData.objects.filter(user_id=user_id).order_by('-id').first()
                        if od:
                            ct = ContentType.objects.get_for_model(OnboardingData)
                            updated = LeadItem.objects.filter(
                                source_ct=ct, source_id=od.id, active=True
                            ).update(active=False, status='archived')
                            archived += updated
                except Exception:
                    # Never block; mirror signal's silent fail
                    pass

            touched += 1
        return touched, archived

    def _run_contact(self, since, dry, chunk) -> Tuple[int, int]:
        touched = 0
        qs = ContactSubmission.objects.filter(_recent_q(ContactSubmission, since))
        for cs in _iter_recent(qs, chunk):
            title = "Contact Form Query"
            msg = getattr(cs, 'message', '') or ''
            subtitle = _trunc(msg, 120)
            if not dry:
                upsert_lead_for_source(
                    cs,
                    tag='contact',
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(cs, 'email', None),
                    contact_phone=getattr(cs, 'phone', None),
                    default_priority=3
                )
            touched += 1
        return touched, 0

    def _run_waitlist(self, since, dry, chunk) -> Tuple[int, int]:
        touched = 0
        qs = WaitlistEntry.objects.filter(_recent_q(WaitlistEntry, since))
        for we in _iter_recent(qs, chunk):
            title = "Waitlist Signup"
            subtitle = (getattr(we, 'email', None) or '') + (
                f" · {getattr(we, 'contact_number', None)}" if getattr(we, 'contact_number', None) else ''
            )
            if not dry:
                upsert_lead_for_source(
                    we,
                    tag='waitlist',
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(we, 'email', None),
                    contact_phone=getattr(we, 'contact_number', None),
                    default_priority=3
                )
            touched += 1
        return touched, 0

    def _run_brand_owner(self, since, dry, chunk) -> Tuple[int, int]:
        touched = 0
        qs = BrandOwner.objects.filter(_recent_q(BrandOwner, since))
        for bo in _iter_recent(qs, chunk):
            title = f"Brand Owner Registered: {getattr(bo, 'name', None) or 'Unnamed'}"
            subtitle = " · ".join(filter(None, [
                getattr(bo, 'contact_email', None),
                getattr(bo, 'contact_phone', None),
            ]))
            if not dry:
                upsert_lead_for_source(
                    bo,
                    tag='brand_owner_reg',
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(bo, 'contact_email', None),
                    contact_phone=getattr(bo, 'contact_phone', None),
                    default_priority=2
                )
            touched += 1
        return touched, 0

    def _run_factory_owner(self, since, dry, chunk) -> Tuple[int, int]:
        touched = 0
        qs = FactoryOwner.objects.filter(_recent_q(FactoryOwner, since))
        for fo in _iter_recent(qs, chunk):
            title = f"Factory Owner Registered: {getattr(fo, 'name', None) or 'Unnamed'}"
            subtitle = " · ".join(filter(None, [
                getattr(fo, 'contact_email', None),
                getattr(fo, 'contact_phone', None),
            ]))
            if not dry:
                upsert_lead_for_source(
                    fo,
                    tag='factory_owner_reg',
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(fo, 'contact_email', None),
                    contact_phone=getattr(fo, 'contact_phone', None),
                    default_priority=2
                )
            touched += 1
        return touched, 0

    def _run_brand(self, since, dry, chunk) -> Tuple[int, int]:
        touched = 0
        qs = Brand.objects.filter(_recent_q(Brand, since))
        for b in _iter_recent(qs, chunk):
            title = f"Brand: {getattr(b, 'name', None) or 'Unnamed'}"
            bits = []
            if getattr(b, 'country', None): bits.append(b.country)
            if getattr(b, 'website', None): bits.append(b.website)
            subtitle = " · ".join(bits)
            if not dry:
                upsert_lead_for_source(
                    b,
                    tag='brand',
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(b, 'director_email', None) or getattr(b, 'poc_email', None),
                    contact_phone=getattr(b, 'director_number', None) or getattr(b, 'poc_number', None),
                    default_priority=3
                )
            touched += 1
        return touched, 0

    def _run_factory(self, since, dry, chunk) -> Tuple[int, int]:
        touched = 0
        qs = Factory.objects.filter(_recent_q(Factory, since))
        for f in _iter_recent(qs, chunk):
            title = f"Factory: {getattr(f, 'name', None) or 'Unnamed'}"
            bits = []
            if getattr(f, 'type_of_products', None): bits.append(f.type_of_products)
            if getattr(f, 'capacity', None): bits.append(f"cap {f.capacity}")
            subtitle = " · ".join(bits)
            if not dry:
                # Prefer factory owner's user for creator during backfill
                try:
                    creator = getattr(getattr(f, 'factory_owner', None), 'user', None)
                except Exception:
                    creator = None
                upsert_lead_for_source(
                    f,
                    tag='factory',
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(f, 'email', None) or getattr(f, 'poc_email', None) or getattr(f, 'director_email', None),
                    contact_phone=getattr(f, 'phone', None) or getattr(f, 'poc_number', None) or getattr(f, 'director_phone', None),
                    default_priority=3,
                    created_by=creator,
                )
            touched += 1
        return touched, 0