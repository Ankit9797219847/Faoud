# leads/management/commands/refresh_leads.py
from __future__ import annotations

import sys
import traceback
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone
from django.contrib.contenttypes.models import ContentType

# --- Import your models ---
from leads.models import LeadItem
from marketing.models import OnboardingData, ContactSubmission, WaitlistEntry
from case.models import Case
from user.models import BrandOwner, FactoryOwner
from utils.models import Brand
from supply.models import Factory, Bid
from core.models import AutoBidConfig, AutoBidConfigParameterValue

# --- Reuse helpers straight from your signals module ---
# NOTE: We import the same functions you already rely on in signals so behavior stays identical.
from leads.signals import (
    upsert_lead_for_source,
    getRequirementDetailsForOnboardingFromAnswers,
    getRequirementDetailsForCaseFromAnswers,
    _get_or_create_lead_for,
    _append_note,
    _safe_str,
    cfg_id_ok,
)

class Command(BaseCommand):
    help = (
        "Refresh (rebuild) LeadItems from source models according to leads/signals.py logic.\n"
        "Also appends Bid and AutoBid activity for the last N days (default 15). "
        "When notes exist, APPENDS new lines instead of replacing."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--days",
            type=int,
            default=15,
            help="Window (in days) for Bid/AutoBid activity to sync. Default: 15",
        )
        parser.add_argument(
            "--since",
            type=str,
            default=None,
            help="Optional ISO date (YYYY-MM-DD). If provided, overrides --days window for Bid/AutoBid.",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Do not write changes; just log what would happen.",
        )
        parser.add_argument(
            "--limit",
            type=int,
            default=None,
            help="Optional cap per model when rebuilding.",
        )

    def handle(self, *args, **opts):
        days = opts["days"]
        dry_run = opts["dry_run"]
        limit = opts["limit"]
        since_str = opts["since"]

        now = timezone.now()
        if since_str:
            try:
                y, m, d = map(int, since_str.split("-"))
                since_dt = timezone.make_aware(timezone.datetime(y, m, d))
            except Exception:
                self.stderr.write(self.style.ERROR(f"Invalid --since '{since_str}'. Use YYYY-MM-DD."))
                return
        else:
            since_dt = now - timedelta(days=days)

        self.stdout.write(self.style.MIGRATE_HEADING("=== Refresh Leads: START ==="))
        self.stdout.write(f"Time now: {now.isoformat()}")
        self.stdout.write(f"Activity window for Bids/AutoBids: since {since_dt.isoformat()}")
        if dry_run:
            self.stdout.write(self.style.WARNING("DRY RUN mode: no changes will be written."))

        # Wrap in an atomic transaction unless dry-run
        ctx = transaction.atomic if not dry_run else _NoopContext

        with ctx():
            # 1) Rebuild all “base” leads that signals cover (append to notes where applicable)
            self._refresh_onboarding(dry_run=dry_run, limit=limit)
            self._refresh_cases(dry_run=dry_run, limit=limit)
            self._refresh_contacts(dry_run=dry_run, limit=limit)
            self._refresh_waitlist(dry_run=dry_run, limit=limit)
            self._refresh_brandowners(dry_run=dry_run, limit=limit)
            self._refresh_factoryowners(dry_run=dry_run, limit=limit)
            self._refresh_brands(dry_run=dry_run, limit=limit)
            self._refresh_factories(dry_run=dry_run, limit=limit)

            # 2) Add recent Bid / AutoBid activity (last N days or since=)
            self._refresh_recent_bids(since_dt=since_dt, dry_run=dry_run, limit=limit)
            self._refresh_recent_autobids(since_dt=since_dt, dry_run=dry_run, limit=limit)

        self.stdout.write(self.style.MIGRATE_HEADING("=== Refresh Leads: DONE ==="))

    # -----------------------
    # Section 1: Base rebuild
    # -----------------------

    def _append_many_notes_if_any(self, li: LeadItem, new_lines: list[str] | None):
        """
        Append many note lines (timestamped by _append_note) only if provided.
        DO NOT overwrite existing notes. Keep subtitle/priority unchanged here.
        """
        if not new_lines:
            return
        for line in new_lines:
            _append_note(li, line, force_subtitle=None, force_priority=None)

    def _refresh_onboarding(self, *, dry_run: bool, limit: int | None):
        qs = OnboardingData.objects.all().order_by("id")
        if limit:
            qs = qs[:limit]
        count = 0
        for od in qs:
            try:
                title = f"BO Lead: {od.product_name or 'Unnamed Product'}"
                bits = []
                if getattr(od, "company_name", None): bits.append(od.company_name)
                if getattr(od, "quantity", None): bits.append(f"qty {od.quantity}")
                if getattr(od, "location", None): bits.append(od.location)
                subtitle = " · ".join(bits) or (getattr(od, "product_category", "") or "")

                details = getRequirementDetailsForOnboardingFromAnswers(od)
                # signals used selected keys to create summary lines for notes:
                summary_lines = []
                for k in ("product_name", "product_category", "quantity", "location", "timeline", "additional_details"):
                    v = details.get(k)
                    if v:
                        summary_lines.append(f"{k}: {v}")

                li = upsert_lead_for_source(
                    od,
                    tag="onboarding",
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(od, "email", None),
                    contact_phone=getattr(od, "mobile", None),
                    default_priority=2,
                    notes=None,  # don't clobber via defaults; we append below
                )

                # If existing notes are empty, initialize them with the summary set as a single snapshot line.
                # If not empty, append the lines.
                if summary_lines:
                    if (li.notes or "").strip():
                        self._append_many_notes_if_any(li, summary_lines)
                    else:
                        # seed with one combined line for readability
                        _append_note(li, " | ".join(summary_lines), force_subtitle=None, force_priority=None)

                count += 1
            except Exception:
                self._err("onboarding", od)
        self._ok("OnboardingData", count)

    def _refresh_cases(self, *, dry_run: bool, limit: int | None):
        qs = Case.objects.all().order_by("id")
        if limit:
            qs = qs[:limit]
        count = 0
        for c in qs:
            try:
                bo = getattr(c, "brand_owner", None)
                title = f"Case {getattr(c, 'id', 'unknown')}: {c.name or 'Unnamed Case'}"
                bits = []
                if bo and getattr(bo, "name", None): bits.append(bo.name)
                if getattr(c, "quantity", None): bits.append(f"qty {c.quantity}")
                if getattr(c, "category", None): bits.append(c.category)
                subtitle = " · ".join(bits)

                details = []
                try:
                    details = getRequirementDetailsForCaseFromAnswers(c) or []
                except Exception:
                    details = []

                li = upsert_lead_for_source(
                    c,
                    tag="case",
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(bo, "contact_email", None) if bo else None,
                    contact_phone=getattr(bo, "contact_phone", None) if bo else None,
                    default_priority=1 if getattr(c, "category", None) in ("npd_with", "onboarding") else 2,
                    notes=None,
                )
                # Append details lines (if any)
                self._append_many_notes_if_any(li, details)

                # Archive latest OnboardingData lead for same user like in signals
                try:
                    if bo and getattr(bo, "user_id", None):
                        user_id = bo.user_id
                        od = OnboardingData.objects.filter(user_id=user_id).order_by("-id").first()
                        if od:
                            ct = ContentType.objects.get_for_model(OnboardingData)
                            if not dry_run:
                                LeadItem.objects.filter(source_ct=ct, source_id=od.id, active=True).update(
                                    active=False, status="archived"
                                )
                except Exception:
                    pass

                count += 1
            except Exception:
                self._err("case", c)
        self._ok("Case", count)

    def _refresh_contacts(self, *, dry_run: bool, limit: int | None):
        qs = ContactSubmission.objects.all().order_by("id")
        if limit:
            qs = qs[:limit]
        count = 0
        for obj in qs:
            try:
                title = "Contact Form Query"
                msg = getattr(obj, "message", "") or ""
                subtitle = (msg[:120]) if msg else ""
                li = upsert_lead_for_source(
                    obj,
                    tag="contact",
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(obj, "email", None),
                    contact_phone=getattr(obj, "phone", None),
                    default_priority=3,
                    notes=None,
                )
                # Append one stabilizing line (only if empty)
                if not (li.notes or "").strip() and subtitle:
                    _append_note(li, f"message: {subtitle}", force_subtitle=None, force_priority=None)
                count += 1
            except Exception:
                self._err("contact", obj)
        self._ok("ContactSubmission", count)

    def _refresh_waitlist(self, *, dry_run: bool, limit: int | None):
        qs = WaitlistEntry.objects.all().order_by("id")
        if limit:
            qs = qs[:limit]
        count = 0
        for obj in qs:
            try:
                title = "Waitlist Signup"
                subtitle = (obj.email or "") + (f" · {getattr(obj, 'contact_number', '')}" if getattr(obj, "contact_number", None) else "")
                upsert_lead_for_source(
                    obj,
                    tag="waitlist",
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(obj, "email", None),
                    contact_phone=getattr(obj, "contact_number", None),
                    default_priority=3,
                    notes=None,
                )
                count += 1
            except Exception:
                self._err("waitlist", obj)
        self._ok("WaitlistEntry", count)

    def _refresh_brandowners(self, *, dry_run: bool, limit: int | None):
        qs = BrandOwner.objects.all().order_by("id")
        if limit:
            qs = qs[:limit]
        count = 0
        for bo in qs:
            try:
                title = f"Brand Owner Registered: {bo.name or 'Unnamed'}"
                subtitle = " · ".join(filter(None, [getattr(bo, "contact_email", None), getattr(bo, "contact_phone", None)]))
                upsert_lead_for_source(
                    bo,
                    tag="brand_owner_reg",
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(bo, "contact_email", None),
                    contact_phone=getattr(bo, "contact_phone", None),
                    default_priority=2,
                    notes=None,
                )
                count += 1
            except Exception:
                self._err("brand_owner", bo)
        self._ok("BrandOwner", count)

    def _refresh_factoryowners(self, *, dry_run: bool, limit: int | None):
        qs = FactoryOwner.objects.all().order_by("id")
        if limit:
            qs = qs[:limit]
        count = 0
        for fo in qs:
            try:
                title = f"Factory Owner Registered: {fo.name or 'Unnamed'}"
                subtitle = " · ".join(filter(None, [getattr(fo, "contact_email", None), getattr(fo, "contact_phone", None)]))
                upsert_lead_for_source(
                    fo,
                    tag="factory_owner_reg",
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(fo, "contact_email", None),
                    contact_phone=getattr(fo, "contact_phone", None),
                    default_priority=2,
                    notes=None,
                )
                count += 1
            except Exception:
                self._err("factory_owner", fo)
        self._ok("FactoryOwner", count)

    def _refresh_brands(self, *, dry_run: bool, limit: int | None):
        qs = Brand.objects.all().order_by("id")
        if limit:
            qs = qs[:limit]
        count = 0
        for b in qs:
            try:
                title = f"Brand: {getattr(b, 'name', '') or 'Unnamed'}"
                bits = []
                if getattr(b, "country", None): bits.append(b.country)
                if getattr(b, "website", None): bits.append(b.website)
                subtitle = " · ".join(bits)
                upsert_lead_for_source(
                    b,
                    tag="brand",
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(b, "director_email", None) or getattr(b, "poc_email", None),
                    contact_phone=getattr(b, "director_number", None) or getattr(b, "poc_number", None),
                    default_priority=3,
                    notes=None,
                )
                count += 1
            except Exception:
                self._err("brand", b)
        self._ok("Brand", count)

    def _refresh_factories(self, *, dry_run: bool, limit: int | None):
        qs = Factory.objects.all().order_by("id")
        if limit:
            qs = qs[:limit]
        count = 0
        for f in qs:
            try:
                title = f"Factory: {getattr(f, 'name', '') or 'Unnamed'}"
                bits = []
                if getattr(f, "type_of_products", None): bits.append(f.type_of_products)
                if getattr(f, "capacity", None): bits.append(f"cap {f.capacity}")
                subtitle = " · ".join(bits)
                upsert_lead_for_source(
                    f,
                    tag="factory",
                    title=title,
                    subtitle=subtitle,
                    contact_email=getattr(f, "email", None) or getattr(f, "poc_email", None) or getattr(f, "director_email", None),
                    contact_phone=getattr(f, "phone", None) or getattr(f, "poc_number", None) or getattr(f, "director_phone", None),
                    default_priority=3,
                    notes=None,
                )
                count += 1
            except Exception:
                self._err("factory", f)
        self._ok("Factory", count)

    # ------------------------------------------
    # Section 2: Recent Bid / AutoBid activities
    # ------------------------------------------

    def _refresh_recent_bids(self, *, since_dt, dry_run: bool, limit: int | None):
        """
        Ensure a Bid lead exists and append a 'snapshot' note for Bids changed in the window.
        We don't try to reconstruct historical deltas; the goal is to add a clear, current line.
        """
        # Prefer updated_at if exists, else created/modified fallback
        qs = Bid.objects.all()
        if hasattr(Bid, "updated_at"):
            qs = qs.filter(updated_at__gte=since_dt).order_by("updated_at")
        elif hasattr(Bid, "modified"):
            qs = qs.filter(modified__gte=since_dt).order_by("modified")
        else:
            qs = qs.filter(id__gte=0).order_by("id")  # fallback (no filter)
        if limit:
            qs = qs[:limit]

        count = 0
        for b in qs:
            try:
                factory_name = getattr(b.factory, "name", None) if getattr(b, "factory_id", None) else None
                title = (
                    f"Bid {b.id} for Case {getattr(b, 'case_id', None)} ({factory_name or 'Factory ?'})"
                    if getattr(b, "case_id", None)
                    else f"Bid {b.id} ({factory_name or 'Factory ?'})"
                )
                subtitle = f"{factory_name or 'Factory ?'}"

                li, _ = _get_or_create_lead_for(b, tag="bid", title=title, subtitle=subtitle)

                # Append a present-state snapshot line (do NOT replace notes)
                snap = f"Snapshot — status={_safe_str(getattr(b, 'status', None))}, quote={_safe_str(getattr(b, 'quote', None))}, quote_bo={_safe_str(getattr(b, 'quote_bo', None))}"
                _append_note(li, snap, force_subtitle=None, force_priority=None)

                count += 1
            except Exception:
                self._err("bid", b)
        self._ok("Bid (recent)", count)

    def _refresh_recent_autobids(self, *, since_dt, dry_run: bool, limit: int | None):
        """
        Ensure AutoBidConfig leads exist and append current-state snapshot lines for:
          - AutoBidConfig changed in window
          - AutoBidConfigParameterValue changed in window
        """
        # AutoBidConfig first
        cfg_qs = AutoBidConfig.objects.all()
        if hasattr(AutoBidConfig, "updated_at"):
            cfg_qs = cfg_qs.filter(updated_at__gte=since_dt).order_by("updated_at")
        elif hasattr(AutoBidConfig, "modified"):
            cfg_qs = cfg_qs.filter(modified__gte=since_dt).order_by("modified")
        else:
            cfg_qs = cfg_qs.order_by("id")

        if limit:
            cfg_qs = cfg_qs[:limit]

        cfg_count = 0
        for cfg in cfg_qs:
            try:
                if not cfg_id_ok(cfg):
                    continue
                factory_name = getattr(cfg.factory, "name", None) if getattr(cfg, "factory_id", None) else None
                subcat_name = getattr(cfg.subcategory, "name", None) if getattr(cfg, "subcategory_id", None) else None
                title = f"AutoBid: {factory_name or 'Factory ?'} / {subcat_name or 'Subcategory ?'}"
                subtitle = f"{getattr(cfg, 'config_type', '?')} · v{getattr(cfg, 'version', 1)}"

                li, _ = _get_or_create_lead_for(cfg, tag="autobid", title=title, subtitle=subtitle)
                snap = f"Config snapshot — enabled={_safe_str(getattr(cfg, 'enabled', None))}, approved_by_am={_safe_str(getattr(cfg, 'approved_by_am', None))}, type={_safe_str(getattr(cfg, 'config_type', None))}, version={_safe_str(getattr(cfg, 'version', None))}"
                _append_note(li, snap, force_subtitle=None, force_priority=None)
                cfg_count += 1
            except Exception:
                self._err("autobid_config", cfg)
        self._ok("AutoBidConfig (recent)", cfg_count)

        # Parameter values next
        pv_qs = AutoBidConfigParameterValue.objects.all()
        if hasattr(AutoBidConfigParameterValue, "updated_at"):
            pv_qs = pv_qs.filter(updated_at__gte=since_dt).order_by("updated_at")
        elif hasattr(AutoBidConfigParameterValue, "modified"):
            pv_qs = pv_qs.filter(modified__gte=since_dt).order_by("modified")
        else:
            pv_qs = pv_qs.order_by("id")

        if limit:
            pv_qs = pv_qs[:limit]

        pv_count = 0
        for pv in pv_qs:
            try:
                cfg = getattr(pv, "auto_bid_config", None)
                if not cfg or not cfg_id_ok(cfg):
                    continue

                factory_name = getattr(cfg.factory, "name", None) if getattr(cfg, "factory_id", None) else None
                subcat_name = getattr(cfg.subcategory, "name", None) if getattr(cfg, "subcategory_id", None) else None
                title = f"AutoBid: {factory_name or 'Factory ?'} / {subcat_name or 'Subcategory ?'}"
                subtitle = f"{getattr(cfg, 'config_type', '?')} · v{getattr(cfg, 'version', 1)}"

                li, _ = _get_or_create_lead_for(cfg, tag="autobid", title=title, subtitle=subtitle)

                pd = getattr(pv, "parameter_definition", None)
                pd_name = getattr(pd, "name", f"param#{getattr(pd, 'id', 'unknown')}")
                # choose actual value
                if getattr(pv, "decimal_value", None) is not None:
                    val = pv.decimal_value
                elif (getattr(pv, "text_value", None) not in (None, "")):
                    val = pv.text_value
                else:
                    val = pv.bool_value
                line = f"Param snapshot — {pd_name} = {_safe_str(val)}"
                _append_note(li, line, force_subtitle=None, force_priority=None)
                pv_count += 1
            except Exception:
                self._err("autobid_param", pv)
        self._ok("AutoBid ParamValues (recent)", pv_count)

    # ---- helpers ----

    def _ok(self, label: str, n: int):
        self.stdout.write(self.style.SUCCESS(f"[OK] {label}: {n} processed"))

    def _err(self, label: str, obj):
        ident = getattr(obj, "id", "unknown")
        self.stderr.write(self.style.ERROR(f"[ERR] {label} id={ident}"))
        traceback.print_exc(file=sys.stderr)


class _NoopContext:
    """No-op context manager used for --dry-run to keep structure simple."""
    def __enter__(self):  # pragma: no cover
        return self
    def __exit__(self, exc_type, exc, tb):  # pragma: no cover
        return False