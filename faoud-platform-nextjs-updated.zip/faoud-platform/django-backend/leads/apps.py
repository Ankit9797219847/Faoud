from django.apps import AppConfig

class LeadsConfig(AppConfig):
    name = 'leads'
    verbose_name = 'Leads'

    def ready(self):
        from . import signals