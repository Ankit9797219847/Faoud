from django.shortcuts import render

# Create your views here.
# leads/views.py
from django.utils import timezone
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, permissions, filters

from case.models import Case
from supply.models import Bid
from user.permissions import IsSuperAccountManager, is_am, is_mngmt, is_super_am
from .models import LeadItem
from .serializers import LeadItemSerializer, LeadItemUpdateSerializer
from rest_framework.permissions import IsAuthenticated
from django.contrib.contenttypes.models import ContentType
from rest_framework.response import Response
from rest_framework import status
from utils.captcha import verify_captcha_or_raise



# leads/views.py
from django.db.models import Q
from rest_framework import generics, permissions, filters
from django_filters.rest_framework import DjangoFilterBackend
from django.utils import timezone

from rest_framework.pagination import PageNumberPagination

class StandardPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 200
class LeadItemListView(generics.ListAPIView):
    serializer_class = LeadItemSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    pagination_class = StandardPagination

    filterset_fields = {
        'status': ['exact', 'in'],
        'priority': ['exact', 'in'],
        'owner': ['exact'],
        'created_by': ['exact', 'in'],
        'tag': ['exact', 'in'],
        'active': ['exact'],
    }
    search_fields = ['title', 'subtitle', 'contact_email', 'contact_phone']
    ordering_fields = ['created_at', 'priority', 'id']
    ordering = ['-created_at']

    def get_queryset(self):
        user = self.request.user
        base = LeadItem.objects.filter(active=True)

        if is_super_am(user) or is_mngmt(user):
            qs = base
        elif is_am(user):
            qs = base.filter(Q(owner__user=user) | Q(created_by=user))
        else:
            qs = base.filter(created_by=user)

        # computed filters (is_new/min_age_days/max_age_days)
        is_new = self.request.query_params.get('is_new')
        if is_new is not None:
            flag = str(is_new).strip().lower() in ('1', 'true', 'yes')
            cutoff = timezone.now() - timezone.timedelta(days=7)
            qs = qs.filter(Q(status='new') | Q(created_at__gte=cutoff)) if flag \
                 else qs.exclude(status='new').filter(created_at__lt=cutoff)

        try:
            min_age = int(self.request.query_params.get('min_age_days', ''))
            qs = qs.filter(created_at__lte=timezone.now() - timezone.timedelta(days=min_age))
        except (TypeError, ValueError):
            pass

        try:
            max_age = int(self.request.query_params.get('max_age_days', ''))
            qs = qs.filter(created_at__gte=timezone.now() - timezone.timedelta(days=max_age))
        except (TypeError, ValueError):
            pass

        return qs

    def list(self, request, *args, **kwargs):
        """
        Group-expanding pagination:
        - Build the normal seed page from filtered/ordered queryset.
        - If any item belongs to a 'case group', include the whole group (Case lead + all Bid leads for that case),
          even if this exceeds page_size. Extra rows respect role visibility but intentionally ignore tag/status filters
          so the group is complete.
        """
        # 1) Normal filtered/ordered queryset
        base_qs = self.filter_queryset(self.get_queryset())

        # 2) Seed page via paginator
        page = self.paginate_queryset(base_qs)
        if page is None:
            # No pagination requested; return plain list
            serializer = self.get_serializer(base_qs, many=True)
            return Response(serializer.data)

        seed_items = list(page)
        if not seed_items:
            # Empty page as usual
            serializer = self.get_serializer(seed_items, many=True)
            return self.get_paginated_response(serializer.data)

        # 3) Compute case_ids represented on this page
        ct_case = ContentType.objects.get_for_model(Case).id
        ct_bid  = ContentType.objects.get_for_model(Bid).id

        case_ids = set()

        # (a) Cases directly present on the page
        for li in seed_items:
            if li.source_ct_id == ct_case and li.source_id:
                case_ids.add(li.source_id)

        # (b) Bids present on the page -> map to their case
        page_bid_ids = [li.source_id for li in seed_items if li.source_ct_id == ct_bid and li.source_id]
        if page_bid_ids:
            bid_to_case = dict(
                Bid.objects.filter(id__in=page_bid_ids)
                .values_list('id', 'case_id')
            )
            for bid_id in page_bid_ids:
                cid = bid_to_case.get(bid_id)
                if cid:
                    case_ids.add(cid)

        if not case_ids:
            # No groups to expand; return the seed page
            serializer = self.get_serializer(seed_items, many=True)
            return self.get_paginated_response(serializer.data)

        # 4) Fetch **all** LeadItems for those case_ids:
        #    - all Case leads whose source_id in case_ids
        #    - all Bid leads whose source_id in bids under those case_ids
        #    Respect SAME role visibility (base_qs), but ignore tag/status filters for completeness.
        #    To achieve that, we re-filter from the *visibility base* only.
        #    The visibility base = get_queryset() WITHOUT filter_backends.
        visibility_base = self.get_queryset().model.objects.filter(
            id__in=self.get_queryset().values_list('id', flat=True)
        )
        # ^ Ensures we don’t leak anything outside role visibility.

        # Find all Bid IDs under the target case_ids
        all_bid_ids = list(
            Bid.objects.filter(case_id__in=case_ids)
            .values_list('id', flat=True)
        )

        # Build the group queryset from the visibility set only
        group_qs = visibility_base.filter(
            Q(source_ct_id=ct_case, source_id__in=case_ids) |
            Q(source_ct_id=ct_bid,  source_id__in=all_bid_ids)
        )

        # If the client requested a specific creator, enforce it for expanded items too
        # so we don't leak bids/cases created by other users (or with null creators).
        # Supports both created_by and created_by__in query params.
        try:
            creator_params = []
            # exact
            single_creator = request.query_params.get('created_by')
            if single_creator:
                creator_params.append(single_creator)
            # in-list (comma separated)
            multi_creator = request.query_params.get('created_by__in')
            if multi_creator:
                creator_params.extend(str(multi_creator).split(','))
            creator_ids = [int(x) for x in creator_params if str(x).strip().isdigit()]
            if creator_ids:
                group_qs = group_qs.filter(created_by_id__in=creator_ids)
        except Exception:
            pass

        # Optional: If you want extra rows to ALSO honor the current user filters (status/tag/etc),
        # replace `visibility_base` above with `base_qs` (but then groups may be incomplete).

        # 5) Merge: keep seed order first, then append the remaining group rows, de-duped
        seed_ids = [li.id for li in seed_items]
        group_items = list(group_qs.exclude(id__in=seed_ids))

        # Stable ordering:
        #   - DRF seed already followed base ordering
        #   - For appended items, we apply the same ordering as the request/view
        # Figure out the active ordering params
        ord_params = request.query_params.getlist('ordering') or self.ordering or ['-created_at']
        # Normalize into Django order_by arguments
        if isinstance(ord_params, str):
            ord_params = [ord_params]
        try:
            group_items = sorted(
                group_items,
                key=lambda x: tuple(
                    getattr(x, f.lstrip('-')) for f in [p for p in ord_params if p.lstrip('-') in self.ordering_fields]
                ),
                reverse=any(p.startswith('-') for p in ord_params)
            )
        except Exception:
            # Fallback: keep DB natural order if complex ordering fails
            pass

        final_items = seed_items + group_items

        # 6) Serialize and respond. Keep normal pagination envelope, add a hint field.
        serializer = self.get_serializer(final_items, many=True)
        data = serializer.data

        resp = self.get_paginated_response(data)
        # Enrich with info about the expansion (non-breaking)
        extra = {
            "expanded_case_ids": sorted(case_ids),
            "seed_count": len(seed_items),
            "added_count": len(group_items),
        }
        # DRF Response.data is a dict; we can safely augment it.
        resp.data["group_expansion"] = extra
        return resp
from rest_framework import generics, permissions
from .serializers import LeadItemCreateSerializer

class LeadItemCreateView(generics.CreateAPIView):
    """
    Anyone can create a lead. We ignore dangerous fields on input.
    """
    serializer_class = LeadItemCreateSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        verify_captcha_or_raise(request)
        return super().create(request, *args, **kwargs)

    def perform_create(self, serializer):
        user = self.request.user if self.request.user.is_authenticated else None
        serializer.save(
            created_by=user,
            status='new',              # enforce
            priority=2,                # enforce default
            owner=None,                # cannot set owner at creation
            active=True,
        )

from rest_framework.exceptions import PermissionDenied

class LeadItemUpdateView(generics.UpdateAPIView):
    serializer_class = LeadItemUpdateSerializer
    permission_classes = [IsAuthenticated]
    queryset = LeadItem.objects.all()
    http_method_names = ['patch', 'put']

    def get_queryset(self):
        # Visibility mirrors the list view and respects role hierarchy.
        user = self.request.user
        base = super().get_queryset()
        if is_super_am(user) or is_mngmt(user):
            return base
        if is_am(user):
            return base.filter(Q(owner__user=user) | Q(created_by=user))
        # non-AM creators cannot update anything
        return base.none()

    def perform_update(self, serializer):
        user = self.request.user
        changing = set(self.request.data.keys())

        # Role flags: in our system SuperAM and MNGMT are groups layered on top of AM
        am = is_am(user)
        super_am = is_super_am(user)
        mngmt = is_mngmt(user)

        # No role -> no updates
        if not (am or super_am or mngmt):
            raise PermissionDenied("You cannot modify this lead.")

        # Allowed fields per role (hierarchy-aware)
        if mngmt:
            allowed = {'owner', 'status', 'priority', 'notes', 'tag', 'active'}
        elif super_am:
            # SuperAMs can do everything except reassign owner and toggle active
            allowed = {'status', 'priority', 'notes', 'tag'}
        else:  # plain AM
            allowed = {'status', 'priority', 'notes'}

        disallowed = changing - allowed
        if disallowed:
            raise PermissionDenied(f"You can only modify {sorted(allowed)}.")

        serializer.save()

    def update(self, request, *args, **kwargs):
        partial = request.method.lower() == "patch"
        instance = self.get_object()
        write_ser = self.get_serializer(instance, data=request.data, partial=partial)
        write_ser.is_valid(raise_exception=True)
        self.perform_update(write_ser)

        # re-fetch and return with full serializer
        instance = LeadItem.objects.select_related("owner").get(pk=instance.pk)
        read_ser = LeadItemSerializer(instance, context=self.get_serializer_context())
        return Response(read_ser.data, status=status.HTTP_200_OK)
    

    # leads/public_views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .models import LeadItem
from .serializers import LeadItemSerializer
from .session_tokens import issue_lead_session_token, verify_lead_session_token

class PublicLeadSessionStart(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        verify_captcha_or_raise(request)

        tag = request.data.get('tag') or 'website_chat'
        title = request.data.get('title') or ''
        subtitle = request.data.get('subtitle') or ''

        lead = LeadItem.objects.create(
            tag=tag,
            title=title[:255],
            subtitle=subtitle[:255],
            status='new',
            priority=2,
            active=True,
            created_by=None,  # anonymous
        )
        tok = issue_lead_session_token(lead.id, minutes=120)
        return Response({
            "lead_id": lead.id,
            "session_token": tok,
        }, status=status.HTTP_201_CREATED)

class PublicLeadSessionPatch(APIView):
    permission_classes = [permissions.AllowAny]

    def patch(self, request, pk: int):
        token = request.headers.get('X-Lead-Session') or ''
        if not verify_lead_session_token(token, pk):
            return Response({"detail": "Invalid or expired session."}, status=status.HTTP_403_FORBIDDEN)

        lead = LeadItem.objects.filter(pk=pk, active=True).first()
        if not lead:
            return Response({"detail": "Lead not found."}, status=status.HTTP_404_NOT_FOUND)

        # Allowed public fields (very strict)
        allowed_fields = {'contact_email', 'contact_phone', 'tag', 'title', 'subtitle'}
        data = {k: v for k, v in request.data.items() if k in allowed_fields}

        # notes_append: append as a new line (server-side anti-spam/length guard)
        notes_append = (request.data.get('notes_append') or '').strip()
        if notes_append:
            new_line = (notes_append[:500]).replace('\n', ' ').strip()
            lead.notes = (lead.notes + '\n' + new_line).strip() if lead.notes else new_line

        # Assign allowed direct fields
        for k, v in data.items():
            setattr(lead, k, (v or '')[:255])

        lead.save(update_fields=list(data.keys()) + (['notes'] if notes_append else []))

        return Response(LeadItemSerializer(lead).data, status=status.HTTP_200_OK)
