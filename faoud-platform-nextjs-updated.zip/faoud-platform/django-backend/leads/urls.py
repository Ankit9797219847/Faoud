# leads/urls.py
from django.urls import path
from .views import LeadItemCreateView, LeadItemListView, LeadItemUpdateView, PublicLeadSessionPatch, PublicLeadSessionStart

urlpatterns = [
    path('leads/', LeadItemListView.as_view(), name='lead-list'),
    path('leads/<int:pk>/', LeadItemUpdateView.as_view(), name='lead-update'),
    path('leads/create/', LeadItemCreateView.as_view(), name='lead-create'),
    path('public/lead-session/start/', PublicLeadSessionStart.as_view(), name='public-lead-session-start'),
    path('public/lead-session/<int:pk>/patch/', PublicLeadSessionPatch.as_view(), name='public-lead-session-patch'),
]