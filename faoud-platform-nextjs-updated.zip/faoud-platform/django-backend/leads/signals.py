# leads/signals.py
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.contenttypes.models import ContentType
from django.utils.text import Truncator
from django.conf import settings
from django.db.models import Q

from django.db.models.signals import pre_save, post_save
from django.utils import timezone
from django.contrib.contenttypes.models import ContentType
from django.dispatch import receiver
import logging
import json

from case.signals import create_onboarding_flow
from core.models import AutoBidConfig, AutoBidConfigParameterValue
from supply.models import Bid
from leads.models import LeadItem

logger = logging.getLogger(__name__)


from core.models import AutoBidConfig
from leads.models import LeadItem

# Source models (import what you actually have)
from marketing.models import OnboardingData, ContactSubmission, WaitlistEntry
from case.models import Case
from product.models import Category, ChosenAnswer, Subcategory
from user.models import BrandOwner, FactoryOwner, AM
from utils.models import Brand  # your Brand model lives under product or utils per your code; adjust import
from supply.models import Bid, Factory
from case.signals_bus import user_onboarded


def _trunc(text: str, n=255) -> str:
    return Truncator(text or '').chars(n)
def getRequirementDetailsForCaseFromAnswers(case: Case) -> list:
    """
    Extract requirement details from answers stored on a Case via ChosenAnswer objects.

    Returns a list of short summary strings (suitable for LeadItem.notes).
    """
    # avoid top-level import cycles; import locally
    # intermediate storage
    details = {
        'product_name': '',
        'sku': '',
        'packaging_material': '',
        'benchmark': '',
        'target_price': '',
        'timeline': '',
        'quantity': '',
        'products_pdf': '',
        'additional_details': '',
    }

    # Robustly fetch chosen answers:
    # - use case.answers.all() if the related_name 'answers' exists
    # - fall back to ChosenAnswer.objects.filter(case=case) if the model is available
    # - otherwise proceed with an empty list
    try:
        if getattr(case, 'answers', None) is not None:
            chosen_qs = case.answers.all()
        elif ChosenAnswer is not None:
            # order by order_index if present to preserve submission order
            qs = ChosenAnswer.objects.filter(case=case)
            if hasattr(ChosenAnswer, 'order_index') or qs.exists() and hasattr(qs.first(), 'order_index'):
                chosen_qs = qs.order_by('order_index')
            else:
                chosen_qs = qs
        else:
            chosen_qs = []
    except Exception:
        chosen_qs = []

    pdf_urls = []

    for ca in chosen_qs:
        q = getattr(ca, 'question', None)
        qtext = (getattr(q, 'question_text', '') or '').lower()

        # derive textual value from the chosen answer
        value = ''
        if getattr(ca, 'answer_text', None):
            value = str(ca.answer_text).strip()
        else:
            opts = getattr(ca, 'selected_options', None)
            if opts is not None:
                try:
                    vals = [str(o.option_text).strip() for o in opts.all()]
                    if vals:
                        value = ", ".join(vals)
                except Exception:
                    value = ''
            if not value and getattr(ca, 'answer_file', None):
                try:
                    f = ca.answer_file
                    v = getattr(f, 'url', None) or str(f)
                    value = str(v)
                except Exception:
                    value = str(getattr(ca, 'answer_file', ''))
        if not value:
            continue

        low = qtext

        # Detect PDF uploads or lists of products -> collect under products_pdf
        if any(k in low for k in ('pdf', 'list of products', 'add the list', 'products list', 'upload pdf', 'add the list of products')):
            pdf_urls.append(_trunc(value, 255))
            continue

        # Map by keywords into details dict
        if any(k in low for k in ('product name', 'product_name', 'name of product', 'what product', 'what product you', 'which product')):
            details['product_name'] = details['product_name'] + (("; " + _trunc(value, 120)) if details['product_name'] else _trunc(value, 120))

        elif any(k in low for k in ('sku', 'provide your sku', 'what would be the sku', 'provide your sku?')):
            details['sku'] = details['sku'] + (("; " + _trunc(value, 80)) if details['sku'] else _trunc(value, 80))

        elif any(k in low for k in ('packaging material', 'type of packaging', 'which type of packaging', 'which type of packaging material', 'packaging')):
            details['packaging_material'] = details['packaging_material'] + (("; " + _trunc(value, 120)) if details['packaging_material'] else _trunc(value, 120))

        elif any(k in low for k in ('benchmark', 'benchmark for', 'please share benchmark', 'give us a benchmark', 'benchmark for product', 'product quality benchmark')):
            details['benchmark'] = details['benchmark'] + ((" · " + _trunc(value,255)) if details['benchmark'] else _trunc(value,255))

        elif any(k in low for k in ('target price', 'finished good target price', 'price you are looking', 'price per unit', 'per unit', 'target price per unit')):
            details['target_price'] = details['target_price'] + (("; " + _trunc(value,80)) if details['target_price'] else _trunc(value,80))

        elif any(k in low for k in ('timeline', 'expected timeline', 'expected lead time', 'what is the expected timeline')):
            details['timeline'] = details['timeline'] + (("; " + _trunc(value,120)) if details['timeline'] else _trunc(value,120))

        elif any(k in low for k in ('quantity', 'qty', 'quantity of products', 'how many', 'quantity to be manufactured')):
            details['quantity'] = details['quantity'] + (("; " + _trunc(value,60)) if details['quantity'] else _trunc(value,60))

        else:
            # fallback -> additional details
            details['additional_details'] = details['additional_details'] + ((" · " + _trunc(value,255)) if details['additional_details'] else _trunc(value,255))

    # finalise pdfs if any
    if pdf_urls:
        details['products_pdf'] = ", ".join(pdf_urls)

    # Build a list of summary strings suitable for LeadItem.notes (preserves ordering and readability)
    summary_parts = []
    order_keys = ['product_name', 'sku', 'packaging_material', 'benchmark', 'target_price', 'timeline', 'quantity', 'products_pdf', 'additional_details']
    for k in order_keys:
        v = details.get(k)
        if v:
            summary_parts.append(f"{k}: {v}")

    return summary_parts

def getRequirementDetailsForOnboardingFromAnswers(od: OnboardingData) -> dict:
    """
    Build a details dict representing all available onboarding answers.
    Prefer explicit model fields, fall back to values in od.answers (if any),
    and collect any extra keys from the answers JSON into additional_details.
    """
    answers = getattr(od, 'answers', {}) or {}

    # canonical fields we want exposed individually
    keys = [
        'product_name',
        'product_category',
        'quantity',
        'location',
        'timeline',
        'budget',
        'company_name',
        'selected_factory',
        'factory_title',
        'factory_items',
        'selected_category_ids',
        'selected_subcategory_ids',
        'custom_category_text',
        'custom_subcategory_text',
        'instructions',
        'requires_formulation',
        'flow_type',
        'client_id',
        'email',
        'mobile',
        'source_route',
        'origination_source',
    ]

    details = {}
    for k in keys:
        # prefer model attribute, then answers dict, else empty
        val = getattr(od, k, None)
        if not val:
            val = answers.get(k, '')
        if val is None:
            val = ''
        # normalise booleans to readable string
        if isinstance(val, bool):
            val = 'yes' if val else 'no'
        details[k] = _trunc(str(val), 255) if val != '' else ''

    category_ids = _coerce_id_list(getattr(od, 'selected_category_ids', []))
    subcategory_ids = _coerce_id_list(getattr(od, 'selected_subcategory_ids', []))
    if category_ids:
        details['matched_categories'] = ", ".join(Category.objects.filter(id__in=category_ids).values_list('name', flat=True))
    else:
        details['matched_categories'] = ''
    if subcategory_ids:
        details['matched_subcategories'] = ", ".join(Subcategory.objects.filter(id__in=subcategory_ids).values_list('name', flat=True))
    else:
        details['matched_subcategories'] = ''

    # Collect structured launch-page answers before the free-form fallback.
    extra_parts = []
    configurator_answers = getattr(od, 'configurator_answers', {}) or {}
    for k, v in configurator_answers.items():
        if v in (None, "", [], {}):
            continue
        label = str(k).replace('_', ' ').title()
        extra_parts.append(f"{label}: {_trunc(str(v), 200)}")

    utm_params = getattr(od, 'utm_params', {}) or {}
    if utm_params:
        utm_text = ", ".join(
            f"{key}={value}"
            for key, value in utm_params.items()
            if value not in (None, "", [], {})
        )
        if utm_text:
            extra_parts.append(f"UTM: {_trunc(utm_text, 240)}")

    # Collect any additional keys from answers that aren't in our canonical list.
    for k, v in answers.items():
        if k in keys:
            continue
        if v is None or v == '':
            continue
        extra_parts.append(f"{k}: {_trunc(str(v), 200)}")

    # also include the model's instructions field (if present) and any explicit additional_details key
    if getattr(od, 'instructions', None):
        extra_parts.insert(0, _trunc(str(getattr(od, 'instructions')), 255))
    if 'additional_details' in answers and answers.get('additional_details'):
        extra_parts.append(_trunc(str(answers.get('additional_details')), 255))

    details['additional_details'] = " · ".join(extra_parts) if extra_parts else ''

    return details

def _coerce_id_list(value):
    if not value:
        return []
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except Exception:
            value = value.split(',')
    if not isinstance(value, (list, tuple)):
        return []
    ids = []
    for item in value:
        try:
            ids.append(int(item))
        except (TypeError, ValueError):
            continue
    return ids

def upsert_lead_for_source(
    source_obj,
    *,
    tag: str,
    title: str,
    subtitle: str,
    contact_email=None,
    contact_phone=None,
    default_status='new',
    default_priority=2,
    notes="",
    created_by=None,
):
    """
    Idempotent creation/update of a LeadItem for a given source object.
    """
    ct = ContentType.objects.get_for_model(source_obj.__class__)
    li, created = LeadItem.objects.get_or_create(
        source_ct=ct,
        source_id=source_obj.pk,
        defaults=dict(
            tag=tag,
            title=_trunc(title),
            subtitle=_trunc(subtitle),
            contact_email=contact_email,
            contact_phone=contact_phone,
            status=default_status,
            priority=default_priority,
            active=True,
            notes="\n".join(notes) if notes else "",
            created_by=getattr(created_by, 'pk', None) and created_by or None,
        ),
    )
    if not created:
        changed = False
        # opportunistically set created_by if provided and not already set
        if created_by and getattr(li, 'created_by_id', None) is None:
            li.created_by = created_by
            changed = True
        for fld, val in [
            ('tag', tag),
            ('title', _trunc(title)),
            ('subtitle', _trunc(subtitle)),
            ('contact_email', contact_email),
            ('contact_phone', contact_phone),
            ('notes', "\n".join(notes) if notes else ""),
        ]:
            if getattr(li, fld) != val:
                setattr(li, fld, val)
                changed = True
        if not li.active:
            li.active = True
            changed = True
        if changed:
            li.save(update_fields=['tag', 'title', 'subtitle', 'contact_email', 'contact_phone', 'active', 'updated_at','notes','created_by'])
    return li

# -------------------------
# OnboardingData -> Lead
# -------------------------
@receiver(post_save, sender=OnboardingData, dispatch_uid="leads.lead_from_onboarding.v1")
def lead_from_onboarding(sender, instance: OnboardingData, created, **kwargs):
    """
    Only create/upsert a lead for onboarding when the user reaches the final step of the onboarding flow.
    Final step threshold can be configured with settings.ONBOARDING_FINAL_STEP (default: 3).
    When creating the lead for the final record, archive older onboarding leads for the same client/email/user.
    """
    # Skip creating Brand Owner onboarding leads when this is a Factory/Manufacturer flow
    try:
        ft = (getattr(instance, 'flow_type', '') or '').strip().lower()
    except Exception:
        ft = ''
    if ft in {"factory", "manufacturer", "fo", "factory_owner", "factoryowner"}:
        return
    # Determine final step from settings (default 3)
    final_step = getattr(settings, 'ONBOARDING_FINAL_STEP', 2)

    # If no step info or step is less than final, do nothing
    try:
        step_val = int(getattr(instance, 'step', 0) or 0)
        if step_val < int(final_step):
            return
    except Exception:
        # If step can't be interpreted, conservatively proceed to create a lead
        pass

    # Note: Keep one LeadItem per OnboardingData row (one lead per "envelope").
    # Do not repoint older leads to the newest onboarding row, because that would merge
    # multiple onboarding envelopes into a single lead and hide prior inquiries.

    title = f"BO-{instance.origination_source} Lead: {instance.product_name or 'Unnamed Product'}"
    bits = []
    if instance.company_name: bits.append(instance.company_name)
    if instance.quantity: bits.append(f"qty {instance.quantity}")
    if instance.location: bits.append(instance.location)

    # Safely incorporate onboarding answers: transform dict -> short readable string
    details = getRequirementDetailsForOnboardingFromAnswers(instance)
    summary_parts = []
    if details:
        if isinstance(details, dict):
            # Pick a few helpful keys for the subtitle and ignore empty values
            summary_keys = (
                'product_name',
                'product_category',
                'matched_categories',
                'matched_subcategories',
                'quantity',
                'location',
                'timeline',
                'custom_category_text',
                'custom_subcategory_text',
                'source_route',
                'origination_source',
                'additional_details',
            )
            for k in summary_keys:
                v = details.get(k)
                if v:
                    label = {
                        'matched_categories': 'Matched categories',
                        'matched_subcategories': 'Matched subcategories',
                        'custom_category_text': 'Custom category/subcategory requested',
                        'custom_subcategory_text': 'Custom subcategory requested',
                    }.get(k, k)
                    summary_parts.append(f"{label}: {v}")

    # Add origination source to summary parts
    if getattr(instance, 'origination_source', None):
        summary_parts.append(f"Source: {instance.origination_source}")

    history = list(getattr(instance, "requirements_history", []) or [])
    history_count = len(history)
    if history_count > 1:
        bits.append(f"{history_count} entries")
        summaries = []
        for entry in history[-5:]:
            product_name = (entry.get("product_name") or "").strip()
            product_category = (entry.get("product_category") or "").strip()
            quantity = (entry.get("quantity") or "").strip()
            timeline = (entry.get("timeline") or "").strip()

            parts = []
            if product_name:
                parts.append(product_name)
            if product_category and product_category.lower() != product_name.lower():
                parts.append(product_category)
            if quantity:
                parts.append(f"qty {quantity}")
            if timeline:
                parts.append(timeline)

            if parts:
                summaries.append("+ " + " — ".join(parts))
        if summaries:
            summary_parts = summaries + summary_parts

    subtitle = " · ".join(bits) or (instance.product_category or "")
    upsert_lead_for_source(
        instance,
        tag='onboarding',
        title=title,
        subtitle=subtitle,
        contact_email=instance.email,
        contact_phone=instance.mobile,
        default_priority=2,
        notes=summary_parts if summary_parts else None,
        created_by=getattr(instance, 'user', None),

    )

    # Immediately trigger Case creation via existing pipeline (idempotent)
    try:
        kwargs_signal = {"onboarding_id": instance.id}
        if getattr(instance, 'user_id', None):
            kwargs_signal["user_id"] = instance.user_id
        # user_onboarded.send(sender=sender, **kwargs_signal)
        create_onboarding_flow(user=getattr(instance, 'user', None), user_id=getattr(instance, 'user_id', None), onboarding_id=instance.id)
    except Exception:
        logger.exception("Failed dispatching user_onboarded from OnboardingData post_save")


# -------------------------
# Case -> Lead (and archive OD lead)
# -------------------------
@receiver(post_save, sender=Case, dispatch_uid="leads.lead_from_case.v1")
def lead_from_case(sender, instance: Case, created, **kwargs):
    bo = getattr(instance, 'brand_owner', None)
    title = f"Case {getattr(instance, 'id', 'unknown')}: {instance.name or 'Unnamed Case'}"
    bits = []
    if bo and getattr(bo, 'name', None): bits.append(bo.name)
    if instance.quantity: bits.append(f"qty {instance.quantity}")
    if instance.category: bits.append(instance.category)

    # Ensure `details` is always defined (avoid UnboundLocalError).
    try:
        details = getRequirementDetailsForCaseFromAnswers(instance) or []
    except Exception:
        details = []

    subtitle = " · ".join(bits)

    li = upsert_lead_for_source(
        instance,
        tag='case',
        title=title,
        subtitle=subtitle,
        contact_email=getattr(bo, 'contact_email', None) if bo else None,
        contact_phone=getattr(bo, 'contact_phone', None) if bo else None,
        default_priority=1 if getattr(instance, 'category', None) in ('npd_with', 'onboarding') else 2,
        notes=details if details else None,
        created_by=getattr(getattr(instance, 'brand_owner', None), 'user', None),
    )



    # Archive the most recent OnboardingData lead for the same user (prevents duplicates)
    # try:
    #     from marketing.models import OnboardingData
    #     user_id = getattr(bo, 'user_id', None)
    #     if user_id:
    #         od = OnboardingData.objects.filter(user_id=user_id).order_by('-id').first()
    #         if od:
    #             ct = ContentType.objects.get_for_model(OnboardingData)
    #             LeadItem.objects.filter(source_ct=ct, source_id=od.id, active=True).update(active=True)
    # except Exception:
    #     # Silent fail: never block Case save
    #     pass

# -------------------------
# ContactSubmission -> Lead
# -------------------------
@receiver(post_save, sender=ContactSubmission)
def lead_from_contact(sender, instance: ContactSubmission, created, **kwargs):
    title = "Contact Form Query"
    msg = getattr(instance, 'message', '') or ''
    subtitle = _trunc(msg, 120)
    upsert_lead_for_source(
        instance,
        tag='contact',
        title=title,
        subtitle=subtitle,
        contact_email=getattr(instance, 'email', None),
        contact_phone=getattr(instance, 'phone', None),
        default_priority=3
    )

# -------------------------
# WaitlistEntry -> Lead
# -------------------------
@receiver(post_save, sender=WaitlistEntry)
def lead_from_waitlist(sender, instance: WaitlistEntry, created, **kwargs):
    title = "Waitlist Signup"
    subtitle = (instance.email or '') + (f" · {getattr(instance, 'contact_number', '')}" if getattr(instance, 'contact_number', None) else '')
    upsert_lead_for_source(
        instance,
        tag='waitlist',
        title=title,
        subtitle=subtitle,
        contact_email=getattr(instance, 'email', None),
        contact_phone=getattr(instance, 'contact_number', None),
        default_priority=3
    )

# -------------------------
# BrandOwner (registration) -> Lead
# -------------------------
@receiver(post_save, sender=BrandOwner)
def lead_from_brand_owner(sender, instance: BrandOwner, created, **kwargs):
    # Treat creation/update as (re)surfacing a "registration" lead
    title = f"Brand Owner Registered: {instance.name or 'Unnamed'}"
    subtitle = " · ".join(filter(None, [
        getattr(instance, 'contact_email', None),
        getattr(instance, 'contact_phone', None),
    ]))
    upsert_lead_for_source(
        instance,
        tag='brand_owner_reg',
        title=title,
        subtitle=subtitle,
        contact_email=getattr(instance, 'contact_email', None),
        contact_phone=getattr(instance, 'contact_phone', None),
        default_priority=2,
        created_by=getattr(instance, 'user', None),
    )

# -------------------------
# FactoryOwner (registration) -> Lead
# -------------------------
@receiver(post_save, sender=FactoryOwner)
def lead_from_factory_owner(sender, instance: FactoryOwner, created, **kwargs):
    title = f"Factory Owner Registered: {instance.name or 'Unnamed'}"
    subtitle = " · ".join(filter(None, [
        getattr(instance, 'contact_email', None),
        getattr(instance, 'contact_phone', None),
    ]))
    upsert_lead_for_source(
        instance,
        tag='factory_owner_reg',
        title=title,
        subtitle=subtitle,
        contact_email=getattr(instance, 'contact_email', None),
        contact_phone=getattr(instance, 'contact_phone', None),
        default_priority=2,
        created_by=getattr(instance, 'user', None),
    )

# -------------------------
# Brand -> Lead (brand registered/added)
# -------------------------
@receiver(post_save, sender=Brand)
def lead_from_brand(sender, instance: Brand, created, **kwargs):
    title = f"Brand: {getattr(instance, 'name', '') or 'Unnamed'}"
    bits = []
    if getattr(instance, 'country', None): bits.append(instance.country)
    if getattr(instance, 'website', None): bits.append(instance.website)
    subtitle = " · ".join(bits)
    upsert_lead_for_source(
        instance,
        tag='brand',
        title=title,
        subtitle=subtitle,
        contact_email=getattr(instance, 'director_email', None) or getattr(instance, 'poc_email', None),
        contact_phone=getattr(instance, 'director_number', None) or getattr(instance, 'poc_number', None),
        default_priority=3
    )

# -------------------------
# Factory -> Lead (factory registered/added)
# -------------------------
@receiver(post_save, sender=Factory)
def lead_from_factory(sender, instance: Factory, created, **kwargs):
    title = f"Factory: {getattr(instance, 'name', '') or 'Unnamed'}"
    bits = []
    if getattr(instance, 'type_of_products', None): bits.append(instance.type_of_products)
    if getattr(instance, 'capacity', None): bits.append(f"cap {instance.capacity}")
    subtitle = " · ".join(bits)
    notes = []
    category_names = list(instance.categories.values_list('name', flat=True))
    subcategory_names = list(instance.subcategories.values_list('name', flat=True))
    if category_names:
        notes.append(f"Matched categories: {', '.join(category_names)}")
    if subcategory_names:
        notes.append(f"Matched subcategories: {', '.join(subcategory_names)}")
    if getattr(instance, 'type_of_products', None):
        notes.append(f"Also wanted to add: {instance.type_of_products}")
    # Prefer the factory owner's user as creator by default; specific views may override
    creator = None
    try:
        fo = getattr(instance, 'factory_owner', None)
        creator = getattr(fo, 'user', None) if fo else None
    except Exception:
        creator = None

    upsert_lead_for_source(
        instance,
        tag='factory',
        title=title,
        subtitle=subtitle,
        contact_email=getattr(instance, 'email', None) or getattr(instance, 'poc_email', None) or getattr(instance, 'director_email', None),
        contact_phone=getattr(instance, 'phone', None) or getattr(instance, 'poc_number', None) or getattr(instance, 'director_phone', None),
        default_priority=3,
        notes=notes,
        created_by=creator,
    )

@receiver(post_save, sender=LeadItem)
def assign_lead_owner_to_case_ams(sender, instance: LeadItem, created, **kwargs):
    """
    Case assignment is now managed explicitly from the workflow page.
    Lead ownership no longer mutates case viewers/assignees.
    """
    return

# ---------- helpers ----------

def _timestamp():
    # ISO-ish but short; adjust to your liking
    return timezone.now().strftime("%Y-%m-%d %H:%M")

def _safe_str(v):
    if v is None:
        return "None"
    try:
        return str(v)
    except Exception:
        return repr(v)

def _get_or_create_lead_for(source_obj, *, tag, title, subtitle):
    """
    Get or create a LeadItem for (source_ct, source_id) and the given tag.
    If exists, it doesn't overwrite existing title/subtitle unless we need to.
    """
    ct = ContentType.objects.get_for_model(source_obj.__class__)
    defaults = dict(
        tag=tag,
        title=title[:255],
        subtitle=subtitle[:255] if subtitle else "",
        priority=1,          # as requested: make them priority 1
        active=True,
        notes="",            # non-null safety
        status='new',        # safe default; your app may not use it here
    )
    li, created = LeadItem.objects.get_or_create(
        source_ct=ct,
        source_id=source_obj.pk,
        defaults=defaults,
    )
    return li, created

def _append_note(li: LeadItem, line: str, *, force_subtitle: str | None = None, force_priority: int | None = 1, keep_last:int = 100):
    """
    Append a single line to the notes with a timestamp.
    Also set priority=1 and/or subtitle if requested; keep last N lines for bounded growth.
    """
    try:
        existing = (li.notes or "").strip()
        stamped = f"[{_timestamp()}] {line}".strip()
        if existing:
            new_notes = existing.splitlines() + [stamped]
        else:
            new_notes = [stamped]
        # trim to last N
        if keep_last and len(new_notes) > keep_last:
            new_notes = new_notes[-keep_last:]

        if force_subtitle is not None:
            li.subtitle = (force_subtitle or "")[:255]
        if force_priority is not None:
            li.priority = int(force_priority)
        li.active = True
        li.notes = "\n".join(new_notes)
        li.save(update_fields=["subtitle", "priority", "active", "notes", "updated_at"])
    except Exception:
        logger.exception("Failed to append note to LeadItem(id=%s)", getattr(li, "id", None))

def _ensure_lead_and_note(source_obj, *, tag, title, subtitle, note_line, force_subtitle=None):
    li, _ = _get_or_create_lead_for(source_obj, tag=tag, title=title, subtitle=subtitle)
    _append_note(li, note_line, force_subtitle=force_subtitle, force_priority=1)

# ============================================================
#               Bid change tracking
# ============================================================

_BID_TRACK_FIELDS = ("status", "quote", "quote_bo")

@receiver(pre_save, sender=Bid)
def _bid_presave_delta(sender, instance: Bid, **kwargs):
    """
    Compute deltas before save so post_save can write lead notes.
    """
    try:
        if not instance.pk:
            instance._delta_bid = {"created": True}
            return
        prev = Bid.objects.get(pk=instance.pk)
        changes = {}
        for f in _BID_TRACK_FIELDS:
            old = getattr(prev, f, None)
            new = getattr(instance, f, None)
            if old != new:
                changes[f] = (old, new)
        if changes:
            instance._delta_bid = {"created": False, "changes": changes}
    except Bid.DoesNotExist:
        instance._delta_bid = {"created": True}
    except Exception:
        logger.exception("Error computing Bid delta")
        instance._delta_bid = {}

@receiver(post_save, sender=Bid)
def _bid_postsave_lead(sender, instance: Bid, created, **kwargs):
    """
    Create/refresh lead for this Bid and append change notes.
    Subtitle logic:
      - If price changed -> "Price changed"
      - Else if status changed -> "Status changed"
    Always priority=1 on change.
    """
    try:
        case_id = getattr(instance, "case_id", None)
        factory_name = getattr(instance.factory, "name", None) if instance.factory_id else None
        title = (
            f"Bid {instance.id} for Case {case_id} ({factory_name or 'Factory ?'})"
            if case_id
            else f"Bid {instance.id} ({factory_name or 'Factory ?'})"
        )
        base_subtitle = f"{factory_name or 'Factory ?'}"

        # Always ensure a lead exists on creation
        li, li_created = _get_or_create_lead_for(
            instance, tag="bid", title=title, subtitle=base_subtitle
        )
        if created or (getattr(instance, "_delta_bid", None) or {}).get("created"):
            _append_note(
                li,
                f"Bid created (Factory {factory_name or '?'} / ID {getattr(instance.factory, 'id', 'N/A')}): status={instance.status}, quote={_safe_str(instance.quote)}, quote_bo={_safe_str(instance.quote_bo)}",
                force_subtitle="Created",
                force_priority=1,
            )
            return

        changes = (getattr(instance, "_delta_bid", {}) or {}).get("changes", {})
        if not changes:
            return  # nothing to do

        # Build human line(s)
        parts = []
        force_subtitle = None
        if "quote" in changes or "quote_bo" in changes:
            force_subtitle = "Price changed"
        elif "status" in changes:
            force_subtitle = "Status changed"

        for field, (old, new) in changes.items():
            parts.append(f"{field}: {_safe_str(old)} → {_safe_str(new)}")

        line = f"Bid updated (Factory {factory_name or '?'} / ID {getattr(instance.factory, 'id', 'N/A')}) — {', '.join(parts)}"
        _append_note(li, line, force_subtitle=force_subtitle, force_priority=1)

    except Exception:
        logger.exception("Failed handling Bid post_save for lead note")

# ============================================================
#           AutoBidConfig & Parameter values tracking
# ============================================================

_AUTOBID_TRACK_FIELDS = ("enabled", "approved_by_am", "config_type", "facility_line_id", "subcategory_id", "version", "name")

@receiver(pre_save, sender=AutoBidConfig)
def _autobid_presave_delta(sender, instance: AutoBidConfig, **kwargs):
    try:
        if not instance.pk:
            instance._delta_autobid = {"created": True}
            return
        prev = AutoBidConfig.objects.get(pk=instance.pk)
        changes = {}
        for f in _AUTOBID_TRACK_FIELDS:
            old = getattr(prev, f, None)
            new = getattr(instance, f, None)
            if old != new:
                changes[f] = (old, new)
        if changes:
            instance._delta_autobid = {"created": False, "changes": changes}
    except AutoBidConfig.DoesNotExist:
        instance._delta_autobid = {"created": True}
    except Exception:
        logger.exception("Error computing AutoBidConfig delta")
        instance._delta_autobid = {}

@receiver(post_save, sender=AutoBidConfig)
def _autobid_postsave_lead(sender, instance: AutoBidConfig, created, **kwargs):
    """
    Ensure an 'autobid' lead exists for every AutoBidConfig and append change notes.
    Subtitle: 'Config changed' on changes, 'Created' on first create.
    """
    try:
        factory_name = getattr(instance.factory, "name", None) if instance.factory_id else None
        subcat_name = getattr(instance.subcategory, "name", None) if instance.subcategory_id else None
        title = f"AutoBid: {factory_name or 'Factory ?'} / {subcat_name or 'Subcategory ?'}"
        subtitle = f"{instance.config_type} · v{getattr(instance,'version',1)}"

        li, li_created = _get_or_create_lead_for(instance, tag="autobid", title=title, subtitle=subtitle)

        delta = getattr(instance, "_delta_autobid", {}) or {}
        if created or delta.get("created"):
            _append_note(li, f"AutoBidConfig created: enabled={instance.enabled}, approved_by_am={instance.approved_by_am}, type={instance.config_type}, version={getattr(instance,'version',1)}", force_subtitle="Created", force_priority=1)
            return

        changes = delta.get("changes", {})
        if not changes:
            return

        parts = []
        for field, (old, new) in changes.items():
            parts.append(f"{field}: {_safe_str(old)} → {_safe_str(new)}")

        _append_note(li, f"Config updated — {', '.join(parts)}", force_subtitle="Config changed", force_priority=1)

    except Exception:
        logger.exception("Failed handling AutoBidConfig post_save for lead note")

# Track changes to individual parameter values under a config

_PARAM_TRACK_FIELDS = ("decimal_value", "text_value", "bool_value", "parameter_definition_id")

@receiver(pre_save, sender=AutoBidConfigParameterValue)
def _param_presave_delta(sender, instance: AutoBidConfigParameterValue, **kwargs):
    try:
        if not instance.pk:
            instance._delta_param = {"created": True}
            return
        prev = AutoBidConfigParameterValue.objects.get(pk=instance.pk)
        changes = {}
        for f in _PARAM_TRACK_FIELDS:
            old = getattr(prev, f, None)
            new = getattr(instance, f, None)
            if old != new:
                changes[f] = (old, new)
        if changes:
            instance._delta_param = {"created": False, "changes": changes}
    except AutoBidConfigParameterValue.DoesNotExist:
        instance._delta_param = {"created": True}
    except Exception:
        logger.exception("Error computing AutoBidConfigParameterValue delta")
        instance._delta_param = {}

@receiver(post_save, sender=AutoBidConfigParameterValue)
def _param_postsave_lead(sender, instance: AutoBidConfigParameterValue, created, **kwargs):
    """
    Whenever a parameter value is created/updated, log a note under the parent AutoBidConfig lead.
    """
    try:
        cfg = instance.auto_bid_config
        if not cfg_id_ok(cfg):
            return

        # Title/subtitle mirror the parent handler so we group notes consistently
        factory_name = getattr(cfg.factory, "name", None) if cfg.factory_id else None
        subcat_name = getattr(cfg.subcategory, "name", None) if cfg.subcategory_id else None
        title = f"AutoBid: {factory_name or 'Factory ?'} / {subcat_name or 'Subcategory ?'}"
        subtitle = f"{cfg.config_type} · v{getattr(cfg,'version',1)}"

        li, li_created = _get_or_create_lead_for(cfg, tag="autobid", title=title, subtitle=subtitle)

        pd = getattr(instance, "parameter_definition", None)
        pd_name = getattr(pd, "name", f"param#{getattr(pd,'id', 'unknown')}")

        delta = getattr(instance, "_delta_param", {}) or {}
        if created or delta.get("created"):
            val = instance.decimal_value if instance.decimal_value is not None else instance.text_value if instance.text_value not in (None, "") else instance.bool_value
            _append_note(li, f"Parameter added — {pd_name} = {_safe_str(val)}", force_subtitle="Config changed", force_priority=1)
            return

        changes = delta.get("changes", {})
        if not changes:
            return

        # Prefer showing the actual value change
        if any(k in changes for k in ("decimal_value", "text_value", "bool_value")):
            old = changes.get("decimal_value", changes.get("text_value", changes.get("bool_value", (None, None))))[0]
            new = changes.get("decimal_value", changes.get("text_value", changes.get("bool_value", (None, None))))[1]
            line = f"Parameter updated — {pd_name}: {_safe_str(old)} → {_safe_str(new)}"
        else:
            # fallback generic
            parts = [f"{k}: {_safe_str(o)} → {_safe_str(n)}" for k,(o,n) in changes.items()]
            line = f"Parameter updated — {', '.join(parts)}"

        _append_note(li, line, force_subtitle="Config changed", force_priority=1)

    except Exception:
        logger.exception("Failed handling AutoBidConfigParameterValue post_save for lead note")

def cfg_id_ok(cfg):
    try:
        return bool(getattr(cfg, "id", None))
    except Exception:
        return False

# --- Owner propagation between Case LeadItems and Bid LeadItems ---

from django.db.models.signals import post_save
from django.utils import timezone
from django.contrib.contenttypes.models import ContentType
from django.dispatch import receiver

from leads.models import LeadItem
from supply.models import Bid
from case.models import Case

def _ct(model_cls):
    return ContentType.objects.get_for_model(model_cls)

@receiver(post_save, sender=LeadItem)
def propagate_owner_from_case_to_bids(sender, instance: LeadItem, created, update_fields=None, **kwargs):
    """
    When a Case LeadItem's owner is set/changed, push the same owner to all Bid LeadItems
    belonging to that Case.
    """
    try:
        # Act only on Case-tagged LeadItems whose source is Case
        if instance.tag != 'case':
            return
        if not instance.source_ct_id or not instance.source_id:
            return
        if instance.source_ct_id != _ct(Case).id:
            return

        # If this was an update and 'owner' wasn't touched, skip
        if not created and update_fields is not None and 'owner' not in update_fields:
            return

        owner_id = getattr(instance, 'owner_id', None)
        if owner_id is None:
            return  # nothing to propagate

        case_id = instance.source_id

        # Find all Bid ids under this case
        bid_ids = list(Bid.objects.filter(case_id=case_id).values_list('id', flat=True))
        if not bid_ids:
            return

        # Update Bid LeadItems whose owner differs (bulk; no post_save fired)
        LeadItem.objects.filter(
            source_ct_id=_ct(Bid).id,
            source_id__in=bid_ids
        ).exclude(owner_id=owner_id).update(owner_id=owner_id, updated_at=timezone.now())

    except Exception:
        # Fail-safe: never break requests/commands because of propagation errors
        import logging
        logging.getLogger(__name__).exception(
            "Owner propagation (case->bids) failed for LeadItem id=%s",
            getattr(instance, 'id', None),
        )


@receiver(post_save, sender=LeadItem)
def set_bid_owner_from_case_on_creation(sender, instance: LeadItem, created, **kwargs):
    """
    When a Bid LeadItem is created, if its related Case LeadItem already has an owner,
    set the Bid LeadItem's owner to match.
    """
    try:
        if instance.tag != 'bid':
            return
        if not created:
            return
        if not instance.source_ct_id or not instance.source_id:
            return
        if instance.source_ct_id != _ct(Bid).id:
            return

        # Get bid to access its case
        try:
            bid = Bid.objects.only('id', 'case_id').get(id=instance.source_id)
        except Bid.DoesNotExist:
            return

        if not bid.case_id:
            return

        # Find the Case LeadItem (prefer active)
        case_lead = (
            LeadItem.objects
            .filter(source_ct_id=_ct(Case).id, source_id=bid.case_id)
            .order_by('-active', '-id')
            .first()
        )
        if not case_lead or not case_lead.owner_id:
            return

        # Only update if different/missing
        if instance.owner_id != case_lead.owner_id:
            LeadItem.objects.filter(id=instance.id).update(
                owner_id=case_lead.owner_id, updated_at=timezone.now()
            )

    except Exception:
        import logging
        logging.getLogger(__name__).exception(
            "Owner sync (bid creation) failed for LeadItem id=%s",
            getattr(instance, 'id', None),
        )
