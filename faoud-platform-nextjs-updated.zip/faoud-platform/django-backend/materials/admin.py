from django.contrib import admin
from simple_history.admin import SimpleHistoryAdmin
from .models import  BillOfMaterials, BillOfMaterialsPackagingMaterial, BillOfMaterialsRawMaterial, RawMaterial

@admin.register(RawMaterial)
class RawMaterialAdmin(SimpleHistoryAdmin):
    list_display = ('name', 'price')
    search_fields = ('name', )
    list_filter = ('price',)

from django.contrib import admin
from simple_history.admin import SimpleHistoryAdmin
from .models import PackagingMaterial

@admin.register(PackagingMaterial)
class PackagingMaterialAdmin(SimpleHistoryAdmin):
    list_display = ('name', 'price')
    search_fields = ('name', )
    list_filter = ('price',)

admin.site.register(BillOfMaterials)

admin.site.register(BillOfMaterialsPackagingMaterial)

admin.site.register(BillOfMaterialsRawMaterial)