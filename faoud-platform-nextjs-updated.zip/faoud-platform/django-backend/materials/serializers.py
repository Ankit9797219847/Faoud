
from rest_framework import serializers

from supply.models import PMSupplier, RMSupplier

from utils.serializers import AddressSerializer
from .models import BillOfMaterials, BillOfMaterialsPackagingMaterial, BillOfMaterialsRawMaterial, RawMaterial, PackagingMaterial
from simple_history.utils import update_change_reason
 # Ensure this exists




class RMSupplierSerializer(serializers.ModelSerializer):
    address = AddressSerializer(many=True, read_only=True)

    class Meta:
        model = RMSupplier
        fields = ['id', 'name', 'address']


class PMSupplierSerializer(serializers.ModelSerializer):
    address = AddressSerializer(many=True, read_only=True)

    class Meta:
        model = PMSupplier
        fields = ['id', 'name', 'address']






class HistoricalRawMaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = RawMaterial.history.model  # Historical model
        fields = ['history_id', 'history_date', 'history_user', 'history_change_reason', 'price']

class RawMaterialSerializer(serializers.ModelSerializer):
    suppliers = RMSupplierSerializer(many=True, read_only=True)  # Read-only for the detailed view of suppliers
    supplier_ids = serializers.PrimaryKeyRelatedField(
        many=True, queryset=RMSupplier.objects.all(), write_only=True, source='suppliers'
    )
    price_history = HistoricalRawMaterialSerializer(many=True, read_only=True, source='history')

    class Meta:
        model = RawMaterial
        fields = ['id', 'name', 'iupac_name', 'price', 'suppliers', 'supplier_ids', 'price_history']
        read_only_fields = ['price_history']

    def update(self, instance, validated_data):
        # Capture the reason for change if provided
        change_reason = self.context['request'].data.get('change_reason', '')
        new_price = validated_data.get('price', instance.price)
        
        if new_price != instance.price:
            # Update the price
            instance.price = new_price
            instance.save()
            # Update change reason
            update_change_reason(instance, change_reason)
        
        # Update other fields
        instance.id_name = validated_data.get('id_name', instance.id_name)
        instance.name = validated_data.get('name', instance.name)
        instance.iupac_name = validated_data.get('iupac_name', instance.iupac_name)
        instance.save()

        # Update suppliers using the validated supplier_ids field
        suppliers = validated_data.get('suppliers', None)
        if suppliers is not None:
            instance.suppliers.set(suppliers)  # Update the suppliers' relation
        
        return instance


class HistoricalPackagingMaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = PackagingMaterial.history.model  # Historical model
        fields = ['history_id', 'history_date', 'history_user', 'history_change_reason', 'price']

class PackagingMaterialSerializer(serializers.ModelSerializer):
    suppliers = PMSupplierSerializer(many=True, read_only=True)  # Read-only supplier details for the detailed view
    supplier_ids = serializers.PrimaryKeyRelatedField(
        many=True, queryset=PMSupplier.objects.all(), write_only=True, source='suppliers'
    )
    price_history = HistoricalPackagingMaterialSerializer(many=True, read_only=True, source='history')

    class Meta:
        model = PackagingMaterial
        fields = ['id', 'name', 'current_status', 'price', 'old_price', 'latest_price', 'material_shape', 'suppliers', 'supplier_ids', 'price_history']
        read_only_fields = ['price_history', 'old_price', 'latest_price']

    def update(self, instance, validated_data):
        # Capture the reason for change if provided
        change_reason = self.context['request'].data.get('change_reason', '')

        # Update price and old price if necessary
        new_price = validated_data.get('price', instance.price)
        if new_price != instance.price:
            # Save old price before updating
            instance.old_price = instance.price
            instance.price = new_price
            instance.latest_price = new_price
            instance.save()
            # Update change reason for history tracking
            update_change_reason(instance, change_reason)

        # Update other fields in the PackagingMaterial model
        instance.name = validated_data.get('name', instance.name)
        instance.current_status = validated_data.get('current_status', instance.current_status)
        instance.material_shape = validated_data.get('material_shape', instance.material_shape)
        instance.save()

        # Update suppliers using the validated supplier_ids field
        suppliers = validated_data.get('suppliers', None)
        if suppliers is not None:
            instance.suppliers.set(suppliers)  # Update the suppliers' relation

        return instance



from rest_framework import serializers
from .models import BillOfMaterials, BillOfMaterialsRawMaterial, BillOfMaterialsPackagingMaterial

class BillOfMaterialsRawMaterialSerializer(serializers.ModelSerializer):
    raw_material_name = serializers.CharField(source='raw_material.name', read_only=True)
    total_cost = serializers.SerializerMethodField()

    class Meta:
        model = BillOfMaterialsRawMaterial
        fields = ['id','raw_material_name', 'quantity', 'price_per_unit', 'total_cost']

    def get_total_cost(self, obj):
        # Access quantity and price_per_unit from the obj instance
        return obj.quantity * obj.price_per_unit

class BillOfMaterialsPackagingMaterialSerializer(serializers.ModelSerializer):
    packaging_material_name = serializers.CharField(source='packaging_material.name', read_only=True)
    total_cost = serializers.SerializerMethodField()

    class Meta:
        model = BillOfMaterialsPackagingMaterial
        fields = ['id','packaging_material_name', 'quantity', 'price_per_unit', 'total_cost']

    def get_total_cost(self, obj):
        # Access quantity and price_per_unit from the obj instance
        return obj.quantity * obj.price_per_unit

class BillOfMaterialsSerializer(serializers.ModelSerializer):
    raw_materials = BillOfMaterialsRawMaterialSerializer(source='billofmaterialsrawmaterial_set', many=True, read_only=True)
    packaging_materials = BillOfMaterialsPackagingMaterialSerializer(source='billofmaterialspackagingmaterial_set', many=True, read_only=True)
    total_cost = serializers.SerializerMethodField()

    class Meta:
        model = BillOfMaterials
        fields = ['product', 'raw_materials', 'packaging_materials', 'total_cost']

    def get_total_cost(self, obj):
        # Calculate total cost by summing up the total costs of raw materials and packaging materials
        total_raw_material_cost = sum([rm.total_cost for rm in obj.billofmaterialsrawmaterial_set.all()])
        total_packaging_material_cost = sum([pm.total_cost for pm in obj.billofmaterialspackagingmaterial_set.all()])
        return total_raw_material_cost + total_packaging_material_cost
