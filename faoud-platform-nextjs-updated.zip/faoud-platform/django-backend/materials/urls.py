from django.urls import path, include
from rest_framework.routers import DefaultRouter

from materials.views import BillOfMaterialsViewSet, BrandOwnerPackagingMaterialViewSet, BrandOwnerRawMaterialViewSet, PMSupplierViewSet, PackagingMaterialViewSet, RMSupplierViewSet, RawMaterialViewSet


router = DefaultRouter()
router.register(r'rm-suppliers', RMSupplierViewSet, basename='rm-supplier')
router.register(r'pm-suppliers', PMSupplierViewSet, basename='pm-supplier')
router.register(r'raw-materials', RawMaterialViewSet, basename='raw-material')
router.register(r'packaging-materials', PackagingMaterialViewSet, basename='packaging-material')

# Brand Owner specific routes
router.register(r'brand-owner/raw-materials', BrandOwnerRawMaterialViewSet, basename='brandowner-raw-material')
router.register(r'brand-owner/packaging-materials', BrandOwnerPackagingMaterialViewSet, basename='brandowner-packaging-material')


urlpatterns = [
    path('', include(router.urls)),
        path('cases/<int:case_id>/bom/', BillOfMaterialsViewSet.as_view({'get': 'get_bom_by_case', 'post': 'create', 'put': 'update_by_case'})),
]
