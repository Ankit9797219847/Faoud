from django.db import models
from simple_history.models import HistoricalRecords

from user.models import BrandOwner

class RawMaterial(models.Model):
    name = models.CharField(max_length=100, default='Raw Material')
    iupac_name = models.CharField(max_length=255, blank=True, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    old_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    latest_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    suppliers = models.ManyToManyField('supply.RMSupplier', related_name='raw_materials', blank=True)
    history = HistoricalRecords()


    def __str__(self):
        return self.name


class PackagingMaterial(models.Model):
    name = models.CharField(max_length=100, default='Packaging Material')
    current_status = models.TextField(blank=True, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    old_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    latest_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    material_shape = models.CharField(max_length=100, default='Material Shape')
    suppliers = models.ManyToManyField('supply.PMSupplier', related_name='packaging_materials', blank=True)
    history = HistoricalRecords()

    def __str__(self):
        return self.name
    


from django.db import models
from materials.models import RawMaterial, PackagingMaterial


class BillOfMaterials(models.Model):
    product = models.ForeignKey('product.Product', on_delete=models.CASCADE)
    brand_owner = models.ForeignKey(BrandOwner, on_delete=models.CASCADE)
    raw_materials = models.ManyToManyField(RawMaterial, through='BillOfMaterialsRawMaterial')
    packaging_materials = models.ManyToManyField(PackagingMaterial, through='BillOfMaterialsPackagingMaterial')
    total_cost = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self):
        return f"BOM for {self.product.name}"

class BillOfMaterialsRawMaterial(models.Model):
    bom = models.ForeignKey(BillOfMaterials, on_delete=models.CASCADE)
    raw_material = models.ForeignKey(RawMaterial, on_delete=models.CASCADE)
    quantity = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    price_per_unit = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    @property
    def total_cost(self):
        return self.quantity * self.price_per_unit

class BillOfMaterialsPackagingMaterial(models.Model):
    bom = models.ForeignKey(BillOfMaterials, on_delete=models.CASCADE)
    packaging_material = models.ForeignKey(PackagingMaterial, on_delete=models.CASCADE)
    quantity = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    price_per_unit = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    @property
    def total_cost(self):
        return self.quantity * self.price_per_unit