from django.shortcuts import get_object_or_404
from rest_framework import viewsets, permissions

from case.models import Case
from product.models import Product, ProductPackagingMaterial, ProductRawMaterial
from product.serializers import ProductPackagingMaterialSerializer, ProductRawMaterialSerializer
from supply.models import PMSupplier, RMSupplier
from user.permissions import IsAccountManager, IsBrandOwner
from .models import BillOfMaterials, BillOfMaterialsPackagingMaterial, BillOfMaterialsRawMaterial, RawMaterial, PackagingMaterial
from .serializers import (
    BillOfMaterialsSerializer,
    RawMaterialSerializer,
    PackagingMaterialSerializer,
    RMSupplierSerializer,
    PMSupplierSerializer,
)
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status

# Custom Permissions

class RMSupplierViewSet(viewsets.ModelViewSet):
    queryset = RMSupplier.objects.all()
    serializer_class = RMSupplierSerializer
    permission_classes = [permissions.IsAuthenticated, IsAccountManager]


class PMSupplierViewSet(viewsets.ModelViewSet):
    queryset = PMSupplier.objects.all()
    serializer_class = PMSupplierSerializer
    permission_classes = [permissions.IsAuthenticated, IsAccountManager]


class RawMaterialViewSet(viewsets.ModelViewSet):
    queryset = RawMaterial.objects.all()
    serializer_class = RawMaterialSerializer
    permission_classes = [IsAccountManager]

    def perform_create(self, serializer):
        print("Creating raw material with data:", serializer.validated_data)
        serializer.save()

    def perform_update(self, serializer):
        print("Updating raw material with data:", serializer.validated_data)
        serializer.save()


class PackagingMaterialViewSet(viewsets.ModelViewSet):
    queryset = PackagingMaterial.objects.all()
    serializer_class = PackagingMaterialSerializer
    permission_classes = [permissions.IsAuthenticated, IsAccountManager]

    def perform_create(self, serializer):
        serializer.save()

    def perform_update(self, serializer):
        serializer.save()


# Views for Brand Owners to view Raw Materials and Packaging Materials
class BrandOwnerRawMaterialViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = ProductRawMaterialSerializer
    permission_classes = [IsBrandOwner | IsAccountManager]

    def get_queryset(self):
        """
        Filters ProductRawMaterial based on the `case_id` passed from the frontend.
        """
        queryset = ProductRawMaterial.objects.all()

        case_id = self.request.query_params.get('case_id', None)
        
        if case_id:
            case = get_object_or_404(Case, id=case_id)

            # Get the product associated with the case
            product = case.product

            # Filter ProductRawMaterial by product or brand owner
            queryset = queryset.filter(product=product)
        
        return queryset

class BrandOwnerPackagingMaterialViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = ProductPackagingMaterialSerializer
    permission_classes = [permissions.IsAuthenticated, IsBrandOwner | IsAccountManager]

    def get_queryset(self):
        """
        Filters ProductPackagingMaterial based on the `case_id` passed from the frontend.
        """
        queryset = ProductPackagingMaterial.objects.all()

        case_id = self.request.query_params.get('case_id', None)
        
        if case_id:
            case = get_object_or_404(Case, id=case_id)

            # Get the product associated with the case
            product = case.product

            # Filter ProductPackagingMaterial by product
            queryset = queryset.filter(product=product)
        
        return queryset




# BILL OF MATERIAL
from rest_framework.decorators import action
from rest_framework.response import Response

from .serializers import BillOfMaterialsSerializer
from rest_framework import viewsets
from django.shortcuts import get_object_or_404

class BillOfMaterialsViewSet(viewsets.ModelViewSet):
    queryset = BillOfMaterials.objects.all()
    serializer_class = BillOfMaterialsSerializer

from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from .models import BillOfMaterials
from .serializers import BillOfMaterialsSerializer
from rest_framework import viewsets
from django.shortcuts import get_object_or_404

class BillOfMaterialsViewSet(viewsets.ModelViewSet):
    queryset = BillOfMaterials.objects.all()
    serializer_class = BillOfMaterialsSerializer

    @action(detail=False, methods=['get'], url_path='by-case/(?P<case_id>[^/.]+)')
    def get_bom_by_case(self, request, case_id=None):
        case = get_object_or_404(Case, id=case_id)
        product = case.product
        bom, created = BillOfMaterials.objects.get_or_create(product=product, brand_owner=case.brand_owner)

        # Fetch all raw materials and packaging materials related to the product
        raw_materials = ProductRawMaterial.objects.filter(product=product)
        packaging_materials = ProductPackagingMaterial.objects.filter(product=product)

        # Add new raw materials to BOM if they are not already added
        for raw_material in raw_materials:
            BillOfMaterialsRawMaterial.objects.get_or_create(
                bom=bom,
                raw_material=raw_material.raw_material,
                defaults={
                    'price_per_unit': raw_material.price
                }
            )

        # Add new packaging materials to BOM if they are not already added
        for packaging_material in packaging_materials:
            BillOfMaterialsPackagingMaterial.objects.get_or_create(
                bom=bom,
                packaging_material=packaging_material.packaging_material,
                defaults={
                    'price_per_unit': packaging_material.price
                }
            )

        # Recalculate total cost after ensuring new materials are added
        bom.total_cost = sum([brm.total_cost for brm in BillOfMaterialsRawMaterial.objects.filter(bom=bom)]) + \
                         sum([bpm.total_cost for bpm in BillOfMaterialsPackagingMaterial.objects.filter(bom=bom)])
        bom.save()

        # Serialize and return the BOM
        serializer = BillOfMaterialsSerializer(bom)
        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(detail=False, methods=['put'], url_path='by-case/(?P<case_id>[^/.]+)')
    def update_by_case(self, request, case_id=None):
        # Retrieve the case by case_id
        case = get_object_or_404(Case, id=case_id)

        # Get or create BOM for the case
        bom, created = BillOfMaterials.objects.get_or_create(
            product=case.product, 
            brand_owner=case.brand_owner
        )

        # Extract raw materials and packaging materials from the request
        raw_materials_data = request.data.get('raw_materials', [])
        packaging_materials_data = request.data.get('packaging_materials', [])

        # Update raw materials
        for rm_data in raw_materials_data:
            # Retrieve the BillOfMaterialsRawMaterial instance by ID
            bomprm = get_object_or_404(BillOfMaterialsRawMaterial, id=rm_data['id'])
            
            # Get the associated ProductRawMaterial by using the raw_material and the product
            product_raw_material = get_object_or_404(ProductRawMaterial, product=bom.product, raw_material=bomprm.raw_material)
            
            # Update or create the BillOfMaterialsRawMaterial
            BillOfMaterialsRawMaterial.objects.update_or_create(
                bom=bom,
                raw_material=product_raw_material.raw_material,
                defaults={
                    'quantity': rm_data['quantity'],
                    'price_per_unit': rm_data['price_per_unit']
                }
            )

        # Update packaging materials
        for pm_data in packaging_materials_data:
            # Retrieve the BillOfMaterialsPackagingMaterial instance by ID
            bom_ppm = get_object_or_404(BillOfMaterialsPackagingMaterial, id=pm_data['id'])
            
            # Retrieve the associated ProductPackagingMaterial by using the packaging_material from bom_ppm
            product_packaging_material = get_object_or_404(ProductPackagingMaterial, 
                                                        product=bom.product, 
                                                        packaging_material=bom_ppm.packaging_material)
            
            # Update or create the BillOfMaterialsPackagingMaterial
            BillOfMaterialsPackagingMaterial.objects.update_or_create(
                bom=bom,
                packaging_material=product_packaging_material.packaging_material,
                defaults={
                    'quantity': pm_data['quantity'],
                    'price_per_unit': pm_data['price_per_unit']
                }
            )

        # Recalculate total cost: Sum the costs from raw materials and packaging materials
        total_raw_material_cost = sum(
            rm.quantity * rm.price_per_unit
            for rm in bom.billofmaterialsrawmaterial_set.all()
        )
        total_packaging_material_cost = sum(
            pm.quantity * pm.price_per_unit
            for pm in bom.billofmaterialspackagingmaterial_set.all()
        )
        bom.total_cost = total_raw_material_cost + total_packaging_material_cost
        bom.save()

        # Serialize and return updated BOM
        serializer = BillOfMaterialsSerializer(bom)
        return Response(serializer.data, status=status.HTTP_200_OK)
