import os

environment = os.getenv('DJANGO_ENV', 'local')  # Default to 'local' if not set
print(f"DJANGO_ENV: {environment}")

if environment == 'production':
    print("Loading production settings")
    from .prod import *
elif environment == "test":
    print("Loading test settings")
    from .test import *
else:
    print("Loading local settings")
    from .local import *

