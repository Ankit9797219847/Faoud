from .base import *

# Production settings
DEBUG = False  # Set this to False in production
ALLOWED_HOSTS = env_list("DJANGO_ALLOWED_HOSTS", default=["api-p1.faoud.com"])

CELERY_BROKER_URL = os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0')
CELERY_RESULT_BACKEND = os.getenv('CELERY_RESULT_BACKEND', 'redis://localhost:6379/0')

# Production database configuration
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv("DB_NAME"),
        "USER": os.getenv("DB_USER"),
        "PASSWORD": os.getenv("DB_PASSWORD"),
        "HOST": os.getenv("DB_HOST", "your-production-host"),
        "PORT": os.getenv("DB_PORT", "5432"),
    }
}
STATICFILES_STORAGE = 'django.core.files.storage.FileSystemStorage'
# Static files configuration
STATIC_URL = '/static/'  # URL to use when referring to static files
STATIC_ROOT = '/home/ubuntu/shadow-api/shadow/static/' # Absolute path where static files are collected
STATICFILES_DIRS = []
# Media files configuration
DEFAULT_FILE_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'  # Use S3 for media storage
AWS_ACCESS_KEY_ID = os.getenv('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.getenv('AWS_SECRET_ACCESS_KEY')
AWS_STORAGE_BUCKET_NAME = os.getenv('AWS_STORAGE_BUCKET_NAME')
AWS_S3_REGION_NAME = os.getenv('AWS_S3_REGION_NAME')
AWS_S3_CUSTOM_DOMAIN = f'{AWS_STORAGE_BUCKET_NAME}.s3.amazonaws.com'
AWS_LOCATION = 'media'

MEDIA_URL = f'https://{AWS_S3_CUSTOM_DOMAIN}/{AWS_LOCATION}/'  # URL for media files

# Django's `STORAGES` configuration
STORAGES = {
    'default': {
        'BACKEND': 'storages.backends.s3boto3.S3Boto3Storage',
        'OPTIONS': {
            'access_key': AWS_ACCESS_KEY_ID,
            'secret_key': AWS_SECRET_ACCESS_KEY,
            'bucket_name': "shadow-frontend",
            'region_name': "us-east-1",
            'default_acl': None,
            'querystring_auth': False,
            'object_parameters': {'CacheControl': 'max-age=86400'},
            'location': AWS_LOCATION,  # S3 location for media files
        },
    },
    'staticfiles': {
        "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        'OPTIONS': {
            "base_url": STATIC_URL,  
        },
    },
}

# Additional security settings
SECRET_KEY = required_env("DJANGO_SECRET_KEY")
X_FRAME_OPTIONS = "DENY"

CORS_ALLOWED_ORIGINS = env_list(
    "CORS_ALLOWED_ORIGINS",
    default=["https://faoud.com", "https://www.faoud.com"],
)
CSRF_TRUSTED_ORIGINS = env_list(
    "CSRF_TRUSTED_ORIGINS",
    default=["https://api-p1.faoud.com", "https://admin.faoud.com", "https://www.faoud.com"],
)


RAZORPAY_KEY_ID = os.getenv('RAZORPAY_KEY_ID')
RAZORPAY_KEY_SECRET = os.getenv('RAZORPAY_KEY_SECRET')

EMAIL_BACKEND = os.getenv("EMAIL_BACKEND", "django.core.mail.backends.smtp.EmailBackend")
EMAIL_HOST = os.getenv('EMAIL_HOST', 'email-smtp.us-east-1.amazonaws.com')        # Example for SendGrid
EMAIL_PORT = os.getenv('EMAIL_PORT',25)                        # Usually 587 or 465
EMAIL_HOST_USER = os.getenv('EMAIL_HOST_USER')              # For SendGrid, 'apikey'
EMAIL_HOST_PASSWORD = os.getenv('EMAIL_HOST_PASSWORD')
EMAIL_USE_TLS = True
DEFAULT_FROM_EMAIL = os.getenv('DEFAULT_FROM_EMAIL','notification@faoud.com')


FRONTEND_URL = os.getenv("FRONTEND_URL", "https://www.faoud.com")
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

