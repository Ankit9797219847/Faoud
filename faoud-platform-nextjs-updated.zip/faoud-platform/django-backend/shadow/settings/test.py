from .base import *

# Disable notifications during tests
DISABLE_NOTIFICATIONS = True
AUTO_ASSIGN_PRIVILEGED_AMS = False

# Avoid persistent DB connections (fix postgres teardown issues)
DATABASES["default"]["CONN_MAX_AGE"] = 0

# Faster password hashing for tests
PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.MD5PasswordHasher",
]

# Run tasks synchronously if using celery
CELERY_TASK_ALWAYS_EAGER = True
CELERY_TASK_EAGER_PROPAGATES = True

# Email backend for tests
EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"
DEFAULT_FROM_EMAIL = "no-reply@faoud.com"
FEEDBACK_REPORT_NOTIFICATION_EMAIL = "jha@faoud.com"
