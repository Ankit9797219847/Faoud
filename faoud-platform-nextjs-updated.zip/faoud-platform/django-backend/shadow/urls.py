"""shadow URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include
from rest_framework import permissions
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from django.conf.urls.static import static

from django.conf import settings

from insights.admin_dashboard import admin_dashboard_view
from shadow.settings import base

schema_view = get_schema_view(
    openapi.Info(
        title="Faoud API",
        default_version='v1',
        description="API ",
        terms_of_service="",
        contact=openapi.Contact(email=""),
        license=openapi.License(name="BSD License"),
    ),
    public=True,
    permission_classes=(permissions.AllowAny,),
)

PREFIX = "api/"

urlpatterns = [
    path("admin/wgo/", admin_dashboard_view, name='custom_admin_dashboard'),
    path("admin/", admin.site.urls),
    path(PREFIX, include("user.urls")),
    path(PREFIX, include("utils.urls")),
    path(PREFIX, include("product.urls")),
    path(PREFIX, include("case.urls")),
    path(PREFIX, include("comms.urls")),
    path("ckeditor5/", include("django_ckeditor_5.urls")),
    path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
    path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
    path(PREFIX, include("supply.urls")),
    path(PREFIX, include("formulation.urls")),
    path(PREFIX, include("materials.urls")),
    path(PREFIX, include("payments.urls")),
    path(PREFIX, include("marketing.urls")),
    path(PREFIX, include("tracking.urls")),
    path(PREFIX, include("core.urls")),
    path(PREFIX, include("process.urls")),
    path(PREFIX, include('notifications.urls')),
    path(PREFIX, include('leads.urls')),
    path(PREFIX, include('services.urls')),  # Service Requests
    # path(f"{PREFIX}marketing/", include('marketing.urls')),
 
]

urlpatterns += static('/media/', document_root=settings.MEDIA_ROOT)