from django.core.mail import send_mail
from django.conf import settings
import logging
from django.template.loader import render_to_string

logger = logging.getLogger(__name__)

def send_email_notification(subject, message, recipient_email):

                                       
    try:
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL,
            [recipient_email],
            html_message=message,
            fail_silently=False,
        )
        logger.info(f"Email sent to {recipient_email}")
    except Exception as e:
        logger.error(f"Failed to send email to {recipient_email}: {e}")
        raise

def send_sms_notification(message, recipient_number):
    try:
        # client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        # logger.info(f"Notification as sms sent successfully.")
        # client.messages.create(
        #     body=message,
        #     from_=settings.TWILIO_PHONE_NUMBER,
        #     to=recipient_number
        # )
        logger.info(f"SMS sent to {recipient_number}")
    except Exception as e:
        logger.error(f"Failed to send SMS to {recipient_number}: {e}")
        raise

import requests
import logging
from django.conf import settings

logger = logging.getLogger(__name__)
def send_whatsapp_notification(
    recipient_number: str,
    parameters: list,
    template_name: str ,
    language_code: str = "en_US"
):
    """
    Sends a WhatsApp template message using the Cloud API.
    if template_name is not provided, it will raise an error.
    
    Parameters:
        recipient_number (str): WhatsApp number in international format.
        parameters (list): List of template parameters (dicts).
        template_name (str): Name of the approved template.
        language_code (str): Language code for the template (default: en_US).
    """
    if not template_name:
        logger.error("Template name is required for WhatsApp message.")
        raise ValueError("Template name is required for WhatsApp message.")
    
    api_config = settings.WHATSAPP_API
    url = f"{api_config['BASE_URL']}/{api_config['PHONE_NUMBER_ID']}/messages"

    headers = {
        "Authorization": f"Bearer {api_config['ACCESS_TOKEN']}",
        "Content-Type": "application/json"
    }

    payload = {
        "messaging_product": "whatsapp",
        "to": recipient_number,
        "type": "template",
        "template": {
            "name": template_name,
            "language": {"code": language_code},
            "components": [
                {
                    "type": "body",
                    "parameters": parameters
                }
            ]
        }
    }

    try:
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        logger.error(f"WhatsApp send failed to {recipient_number}: {e}")
        raise
