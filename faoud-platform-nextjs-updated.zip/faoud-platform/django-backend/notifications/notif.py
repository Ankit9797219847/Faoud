import logging
from django.contrib.auth.models import User
from django.template import Template, Context
from django.conf import settings
from .models import Notification, NotificationTemplate, UserNotification
from .tasks import send_notification_task

logger = logging.getLogger(__name__)

def send_notification(
    channels,
    template_name,
    context=None,
    users=None,
    emails=None,
    phone_numbers=None,
    whatsapp_numbers=None,
    notification_type='operational',
    whatsapp_params=None,
):
    """
    A single function to schedule notifications (email, SMS, WhatsApp) with 
    placeholders and an HTML template, all stored in the DB.
    """
    try:
        if getattr(settings, "DISABLE_NOTIFICATIONS", False):
            logger.info(
                "Notifications disabled; skipping send_notification for template '%s'",
                template_name,
            )
            return None

        # Validate channels
        supported_channels = {'email', 'sms', 'whatsapp'}
        invalid_channels = set(channels) - supported_channels
        if invalid_channels:
            raise ValueError(f"Unsupported channels: {invalid_channels}")

        # Gather recipients
        recipient_emails = set(emails or [])
        recipient_phone_numbers = set(phone_numbers or [])
        recipient_whatsapp_numbers = set(whatsapp_numbers or [])

        # If users are provided, add them to the relevant recipient lists
        if users:
            for user in users:
                if 'email' in channels and user.email:
                    recipient_emails.add(user.email)
                if 'sms' in channels and hasattr(user, 'brandowner') and user.brandowner.contact_phone:
                    recipient_phone_numbers.add(user.brandowner.contact_phone)
                if 'sms' in channels and hasattr(user, 'factoryowner') and user.factoryowner.contact_phone:
                    recipient_phone_numbers.add(user.factoryowner.contact_phone)
                if 'whatsapp' in channels and hasattr(user, 'brandowner') and user.brandowner.contact_phone:
                    recipient_whatsapp_numbers.add(user.brandowner.contact_phone)
                if 'whatsapp' in channels and hasattr(user, 'factoryowner') and user.factoryowner.contact_phone:
                    recipient_whatsapp_numbers.add(user.factoryowner.contact_phone)

        # Fetch the template from DB
        template = NotificationTemplate.objects.filter(name=template_name).first()
        if not template:
            raise ValueError(f"No NotificationTemplate found with name '{template_name}'")

        # Create a single Notification instance for tracking
        notification = Notification.objects.create(
            type=notification_type,
            template=template
        )

        # Create UserNotification entries for each user in all channels
        # (If you want to track them by channel, you can adapt accordingly.)
        all_contacts = (
            [(email, 'email') for email in recipient_emails] +
            [(phone, 'sms') for phone in recipient_phone_numbers] +
            [(phone, 'whatsapp') for phone in recipient_whatsapp_numbers]
        )

        # Deduplicate or handle as needed
        unique_contacts = set(all_contacts)

        for contact, channel in unique_contacts:
            # Find user by email or phone if you want to store user associations
            if channel == 'email':
                user_obj = User.objects.filter(email=contact).first()
            else:
                user_obj = User.objects.filter(brandowner__contact_phone=contact).first()
                if not user_obj:
                    user_obj = User.objects.filter(factoryowner__contact_phone=contact).first()

            if user_obj:
                UserNotification.objects.create(
                    user=user_obj,
                    notification=notification
                )
            else:
                logger.warning(f"No user found for {channel} contact: {contact}")

        # Enqueue the Celery task to actually send the messages
        # We pass in the channels, the notification ID, and any context needed for placeholders
        send_notification_task(notification.id, list(channels), context or {}, whatsapp_params or {})

        logger.info(f"Notification {notification.id} created and queued for channels: {channels}")
        return notification

    except Exception as e:
        logger.error(f"Error in send_notification: {e}")
        raise


from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
def send_html_email(subject, template_name, context, recipients):
    """
    Sends an HTML + plain-text fallback email.
    """
    text_content = render_to_string(template_name.replace('.html', '.txt'), context) \
                    if template_name.endswith('.html') else ''
    html_content = render_to_string(template_name, context)

    msg = EmailMultiAlternatives(subject, text_content or html_content, settings.DEFAULT_FROM_EMAIL, recipients)
    msg.attach_alternative(html_content, "text/html")
    try:
        msg.send()
    except Exception:
        logger.exception("Failed to send email")
        raise
