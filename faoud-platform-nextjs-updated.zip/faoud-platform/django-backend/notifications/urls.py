from django.urls import include, path

from rest_framework.routers import DefaultRouter
from .views import NotificationViewSet, UserNotificationViewSet, WhatsAppBusinessWebhookView, RemindFactoryOwnerView

router = DefaultRouter()
router.register(r'notifications', NotificationViewSet)
router.register(r'user-notifications', UserNotificationViewSet, basename='user-notifications')

urlpatterns = router.urls
urlpatterns = [
    path('webhook/whatsapp/', WhatsAppBusinessWebhookView.as_view(), name='whatsapp_webhook'),
      # Other URL patterns
    path('', include(router.urls)),
    path('remind-factory-owner/', RemindFactoryOwnerView.as_view(), name='remind_factory_owner'),
]