from django.utils import timezone
from celery import shared_task
from django.template import Template, Context
import logging

from shadow import settings
from user.models import BrandOwner, FactoryOwner
from .models import Campaign, Notification, UserNotification
from .services import send_email_notification, send_sms_notification, send_whatsapp_notification

logger = logging.getLogger(__name__)

@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_notification_task(self, notification_id, channels, context, whatsapp_params=None):
    """
    Celery task to send notifications via specified channels.

    Parameters:
        notification_id (int): ID of the Notification instance.
        channels (list): List of channels to send notifications through.
        context (dict): Placeholder data for rendering templates.
    """
    try:
        notification = Notification.objects.get(id=notification_id)
        template = notification.template

        # Gather all UserNotifications for this Notification
        user_notifications = UserNotification.objects.filter(notification=notification)

        # For each user_notification, we figure out the channel contact
        for user_notification in user_notifications:
            user = user_notification.user

            # Render placeholders for each channel
            if 'email' in channels and user.email and has_mailing_permission(user, notification.type):
                # e.g., skip marketing emails if unsubscribed
                subject = render_template_string(template.subject_template, context)
                email_body = render_template_string(template.email_body_template, context)
                send_email_notification(subject, email_body, user.email)
                logger.info(f"Email sent to {user.email}")

            if 'sms' in channels and user.brandowner.contact_phone:
                sms_body = render_template_string(template.sms_body_template, context)
                send_sms_notification(sms_body, user.brandowner.contact_phone)
                if hasattr(user, 'brandowner') and user.brandowner.contact_phone:
                    phone = (BrandOwner.objects.get(user=user)).contact_phone
                    send_sms_notification(sms_body, phone)
                    logger.info(f"SMS sent to brandowner {phone}")
                if hasattr(user, 'factoryowner') and user.factoryowner.contact_phone:
                    phone = (FactoryOwner.objects.get(user=user)).contact_phone
                    send_sms_notification(sms_body, phone)
                    logger.info(f"SMS sent to factoryowner {phone}")

            if 'whatsapp' in channels and user:
                # whatsapp_body = render_template_string(template.whatsapp_body_template, context)
                if hasattr(user, 'brandowner') and user.brandowner.contact_phone:
                    phone = (BrandOwner.objects.get(user=user)).contact_phone
                    send_whatsapp_notification( phone,whatsapp_params, template.whatsapp_body_template)
                    logger.info(f"WhatsApp sent to {phone}")
                if hasattr(user, 'factoryowner') and user.factoryowner.contact_phone:
                    phone = (FactoryOwner.objects.get(user=user)).contact_phone
                    send_whatsapp_notification( phone,whatsapp_params, template.whatsapp_body_template)
                    logger.info(f"WhatsApp sent to {phone}")

        logger.info(f"Notification {notification_id} fully sent via {channels}.")

    except Notification.DoesNotExist:
        logger.error(f"Notification with ID {notification_id} does not exist.")
    except Exception as e:
        logger.error(f"Error sending notification {notification_id}: {e}")
        self.retry(exc=e)





 
@shared_task
def process_campaign(campaign_id, batch_size=1000):
    """
    Celery task that processes a Campaign in batches.
    """
    try:
        campaign = Campaign.objects.get(id=campaign_id)
    except Campaign.DoesNotExist:
        logger.error(f"Campaign {campaign_id} does not exist.")
        return

    # Mark campaign as sending
    campaign.status = 'sending'
    campaign.save()

    users_qs = campaign.segment.get_users()

    # Send to users in batches to avoid massive queries/timeouts
    offset = 0
    total_sent = 0
    while True:
        batch = users_qs[offset:offset+batch_size]
        if not batch:
            break
        
        # Send notifications to each user in this batch
        for user in batch:
            send_marketing_notification(user, campaign)

        offset += batch_size
        total_sent += len(batch)

    # Mark campaign as completed
    campaign.status = 'completed'
    campaign.save()
    logger.info(f"Campaign {campaign.id} completed sending {total_sent} notifications.")


from user.privacy import build_unsubscribe_token


def send_marketing_notification(user, campaign):
    """
    Actually sends the notification(s) to a single user. 
    We create a UserNotification record for reference.
    """
    template = campaign.template

    # Example: decide which channels to send to based on the template's `channel`
    # or you can send across multiple channels if that's your design.
    channels = campaign.channels
    # print channels in output
    
    unsubscribe_token = build_unsubscribe_token(user)
    unsubscribe_url = f"{settings.FRONTEND_URL}/unsubscribe?token={unsubscribe_token}"
    context = {
        'unsubscribe_url': unsubscribe_url,
        'message': 'Thank you for being part of Faoud!',
    }

    logger.info(f"Sending campaign {campaign.id} to user {user.id} on channels: {channels}")

    if 'email' in channels and has_mailing_permission(user, 'marketing'):
        email_body = render_template_string(template.email_body_template, context)
        subject= render_template_string(template.subject_template, context)
        send_email_notification(subject, email_body, user.email)
    elif 'sms' in channels and sms_body:
        sms_body = render_template_string(template.sms_body_template, {})
        send_sms_notification(sms_body, user.brandowner.contact_phone)
        if hasattr(user, 'brandowner') and user.brandowner.contact_phone:
            phone = (BrandOwner.objects.get(user=user)).contact_phone
            send_sms_notification(sms_body, phone)
            logger.info(f"SMS sent to brandowner {phone}")
        if hasattr(user, 'factoryowner') and user.factoryowner.contact_phone:
            phone = (FactoryOwner.objects.get(user=user)).contact_phone
            send_sms_notification(sms_body, phone)
            logger.info(f"SMS sent to factoryowner {phone}")
    elif 'whatsapp' in channels and whatsapp_body:
        whatsapp_body = render_template_string(template.whatsapp_body_template,{} )
        if hasattr(user, 'brandowner') and user.brandowner.contact_phone:
            phone = (BrandOwner.objects.get(user=user)).contact_phone
            send_whatsapp_notification(phone, template.whatsapp_body_template)
            logger.info(f"WhatsApp sent to {phone}")
        if hasattr(user, 'factoryowner') and user.factoryowner.contact_phone:
            phone = (FactoryOwner.objects.get(user=user)).contact_phone
            send_whatsapp_notification(phone, template.whatsapp_body_template)
            logger.info(f"WhatsApp sent to {phone}")
    logger.info(f"Sent campaign {campaign.id} to user {user.id} on channel: {channels}")


    user_notification = UserNotification.objects.create(
        user=user,
        campaign=campaign,
        is_read=False,
        sent_at=timezone.now(),
    )
    logger.info(f"UserNotification {user_notification.id} created for user {user.id}.") 


def render_template(template_string, context_data):
    """
    Simple Django template rendering with context.
    """
    if not template_string:
        return ""
    t = Template(template_string)
    c = Context(context_data)
    return t.render(c)

def render_template_string(template_string, context):
    """Render a Django template string with a given context."""
    if not template_string:
        return ""
    return Template(template_string).render(Context(context))

    
def send_email(subject, message, to_email):
    from django.core.mail import send_mail
    try:
        send_mail(
            subject=subject,
            message=message,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[to_email],
            html_message=message,  # If HTML
            fail_silently=False
        )
        logger.info(f"Email sent to {to_email}")
    except Exception as e:
        logger.error(f"Failed to send email to {to_email}: {e}")

def send_sms(message, to_number):
    # Implement your Twilio logic here
    try:
        # client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        # client.messages.create(
        #     body=message,
        #     from_=settings.TWILIO_PHONE_NUMBER,
        #     to=to_number
        # )
        logger.info(f"SMS sent to {to_number}")
    except Exception as e:
        logger.error(f"Failed to send SMS to {to_number}: {e}")



def get_user_phone(user):
    # Implement how you store phone numbers (e.g., user.profile.phone)
    return user.profile.phone if hasattr(user, 'profile') else None



@shared_task
def check_scheduled_campaigns():
    from django.utils import timezone
    from .models import Campaign

    now = timezone.now()
    campaigns = Campaign.objects.filter(status='scheduled', scheduled_time__lte=now)
    for campaign in campaigns:
        process_campaign.delay(campaign.id)



def has_mailing_permission(user, email_type):
    """
    Check if the user has permission to receive a specific type of email.

    Parameters:
        user (User): The user instance.
        email_type (str): The type of email ('marketing' or 'operational').

    Returns:
        bool: True if the user has permission, False otherwise.
    """

    if hasattr(user, 'am'):
        return True

    if email_type == 'marketing':
        if hasattr(user, 'brandowner') and user.brandowner.marketing_emails:
            return True
        if hasattr(user, 'factoryowner') and user.factoryowner.marketing_emails:
            return True
    elif email_type == 'operational':
        if hasattr(user, 'brandowner') and user.brandowner.operational_emails:
            return True
        if hasattr(user, 'factoryowner') and user.factoryowner.operational_emails:
            return True
    return False
