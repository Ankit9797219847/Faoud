import threading
from datetime import timedelta
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone

from case.models import Alert, Case, ProgressStage
from notifications.notif import send_notification
from payments.models import Order, PaymentLayer, SampleOrder
from supply.models import Bid, Factory, SampleOrderTracking
from django.contrib.auth.models import User

from tracking.helper import hasManufacturingStarted, hasProcurementStarted
from tracking.models import FDA, PM, RM, Manufacturing
from user.models import AM, BrandOwner
from django.db.models import Q
from django.db.models.signals import m2m_changed


def schedule_notification(scheduled_time, channels, template_name, context, users, notification_type):
    """
    Schedules a call to send_notification at the given scheduled_time.
    Includes a try/except so that an error during scheduling won't break flow.
    """
    try:
        if getattr(settings, "DISABLE_NOTIFICATIONS", False):
            return

        delay = (scheduled_time - timezone.now()).total_seconds()
        if delay < 0:
            delay = 0

        def safe_send():
            try:
                send_notification(
                    channels=channels,
                    template_name=template_name,
                    context=context,
                    users=users,
                    notification_type=notification_type,
                    whatsapp_params=context.get('whatsapp_params', None)  # Pass any additional params if needed
                )
            except Exception as e:
                # Here you can log the exception or handle it as needed
                print(f"[Error in send_notification] {str(e)}")

        threading.Timer(delay, safe_send).start()

    except Exception as e:
        # Here you can log the exception or handle it as needed
        print(f"[Error in schedule_notification] {str(e)}")


def get_interested_factory_owner_users(case):
    """
    Returns a list of *email addresses* for users whose factories' category and 
    subcategories match the case's product.
    """
    try:
        if case is None:
            return []

        product = getattr(case, "product", None)
        if product is None:
            return []

        category = getattr(product, "category", None)
        subcategory = getattr(product, "subcategory", None)
        if category is None and subcategory is None:
            return []

        # Find all factories with matching category & subcategory.
        filters = Q()
        if category is not None:
            filters |= Q(categories=category)
        if subcategory is not None:
            filters |= Q(subcategories=subcategory)
        owner_factories = Factory.objects.filter(filters)

        # Get the user IDs from these factories.
        factory_owner_users = owner_factories.values_list('factory_owner__user', flat=True).distinct()

        # Return the email addresses for these users.
        return list(User.objects.filter(id__in=factory_owner_users)
                                )
    except Exception as e:
        print(f"[Error in get_interested_factory_owner_users] {str(e)}")
        return []


# --- Inserted helper functions for AM names and phone ---
def get_am_names(case):
    """Return a comma-separated list of AM names for a case, or a default name."""
    try:
        if hasattr(case, 'am') and hasattr(case.am, 'all'):
            names = [am.name for am in case.am.all() if getattr(am, 'name', None)]
            return ", ".join(names) if names else "Rutuja"
    except Exception:
        pass
    return "Rutuja"


def get_am_phone(case):
    """Return the first available AM phone for a case, or a default phone."""
    try:
        if hasattr(case, 'am') and hasattr(case.am, 'all'):
            for am in case.am.all():
                phone = getattr(am, 'contact_phone', None)
                if phone:
                    return phone
    except Exception:
        pass
    return "+91 8999292034"

# --- Helper to build tel: link ---
def build_tel_link(phone: str):
    """Return a tel: link for click-to-call. Keeps leading + and digits only."""
    try:
        phone = phone or ""
        # Keep leading + if present, then digits
        cleaned = []
        plus_kept = False
        for i, ch in enumerate(phone.strip()):
            if ch == '+' and i == 0 and not plus_kept:
                cleaned.append(ch)
                plus_kept = True
            elif ch.isdigit():
                cleaned.append(ch)
        number = ''.join(cleaned)
        return f"tel:{number}" if number else ""
    except Exception:
        return ""

# --- Inserted helper functions for single AM name and FO name ---
def get_am_name(case):
    """Pick a single AM name with priority: no-group > superAM (random) > first non-MNGNMT; else default."""
    try:
        if not (hasattr(case, 'am') and hasattr(case.am, 'all')):
            return "Rutuja"
        ams = list(case.am.all())
        if not ams:
            return "Rutuja"

        def user_for(am):
            return getattr(am, 'user', None)

        def in_group(am, group_name: str) -> bool:
            u = user_for(am)
            try:
                return bool(u and u.groups.filter(name=group_name).exists())
            except Exception:
                return False

        def group_count(am) -> int:
            u = user_for(am)
            try:
                return int(u.groups.count()) if u else 0
            except Exception:
                return 0

        # 1) Exclude MNGNMT
        non_mngnmt = [am for am in ams if not in_group(am, 'MNGMNT')]

        # 2) Prefer AMs with NO groups
        no_group_ams = [am for am in non_mngnmt if group_count(am) == 0]
        if no_group_ams:
            return getattr(no_group_ams[0], 'name', None) or "Rutuja"

        # 3) Otherwise choose from superAM at random
        super_ams = [am for am in ams if in_group(am, 'superAM')]
        if super_ams:
            import random
            chosen = random.choice(super_ams)
            return getattr(chosen, 'name', None) or "Rutuja"

        # 4) Fallback to first non-MNGNMT if exists
        if non_mngnmt:
            return getattr(non_mngnmt[0], 'name', None) or "Rutuja"

    except Exception:
        pass
    return "Rutuja"

def get_fo_name(factory_owner):
    """Return the factory owner's display name if available."""
    try:
        return getattr(factory_owner, 'name', None) or getattr(getattr(factory_owner, 'user', None), 'first_name', '') or 'Factory Owner'
    except Exception:
        return 'Factory Owner'


@receiver(post_save, sender=Case)     # done
def schedule_case_notifications(sender, instance, created, **kwargs):
    try:
        if created:
            now = timezone.now()

            scheduled_time = now + timedelta(minutes=0.1)
            # Use the in-memory instance rather than refetching from DB
            case = Case.objects.get(id=instance.id)
            # Build a JSON-serializable context. Avoid sets in whatsapp_params.
            context = {
                'user': getattr(instance.brand_owner, 'name', 'Valued Customer'),
                'am_name': get_am_name(instance),
                'case_name': ("Waiting for Review" if (not instance.name or instance.name.strip().lower() == "unnamed case") else instance.name),
                # Pass ordered placeholders as a list (JSON-serializable) for WhatsApp templates
                'whatsapp_params': [
                    (instance.name or "Your Requirement"),
                    getattr(instance.brand_owner, 'name', ''),
                    (instance.name or "Your Requirement"),
                    get_am_name(instance),
                ],
            }
            schedule_notification(
                scheduled_time=scheduled_time,
                channels=['email'],
                template_name='bo_case_registered',
                context=context,  # needs to be updated
                users=[instance.brand_owner.user],
                notification_type='operational'
            )

        
            now = timezone.now()
            account_manager_users = [am.user for am in AM.objects.all()]
            # account_manager_users = [am.user for am in case.am.all()] if hasattr(case, 'am') else []
            if account_manager_users:
                message = f"A new case has been created with the following details: Case Id : {case.id}, Case Name : {case.name}, Brand Owner : {case.brand_owner.name if case.brand_owner else 'N/A'}, Product : {case.product.name if case.product else 'N/A'}, Quantity : {case.quantity if case.quantity else 'N/A'}. Please review the case and take necessary actions."
                schedule_notification(
                    scheduled_time=now,
                    channels=['email'],
                    template_name='default_body_email',
                    context={'message': message, 'subject': 'New Case Created'},
                    users=account_manager_users,
                    notification_type='operational'
                )
            Alert.objects.create(
            case=instance, 
            message="A new case has been created and needs review."
        )
    except Exception as e:
        print(f"[Error in schedule_case_notifications] {str(e)}")



@receiver(post_save, sender=ProgressStage) #running
def reviewed_case_notification(sender, instance, created, **kwargs):
    """
    When a case is reviewed (i.e. ProgressStage is saved), notify the brand owner and interested factory owners.
    """
    try:
        now = timezone.now()
        case = Case.objects.get(id = instance.case.id)
        product_name = case.product.name if getattr(case, 'product', None) and getattr(case.product, 'name', None) else "your product"
        # Notify brand owner immediately
        scheduled_time = now + timedelta(minutes=0.2)
        context = {
            'case_name': case.name if case.name else "Your Requirement",
            'am_name': get_am_name(case),
            'to_bid_link': f'https://www.faoud.com/dashboard/brand-owner/track-your-order/?caseId={case.id}',
            'am_phone': get_am_phone(case),
            'whatsapp_params': []
        }
        if instance.stage.name == 'Reviewed':
            schedule_notification(
                scheduled_time=scheduled_time,
                channels=['email'],
                template_name='bo_case_reviewed',
                context=context, # needs to be updated
                users=[case.brand_owner.user],
                notification_type='operational'
            )

        # Notify interested factory owners (with a 1-minute delay)
        factory_owner_users = get_interested_factory_owner_users(case)    #error
        if factory_owner_users  and instance.stage.name == 'Reviewed':
            scheduled_time = now + timedelta(minutes=0.2)
            # Build safe factory-owner bidding link
            category_slug = getattr(getattr(case.product, 'category', None), 'slug', None)
            subcategory_slug = getattr(getattr(case.product, 'subcategory', None), 'slug', None)
            if category_slug and subcategory_slug:
                fo_bid_link = f"https://www.faoud.com/manufacture/order/{category_slug}/{subcategory_slug}/{case.id}"
            else:
                fo_bid_link = "https://www.faoud.com/manufacture/order/"
            context = {
                'case_name_fo': case.product.name if getattr(case, 'product', None) and getattr(case.product, 'name', None) else "Brand's Requirement",
                'am_name': get_am_name(case),
                'to_bids_link': fo_bid_link,
                'am_phone': get_am_phone(case),
                'whatsapp_params': []
            }
            schedule_notification(
                scheduled_time=scheduled_time,
                channels=['email'],
                template_name='fo_new_req_rcvd',
                context=context, # needs to be updated
                users=factory_owner_users,
                notification_type='operational'
            )
        elif instance.stage.name == 'Reviewed':
            # Fallback to account managers if no interested factory owners
            account_manager_users = [am.user for am in case.am.all()] if hasattr(case, 'am') else []
            message = (
                    f"A new requirement suitable for factories has been posted, but no factory in the "
                    f"category ({case.product.category}) is registered on Faoud. Please "
                    f"<a href='https://faoud.com/login'>log in</a> to register."
                )
            schedule_notification(
                scheduled_time=now,
                channels=['email',],
                template_name='default_body_email',
                context={'message': message, 'subject': 'No Factories Found for a case'},
                users=account_manager_users,
                notification_type='operational'
            )
            Alert.objects.create(
            case=case, 
            message="A new requirement suitable for factories has been posted, but no factory in the category is registered on Faoud."
        )
    except Exception as e:
        print(f"[Error in reviewed_case_notification] {str(e)}")




@receiver(post_save, sender=Bid)
def bid_field_changed_notification(sender, instance, created, **kwargs):
    """
    When a Bid is updated or created, notify the appropriate parties.
    """
    if getattr(settings, "DISABLE_NOTIFICATIONS", False):
        return

    case = instance.case
    bo_id = case.brand_owner.id
    case = Case.objects.get(id=case.id)
    bid = Bid.objects.get(id=instance.id)
    try:
        now = timezone.now()
        # Check if tag has changed and status is 'in_review'
        if instance.tag and instance.status == 'in_review':
            # Notify brand owner if the bid's tag (or a specific field) indicates a change
            case = instance.case
            bo_id = case.brand_owner.id
            case = Case.objects.get(id=case.id)
            bid = Bid.objects.get(id=instance.id)
            factory = bid.factory
            # trim the address to get a short location from the end of the address, if no comma, display "Details in Dashboard"
            factory_short_location = factory.address.split(',')[-1].strip() if ',' in factory.address else "Details in Dashboard"
            brand_owner = BrandOwner.objects.get(id=bo_id)
            if instance.tag:  # Replace with an appropriate condition if needed
                context= {
                    'case_name_bo': case.name if case.name else "Your Requirement",
                    'contact_am_link': build_tel_link(get_am_phone(case)),
                    'compare_bids_link' :f'https://www.faoud.com/dashboard/brand-owner/track-your-order/?caseId={case.id}',
                    'whatsapp_params': [],
                    'factory_location':factory_short_location,
                    'case_id': case.id,
                    'price_per_unit': instance.quote_bo if instance.quote_bo else "N/A",
                    'moq':factory.capacity if factory.capacity else "N/A",
                    'bid_eta': instance.eta if instance.eta else "N/A"
                }
                schedule_notification(
                    scheduled_time=now,
                    channels=['email'],
                    template_name='bo_bid_rcvd',
                    context=context,
                    users=[brand_owner.user],
                    notification_type='operational'
                )

        # If newly created
        if created:
            case_id = instance.case.id
            bid = Bid.objects.get(id=instance.id)
            case = Case.objects.get(id=case_id)
            account_manager_users = [am.user for am in case.am.all()] if hasattr(case, 'am') else []
            if account_manager_users:
                factory = getattr(bid, 'factory', None)
                factory_name = getattr(factory, 'name', 'N/A') if factory else 'N/A'
                factory_id = getattr(factory, 'id', 'N/A') if factory else 'N/A'
                price_per_unit = (
                    getattr(instance, 'quote_bo', None)
                    or getattr(instance, 'quote', None)
                    or 'N/A'
                )
                moq = getattr(factory, 'capacity', None) if factory and getattr(factory, 'capacity', None) else 'N/A'
                eta = getattr(instance, 'eta', None) or 'N/A'

                # Helpful links
                track_link = f"https://www.faoud.com/dashboard/account-manager/user-case/?caseId={case.id}"
                am_tel = build_tel_link(get_am_phone(case))
                message = (
                    f"New bid added for Case #{case.id} – {case.name or 'Details in Dashboard'}\n"
                    f"Factory: {factory_name} (ID: {factory_id})\n"
                    f"Price/Unit: {price_per_unit}\n"
                    f"MOQ: {moq}\n"
                    f"ETA: {eta}\n"
                    f"Compare/Track: {track_link}\n"
                    f"Call AM: {am_tel}"
                )
                schedule_notification(
                    scheduled_time=now,
                    channels=['email'],
                    template_name='default_body_email',
                    context={'message': message, 'subject': 'New Bid Added'},
                    users=account_manager_users,
                    notification_type='operational'
                )
            Alert.objects.create(
            case=case, 
            message="A factory owner has added a bid, here are the details: {instance}"


            
        )
            if instance.status == 'in_review':
                context={
                    'product_name': case.product.name if case.product and case.product.name else "Details in Dashboard",
                    'am_name': get_am_name(instance.case),
                    'contact_am_link': build_tel_link(get_am_phone(instance.case)),
                    'track_bid_link': f"https://faoud.com/dashboard/factory-owner"
                }
                schedule_notification(
                    scheduled_time=now,
                    channels=['email'],
                    template_name='fo_bidrcvd',
                    context=context,
                    users=[instance.factory.factory_owner.user],
                    notification_type='operational'
                )

        # If bid has gotten rejected
        if instance.status == 'rejected' and instance.tag:
            context= {
                    'factory_owner_name': get_fo_name(instance.factory.factory_owner),
                    'product_name': case.product.name if case.product and case.product.name else "Details in Dashboard",
                    'contact_support_link' : build_tel_link(get_am_phone(instance.case)),
                    'dashboard_link' :f"https://faoud.com/dashboard/factory-owner",
                    'whatsapp_params': [],
                    'case_id': case.id,
                    'new_projects_link':f"https://faoud.com/dashboard/factory-owner",
                }
            schedule_notification(
                scheduled_time=now,
                channels=['email'],
                template_name='fo_bid_rejected',
                context=context,
                users=[instance.factory.factory_owner.user],
                notification_type='operational'
            )
        #When bid is live
        if instance.status == 'in_review' and instance.tag:
            context= {
                'factory_owner_name': get_fo_name(instance.factory.factory_owner),
                'product_name': case.product.name if case.product and case.product.name else "Details in Dashboard",
                'modify_bid_link': f"https://faoud.com/dashboard/factory-owner",
                'view_bid_link': f"https://faoud.com/dashboard/factory-owner",
                'price_per_unit': instance.quote if instance.quote else "N/A",
                'bid_eta': instance.eta if instance.eta else "N/A",
                'whatsapp_params': [],
                'bid_submission_date': instance.created_at.isoformat() if instance.created_at else "N/A",
                'case_id': case.id,
                'contact_support_link': build_tel_link(get_am_phone(instance.case)),
            }
            schedule_notification(
                scheduled_time=now,
                channels=['email'],
                template_name='fo_bid_live',
                context=context,
                users=[instance.factory.factory_owner.user],
                notification_type='operational'
            )
        if instance.status == 'SAMPLE_ORDERED' and instance.tag:
            context= {
                'case_name_fo': case.product.name if case.product and case.product.name else "Details in Dashboard",
                'sample_order_link': f"https://www.faoud.com/dashboard/factory-owner/case-details/sample-order?bidId={instance.id}",
                'whatsapp_params': [],
                'case_id': case.id,
                'am_name': get_am_name(instance.case),
                'contact_support_link': build_tel_link(get_am_phone(instance.case)),
            }
            schedule_notification(
                scheduled_time=now,
                channels=['email'],
                template_name='fo_sample_req',
                context=context,
                users=[instance.factory.factory_owner.user],
                notification_type='operational'
            )
        # if instance.status == 'accepted' and instance.tag:
        #     context= {
        #         'case_name_fo': case.product.name if case.product and case.product.name else "Details in Dashboard",
        #         'dashboard_link': f"https://www.faoud.com/dashboard/factory-owner/case-details/bid-details?caseId={case.id}&bidId={instance.id}",
        #         'case_id': case.id,
        #         'bid_id': instance.id,
        #         'whatsapp_params': [],
        #         'am_name': get_am_name(instance.case),
        #         'contact_support_link': build_tel_link(get_am_phone(instance.case)),
        #     }
        #     schedule_notification(
        #         scheduled_time=now,
        #         channels=['email'],
        #         template_name='fo_bid_accepted',
        #         context=context,
        #         users=[instance.factory.factory_owner.user],
        #         notification_type='operational'
        #     )
        

    except Exception as e:
        print(f"[Error in bid_field_changed_notification] {str(e)}")
