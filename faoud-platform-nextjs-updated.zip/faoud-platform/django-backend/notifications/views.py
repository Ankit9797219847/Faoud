from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Notification, UserNotification
from .serializers import NotificationSerializer, UserNotificationSerializer
from .tasks import send_notification_task

import json
import logging
from django.conf import settings
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views import View
from django.utils.decorators import method_decorator

logger = logging.getLogger(__name__)


class NotificationViewSet(viewsets.ModelViewSet):
    queryset = Notification.objects.all()
    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAdminUser]

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAdminUser])
    def send(self, request, pk=None):
        notification = self.get_object()
        send_notification_task.delay(notification.id)
        return Response({'status': 'Notification has been queued for sending.'}, status=status.HTTP_200_OK)

class UserNotificationViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = UserNotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return UserNotification.objects.filter(user=self.request.user)

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def mark_as_read(self, request, pk=None):
        try:
            user_notification = self.get_object()
            user_notification.is_read = True
            user_notification.save()
            return Response({'status': 'Notification marked as read.'}, status=status.HTTP_200_OK)
        except UserNotification.DoesNotExist:
            return Response({'error': 'Notification not found.'}, status=status.HTTP_404_NOT_FOUND)



from django.http import JsonResponse, HttpResponse
from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
import json
import logging

logger = logging.getLogger(__name__)

@method_decorator(csrf_exempt, name='dispatch')
class WhatsAppBusinessWebhookView(View):
    def get(self, request, *args, **kwargs):
        mode = request.GET.get('hub.mode')
        token = request.GET.get('hub.verify_token')
        challenge = request.GET.get('hub.challenge')
        print("mode", mode, "token", token, "challenge", challenge)
        if mode == 'subscribe' and token == settings.WHATSAPP_VERIFY_TOKEN:
            logger.info("Webhook verified successfully.")
            return HttpResponse(challenge, status=200)
        else:
            logger.error("Webhook verification failed. Mode: %s, Token: %s", mode, token)
            return HttpResponse("Verification token mismatch", status=403)

    def post(self, request, *args, **kwargs):
        try:
            payload = json.loads(request.body.decode('utf-8'))
            logger.info("Received WhatsApp webhook event: %s", payload)
            for entry in payload.get('entry', []):
                for change in entry.get('changes', []):
                    value = change.get('value', {})
                    if 'messages' in value:
                        process_incoming_messages(value.get('messages'))
                    if 'statuses' in value:
                        process_status_updates(value.get('statuses'))
            return JsonResponse({"status": "success"}, status=200)
        except Exception as e:
            logger.exception("Error processing WhatsApp webhook event: %s", e)
            return JsonResponse({"error": str(e)}, status=400)

def process_incoming_messages(messages):
    for message in messages:
        sender = message.get('from')
        msg_id = message.get('id')
        msg_text = message.get('text', {}).get('body', '')
        logger.info("New incoming message from %s: %s", sender, msg_text)

def process_status_updates(statuses):
    for status in statuses:
        msg_id = status.get('id')
        status_value = status.get('status')
        timestamp = status.get('timestamp')
        logger.info("Message %s updated to status %s at %s", msg_id, status_value, timestamp)


from rest_framework.views import APIView
from user.models import FactoryOwner
from notifications.notif import send_notification
from user.permissions import IsAccountManager, IsBrandOwner, IsFactoryOwner


class RemindFactoryOwnerView(APIView):
    permission_classes = [IsAccountManager | IsBrandOwner | IsFactoryOwner]

    def post(self, request, *args, **kwargs):
        try:
            factory_owner_id = request.data.get("factory_owner_id")
            if not factory_owner_id:
                return Response({"error": "Missing factory_owner_id"}, status=status.HTTP_400_BAD_REQUEST)

            # Fetch the factory owner
            factory_owner = FactoryOwner.objects.filter(id=factory_owner_id).first()
            if not factory_owner:
                return Response({"error": "Factory owner not found"}, status=status.HTTP_404_NOT_FOUND)

            # Prepare the context for the email template
            context = {
                "factory_owner_name": factory_owner.user.get_full_name() or factory_owner.user.username,
                "factory_name": factory_owner.user.get_full_name() or factory_owner.user.username
            }

            # 🟡 For testing, override with a specific email address

            send_notification(
                channels=["email"],
                template_name="factory_reminder_upload_flowchart",
                context=context,
                users=[factory_owner.user],  # Keep the user association for tracking
                notification_type="operational",
            )

            return Response({"status": f"Reminder email sent to {factory_owner.user.email}!"}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)