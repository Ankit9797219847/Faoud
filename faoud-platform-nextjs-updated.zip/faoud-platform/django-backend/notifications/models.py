from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

class NotificationTemplate(models.Model):
    CHANNEL_CHOICES = (
        ('email', 'Email'),
        ('sms', 'SMS'),
        ('whatsapp', 'WhatsApp'),
    )
    name = models.CharField(max_length=100, unique=True)

    # You can choose to keep channel or remove it, depending on your design.
    # If you keep channel, you might store separate template objects per channel.
    channel = models.CharField(max_length=20, choices=CHANNEL_CHOICES, blank=True, null=True)

    subject_template = models.CharField(max_length=255, blank=True, null=True)
    email_body_template = models.TextField(blank=True, null=True)  # HTML or text for email
    sms_body_template = models.TextField(blank=True, null=True)    # Text for SMS
    whatsapp_body_template = models.TextField(blank=True, null=True)  # Text for WhatsApp

    def __str__(self):
        return f"{self.name}"


class Notification(models.Model):
    TYPE_CHOICES = (
        ('operational', 'Operational'),
        ('marketing', 'Marketing'),
    )
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    template = models.ForeignKey(NotificationTemplate, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    scheduled_time = models.DateTimeField(blank=True, null=True)  # Optional scheduling

    def __str__(self):
        return f"{self.get_type_display()} - {self.template.name} at {self.created_at}"

class UserNotification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    # One of these might be set, but not both.
    notification = models.ForeignKey(
        'Notification',
        on_delete=models.CASCADE,
        null=True, blank=True
    )
    campaign = models.ForeignKey(
        'Campaign',
        on_delete=models.CASCADE,
        null=True, blank=True
    )

    is_read = models.BooleanField(default=False)
    sent_at = models.DateTimeField(auto_now_add=True)

    def clean(self):
        super().clean()
        # Enforce that exactly one of campaign or notification should be set.
        if self.notification and self.campaign:
            raise ValidationError("A UserNotification cannot reference both a Notification and a Campaign.")
        if not self.notification and not self.campaign:
            raise ValidationError("A UserNotification must reference either a Notification or a Campaign.")

    def __str__(self):
        # Show which type it is referencing
        if self.notification:
            return f"UserNotification - Notification {self.notification.id} for {self.user.username}"
        return f"UserNotification - Campaign {self.campaign.id} for {self.user.username}"
    

from django.db import models
from django.contrib.auth.models import User
from django.db.models import Count, Q, F
from django.utils import timezone
from datetime import timedelta

class MarketingSegment(models.Model):
    """
    Define a set of filtering rules for targeting users.
    Toggle filters in the admin panel and configure each filter with extra parameters.
    """
    name = models.CharField(max_length=100, unique=True)
    joined_after = models.DateField(blank=True, null=True)

    # Filter toggles and configuration fields
    filter_case_count = models.BooleanField(default=False)
    case_count_operator = models.CharField(
        max_length=10, blank=True, null=True, 
        help_text="Enter 'less' or 'more' for filtering on number of cases"
    )
    case_count_value = models.IntegerField(blank=True, null=True)

    filter_case_stage = models.BooleanField(default=False)
    case_stage_value = models.CharField(
        max_length=50, blank=True, null=True,
        help_text="Enter the stage name to filter cases on that stage"
    )
    # sending to a user with particular email address

    trial_email = models.EmailField(blank=True, null=True) 
    filter_email_for_trial = models.BooleanField(default=False)

    filter_has_no_brand_is_brandowner = models.BooleanField(default=False)
    filter_is_brandowner = models.BooleanField(default=False)
    filter_is_factoryowner = models.BooleanField(default=False)

    filter_factory_count = models.BooleanField(default=False)
    factory_count_operator = models.CharField(
        max_length=10, blank=True, null=True,
        help_text="Enter 'less' or 'more' for filtering on number of factories"
    )
    factory_count_value = models.IntegerField(blank=True, null=True)

    # filter_fo_sample_not_dispatched_yet_tracking = models.BooleanField(default=False)

    filter_case_bids = models.BooleanField(default=False)
    case_bids_operator = models.CharField(
        max_length=10, blank=True, null=True,
        help_text="Enter 'exact', 'less', or 'more' for filtering on bid count"
    )
    case_bids_value = models.IntegerField(blank=True, null=True)

    filter_latest_case_days = models.BooleanField(default=False)
    latest_case_days_value = models.IntegerField(blank=True, null=True)

    # This field will store the resulting users after applying all filters.
    filtered_users = models.ManyToManyField(User, related_name='segments', blank=True)

    def __str__(self):
        return self.name

    def get_users(self):
        """
        Return a queryset of User objects that match the segment criteria.
        Each filter is applied only if the toggle is enabled.
        """
        qs = User.objects.all()

        # Filter by city and join date
        
        if self.joined_after:
            qs = qs.filter(date_joined__gte=self.joined_after)
            # Users having less/more than a specified number of cases.
            if self.filter_case_count and self.case_count_value is not None and self.case_count_operator:
                qs = qs.annotate(
                brandowner_case_count=Count('brandowner__case', distinct=True),
                factoryowner_case_count=Count('factoryowner__factories__case', distinct=True)
                ).annotate(
                total_case_count=F('brandowner_case_count') + F('factoryowner_case_count')
                )
                if self.case_count_operator.lower() == 'less':
                    qs = qs.filter(total_case_count__lt=self.case_count_value)
                elif self.case_count_operator.lower() == 'more':
                    qs = qs.filter(total_case_count__gt=self.case_count_value)

        # Users having at least one case on a specific stage.
        if self.filter_case_stage and self.case_stage_value:
            qs = qs.filter(
                Q(brandowner__case__progress_stages__stage__name=self.case_stage_value)
            )

        # Users having a specific email address
        if self.filter_email_for_trial and self.trial_email:
            qs = qs.filter(email=self.trial_email)


        # Users having a related brand (assuming relation via BrandOwner and brands relation)
        if self.filter_has_no_brand_is_brandowner:
            qs = qs.filter(brandowner__brands__isnull=True)
            

        # Users being associated to BrandOwner/FactoryOwner/AM profiles to be selected from bo,fo,am
        if self.filter_is_brandowner:
            qs = qs.filter(brandowner__isnull=False)
        if self.filter_is_factoryowner:
            qs = qs.filter(factoryowner__isnull=False)


        # Users having less/greater than x factories (via FactoryOwner)
        if self.filter_factory_count and self.factory_count_value is not None and self.factory_count_operator:
            qs = qs.annotate(factory_count=Count('factoryowner__factories'))
            if self.factory_count_operator.lower() == 'less':
                qs = qs.filter(factory_count__lt=self.factory_count_value)
            elif self.factory_count_operator.lower() == 'more':
                qs = qs.filter(factory_count__gt=self.factory_count_value)

        # Users with sample orders with empty tracking data.


        # Users having at least one case with a specific number of bids. - not working
        if self.filter_case_bids and self.case_bids_value is not None and self.case_bids_operator:
            qs = qs.annotate(total_bids=Count('cases__bids', distinct=True))

            if self.case_bids_operator.lower() == 'exact':
                qs = qs.filter(total_bids=self.case_bids_value)
            elif self.case_bids_operator.lower() == 'less':
                qs = qs.filter(total_bids__lt=self.case_bids_value)
            elif self.case_bids_operator.lower() == 'more':
                qs = qs.filter(total_bids__gt=self.case_bids_value)

        # Users whose latest case was created more than x days ago.
        if self.filter_latest_case_days and self.latest_case_days_value is not None:
            threshold_date = timezone.now() - timedelta(days=self.latest_case_days_value)
            
            qs = qs.filter(brandowner__cases__start_date__lte=threshold_date)

        return qs.distinct()

    def update_filtered_users(self):
        """
        Updates the filtered_users field with the result of get_users().   
        """
        users_qs = self.get_users()
        # Set the many-to-many relation to the new queryset
        self.filtered_users.set(users_qs)



from django.db import models
from django.utils import timezone
from django.core.exceptions import ValidationError

def validate_channels(value):
    valid_channels = ['email', 'sms', 'whatsapp']
    for channel in value:
        if channel not in valid_channels:
            raise ValidationError(f"Invalid channel: {channel}")

class Campaign(models.Model):
    """
    Represents a marketing campaign with a specific segment and template.
    """
    STATUS_CHOICES = (
        ('draft', 'Draft'),
        ('scheduled', 'Scheduled'),
        ('sending', 'Sending'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    )

    name = models.CharField(max_length=255)
    segment = models.ForeignKey(MarketingSegment, on_delete=models.CASCADE)
    template = models.ForeignKey(NotificationTemplate, on_delete=models.CASCADE)
    scheduled_time = models.DateTimeField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    channels = models.JSONField(
        default=list, blank=True, null=True,
        validators=[validate_channels]
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    def is_ready_to_send(self):
        """
        Checks if it's time to send the campaign (i.e., now >= scheduled_time).
        """
        if self.scheduled_time and timezone.now() >= self.scheduled_time:
            return True
        return False
