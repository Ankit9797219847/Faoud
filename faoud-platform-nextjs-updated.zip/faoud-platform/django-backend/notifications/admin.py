from django.contrib import admin
from django import forms
# Register your models here.
from django.contrib import admin
from .models import NotificationTemplate, Notification, UserNotification, Campaign
from .tasks import send_notification_task

CHANNEL_CHOICES = [
    ('email', 'Email'),
    ('sms', 'SMS'),
    ('whatsapp', 'WhatsApp'),
]

class CampaignForm(forms.ModelForm):
    channels = forms.MultipleChoiceField(
        choices=CHANNEL_CHOICES, required=False,
        widget=forms.CheckboxSelectMultiple
    )
    class Meta:
        model = Campaign
        fields = '__all__'

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.channels = self.cleaned_data['channels']
        if commit:
            instance.save()
        return instance

@admin.register(NotificationTemplate)
class NotificationTemplateAdmin(admin.ModelAdmin):
    list_display = ('name', 'channel')
    search_fields = ('name', 'channel')
    ordering = ('-id',)

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('id', 'type', 'template', 'created_at', 'scheduled_time')
    list_filter = ('type', 'template__channel')
    actions = ['send_selected_notifications']
    ordering = ('-created_at',)

    def send_selected_notifications(self, request, queryset):
        for notification in queryset:
            send_notification_task.delay(notification.id, ['email', 'sms', 'whatsapp'], {})
        self.message_user(request, "Selected notifications have been queued for sending.")
    send_selected_notifications.short_description = "Send selected notifications"

@admin.register(UserNotification)
class UserNotificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'notification','campaign', 'is_read', 'sent_at')
    list_filter = ('is_read', 'sent_at')
    search_fields = ('user__username', 'notification__template__name')
    ordering = ('-sent_at',)



from django.contrib import admin
from django.contrib import messages
from .models import MarketingSegment, Campaign, NotificationTemplate


@admin.register(MarketingSegment)
class MarketingSegmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'joined_after', 'filtered_user_count')
    readonly_fields = ('filtered_user_count',)
    actions = ['update_filtered_users']

    def filtered_user_count(self, obj):
        return obj.filtered_users.count()
    filtered_user_count.short_description = "Filtered Users Count"

    def update_filtered_users(self, request, queryset):
        """
        Admin action to update the filtered users for selected MarketingSegments.
        """
        for segment in queryset:
            segment.update_filtered_users()
        self.message_user(request, "Filtered users updated for selected segments.", messages.SUCCESS)
    update_filtered_users.short_description = "Update filtered users for selected segments"

@admin.register(Campaign)
class CampaignAdmin(admin.ModelAdmin):
    form = CampaignForm
    list_display = ('name', 'segment', 'template', 'scheduled_time', 'status')
    actions = ['schedule_campaign']

    def schedule_campaign(self, request, queryset):
        """
        A custom admin action that schedules the selected campaigns
        by setting status to 'scheduled' and scheduled_time to now if not set.
        """
        for campaign in queryset:
            if campaign.status == 'draft':
                if not campaign.scheduled_time:
                    from django.utils import timezone
                    campaign.scheduled_time = timezone.now()
                campaign.status = 'scheduled'
                campaign.save()
        self.message_user(request, "Selected campaigns have been scheduled.")
    schedule_campaign.short_description = "Schedule selected campaigns"
