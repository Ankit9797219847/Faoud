import os

# Base directory of your Django project
base_dir = os.path.dirname(os.path.abspath(__file__))

# App directories and their models
apps_models = {
    "case": [
        '''from django.db import models

class Service(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Stage(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Case(models.Model):
    services = models.ManyToManyField(Service, default=0)
    stages = models.ManyToManyField(Stage, default=0)
    quantity = models.PositiveIntegerField(default=0)
    eta = models.DateField(default='2021-09-01')
    am = models.ManyToManyField('user.AM', related_name='cases')
    formulation = models.ForeignKey('formulation.Formulation', on_delete=models.CASCADE, default=0)
    product = models.ForeignKey('product.Product', on_delete=models.CASCADE, default=0)
    delivery_address = models.ForeignKey('utils.Address', on_delete=models.CASCADE, related_name='brand_address', default=1)
    factory = models.ForeignKey('supply.Factory', on_delete=models.CASCADE, default=0)
    factory_quote = models.TextField(default='0')
    bids = models.ManyToManyField('supply.Bid', related_name='cases')

    def __str__(self):
        return f"Case {self.id}"

class ProgressStage(models.Model):
    NAME_CHOICES = [
        ('choice1', 'Formulation'),
        ('choice2', 'PM'),
        ('choice3', 'RM'),
        ('choice4', 'Licensing'),
        ('choice5', 'Label'),
        ('choice6', 'Production'),
        ('choice7', 'QA'),
        ('choice8', 'Packaging'),
        ('choice9', 'Shipping'),
    ]

    name = models.CharField(max_length=100)
    multi_choice = models.CharField(max_length=50, choices=NAME_CHOICES, default='choice1')
    estd_time_reqd = models.DurationField(default='0')
    completion_date = models.DateField(null=True, blank=True)
    order_in_timeline = models.IntegerField(default=0)
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name='progress_stages', default=0)

    def __str__(self):
        return f"Progress Stage {self.name} for Case {self.case.id}"'''
    ],
    "user": [
        '''from django.db import models

class BrandOwner(models.Model):
    name = models.CharField(max_length=100)
    contact = models.CharField(max_length=100)
    email = models.EmailField()
    lightning_off = models.TextField()

    def __str__(self):
        return self.name

class Formulator(models.Model):
    name = models.CharField(max_length=100)
    age = models.PositiveIntegerField()
    employee_id = models.CharField(max_length=100)
    formulations = models.ManyToManyField('formulation.Formulation', related_name='formulators')
    skills = models.TextField()

    def __str__(self):
        return self.name

class AM(models.Model):
    name = models.CharField(max_length=100)
    contact = models.CharField(max_length=100)
    email = models.EmailField()
    case = models.ForeignKey('case.Case', on_delete=models.CASCADE, related_name='ams')

    def __str__(self):
        return self.name'''
    ],
    "product": [
        '''from django.db import models

class Product(models.Model):
    name = models.CharField(max_length=100)
    form_factor = models.CharField(max_length=100)
    stages = models.TextField()

    def __str__(self):
        return self.name

class Questionnaire(models.Model):
    id_name = models.CharField(max_length=100)
    domestic = models.TextField()
    audit = models.TextField()
    answer = models.TextField()

    def __str__(self):
        return self.id_name

class QuestionnaireAnswer(models.Model):
    questionnaire = models.ForeignKey(Questionnaire, on_delete=models.CASCADE)
    answer = models.TextField()

    def __str__(self):
        return f"Answer for {self.questionnaire.id_name}"

class Question(models.Model):
    questionnaire = models.ForeignKey(Questionnaire, on_delete=models.CASCADE)
    text = models.TextField()

    def __str__(self):
        return self.text'''
    ],
    "supply": [
        '''from django.db import models

class RMSupplier(models.Model):
    name = models.CharField(max_length=100)
    rm = models.TextField()

    def __str__(self):
        return self.name

class PMSupplier(models.Model):
    material_shape = models.CharField(max_length=100)
    same_as_rm = models.BooleanField()

    def __str__(self):
        return self.material_shape

class Factory(models.Model):
    PRODUCT_TYPE_CHOICES = [
        ('type1', 'Type 1'),
        ('type2', 'Type 2'),
        ('type3', 'Type 3'),
    ]

    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    type_of_products = models.CharField(max_length=50, choices=PRODUCT_TYPE_CHOICES)
    cases = models.ManyToManyField('case.Case', related_name='factories')
    licenses = models.TextField()

    def __str__(self):
        return self.name

class Bid(models.Model):
    factory = models.ForeignKey(Factory, on_delete=models.CASCADE)
    quote = models.TextField()
    eta = models.DateField()
    case = models.ForeignKey('case.Case', on_delete=models.CASCADE, related_name='bids_cases')

    def __str__(self):
        return f"Bid {self.id} for Case {self.case.id} by Factory {self.factory.name}"'''
    ],
    "formulation": [
        '''from django.db import models

class Formulation(models.Model):
    briefs = models.ManyToManyField('utils.Brief', related_name='formulations_added_or_edited_by_am')
    product = models.ForeignKey('product.Product', on_delete=models.CASCADE, related_name='formulations')
    formulators = models.ManyToManyField('user.Formulator', related_name='formulations')
    documents = models.FileField(upload_to='formulation_documents/', blank=True, null=True)

    def __str__(self):
        return self.id'''
    ],
    "comms": [
        '''from django.db import models

class Chat(models.Model):
    name = models.CharField(max_length=100)
    content = models.TextField()
    case = models.ForeignKey('case.Case', on_delete=models.CASCADE, related_name='chats')

    def __str__(self):
        return self.name'''
    ],
    "utils": [
        '''from django.db import models

class Brand(models.Model):
    id_name = models.CharField(max_length=100)
    short_name = models.CharField(max_length=100)
    type_of_product = models.CharField(max_length=100)
    address = models.TextField()

    def __str__(self):
        return self.id_name

class Address(models.Model):
    id_name = models.CharField(max_length=100)
    address = models.TextField()
    name_for_interview = models.TextField()

    def __str__(self):
        return self.id_name

class Brief(models.Model):
    id_name = models.CharField(max_length=100)
    activity = models.TextField()
    quote = models.TextField()
    formulation = models.TextField()

    def __str__(self):
        return self.id_name'''
    ],
    "materials": [
        '''from django.db import models

class RawMaterial(models.Model):
    id_name = models.CharField(max_length=100)
    current_status = models.TextField()
    suppliers = models.TextField()

    def __str__(self):
        return self.id_name

class PackagingMaterial(models.Model):
    id_name = models.CharField(max_length=100)
    current_status = models.TextField()
    suppliers = models.TextField()

    def __str__(self):
        return self.id_name'''
    ],
}

# Function to write models to the respective app directories
def write_models(app_name, models):
    models_path = os.path.join(base_dir, app_name, 'models.py')
    with open(models_path, 'w') as file:
        file.write("from django.db import models\n\n")
        file.write("\n\n".join(models))

# Write models to each app
for app, models in apps_models.items():
    write_models(app, models)
