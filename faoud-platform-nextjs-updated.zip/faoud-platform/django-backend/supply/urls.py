from django.urls import path, include
from rest_framework.routers import DefaultRouter

from case.views import AvailableFactoriesView
from .views import AccountManagerFactoryCreateView, AccountManagerFactoryDashboardView, AccountManagerTrackingView, ActiveTagsView, AMPermissionsCheckView, BidViewSet, BrandOwnerBidsView, BrandOwnerTrackingView, CaseBidAndFactoryDetailsView, CaseListForBiddingView, CategorySubcategoriesView, DeselectFactoryView, DocumentUploadView, FactoryAutoBidSubcategoriesView, FactoryCategoriesView, FactoryDiffView, FactoryDocumentUploadView, FactoryFilteredView, FactoryMiniCreateView, FactoryOwnerTrackingView, FactorySubcategoriesView, FactorySuggestiveSearchView, FactoryViewSet, ManageBidsView, PMBrandDataView, PaginatedCaseListView, RMBrandDataView, UpdateCaseWithFactoryView, UsedSubcategoriesView, UserBidsView, GuestBidCreateView

router = DefaultRouter()
router.register(r'factories', FactoryViewSet, basename='factory')
router.register(r'bids', BidViewSet, basename='bid')


urlpatterns = [
    # Account Manager Permissions Check
    path('am/permissions/', AMPermissionsCheckView.as_view(), name='am-permissions'),
    
    # Account Manager Factory Dashboard - separate endpoint
    path('am/factories/dashboard/', AccountManagerFactoryDashboardView.as_view(), name='am-factory-dashboard'),
    
    # Account Manager Factory Filtering - new modular filtering endpoint
    path('am/factories/filtered/', FactoryFilteredView.as_view(), name='am-factory-filtered'),
    
    # Account Manager Factory Creation - for creating factories on behalf of factory owners
    path('am/factories/create/', AccountManagerFactoryCreateView.as_view(), name='am-factory-create'),
    
    # Factories
    path('factories/', FactoryViewSet.as_view({'get': 'list', 'post': 'create'}), name='factory-list-create'),
    path('factories/<int:pk>/', FactoryViewSet.as_view({'get': 'retrieve', 'put': 'update', 'delete': 'destroy','patch': 'update',}), name='factory-detail'),
    # Case list for bidding for FactoryOwners (Only cases in FactorySelection stage and without factory assigned)
    path('cases/bidding/', CaseListForBiddingView.as_view(), name='case-list-for-bidding'),
    path("factories/minimal/", FactoryMiniCreateView.as_view(),
     name="factory-mini-create"),
    # Manage Bids by Account Manager
    path('cases/<int:case_id>/bids/', ManageBidsView.as_view(), name='manage-bids'),

    # Brand Owner can view bids for a specific product and case
    path('cases/<int:case_id>/bid-list/', BrandOwnerBidsView.as_view(), name='brand-owner-bids'),
    path('bids/tags/', ActiveTagsView.as_view(), name='active-tags-list'),
        path(
        'factories/<int:factory_id>/documents/<str:section>/',
        DocumentUploadView.as_view(),
        name='factory-doc-upload'
    ),
    # change-log diff
    path('factories/<int:pk>/diff/', FactoryDiffView.as_view(), name='factory-diff'),
    # Bids CRUD
    path('bids/', BidViewSet.as_view({'get': 'list', 'post': 'create'}), name='bid-list-create'),
    path('bids/<int:pk>/', BidViewSet.as_view({'get': 'retrieve', 'put': 'update', 'patch': 'partial_update', 'delete': 'destroy'}), name='bid-detail'),
    path('bids/guest/', GuestBidCreateView.as_view(), name='guest-bid-create'),
    path('user/bids/', UserBidsView.as_view(), name='user-bids'),
    path('factories/suggestive-search/', FactorySuggestiveSearchView.as_view(), name='factory-suggestive-search'),
    path('cases/<int:case_id>/bid-factory/', CaseBidAndFactoryDetailsView.as_view(), name='case-bid-factory-details'),

    # Update case with selected factory and bid
    path('cases/<int:case_id>/update-factory/<int:factory_id>/', UpdateCaseWithFactoryView.as_view(), name='update-case-with-factory'),


    path("factories/<int:factory_id>/documents/", FactoryDocumentUploadView.as_view()),

    # New Bind and Deselect Factory View
    path('cases/<int:case_id>/deselect-factory/<int:factory_id>/', DeselectFactoryView.as_view(), name='deselect-factory-from-case'),

        
    # RMBrandData URLs
    path('cases/<int:case_id>/rm-brand-data/', RMBrandDataView.as_view(), name='rm-brand-data'),
    
    # PMBrandData URLs
    path('cases/<int:case_id>/pm-brand-data/', PMBrandDataView.as_view(), name='pm-brand-data'),

    # Factory Owner Tracking (Input tracking details)
    path(
        "factory-owner/sample-orders/<int:bid_id>/tracking/",
        FactoryOwnerTrackingView.as_view(),
        name="factory-owner-tracking",
    ),

    # Account Manager Tracking (Confirm details)
    path(
        "account-manager/sample-orders/<int:bid_id>/tracking/",
        AccountManagerTrackingView.as_view(),
        name="account-manager-tracking",
    ),

    # Brand Owner Tracking (Fetch confirmed details)
    path(
        "brand-owner/sample-orders/<int:bid_id>/tracking/",
        BrandOwnerTrackingView.as_view(),
        name="brand-owner-tracking",
    ),
    path('factories/<int:factory_id>/categories/', FactoryCategoriesView.as_view(), name='factory-categories'),
    path('factories/<int:factory_id>/subcategories/', FactorySubcategoriesView.as_view(), name='factory-subcategories'),
    path('categories/<int:category_id>/subcategories/', CategorySubcategoriesView.as_view(), name='category-subcategories'),
    path('factories/<int:factory_id>/used-subcategories/', UsedSubcategoriesView.as_view(), name='factory-used-subcategories'),
    path("factories/<int:factory_id>/autobid-subcategories/",FactoryAutoBidSubcategoriesView.as_view(),name="factory-autobid-subcategories",),
    path('cases/paginated/', PaginatedCaseListView.as_view(), name='paginated-case-list'),

]

