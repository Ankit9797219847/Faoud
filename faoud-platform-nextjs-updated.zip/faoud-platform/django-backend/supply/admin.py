from django.contrib import admin
from .models import Document, FactoryDocument, RMSupplier, PMSupplier, Factory, Bid,SampleOrderTracking

class FactoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'display_categories', 'display_subcategories', 'created_at', 'updated_at')
    list_filter = ('created_at', 'updated_at')
    ordering = ('-updated_at',)
    filter_horizontal = ('categories','subcategories')

    def display_categories(self, obj):
        return ", ".join([c.name for c in obj.categories.all()])
    display_categories.short_description = "Categories"

    def display_subcategories(self, obj):
        return ", ".join([s.name for s in obj.subcategories.all()])
    display_subcategories.short_description = "Subcategories"

class BidAdmin(admin.ModelAdmin):
    list_display = ('display_bid_info','created_at','updated_at')
    list_filter = ('created_at', 'updated_at')
    ordering = ('-updated_at',)
    filter_horizontal = ('machinery_flows',)

    def display_bid_info(self, obj):
        return str(obj)

    display_bid_info.short_description = "Bid Information"

admin.site.register(RMSupplier)
admin.site.register(PMSupplier)
admin.site.register(Factory, FactoryAdmin)
admin.site.register(Bid,BidAdmin)
# register factory document model and add filters as many possible
class FactoryDocumentAdmin(admin.ModelAdmin):
    list_display = ('name', 'file', 'doc_type', )
    list_filter = ('doc_type', )
    search_fields = ('name',)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs
    
admin.site.register(FactoryDocument, FactoryDocumentAdmin)
admin.site.register(Document)
admin.site.register(SampleOrderTracking)

from .models import Tag

@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ('code', 'label', 'active')
    list_filter = ('active',)
    search_fields = ('code', 'label')
