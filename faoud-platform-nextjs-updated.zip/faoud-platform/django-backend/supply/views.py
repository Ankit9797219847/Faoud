from django.utils import timezone
from django.forms import ValidationError
from django.shortcuts import get_object_or_404
from rest_framework import serializers, viewsets, response
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import PermissionDenied
from rest_framework.pagination import PageNumberPagination

from case.models import Case, ProgressStage, Stage
from case.serializers import CaseSerializer
from payments.models import Feature, UserFeature
from process.models import FacilityLine
from product.models import Product
from user import permissions
from user.models import FactoryOwner
from user.permissions import IsAccountManager, IsBrandOwner, IsFactoryOwner, IsPrivilegedAccountManager, IsNormalAccountManager
from .models import Document, SampleOrderTracking, Tag, FactoryDocument
from .models import Bid, Factory
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework import generics, viewsets
from .models import Bid
from .serializers import AccountManagerTrackingSerializer, BasicSerializer, BidSerializer, BidWithFactorySerializer, CategorySerializer, DirectorSerializer,  ExportSerializer, FactoryDocumentSerializer, FactoryMiniCreateSerializer, PMBrandDataSerializer, RMBrandDataSerializer, TagSerializer
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from rest_framework.response import Response
from rest_framework import status

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import get_object_or_404
from .models import RMBrandData, PMBrandData
import json


from .serializers import FactoryBaseSerializer

from django.shortcuts import get_object_or_404
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Factory
from .serializers import FactorySerializer

from .help import anonymize_factory_data
from django.db.models import Count, Q
from django.db import transaction
from django.contrib.auth.models import User
from django.utils.text import slugify
import re
import secrets
from rest_framework.permissions import AllowAny
from user.utils import send_confirm_set_password_email
from django.contrib.contenttypes.models import ContentType
from leads.models import LeadItem



class FactorySuggestiveSearchView(APIView):
    permission_classes = []  # Open access since no auth is required

    def get(self, request, *args, **kwargs):
        # Get the requested product type from the user answers
        product_type = request.query_params.get('product_type', None)

        if product_type:
            # Use icontains for a case-insensitive, partial match
            factories = Factory.objects.filter(type_of_products__icontains=product_type)
        else:
            # Return all factories if no product_type is provided
            factories = Factory.objects.all()

        # Limit to a maximum of 10 factories
        factory_count = factories.count()

        # If we have fewer than 10 factories, add placeholders
        if factory_count < 12:
            placeholders = [
                {
                    'name': f'Industry {i+1}',
                    'phone': 'N/A',
                    'email': 'N/A',
                    'type_of_products': product_type if product_type else 'N/A',
                    'licenses': 'None',
                    'capacity': 0,
                    'price_per_unit': '0.00',
                    'website': None,
                    'address': 'N/A',
                    'image': 'https://www.cosmeticsmanufacturer.in/wp-content/uploads/2022/11/cosmetic-manufecturing.jpg',
                } for i in range(12 - factory_count)
            ]

            # Combine real factories with placeholders
            serializer = FactorySerializer(factories, many=True)
            return Response(serializer.data + placeholders, status=status.HTTP_200_OK)

        # If we have 10 or more factories, return the first 10
        serializer = FactorySerializer(factories[:12], many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class GuestBidCreateView(APIView):
    """
    Public endpoint to submit a bid as a guest factory owner.
    Steps (atomic):
    - Create a User (inactive) and FactoryOwner profile
    - Create a minimal Factory for that owner
    - Create a Bid against the provided case using that factory

    Request (multipart/form-data):
    - email (str), phone (str), factory_name (str, optional)
    - case (int), quote_text (str/decimal), eta (date, optional)
    - document_files[] (files, optional)
    """
    permission_classes = [AllowAny]
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request):
        email = (request.data.get('email') or '').strip().lower()
        phone = (request.data.get('phone') or '').strip()
        factory_name = (request.data.get('factory_name') or '').strip()
        case_id = request.data.get('case')
        quote_text = request.data.get('quote_text', '')
        eta = request.data.get('eta', None)

        if not email or not phone or not case_id:
            return Response({
                'error': 'email, phone and case are required'
            }, status=status.HTTP_400_BAD_REQUEST)

        case = get_object_or_404(Case, id=case_id)

        # Create everything in a single transaction
        with transaction.atomic():
            # 1) Create User
            # Username rule: first 6 characters of the email's local part
            local = (email.split('@')[0] or 'guest')
            # Keep display name similar to before for factory naming
            name_parts = [p for p in re.split(r"[^a-zA-Z]+", local) if p]
            display_name_base = (name_parts[0].capitalize() if name_parts else "Guest")

            username_base = (local[:6] or 'guest')
            candidate = username_base
            counter = 2
            while User.objects.filter(username=candidate).exists():
                candidate = f"{username_base}{counter}"
                counter += 1

            username = candidate
            # Generate a secure temporary password (Django's make_random_password may not exist in newer versions)
            tmp_password = secrets.token_urlsafe(16)
            user = User.objects.create(username=username, email=email, is_active=False)
            user.set_password(tmp_password)
            user.save()

            # 2) Create FactoryOwner profile
            fo = FactoryOwner.objects.create(
                user=user,
                name=factory_name or f"{display_name_base}'s Factory",
                contact_phone=phone,
                contact_email=email,
                terms_accepted=True,
                terms_accepted_at=timezone.now(),
                terms_version_accepted='v1.0'
            )

            # 3) Create minimal Factory
            factory_payload = {
                'name': factory_name or f"{display_name_base}'s Factory",
            }
            factory_serializer = FactoryMiniCreateSerializer(
                data=factory_payload,
                context={'factory_owner': fo}
            )
            factory_serializer.is_valid(raise_exception=True)
            factory = factory_serializer.save()
            fo.factories.add(factory)

            # 4) Create Bid
            documents = request.FILES.getlist('document_files')
            bid_payload = {
                'factory': factory.id,
                'case': case.id,
                'quote_text': quote_text,
                'document_files': documents,
            }
            if eta:
                bid_payload['eta'] = eta
            bid_serializer = BidSerializer(data=bid_payload, context={'request': request})
            bid_serializer.is_valid(raise_exception=True)
            bid = bid_serializer.save()

        # Send the same email as manufacturer homepage signup (confirm + set password)
        try:
            send_confirm_set_password_email(user)
        except Exception:
            # Non-fatal: continue even if email sending fails
            pass

        # Ensure the factory lead shows the new factory owner's user as creator
        try:
            ct = ContentType.objects.get_for_model(Factory)
            LeadItem.objects.filter(source_ct=ct, source_id=factory.id).update(created_by=user)
        except Exception:
            pass

        # Return created bid
        return Response(BidSerializer(bid, context={'request': request}).data, status=status.HTTP_201_CREATED)

class FactoryMiniCreateView(APIView):
    permission_classes = [IsFactoryOwner]

    def post(self, request):
        serializer = FactoryMiniCreateSerializer(
            data=request.data,
            context={'factory_owner': request.user.factoryowner}
        )
        factory_owner = get_object_or_404(FactoryOwner, user=request.user)
        serializer.is_valid(raise_exception=True)
        factory = serializer.save()
        # Add the newly created factory to the factory_owner.factories ManyToMany field
        factory_owner.factories.add(factory)

        response_data = FactoryMiniCreateSerializer(factory).data
        # Ensure the corresponding factory lead shows the creator (FO)
        try:
            ct = ContentType.objects.get_for_model(Factory)
            LeadItem.objects.filter(source_ct=ct, source_id=factory.id).update(created_by=request.user)
        except Exception:
            pass
        return Response(response_data, status=201)


class AccountManagerFactoryCreateView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request):
        # Get factory owner ID from request data
        factory_owner_id = request.data.get('factory_owner_id')
        if not factory_owner_id:
            return Response(
                {'error': 'factory_owner_id is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            factory_owner = FactoryOwner.objects.get(id=factory_owner_id)
        except FactoryOwner.DoesNotExist:
            return Response(
                {'error': 'Factory owner not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Create a copy of request data without factory_owner_id for serializer
        factory_data = request.data.copy()
        factory_data.pop('factory_owner_id', None)
        
        serializer = FactoryMiniCreateSerializer(
            data=factory_data,
            context={'factory_owner': factory_owner}
        )
        serializer.is_valid(raise_exception=True)
        factory = serializer.save()
        
        # Add the newly created factory to the factory_owner.factories ManyToMany field
        factory_owner.factories.add(factory)

        response_data = FactoryMiniCreateSerializer(factory).data
        # Override lead creator to AM who performed creation
        try:
            ct = ContentType.objects.get_for_model(Factory)
            LeadItem.objects.filter(source_ct=ct, source_id=factory.id).update(created_by=request.user)
        except Exception:
            pass
        return Response(response_data, status=status.HTTP_201_CREATED)



class FactoryViewSet(viewsets.ModelViewSet):
    queryset = Factory.objects.all()
    serializer_class = FactorySerializer
    permission_classes = [IsAuthenticated]


    def get_queryset(self):
        queryset = super().get_queryset().annotate(
            factory_line_count=Count('facility_lines', distinct=True),
            autobid_count=Count('auto_bid_configs', distinct=True),
        )
        user = self.request.user

        if hasattr(user, 'factoryowner'):
            queryset = queryset.filter(factory_owner=user.factoryowner)
        elif hasattr(user, 'am'):
            queryset = queryset  # AMs see all

        # optional verified filter
        verified_param = self.request.query_params.get('verified')
        if verified_param in ('1', 'true', 'True'):
            queryset = queryset.filter(verified=True)

        # case_id filter (keep your existing category/subcategory matching)
        case_id = self.request.query_params.get('case_id', None)
        if case_id:
            try:
                case = Case.objects.get(id=case_id)
            except Case.DoesNotExist:
                raise ValidationError("Case not found.")
            product = case.product
            if not product or not product.category or not product.subcategory:
                return queryset.none()
            queryset = queryset.filter(
                categories=product.category,
                subcategories=product.subcategory
            )
        return queryset

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        serializer = self.get_serializer(queryset, many=True)
        data = serializer.data

        if hasattr(request.user, 'brandowner'):
            anonymized_data = [anonymize_factory_data(factory) for factory in data]
            return Response(anonymized_data)
        return Response(data)

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        data = serializer.data

        if hasattr(request.user, 'brandowner'):
            anonymized_data = anonymize_factory_data(data)
            return Response(anonymized_data)
        return Response(data)


    def perform_create(self, serializer):
        if not hasattr(self.request.user, 'factoryowner'):
            raise ValidationError("The authenticated user is not a Factory Owner")

        factory_owner = get_object_or_404(FactoryOwner, user=self.request.user)
        factory = serializer.save()
        factory.factory_owner = factory_owner
        factory.save()
        factory_owner.factories.add(factory)
        factory_owner.save()
        self._handle_documents(self.request.FILES.getlist('documents'), factory)


        
    def perform_update(self, serializer):
        instance_before = self.get_object()
        
        # Check if verification status is being changed
        is_verification_change = 'verified' in serializer.validated_data
        
        if is_verification_change:
            # Only privileged AMs (SuperAM/MNGMNT) can change verification status
            if not (hasattr(self.request.user, 'am') and 
                    self.request.user.groups.filter(name__in=['superAM', 'MNGMNT']).exists()):
                raise PermissionDenied("Only Super Account Managers and Management Account Managers can change factory verification status.")
        
        # For normal AMs, check if they're trying to edit a verified factory
        if hasattr(self.request.user, 'am'):
            is_normal_am = not self.request.user.groups.filter(name__in=['superAM', 'MNGMNT']).exists()
            if is_normal_am and instance_before.verified and not is_verification_change:
                raise PermissionDenied("Normal Account Managers cannot edit verified factories. Only unverified factories can be edited.")
        
        changed = {
            k for k, v in serializer.validated_data.items()
            if getattr(instance_before, k) != v
        }
        
        factory = serializer.save()
        
        # Auto-unverify when factory owner makes changes (not AM changes)
        if changed and hasattr(self.request.user, "factoryowner"):
            factory.verified = False
            factory.save(update_fields=["verified"])


class FactoryDocumentUploadView(generics.CreateAPIView):
    """
    POST /factories/<id>/documents/
    Body (multipart): file, name (optional), doc_type (= CORE|EXPORT|EXTRA)
    """
    serializer_class   = FactoryDocumentSerializer
    permission_classes = [IsFactoryOwner]
    parser_classes     = (MultiPartParser, FormParser)

    def perform_create(self, serializer):
        factory_id = self.kwargs["factory_id"]
        factory    = get_object_or_404(Factory, pk=factory_id)
        doc = serializer.save(factory=factory, name=self.request.data.get("name") or
                              self.request.FILES["file"].name)

        # mark unverified if owner uploads
        if hasattr(self.request.user, "factoryowner"):
            factory.verified = False
            factory.save(update_fields=["verified"])

        return doc


class CaseBidAndFactoryDetailsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        if not case.factory:
            return Response({"error": "No factory selected for this case."}, status=status.HTTP_404_NOT_FOUND)

        bid = Bid.objects.filter(case=case, factory=case.factory).first()
        if not bid:
            return Response({"error": "No bid found for the selected factory in this case."}, status=status.HTTP_404_NOT_FOUND)

        serializer = BidWithFactorySerializer(bid)
        data = serializer.data

        if hasattr(request.user, 'brandowner'):
            data['factory'] = anonymize_factory_data(data['factory'], bid.id)
        return Response(data, status=status.HTTP_200_OK)





class CaseListForBiddingView(APIView):
    permission_classes = [IsFactoryOwner]

    def get(self, request):
        factory_owner_user = request.user

        # Get the factory owner linked to the authenticated user
        factory_owner = getattr(factory_owner_user, 'factoryowner', None)
        if not factory_owner:
            return Response({"error": "Not associated with any FactoryOwner account."}, status=status.HTTP_403_FORBIDDEN)

        # Get all factories owned by this factory owner
        owner_factories = Factory.objects.filter(factory_owner=factory_owner)

        # Get the "FactorySelection" stage
        factory_selection_stage = Stage.objects.filter(order=0).first()
        if not factory_selection_stage:
            return Response({"error": "FactorySelection stage not found."}, status=status.HTTP_404_NOT_FOUND)

        # Fetch cases in FactorySelection stage, completed, and not yet assigned to any factory
        cases = Case.objects.filter(
            progress_stages__stage=factory_selection_stage,
            progress_stages__completion_date__isnull=False,
            factory__isnull=True
        ).distinct()

        # Filter cases based on category and subcategory match
        filtered_cases = []
        for case in cases:
            product = case.product
            if product and product.category and product.subcategory:
                match_found = owner_factories.filter(
                    categories__id=product.category.id,
                    subcategories__id=product.subcategory.id
                ).exists()
                if match_found:
                    filtered_cases.append(case)

        serializer = CaseSerializer(filtered_cases, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)



    

class ManageBidsView(APIView):
    permission_classes = [IsAccountManager]

    def get(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        bids = Bid.objects.filter(case=case)
        serializer = BidSerializer(bids, many=True, context={'request': request})
        return Response(serializer.data, status=status.HTTP_200_OK)

    def patch(self, request, bid_id):
        bid = get_object_or_404(Bid, id=bid_id)
        tag = request.data.get('tag')

        if tag not in dict(Bid.TAG_CHOICES):
            return Response({"error": "Invalid tag."}, status=status.HTTP_400_BAD_REQUEST)

        bid.tag = tag
        bid.save()

        return Response({"message": f"Bid {bid_id} tagged as {tag}."}, status=status.HTTP_200_OK)
    


    

class BrandOwnerBidsView(APIView):
    permission_classes = [IsBrandOwner ]

    def get(self, request, case_id):
        case = get_object_or_404(Case, id=case_id, brand_owner=request.user.brandowner)
        bids = Bid.objects.filter(case=case).exclude(tag__isnull=True).exclude(tag='')
        serializer = BidSerializer(bids, many=True, context={'request': request})
        bids_data = serializer.data

        for bid in bids_data:
            if bid.get('factory'):
                bid['factory'] = anonymize_factory_data(bid['factory'],bid['id'])
        return Response(bids_data, status=status.HTTP_200_OK)







from .help import anonymize_factory_data
from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Bid
from .serializers import BidSerializer
from .help import anonymize_factory_data

class IsAMOrFO(permissions.BasePermission):
    def has_permission(self, request, view):
        u = request.user
        return hasattr(u, 'am') or hasattr(u, 'factoryowner')
class BidViewSet(viewsets.ModelViewSet):
    queryset = Bid.objects.all()
    serializer_class = BidSerializer
    permission_classes = [IsAuthenticated]

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context.update({"request": self.request})
        return context
    
    def create(self, request, *args, **kwargs):
        # Only AMs or FactoryOwners can create bids
        if not IsAMOrFO().has_permission(request, self):
            return Response({"detail": "Only Account Managers or Factory Owners can create bids."},
                            status=status.HTTP_403_FORBIDDEN)
        # Note: Unverified factories are allowed to bid. The serializer accepts all factories
        # (no verification gating in queryset), and this is intentional for the current flow.
        return super().create(request, *args, **kwargs)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()

        # Restrict updates to when the status is 'in_review'
        if instance.status != 'in_review':
            return Response(
                {"detail": "Updates are only allowed while status is 'in_review'."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Update fields if provided in the request
        if 'status' in request.data:
            instance.status = request.data.get('status')
        if 'tag' in request.data:
            instance.tag = request.data.get('tag')
        if 'quote_bo' in request.data:
            instance.quote_bo = request.data.get('quote_bo')
        if partial:
            instance.tag = None

        # Serialize the updated instance
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)  # This already saves the instance

        # Modify response for BrandOwner
        response_data = serializer.data
        user = request.user
        if hasattr(user, 'brandowner') and response_data.get('factory'):
            response_data['factory'] = anonymize_factory_data(response_data['factory'])

        return Response(response_data)
                

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        serializer = self.get_serializer(queryset, many=True)
        data = serializer.data

        # Anonymize data for Brand Owners
        if hasattr(request.user, 'brandowner'):
            anonymized_data = []
            for bid in data:
                if bid.get('factory'):
                    bid['factory'] = anonymize_factory_data(bid['factory'], bid['id'])
                anonymized_data.append(bid)
            return Response(anonymized_data)

        return Response(data)

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        data = serializer.data

        # Anonymize data for Brand Owners
        if hasattr(request.user, 'brandowner') and data.get('factory'):
            data['factory'] = anonymize_factory_data(data['factory'])

        return Response(data)






class UserBidsView(APIView):
    permission_classes = [IsAuthenticated, IsFactoryOwner]

    def get(self, request):
        # Assuming `FactoryOwner` is associated with the authenticated user
        factoryowner = request.user.factoryowner
        factories = Factory.objects.filter(factory_owner=factoryowner)

        if not factories.exists():
            return Response({"error": "No factories found for the user"}, status=status.HTTP_404_NOT_FOUND)

        # Fetch all bids associated with the factories owned by the user
        bids = Bid.objects.filter(factory__in=factories)

        # Serialize the bids
        serializer = BidSerializer(bids, many=True,context={'request': request})

        return Response(serializer.data, status=status.HTTP_200_OK)
    
class UpdateCaseWithFactoryView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, case_id, factory_id):
        bid_id = request.query_params.get('bid_id')
        # Get the case and factory objects
        case = get_object_or_404(Case, id=case_id)
        factory = get_object_or_404(Factory, id=factory_id)
        bid = get_object_or_404(Bid, id=bid_id)
        case.bidSelected = bid
        Bid.objects.filter(case=case).update(status='locked')
        # # Fetch the bid associated with the selected factory for the case
        # selected_bid = Bid.objects.filter(case=case, factory=factory).first()

        # if not selected_bid:
        #     return Response({"error": "No bid found for this case and factory."}, status=status.HTTP_404_NOT_FOUND)

        # # Set the status of the selected bid to 'accepted'
        # selected_bid.status = 'accepted'
        # selected_bid.save()

        # # Set the status of all other bids related to the case to 'rejected'
        # Bid.objects.filter(case=case).exclude(id=selected_bid.id).update(status='rejected')

        # Update the case with the selected factory
        case.factory = factory
        case.save()

        # 2. Mark the "FactorySelection" stage as COMPLETED
        factory_selection_stage = Stage.objects.get(name="Factory Selection")
        fs_progress, _ = ProgressStage.objects.get_or_create(
            case=case,
            stage=factory_selection_stage,
            defaults={'order_in_timeline': factory_selection_stage.order}
        )
        if not fs_progress.completion_date:
            fs_progress.completion_date = timezone.now().date()
            fs_progress.save()

        # 3. Create/mark the "Orders" stage as ACTIVE (not completed)
        orders_stage = Stage.objects.get(name="Orders")
        orders_progress, created = ProgressStage.objects.get_or_create(
            case=case,
            stage=orders_stage,
            defaults={'order_in_timeline': orders_stage.order}
        )
        # We do NOT set `completion_date` because we only want it
        # completed once the user actually pays the ADVANCE or final.

        return Response({"message": "Case updated with selected factory and bids status updated."}, status=status.HTTP_200_OK)
    


class DeselectFactoryView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, case_id, factory_id):
        # Get the case and factory objects
        case = get_object_or_404(Case, id=case_id)
        factory = get_object_or_404(Factory, id=factory_id)

        # Ensure that the factory to be deselected is the current factory for the case

        case.factory = None  # Set the factory to None to deselect it
        case.bidSelected = None  # Optionally reset the selected bid if needed
        case.save()

        Bid.objects.filter(case=case).update(status='in_review')
        Bid.objects.filter(case=case, sample_paid = True).update(status='SAMPLE_ORDERED')

        manufacturing_feature = Feature.objects.filter(name="Manufacturing Cost").first()
        if manufacturing_feature:
            user_feature = UserFeature.objects.filter(
                feature=manufacturing_feature, user=request.user, case=case
            ).first()
            if user_feature:
                user_feature.delete()

         # 2. Revert the "FactorySelection" stage (remove completion_date)
        factory_selection_stage = Stage.objects.get(name="Factory Selection")
        fs_progress = ProgressStage.objects.filter(case=case, stage=factory_selection_stage).first()
        if fs_progress:
            fs_progress.completion_date = None
            fs_progress.save()

        # 3. Remove or revert the “Orders” stage
        #    You can do either:
        orders_stage = Stage.objects.get(name="Orders")
        orders_progress = ProgressStage.objects.filter(case=case, stage=orders_stage).first()
        if orders_progress:
            # Option A: Delete it entirely
            orders_progress.delete()
            # Option B: Just un-complete it, if you prefer:
            # orders_progress.completion_date = None
            # orders_progress.save()

            # Optionally reset the status of all bids related to the case if necessary
            # Bid.objects.filter(case=case).update(status='pending')  # Reset status as desired

        return Response({"message": "Factory deselected from case."}, status=status.HTTP_200_OK)

    



def bindingCasewithFactory(case_id):
    # Get the case and factory objects
    case = get_object_or_404(Case, id=case_id)
    factory = case.factory
    bid = case.bidSelected

    if not bid:
        return Response({"error": "No bid found for the bid id provided"}, status=status.HTTP_404_NOT_FOUND)

    # Set the status of the selected bid to 'accepted'
    bid.status = 'accepted'
    bid.save()

    # Set the status of all other bids related to the case to 'rejected'
    Bid.objects.filter(case=case).exclude(id=bid.id).update(status='rejected')

    # Update the case with the selected factory
    case.factory = factory
    case.save()


from rest_framework.parsers import JSONParser
    
class RMBrandDataView(APIView):
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def get(self, request, case_id):
        """Fetch PMBrandData for a specific case"""
        case = get_object_or_404(Case, id=case_id)
        pm_data = get_object_or_404(RMBrandData, case=case)
        serializer = RMBrandDataSerializer(pm_data)
        return Response(serializer.data, status=status.HTTP_200_OK)



    def post(self, request, case_id):
        """Create or update RMBrandData, but only if verified_by_account_manager is False."""
        case = get_object_or_404(Case, id=case_id)
        
        try:
            rm_data = RMBrandData.objects.get(case=case)
            if rm_data.verified_by_account_manager:
                return Response(
                    {'detail': 'Cannot update RMBrandData as it has been verified by the account manager.'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            # Update existing RMBrandData
            serializer = RMBrandDataSerializer(rm_data, data=request.data, partial=True)
        except RMBrandData.DoesNotExist:
            # Create new RMBrandData
            serializer = RMBrandDataSerializer(data=request.data, partial=True)
        
        if serializer.is_valid():
            serializer.save(case=case)
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def patch(self, request, case_id):
        """Update RMBrandData fields later"""
        case = get_object_or_404(Case, id=case_id)
        rm_data = get_object_or_404(RMBrandData, case=case)
        serializer = RMBrandDataSerializer(rm_data, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)      


class PMBrandDataView(APIView):

    def get(self, request, case_id):
        """Fetch PMBrandData for a specific case"""
        case = get_object_or_404(Case, id=case_id)
        pm_data = get_object_or_404(PMBrandData, case=case)
        serializer = PMBrandDataSerializer(pm_data)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, case_id):
        """Create or update PMBrandData, but only if approved_by_account_manager is False."""
        case = get_object_or_404(Case, id=case_id)
        
        try:
            pm_data = PMBrandData.objects.get(case=case)
            if pm_data.checked_by_account_manager:
                return Response(
                    {'detail': 'Cannot update PMBrandData as it has been approved by the account manager.'},
                    status=status.HTTP_400_BAD_REQUEST
                )
            # Update existing PMBrandData
            serializer = PMBrandDataSerializer(pm_data, data=request.data, partial=True)
        except PMBrandData.DoesNotExist:
            # Create new PMBrandData
            serializer = PMBrandDataSerializer(data=request.data, partial=True)
        
        if serializer.is_valid():
            serializer.save(case=case)
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def patch(self, request, case_id):
        """Update PMBrandData fields later"""
        case = get_object_or_404(Case, id=case_id)
        pm_data = get_object_or_404(PMBrandData, case=case)
        serializer = PMBrandDataSerializer(pm_data, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    


from .serializers import FactoryOwnerTrackingSerializer, SampleOrderTrackingSerializer

class FactoryOwnerTrackingView(APIView):
    """ Allows Factory Owners to create or update tracking details for a bid """
    permission_classes = [IsAuthenticated]

    def get(self, request, bid_id):
        """ Fetch or initialize tracking details for a specific bid """
        bid = get_object_or_404(Bid, id=bid_id)
        tracking, created = SampleOrderTracking.objects.get_or_create(bid=bid)
        serializer = SampleOrderTrackingSerializer(tracking)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, bid_id):
        """ Allow Factory Owner to update tracking details """
        bid = get_object_or_404(Bid, id=bid_id)
        tracking, created = SampleOrderTracking.objects.get_or_create(bid=bid)

        serializer = FactoryOwnerTrackingSerializer(tracking, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class AccountManagerTrackingView(APIView):
    """ Allows Account Manager to confirm tracking details """
    permission_classes = [IsAuthenticated, IsAccountManager]

    def get(self, request, bid_id):
        """ Fetch tracking details submitted by the Factory Owner """
        tracking = get_object_or_404(SampleOrderTracking, bid_id=bid_id)
        serializer = SampleOrderTrackingSerializer(tracking)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, bid_id):
        """ Confirm tracking details and make them visible to the Brand Owner """
        tracking = get_object_or_404(SampleOrderTracking, bid_id=bid_id)

        serializer = AccountManagerTrackingSerializer(tracking, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save(is_confirmed_by_am=True)  # Mark as confirmed
            return Response(serializer.data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class BrandOwnerTrackingView(APIView):
    permission_classes = [IsAuthenticated, IsBrandOwner]
    """ Allows Brand Owners to fetch confirmed tracking details """

    def get(self, request, bid_id):
        """ Fetch only confirmed tracking details """
        tracking = get_object_or_404(SampleOrderTracking, bid_id=bid_id, is_confirmed_by_am=True)
        serializer = AccountManagerTrackingSerializer(tracking)  # Fetch AM fields
        return Response(serializer.data, status=status.HTTP_200_OK)



class ActiveTagsView(APIView):
    permission_classes = [IsAuthenticated]  # or [] if you prefer open access

    def get(self, request, *args, **kwargs):
        tags = Tag.objects.filter(active=True)
        serializer = TagSerializer(tags, many=True)
        return Response(serializer.data, status=200)
    




SECTION_SERIALIZERS = {
    'basic':    BasicSerializer,
    'category': CategorySerializer,
    'director': DirectorSerializer,
    'exports':  ExportSerializer,
}

# ---------- one-file upload ----------
from .models import Document
from .serializers import FactoryBaseSerializer  # reuse

class DocumentUploadView(generics.CreateAPIView):
    queryset           = Document.objects.none()
    permission_classes = (IsFactoryOwner,)
    parser_classes     = (MultiPartParser, FormParser)

    def post(self, request, factory_id, section):
        factory = get_object_or_404(Factory, pk=factory_id)
        self.check_object_permissions(request, factory)

        file = request.FILES.get('file')
        if not file:
            return Response({'detail': 'file required'}, status=400)
        Document.objects.create(factory=factory, name=file.name, file=file)

        # invalidate verification
        if hasattr(request.user, 'factoryowner'):
            factory.verified = False
            factory.save()

        return Response(FactoryBaseSerializer(factory).data, status=201)


# ---------- diff history ----------
class FactoryDiffView(generics.RetrieveAPIView):
    permission_classes = (IsFactoryOwner,)
    serializer_class   = FactoryBaseSerializer
    queryset           = Factory.objects.all()

    def get(self, request, *args, **kwargs):
        factory   = self.get_object()
        version_a = factory.versions.all()[0]               # latest
        version_b = factory.versions.all()[1] if factory.versions.count() > 1 else None
        from .utils import diff
        return Response({
            'latest': version_a.snapshot,
            'previous': version_b.snapshot if version_b else {},
            'changes': diff(version_b.snapshot if version_b else {}, version_a.snapshot),
        })
    
from rest_framework.permissions import AllowAny
from product.serializers import CategorySerializer, SubcategorySerializer
from product.models import Category
class FactoryCategoriesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, factory_id):
        try:
            factory = Factory.objects.get(id=factory_id)
        except Factory.DoesNotExist:
            return Response({"error": "Factory not found"}, status=404)

        categories = factory.categories.all()
        return Response(CategorySerializer(categories, many=True).data)


class FactorySubcategoriesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, factory_id):
        try:
            factory = Factory.objects.get(id=factory_id)
        except Factory.DoesNotExist:
            return Response({"error": "Factory not found"}, status=404)

        subcategories = factory.subcategories.all()
        return Response(SubcategorySerializer(subcategories, many=True).data)


class CategorySubcategoriesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, category_id):
        try:
            category = Category.objects.get(id=category_id)
        except Category.DoesNotExist:
            return Response({"error": "Category not found"}, status=404)

        subcategories = category.subcategories.all()
        return Response(SubcategorySerializer(subcategories, many=True).data)

class UsedSubcategoriesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, factory_id):
        # Optional: check if factory exists
        if not Factory.objects.filter(id=factory_id).exists():
            return Response({"detail": "Factory not found"}, status=404)

        # Get all facility lines for the factory
        facility_lines = FacilityLine.objects.filter(factory_id=factory_id)

        # Extract all subcategory IDs across all lines
        used_ids = (
            FacilityLine.subcategories.through.objects
            .filter(facilityline__in=facility_lines)
            .values_list('subcategory_id', flat=True)
            .distinct()
        )

        return Response(list(used_ids))



from core.models import AutoBidConfig          # adjust import path

class FactoryAutoBidSubcategoriesView(APIView):
    """
    Return **only the sub-category IDs** already used in Auto-Bid configs
    for the given factory.
    """
    permission_classes = [AllowAny]

    def get(self, request, factory_id):
        used_ids = (
            AutoBidConfig.objects
            .filter(factory_id=factory_id)
            .values_list("subcategory_id", flat=True)
            .distinct()
        )
        return Response(list(used_ids))

class PaginatedCaseListView(APIView):
    permission_classes = [IsAuthenticated]

    class CasePagination(PageNumberPagination):
        page_size = 10

    def get(self, request):
        paginator = self.CasePagination()
        factory_selection_stage = Stage.objects.filter(order=0).first()
        if not factory_selection_stage:
            return Response({"error": "FactorySelection stage not found."}, status=status.HTTP_404_NOT_FOUND)
        cases = Case.objects.filter(
            progress_stages__stage=factory_selection_stage,
            progress_stages__completion_date__isnull=False,
            factory__isnull=True
        ).distinct()

        # Filter out cases where product is None
        cases = cases.exclude(product__isnull=True)
        queryset = cases
        page = paginator.paginate_queryset(queryset, request)
        serializer = CaseSerializer(page, many=True)
        return paginator.get_paginated_response(serializer.data)


class AccountManagerFactoryDashboardView(APIView):
    """
    Endpoint for Account Managers to view all factories in the same format
    as Factory Owner dashboard, but without filtering to specific factory owner.
    """
    permission_classes = [IsAccountManager]

    def get(self, request, *args, **kwargs):
        # Get all factories with the same annotations as FactoryViewSet
        queryset = Factory.objects.all().annotate(
            factory_line_count=Count('facility_lines', distinct=True),
            autobid_count=Count('auto_bid_configs', distinct=True),
        )

        # Apply optional filters (same as FactoryViewSet)
        verified_param = request.query_params.get('verified')
        if verified_param in ('1', 'true', 'True'):
            queryset = queryset.filter(verified=True)

        # case_id filter for category/subcategory matching
        case_id = request.query_params.get('case_id', None)
        if case_id:
            try:
                case = Case.objects.get(id=case_id)
            except Case.DoesNotExist:
                raise ValidationError("Case not found.")
            product = case.product
            if not product or not product.category or not product.subcategory:
                return Response([], status=status.HTTP_200_OK)
            queryset = queryset.filter(
                categories=product.category,
                subcategories=product.subcategory
            )

        # Serialize using the same FactorySerializer as Factory Owner dashboard
        serializer = FactorySerializer(queryset, many=True)
        
        # Return the same format as Factory Owner sees (no anonymization)
        return Response(serializer.data, status=status.HTTP_200_OK)


class FactoryFilteredView(APIView):
    """
    Advanced filtering endpoint for Account Manager factory list with modular filter support
    GET /am/factories/filtered/?categories=1,2&subcategories=3,4&name=abc&verified=true
    """
    permission_classes = [IsAccountManager]

    def get_filter_options(self, request=None):
        """
        Get available filter options for the frontend
        This method defines all available filters - easily extensible for future filters
        Supports dynamic subcategories based on selected categories
        """
        from product.models import Category, Subcategory
        
        # Get all categories that have associated factories
        categories = list(Category.objects.filter(
            factoriesCategory__isnull=False
        ).distinct().values('id', 'name'))
        
        # Get subcategories dynamically based on selected categories
        selected_categories = None
        if request:
            categories_param = request.query_params.get('categories')
            if categories_param:
                try:
                    selected_categories = [int(x.strip()) for x in categories_param.split(',') if x.strip()]
                except (ValueError, TypeError):
                    pass
        
        # Filter subcategories based on selected categories if provided
        if selected_categories:
            # Get all subcategories for the selected categories
            subcategories = list(Subcategory.objects.filter(
                category__id__in=selected_categories
            ).values('id', 'name', 'category'))
        else:
            # Return empty subcategories when no categories are selected
            subcategories = []
        
        # Get available document types from FactoryDocument model
        document_types = [
            {'value': 'CORE', 'label': 'Core Documents'},
            {'value': 'EXPORT', 'label': 'Export Documents'}, 
            {'value': 'EXTRA', 'label': 'Extra Documents'}
        ]
        
        # Define specific document names as requested
        document_names = [
            {'value': 'PRODUCT_DOC', 'label': 'Product Document'},
            {'value': 'SITE_MASTER', 'label': 'Site Master File'},
            {'value': 'BIS_FSSAI', 'label': 'BIS/FSSAI Certificate'},
            {'value': 'POLLUTION_CERT', 'label': 'Pollution Certificate'},
            {'value': 'FACTORY_LICENSE', 'label': 'Factory License'},
            {'value': 'GST', 'label': 'GST Certificate'},
        ]
        
        return {
            'categories': categories,
            'subcategories': subcategories,
            'document_types': document_types,
            'document_names': document_names,
            'filters_available': {
                'name': {'type': 'text', 'description': 'Filter by factory name'},
                'categories': {'type': 'multiselect', 'description': 'Filter by categories'},
                'subcategories': {'type': 'multiselect', 'description': 'Filter by subcategories'},
                'verified': {'type': 'boolean', 'description': 'Filter by verification status'},
                'exports_supported': {'type': 'boolean', 'description': 'Filter by export capability'},
                'capacity_min': {'type': 'number', 'description': 'Minimum capacity filter'},
                'capacity_max': {'type': 'number', 'description': 'Maximum capacity filter'},
                'operational_since': {'type': 'number', 'description': 'Filter by operational year'},
                'documents': {'type': 'multiselect', 'description': 'Filter by document types'},
                'document_logic': {'type': 'select', 'options': ['AND', 'OR'], 'description': 'Logic for multiple document filters'}
            }
        }

    def apply_filters(self, queryset, request):
        """
        Apply filters to the queryset based on request parameters
        This method handles all filtering logic - easily extensible
        """
        # Name filter (case-insensitive partial match)
        name = request.query_params.get('name')
        if name:
            queryset = queryset.filter(name__icontains=name)

        # Categories filter (multiple IDs)
        categories = request.query_params.get('categories')
        if categories:
            try:
                category_ids = [int(x.strip()) for x in categories.split(',') if x.strip()]
                if category_ids:
                    queryset = queryset.filter(categories__id__in=category_ids)
            except (ValueError, TypeError):
                pass  # Invalid category IDs, skip filter

        # Subcategories filter (multiple IDs)
        subcategories = request.query_params.get('subcategories')
        if subcategories:
            try:
                subcategory_ids = [int(x.strip()) for x in subcategories.split(',') if x.strip()]
                if subcategory_ids:
                    queryset = queryset.filter(subcategories__id__in=subcategory_ids)
            except (ValueError, TypeError):
                pass  # Invalid subcategory IDs, skip filter

        # Verified filter
        verified = request.query_params.get('verified')
        if verified is not None:
            if verified.lower() in ('true', '1', 'yes'):
                queryset = queryset.filter(verified=True)
            elif verified.lower() in ('false', '0', 'no'):
                queryset = queryset.filter(verified=False)

        # Exports supported filter
        exports_supported = request.query_params.get('exports_supported')
        if exports_supported is not None:
            if exports_supported.lower() in ('true', '1', 'yes'):
                queryset = queryset.filter(exports_supported=True)
            elif exports_supported.lower() in ('false', '0', 'no'):
                queryset = queryset.filter(exports_supported=False)

        # Capacity range filters
        capacity_min = request.query_params.get('capacity_min')
        if capacity_min:
            try:
                queryset = queryset.filter(capacity__gte=int(capacity_min))
            except (ValueError, TypeError):
                pass

        capacity_max = request.query_params.get('capacity_max')
        if capacity_max:
            try:
                queryset = queryset.filter(capacity__lte=int(capacity_max))
            except (ValueError, TypeError):
                pass

        # Operational since filter
        operational_since = request.query_params.get('operational_since')
        if operational_since:
            try:
                queryset = queryset.filter(operational_since__gte=int(operational_since))
            except (ValueError, TypeError):
                pass

        # Document filters
        documents = request.query_params.get('documents')
        if documents:
            try:
                # Parse document filters - specific document names
                doc_filters = [x.strip() for x in documents.split(',') if x.strip()]
                if doc_filters:
                    # Get logic type (AND/OR) - default to OR
                    document_logic = request.query_params.get('document_logic', 'OR').upper()
                    
                    # Define mapping for specific document names to search patterns
                    doc_name_mapping = {
                        'PRODUCT_DOC': 'Product',
                        'SITE_MASTER': 'Site Master',
                        'BIS_FSSAI': ['BIS', 'FSSAI'],
                        'POLLUTION_CERT': ['Pollution', 'Environment'],
                        'FACTORY_LICENSE': ['Factory License', 'License'],
                        'GST': 'GST',
                    }
                    
                    if document_logic == 'AND':
                        # Factory must have ALL specified documents
                        for doc_filter in doc_filters:
                            if doc_filter in doc_name_mapping:
                                patterns = doc_name_mapping[doc_filter]
                                if isinstance(patterns, list):
                                    # Multiple patterns - any pattern should match
                                    q_obj = Q()
                                    for pattern in patterns:
                                        q_obj |= Q(compliance_documents__name__icontains=pattern)
                                    queryset = queryset.filter(q_obj)
                                else:
                                    # Single pattern
                                    queryset = queryset.filter(compliance_documents__name__icontains=patterns)
                            elif doc_filter in ['CORE', 'EXPORT', 'EXTRA']:
                                # Filter by document type
                                queryset = queryset.filter(compliance_documents__doc_type=doc_filter)
                            else:
                                # Filter by document name (partial match)
                                queryset = queryset.filter(compliance_documents__name__icontains=doc_filter)
                    else:
                        # Factory must have ANY of the specified documents (OR logic)
                        q_objects = Q()
                        
                        for doc_filter in doc_filters:
                            if doc_filter in doc_name_mapping:
                                patterns = doc_name_mapping[doc_filter]
                                if isinstance(patterns, list):
                                    # Multiple patterns - any pattern should match
                                    for pattern in patterns:
                                        q_objects |= Q(compliance_documents__name__icontains=pattern)
                                else:
                                    # Single pattern
                                    q_objects |= Q(compliance_documents__name__icontains=patterns)
                            elif doc_filter in ['CORE', 'EXPORT', 'EXTRA']:
                                # Filter by document type
                                q_objects |= Q(compliance_documents__doc_type=doc_filter)
                            else:
                                # Filter by document name (partial match)
                                q_objects |= Q(compliance_documents__name__icontains=doc_filter)
                        
                        if q_objects:
                            queryset = queryset.filter(q_objects)
                    
                    # Ensure distinct results since we're joining with documents
                    queryset = queryset.distinct()
                    
            except (ValueError, TypeError):
                pass  # Invalid document filters, skip filter

        return queryset

    def get(self, request, *args, **kwargs):
        # Check if requesting filter options
        if request.query_params.get('get_options') == 'true':
            return Response(self.get_filter_options(request), status=status.HTTP_200_OK)

        # Get base queryset with annotations
        queryset = Factory.objects.all().annotate(
            factory_line_count=Count('facility_lines', distinct=True),
            autobid_count=Count('auto_bid_configs', distinct=True),
        ).distinct()

        # Apply all filters
        queryset = self.apply_filters(queryset, request)

        # Pagination
        page = request.query_params.get('page', 1)
        limit = request.query_params.get('limit', 10)

        try:
            page = int(page)
            limit = int(limit)
            limit = min(limit, 100)  # Max 100 items per page
        except (ValueError, TypeError):
            page = 1
            limit = 10

        # Apply pagination
        start_index = (page - 1) * limit
        end_index = start_index + limit
        total_count = queryset.count()
        paginated_queryset = queryset[start_index:end_index]

        # Serialize the data
        serializer = FactorySerializer(paginated_queryset, many=True)
        
        # Return paginated response
        return Response({
            'results': serializer.data,
            'count': total_count,
            'page': page,
            'limit': limit,
            'total_pages': (total_count + limit - 1) // limit,
        }, status=status.HTTP_200_OK)


class AMPermissionsCheckView(APIView):
    """
    API to check Account Manager permissions for factory operations
    """
    permission_classes = [IsAccountManager]
    
    def get(self, request):
        user = request.user
        
        # Check if user is Super AM or Management AM
        is_privileged_am = user.groups.filter(name__in=['superAM', 'MNGMNT']).exists()
        is_super_am = user.groups.filter(name='superAM').exists()
        is_management_am = user.groups.filter(name='MNGMNT').exists()
        
        return Response({
            'is_privileged_am': is_privileged_am,
            'is_super_am': is_super_am,
            'is_management_am': is_management_am,
            'can_verify_factories': is_privileged_am,
            'can_edit_verified_factories': is_privileged_am,
            'can_edit_unverified_factories': True,  # All AMs can edit unverified factories
        })
