from django.forms.models import model_to_dict
from .models import IMMUTABLE

EXCLUDE = set(IMMUTABLE) | {
    'id', 'created_at', 'updated_at', 'verified',
    'factory_owner', 'history', 'versions'
}

def percent_complete(factory):
    d = model_to_dict(factory, exclude=('image',))   # image is optional
    total   = len([k for k in d if k not in EXCLUDE])
    filled  = sum(bool(v) for k, v in d.items() if k not in EXCLUDE)
    return round((filled / total) * 100) if total else 0
