from decimal import Decimal
from django.db import models
from django.forms import JSONField, ValidationError
from user.models import FactoryOwner
import datetime


class RMSupplier(models.Model):
    name = models.CharField(max_length=100, default='Supplier')
    address = models.ManyToManyField('utils.Address', related_name='suppliers_address', blank=True)
    rms = models.ManyToManyField('materials.RawMaterial', related_name='rm_suppliers', blank=True)

    def __str__(self):
        return self.name

class PMSupplier(models.Model):
    name = models.CharField(max_length=100, default='Supplier')
    address = models.ManyToManyField('utils.Address', related_name='pm_suppliers_address', blank=True)
    pms = models.ManyToManyField('materials.PackagingMaterial', related_name='pm_suppliers', blank=True)    

    def __str__(self):
        return self.name

from django.db import models

class Document(models.Model):
    factory = models.ForeignKey('Factory', related_name='documents', on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    file = models.FileField(upload_to='factory_documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    bid = models.ForeignKey('Bid', on_delete=models.CASCADE, related_name='documents', null=True, blank=True)


    def __str__(self):
        return f"{self.name} for {self.factory.name}"
from simple_history.models import HistoricalRecords

IMMUTABLE = ('name', 'gst_number', 'legal_entity')

class Factory(models.Model):
    # ---------- immutable ----------
    name            = models.CharField(max_length=100)
    gst_number      = models.CharField(max_length=15, blank=True, null=True)
    legal_entity    = models.CharField(max_length=100, blank=True, null=True)
    category_old = models.ForeignKey(
        'product.Category', null=True, on_delete=models.SET_NULL, related_name='+'
    )
    categories = models.ManyToManyField(
    'product.Category', blank=True, related_name='factoriesCategory'
)

    subcategories = models.ManyToManyField(
        'product.Subcategory', blank=True, related_name='factories'
    )
    # --------------------------------

    # ---------- basic ---------------
    phone           = models.CharField(max_length=15, blank=True, null=True)
    email           = models.EmailField(blank=True, null=True)
    address         = models.CharField(max_length=255, blank=True, null=True)
    website         = models.CharField(max_length=255, blank=True, null=True)
    image           = models.ImageField(
                        upload_to='factory_images/',
                        blank=True, null=True,
                        default='factory_images/factory1.png')
    # ---------- product -------------
    type_of_products= models.TextField(blank=True, null=True)
    licenses        = models.TextField(blank=True, null=True)
    capacity        = models.PositiveIntegerField(null=True, blank=True)
    # ---------- director / poc ------
    director_name   = models.CharField(max_length=100, blank=True, null=True)
    director_phone  = models.CharField(max_length=15,  blank=True, null=True)
    director_email  = models.EmailField(blank=True, null=True)
    poc_name        = models.CharField(max_length=100, blank=True, null=True)
    poc_number      = models.CharField(max_length=15,  blank=True, null=True)
    poc_email       = models.EmailField(blank=True, null=True)
    # ---------- misc ----------------
    exports_supported = models.BooleanField(default=False)
    verified        = models.BooleanField(default=False)
    factory_owner   = models.ForeignKey(
                        FactoryOwner, on_delete=models.CASCADE,
                        related_name='factories_owner', blank=True, null=True)

    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)
    operational_since = models.IntegerField(
                        help_text="Year when the factory started operations",
                        blank=True, null=True
                    )

    # ---------- history / versions --
    history         = HistoricalRecords(inherit=True)          # simple-history
    # keep the light JSON snapshot for “diff tabs”
    versions        = models.ManyToManyField('FactoryVersion', blank=True)

    # ---------- helpers -------------
    @property
    def percent_complete(self):
        from .utils import percent_complete
        return percent_complete(self)

    # -------------------------------
    def save(self, *args, **kwargs):
        creating = self._state.adding   # important!

        if not creating:
            # Only check immutability on updates
            orig = Factory.objects.get(pk=self.pk)
            for f in IMMUTABLE:
                if getattr(orig, f) != getattr(self, f):
                    raise ValidationError(f"{f.replace('_',' ').title()} is immutable.")

        super().save(*args, **kwargs)

        # Create snapshot AFTER saving
        snap, _ = FactoryVersion.objects.get_or_create(
            snapshot=self._dict_light()
        )
        self.versions.add(snap)

    def _dict_light(self):
        fields = [f.name for f in self._meta.fields if f.name != 'image']

        light_data = {}

        for field_name in fields:
            value = getattr(self, field_name)
            field_object = self._meta.get_field(field_name)

            if field_object.is_relation and value is not None:
                light_data[field_name] = value.pk

            elif isinstance(value, (datetime.datetime, datetime.date)):
                light_data[field_name] = value.isoformat()

            else:
                light_data[field_name] = value

        return light_data

class FactoryVersion(models.Model):
    snapshot = models.JSONField()
    created  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return f"Version at {self.created.strftime('%Y-%m-%d %H:%M:%S')}"


from django.db import models


    
class Bid(models.Model):
    STATUS_CHOICES = [
        ('in_review', 'In Review'),
        ('rejected', 'Rejected'),
        ('accepted', 'Accepted'),
        ('locked', 'Locked'),
        ('SAMPLE_ORDERED', 'Sample Ordered'),
    ]

    
    factory = models.ForeignKey(Factory, on_delete=models.CASCADE, related_name='bids_factories', blank=True, null=True)
    quote = models.DecimalField(max_digits=15, decimal_places=2, default=Decimal('0.00'))
    quote_bo = models.DecimalField(max_digits=15, decimal_places=2, default=Decimal('0.00'))
    eta = models.DateField(default='2021-09-01')
    case = models.ForeignKey('case.Case', on_delete=models.CASCADE, related_name='bids_cases', default=0)
    sample_paid = models.BooleanField(default=False)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='in_review')
    tag = models.CharField(max_length=50, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    facility_line = models.ForeignKey(
        'process.FacilityLine',
        on_delete=models.CASCADE,
        related_name='bid_facility_line',
        blank=True,
        null=True
    )
    autobid_parameters = models.ManyToManyField(
        'core.AutoBidConfigParameterValue',
        related_name='param_autobid',
        blank=True
    )

    machinery_flows = models.ManyToManyField(
        'process.MachineryFlow',
        related_name='bid_machinery_flows',
        blank=True,

    )

    def __str__(self):
        return f"Bid {self.id} for Case {self.case.id} by Factory {self.factory.name}"
    
    @property
    def formatted_quote(self):
        try:
            return f"INR {Decimal(self.quote):.2f}"
        except (ValueError, TypeError):
            return "Invalid quote"
        
    @property
    def rank(self):
        """
        Calculate the rank of the bid based on the quote value.
        The bid with the **lowest** quote gets rank 1.
        """
        # Get all bids for the same case, sorted by quote in ascending order
        bids_for_case = Bid.objects.filter(case=self.case).order_by('quote')

        # Convert to list so we can use index lookup
        bids_list = list(bids_for_case)

        try:
            return bids_list.index(self) + 1  # 1-based rank
        except ValueError:
            return None


class SampleOrderTracking(models.Model):
    bid = models.OneToOneField('Bid', on_delete=models.CASCADE, related_name='tracking_details')
    
    # Fields updated by Factory Owner
    tracking_id = models.CharField(max_length=100, blank=True, null=True, help_text="Tracking ID added by factory owner")
    tracking_link = models.URLField(max_length=500, blank=True, null=True, help_text="Tracking link added by factory owner")
    remarks = models.TextField(blank=True, null=True, help_text="Remarks added by factory owner")

    # Fields updated/confirmed by Account Manager
    tracking_id_am = models.CharField(max_length=100, blank=True, null=True, help_text="Tracking ID confirmed by Account Manager")
    tracking_link_am = models.URLField(max_length=500, blank=True, null=True, help_text="Tracking link confirmed by Account Manager")
    remarks_am = models.TextField(blank=True, null=True, help_text="Remarks confirmed by Account Manager")

    # Confirmation flag for Account Manager
    is_confirmed_by_am = models.BooleanField(default=False, help_text="Status indicating if Account Manager has confirmed the details")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Tracking Details for Bid {self.bid.id}"


class RMBrandData(models.Model):
    case = models.OneToOneField('case.Case', on_delete=models.CASCADE, related_name='rm_brand_data')
    document_coa = models.FileField(upload_to='documents/coa/', null=True, blank=True)
    verified_by_account_manager = models.BooleanField(default=False)
    address = models.TextField(null=True, blank=True)
    phone_number = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"RM Data for Case: {self.case.name}"

class PMBrandData(models.Model):
    case = models.OneToOneField('case.Case', on_delete=models.CASCADE, related_name='pm_brand_data')
    address_for_pickup = models.TextField(null=True, blank=True)
    phone_number = models.TextField(null=True, blank=True)
    dispatched = models.BooleanField(default=False)
    checked_by_account_manager = models.BooleanField(default=False)
    factory_address = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"PM Data for Case: {self.case.name}"




class Tag(models.Model):
    code = models.CharField(max_length=50, unique=True)
    label = models.CharField(max_length=255)
    active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.label} ({'Active' if self.active else 'Inactive'})"



class FactoryDocument(models.Model):
    CORE   = "CORE"
    EXPORT = "EXPORT"
    EXTRA  = "EXTRA"
    TYPES  = [(CORE, "Core"), (EXPORT, "Export"), (EXTRA, "Extra")]

    factory   = models.ForeignKey("Factory", on_delete=models.CASCADE,
                                  related_name="compliance_documents")
    name      = models.CharField(max_length=100)
    file      = models.FileField(upload_to="factory_documents/")   # <- real bytes
    doc_type  = models.CharField(max_length=10, choices=TYPES)
    uploaded  = models.DateTimeField(auto_now_add=True)

    def url(self):
        return self.file.url 
