from rest_framework import serializers, viewsets
from rest_framework.permissions import IsAuthenticated

from case.models import Case
from core.models import AutoBidConfigParameterValue
from core.serializers import AutoBidConfigParameterValueSerializer
from process.models import FacilityLine
from process.serializers import FacilityLineSerializer, MachineryFlowSerializer
from product.models import Subcategory
from user.serializers import FactoryOwnerSerializer
from .models import Bid, Document,  Factory, FactoryDocument, PMBrandData, PMSupplier, RMBrandData, RMSupplier, Tag

IMMUTABLE = ['name', 'gst_number', 'legal_entity']

class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['id', 'name', 'file', 'uploaded_at']



from product.models import Category

        
class FactoryMiniCreateSerializer(serializers.ModelSerializer):
    """
    Serializer for minimal factory creation.
    Only the core immutable fields required initially.
    """
    categories = serializers.PrimaryKeyRelatedField(
        many=True,
        queryset=Category.objects.all(),
        required=False
    )

    class Meta:
        model = Factory
        fields = ("id", "name", "gst_number", "legal_entity", "categories", "subcategories", "type_of_products")
        extra_kwargs = {
            "name": {"required": True},
            "gst_number": {"required": False, "allow_null": True, "allow_blank": True},
            "legal_entity": {"required": False, "allow_null": True, "allow_blank": True},
            "categories": {"required": False},
            "subcategories": {"required": False},
            "type_of_products": {"required": False, "allow_null": True, "allow_blank": True},
        }

    def create(self, validated_data):
        subcategories = validated_data.pop('subcategories', None)
        categories = validated_data.pop('categories', None)
        factory_owner = self.context['factory_owner']

        factory = Factory.objects.create(factory_owner=factory_owner, **validated_data)

        if subcategories:
            factory.subcategories.set(subcategories)
        if categories:
            factory.categories.set(categories)

        return factory

    

class FactoryBaseSerializer(serializers.ModelSerializer):
    percent_complete = serializers.IntegerField(read_only=True)

    class Meta:
        model  = Factory
        fields = "__all__"
        read_only_fields = ("factory_owner", *IMMUTABLE, "percent_complete")

    # ---- new logic -------------------------------------------------
    def validate(self, attrs):
        user = self.context["request"].user
        if "verified" in attrs and not hasattr(user, "am"):
            raise serializers.ValidationError(
                {"verified": "Only Account Managers may change this field."}
            )
        return super().validate(attrs)

class FactoryDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model  = FactoryDocument
        fields = ("id", "name", "doc_type", "file", "uploaded")   # `file` gives URL
    
class FactorySerializer(serializers.ModelSerializer):
    factory_owner = FactoryOwnerSerializer(read_only=True)
    compliance_documents = FactoryDocumentSerializer(many=True, read_only=True)
    subcategories = serializers.PrimaryKeyRelatedField(
    queryset=Subcategory.objects.all(),
    many=True,
    required=False
    )
    subcategories_names = serializers.SerializerMethodField()
    percent_complete = serializers.IntegerField(read_only=True)
    factory_line_count = serializers.IntegerField(read_only=True)
    autobid_count = serializers.IntegerField(read_only=True)


    class Meta:
        model = Factory
        fields = '__all__'
        extra_kwargs = {
            'name': {'required': False},
            'gst_number': {'required': False},
            'legal_entity': {'required': False},
        }

    def validate(self, attrs):
        if self.instance:
            for f in ['name','gst_number','legal_entity']:
                if f in attrs and attrs[f] != getattr(self.instance, f):
                    raise serializers.ValidationError({f: 'Immutable once set.'})
        return attrs
            

    def get_subcategories_names(self, instance):
        return [subcat.name for subcat in instance.subcategories.all()]    


from rest_framework import serializers
from .models import Factory, IMMUTABLE



from rest_framework import serializers
from .models import Bid, Factory, Document
from .serializers import FactorySerializer, DocumentSerializer
from django.contrib.contenttypes.models import ContentType
from leads.models import LeadItem

class BidSerializer(serializers.ModelSerializer):
    factory = serializers.PrimaryKeyRelatedField(queryset=Factory.objects.all())
    documents = DocumentSerializer(many=True, read_only=True)
    quote_bo = serializers.SerializerMethodField()
    quote = serializers.SerializerMethodField()
    quote_text = serializers.DecimalField(
        max_digits=10, 
        decimal_places=2, 
        write_only=True, 
        required=False, 
        allow_null=True
    )
    document_files = serializers.ListField(
        child=serializers.FileField(),
        write_only=True,
        required=False,
        allow_empty=True,
    )
    facility_line = FacilityLineSerializer(required=False, allow_null=True)
    autobid_parameters = AutoBidConfigParameterValueSerializer(
        many=True,
        required=False,
        allow_null=True
    )
    machinery_flows = MachineryFlowSerializer(many=True, required=False, allow_null=True)
    rank = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Bid
        fields = [
            'id', 'factory', 'quote', 'eta', 'case', 'status',
            'tag', 'documents', 'document_files', 'quote_bo', 'sample_paid',
            'quote_text', 'facility_line', 'autobid_parameters',
            'machinery_flows',
            'tag', 'documents', 'document_files', 'quote_bo', 'sample_paid',   'quote_text', 'rank' # Added 'quote_text' to fields
        ]

    def get_rank(self, obj):
    
        return obj.rank  # Access the rank property defined in the model    

    def __init__(self, *args, **kwargs):
        super(BidSerializer, self).__init__(*args, **kwargs)
        request = self.context.get('request', None)
        if request:
            user = request.user
            if hasattr(user, 'brandowner'):
                # Brand Owners should not see 'quote_bo'
                self.fields.pop('quote_bo')
            elif not hasattr(user, 'am'):
                # Only Account Managers can see 'quote_bo'
                self.fields.pop('quote_bo')

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        # Serialize factory details
        representation['factory'] = FactorySerializer(instance.factory).data
        return representation

    def get_quote(self, obj):
        user = self.context.get("request").user
        if hasattr(user, 'brandowner') and obj.quote_bo and obj.quote_bo != "0":
            return obj.quote_bo
        return obj.quote

    def get_quote_bo(self, obj):
        user = self.context.get("request").user
        if hasattr(user, 'am'):
            return obj.quote_bo
        return None

    def create(self, validated_data):
        # Extract nested data
        quote = validated_data.pop('quote_text', '')
        document_files = validated_data.pop('document_files', [])
        facility_line_data = self.initial_data.get('facility_line', None)
        autobid_params_data = validated_data.pop('autobid_parameters', [])
        factory = validated_data.pop('factory')
        case = validated_data.pop('case')

        # Create Bid
        bid = Bid.objects.create(
            factory=factory,
            quote=quote,
            case=case,
            **validated_data
        )

        # If needed, create a FacilityLine object
        if facility_line_data:
            fl_obj = FacilityLine.objects.get(id=facility_line_data)
            bid.facility_line = fl_obj
            flows = fl_obj.machinery_flows.all()
            bid.machinery_flows.set(flows)

        # Handle auto-bid logic (example placeholders) with safe guards
        product = getattr(case, 'product', None)
        subcat = getattr(product, 'subcategory', None) if product else None
        if subcat and getattr(subcat, 'auto_bid', False):
            from decimal import Decimal
            bid.tag = "more_bids"
            bid.quote_bo = Decimal(str(quote)) * subcat.multiplier + subcat.additive

        bid.save()

        # Ensure the corresponding LeadItem records the creator
        try:
            req = self.context.get('request')
            user = getattr(req, 'user', None)
            if user and getattr(user, 'id', None):
                ct = ContentType.objects.get_for_model(Bid)
                # Update only the newly created bid's lead
                LeadItem.objects.filter(source_ct=ct, source_id=bid.id).update(created_by=user)
        except Exception:
            # Do not fail bid creation if lead update fails
            pass

        # Attach uploaded documents
        for file in document_files:
            Document.objects.create(
                bid=bid,
                factory=factory,
                file=file,
                name=file.name
            )

        # Create or attach many-to-many AutoBidConfigParameterValue objects
        for param_data in autobid_params_data:
            param_obj = AutoBidConfigParameterValue.objects.create(**param_data)
            bid.autobid_parameters.add(param_obj)

        return bid

    def update(self, instance, validated_data):
        # Extract nested data
        quote = validated_data.pop('quote_text', None)
        document_files = validated_data.pop('document_files', [])
        facility_line_data = validated_data.pop('facility_line', None)
        autobid_params_data = validated_data.pop('autobid_parameters', None)

        user = self.context.get("request").user

        # Update quote only if user can
        if quote is not None:
            if hasattr(user, 'factoryowner') and instance.status == 'in_review':
                instance.quote = quote
            else:
                raise serializers.ValidationError(
                    "You do not have permission to update the quote."
                )

        # Only allow account managers to update quote_bo
        if 'quote_bo' in validated_data:
            if hasattr(user, 'am'):
                instance.quote_bo = validated_data.pop('quote_bo')
            else:
                validated_data.pop('quote_bo', None)

        # Update facility line
        if facility_line_data:
            if instance.facility_line:
                for attr, value in facility_line_data.items():
                    setattr(instance.facility_line, attr, value)
                instance.facility_line.save()
            else:
                instance.facility_line = FacilityLine.objects.create(**facility_line_data)

        # Update M2M field if provided
        if autobid_params_data is not None:
            instance.autobid_parameters.clear()
            for param_data in autobid_params_data:
                param_obj = AutoBidConfigParameterValue.objects.create(**param_data)
                instance.autobid_parameters.add(param_obj)

        # Update other Bid fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # Handle uploaded documents
        for file in document_files:
            Document.objects.create(
                bid=instance,
                factory=instance.factory,
                file=file,
                name=file.name
            )

        return instance


class BidWithFactorySerializer(serializers.ModelSerializer):
    factory = FactorySerializer()  # Nested serializer to include factory details
    documents = DocumentSerializer(many=True, required=False)
    machinery_flows = MachineryFlowSerializer(many=True, required=False)
    class Meta:
            model = Bid
            fields = ['id', 'factory', 'quote', 'eta', 'case', 'status', 'tag', 'documents', 'machinery_flows']

    def create(self, validated_data):
            documents_data = validated_data.pop('documents', [])
            bid = Bid.objects.create(**validated_data)
            for document_data in documents_data:
                Document.objects.create(bid=bid, **document_data)
            return bid

    def update(self, instance, validated_data):
            documents_data = validated_data.pop('documents', [])
            for attr, value in validated_data.items():
                setattr(instance, attr, value)
            instance.save()

            # Update the documents related to the bid
            if documents_data:
                instance.documents.all().delete()  # If you want to replace documents
                for document_data in documents_data:
                    Document.objects.create(bid=instance, **document_data)

            return instance
    
    def validate_tag(self, value):
        """
        Check if 'tag' corresponds to an active Tag in the database.
        """
        if value:
            try:
                db_tag = Tag.objects.get(code=value)
                if not db_tag.active:
                    raise serializers.ValidationError("This tag is not active.")
            except Tag.DoesNotExist:
                raise serializers.ValidationError("This tag does not exist.")
        return value


class SupplierSerializer(serializers.ModelSerializer):


    class Meta:
        model = RMSupplier
        fields = ['id', 'name', 'address']

    class Meta:
        model = PMSupplier
        fields = ['id', 'name', 'address']

class RMBrandDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = RMBrandData
        fields = '__all__'

    def create(self, validated_data):
        case = validated_data.pop('case', None)
        instance = RMBrandData.objects.create(case=case, **validated_data)
        return instance



class PMBrandDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = PMBrandData
        fields = '__all__'

    def create(self, validated_data):
        case = validated_data.pop('case', None)
        instance = PMBrandData.objects.create(case=case, **validated_data)
        return instance
    
from .models import SampleOrderTracking

class SampleOrderTrackingSerializer(serializers.ModelSerializer):
    """ General Serializer for retrieving tracking data """
    class Meta:
        model = SampleOrderTracking
        fields = "__all__"


class FactoryOwnerTrackingSerializer(serializers.ModelSerializer):
    """ Serializer for Factory Owner to update tracking details """
    class Meta:
        model = SampleOrderTracking
        fields = ["tracking_id", "tracking_link", "remarks"]


class AccountManagerTrackingSerializer(serializers.ModelSerializer):
    """ Serializer for Account Manager to confirm tracking details """
    class Meta:
        model = SampleOrderTracking
        fields = ["tracking_id_am", "tracking_link_am", "remarks_am", "is_confirmed_by_am"]

    def validate(self, data):
        """ Ensure Factory Owner has provided tracking details before AM confirms them """
        instance = self.instance
        if not instance.tracking_id or not instance.tracking_link:
            raise serializers.ValidationError("Tracking details must be provided by the factory owner before confirmation.")
        return data



class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ("id", "code", "label", "active")


class BasicSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Factory
        fields = ('phone', 'email', 'address', 'website', 'image')


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model  = Factory
        fields = (
            'category', 'subcategories', 'type_of_products',
            'licenses', 'capacity', 'price_per_unit',
        )


class DirectorSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Factory
        fields = (
            'director_name', 'director_phone', 'director_email',
            'poc_name', 'poc_number', 'poc_email',
        )


class ExportSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Factory
        fields = ('exports_supported', )


