# supply/serializers_public.py
from rest_framework import serializers
from .models import Factory
import random
import string
from product.serializers_public import PublicSubcategorySerializer, PublicCategorySerializer
import re

class PublicFactorySerializer(serializers.ModelSerializer):
    subcategories = PublicSubcategorySerializer(many=True, read_only=True)
    categories = PublicCategorySerializer(many=True, read_only=True)
    class Meta:
        model = Factory
        fields = ['id', 'name', 'image', 'address', 'operational_since','subcategories','categories']

    def to_representation(self, instance):
        data = super().to_representation(instance)
        original_name = data.get('name', '')
        gibberished_name = ''.join(random.choices(string.ascii_letters + string.digits, k=len(original_name)))
        data['name'] = gibberished_name

        address = data.get('address', '')
        if address:
            # Remove trailing pincode if present
            address = address.strip()
            # Remove 5 digit pincode at the end (with optional preceding space)
            address = re.sub(r'\s*\b\d{5}\b$', '', address).strip()
            # Find last comma
            last_comma = address.rfind(',')
            if last_comma != -1:
                last_part = address[last_comma+1:].strip()
            else:
                last_part = address
            # Get last word
            last_word = last_part.split()[-1] if last_part.split() else ''
            data['address'] = last_word

        return data