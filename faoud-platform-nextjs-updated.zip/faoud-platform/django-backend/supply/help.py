def anonymize_factory_data(factory_data, bid_id=None):
    """
    Helper function to anonymize factory and factory owner data for Brand Owners.
    """
    bid_identifier = str(bid_id) if bid_id is not None else ""
    anonymized_factory = {
        "id": factory_data["id"],
        "name": f"Bid {hash(factory_data['name'] + bid_identifier) % 1000}",  # Safe even if bid_id is missing
        "phone": "xxxxxxxxxx",
        "email": "hidden@factory.com",
        "address": "Location Hidden",
        "website": "Not Available",
        "licenses": "Confidential",
        "director_name": None,
        "director_phone": "xxxxxxxxxx",
        "director_email": "hidden@director.com",
        "poc_name": "Not Available",
        "poc_number": "xxxxxxxxxx",
        "poc_email": "hidden@poc.com",
        "type_of_products": factory_data["type_of_products"],
        "capacity": factory_data["capacity"],

        # "price_per_unit": factory_data["price_per_unit"],
        "verified": factory_data["verified"],
        "image": '/assets/fallback-img/fallback_factory.png',
        # "documents": factory_data["documents"],

        "factory_owner": {
            "id": factory_data["factory_owner"]["id"],
            "name": f"Owner {hash(factory_data['factory_owner']['name']) % 1000}",
            "contact_phone": "xxxxxxxxxx",
            "contact_email": "hidden@owner.com",
            "terms_accepted": None,
            "terms_accepted_at": None,
            "terms_version_accepted": None,
            "user": None,
            "factories": [],
            "cases": [],
        },
    }
    return anonymized_factory
