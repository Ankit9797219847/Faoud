from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("supply", "0040_alter_factory_gst_number_alter_factory_legal_entity_and_more"),
    ]

    operations = [
        migrations.AlterField(
            model_name="factory",
            name="type_of_products",
            field=models.TextField(blank=True, null=True),
        ),
        migrations.AlterField(
            model_name="historicalfactory",
            name="type_of_products",
            field=models.TextField(blank=True, null=True),
        ),
    ]
