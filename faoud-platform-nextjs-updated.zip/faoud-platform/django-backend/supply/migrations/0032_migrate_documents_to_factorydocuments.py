
from django.db import migrations

def migrate_documents_to_factorydocuments(apps, schema_editor):
    Document = apps.get_model('supply', 'Document')
    FactoryDocument = apps.get_model('supply', 'FactoryDocument')

    for doc in Document.objects.filter(bid__isnull=True):
        FactoryDocument.objects.create(
            factory=doc.factory,
            name=doc.name,
            file=doc.file,
            doc_type="EXTRA",
            uploaded=doc.uploaded_at
        )

class Migration(migrations.Migration):

    dependencies = [
        ('supply', '0031_remove_factory_price_per_unit_and_more'),
    ]

    operations = [
        migrations.RunPython(migrate_documents_to_factorydocuments, reverse_code=migrations.RunPython.noop),
    ]