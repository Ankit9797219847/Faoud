from rest_framework import serializers
from notifications.notif import send_notification
from payments.utils import add_feature_to_case_and_user
from product.models import Product
from product.serializers import ChosenAnswerSerializer
from formulation.serializers import FormulationSerializer
from product.serializers import ProductSerializer
from supply.serializers import FactorySerializer
from .models import Alert, Case, Service

class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = "__all__"

class CaseUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Case
        fields = ["id", "formulation"]

class CaseSerializer(serializers.ModelSerializer):
    factory = FactorySerializer(read_only=True)
    product = ProductSerializer(read_only=True)
    formulation = FormulationSerializer(read_only=True)
    services = ServiceSerializer(read_only=True, many=True)
    category_slug = serializers.SerializerMethodField()
    subcategory_slug = serializers.SerializerMethodField()
    subcategory_name = serializers.SerializerMethodField()


    product_id = serializers.PrimaryKeyRelatedField(
        queryset=Product.objects.all(), write_only=True, source='product', required=True
    )

    class Meta:
        model = Case
        fields = [
            "id",
            "brand_owner",
            "start_date",
            "services",
            "stages",
            "quantity",
            "eta",
            "am",
            "formulation",
            "product",
            "product_id",
            "delivery_address",
            "factory_quote",
            "bids",
            "factory",
            "category",
            "category_slug",
            "subcategory_slug",
            "subcategory_name",
            "color"
        ]
        read_only_fields = [
            "brand_owner",
            "start_date",
            "services",
            "stages",
            "am",
            "formulation",
            "product",
            "delivery_address",
            "factory_quote",
            "bids",
            "factory",
            "category",
            "category_slug",
            "subcategory_slug",
            "subcategory_name",
            "color"
        ]

    def get_category_slug(self, obj):
        return obj.product.subcategory.category.slug if obj.product and obj.product.subcategory and obj.product.subcategory.category else None

    def get_subcategory_slug(self, obj):
        return obj.product.subcategory.slug if obj.product and obj.product.subcategory else None
    
    def get_subcategory_name(self, obj):
        return obj.product.subcategory.name if obj.product and obj.product.subcategory else None


    def create(self, validated_data):
        product = validated_data.pop('product', None)
        add_feature_to_case_and_user()
        case = Case.objects.create(**validated_data, product=product)
        # Handle other Many-to-Many fields if necessary
        return case

    def update(self, instance, validated_data):
        product = validated_data.pop('product', None)
        if product:
            instance.product = product
            instance.save()
        # Update other fields as necessary
        return instance
    
class AlertSerializer(serializers.ModelSerializer):
    class Meta:
        model = Alert
        fields = [
            "id",
            "case",
            "created_date",
            "done_date",
            "is_done",
            "message",
        ]
        read_only_fields = ["created_date", "done_date"]

class CaseColorUpdateSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Case
        fields = ['color']

    def validate_color(self, value):
        
        valid_colors = [choice[0] for choice in Case.COLOR_CHOICES]
        # Allow an empty string to remove the color
        if value and value not in valid_colors:
            raise serializers.ValidationError(f"'{value}' is not a valid color choice.")
        return value


class CasePriorityUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Case
        fields = ["priority"]

    def validate_priority(self, value):
        valid_priorities = [choice[0] for choice in Case.PRIORITY_CHOICES]
        if value not in valid_priorities:
            raise serializers.ValidationError(f"'{value}' is not a valid priority choice.")
        return value
