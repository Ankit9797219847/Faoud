from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("case", "0017_case_priority"),
    ]

    operations = [
        migrations.AddField(
            model_name="case",
            name="last_opened_by_am_at",
            field=models.DateTimeField(blank=True, db_index=True, null=True),
        ),
        migrations.AlterField(
            model_name="case",
            name="priority",
            field=models.CharField(
                choices=[
                    ("normal", "Normal"),
                    ("priority", "Priority"),
                    ("inactive", "Inactive"),
                    ("dispatched", "Dispatched"),
                ],
                db_index=True,
                default="normal",
                help_text="Simple AM-set case marker for dashboard ranking.",
                max_length=20,
            ),
        ),
    ]
