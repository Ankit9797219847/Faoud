from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("case", "0016_alter_case_color"),
    ]

    operations = [
        migrations.AddField(
            model_name="case",
            name="priority",
            field=models.CharField(
                choices=[("normal", "Normal"), ("priority", "Priority")],
                db_index=True,
                default="normal",
                help_text="Simple AM-set priority marker for dashboard ranking.",
                max_length=20,
            ),
        ),
    ]
