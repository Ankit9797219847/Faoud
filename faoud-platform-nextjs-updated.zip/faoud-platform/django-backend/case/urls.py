from django.urls import path
from .views import  (
    AlertDetailAPIView, AlertListCreateAPIView, ArchiveCaseView, AssignedCasesView, 
    AssignFaoudProductToCaseView, CaseNotesUpdateView, CaseOperationalStatusDeleteView, 
    CaseOperationalStatusUpdateView, CaseOperationalStatusUpsertView, CaseProductHistoryView, 
    CaseAssignmentView, CaseStagePreviewAPIView, CaseStageSummaryAPIView, CaseStageTransitionAPIView,
    CaseUsersView, CaseViews, AvailableFactoriesView, CaseUpdateView, EditCaseProductView,
    GetAvailableStagesView, MarkAlertDoneAPIView, OperationalStatusListView, 
    PublicCaseDetailView, RestoreCaseView, SoftDeleteCaseView, UpdateCaseNameView, 
    UpdateCaseStageView, UpdateCaseColorView, UpdateCasePriorityView
)

urlpatterns = [
    path("cases/list_noprod/", CaseViews.as_view({"get": "list_noprod"})),
    path("cases/list_prod/", CaseViews.as_view({"get": "list_prod"})),
    path(
        "cases/list_brand_owner_dashboard/",
        CaseViews.as_view({"get": "list_brand_owner_dashboard"}),
        name="brand-owner-dashboard-cases",
    ),
    path("cases/list_archived/", CaseViews.as_view({"get": "list_archived"})),
    path(
        "cases/<int:case_id>/update-formulator/<int:formulator_id>/",
        CaseUpdateView.as_view(),
        name="case-update-formulator",
    ),
    path(
        "cases/<int:case_id>/available-factories/",
        AvailableFactoriesView.as_view(),
        name="available-factories",
    ),
    path("cases/<int:case_id>/", CaseViews.as_view({"get": "get_case"})),
    path('cases/list_assigned/', AssignedCasesView.as_view(), name='list-assigned-cases'),
    path('cases/<int:case_id>/stages/', GetAvailableStagesView.as_view(), name='available-stages'),
    path('cases/<int:case_id>/stage-summary/', CaseStageSummaryAPIView.as_view(), name='case-stage-summary'),
    path('cases/<int:case_id>/stage-preview/', CaseStagePreviewAPIView.as_view(), name='case-stage-preview'),
    path('cases/<int:case_id>/stage-transition/', CaseStageTransitionAPIView.as_view(), name='case-stage-transition'),
    path('cases/<int:case_id>/stage/', UpdateCaseStageView.as_view(), name='update-case-stage'),
    path('cases/<int:case_id>/users/', CaseUsersView.as_view(), name='case-users'),
    path('cases/<int:case_id>/assignment/', CaseAssignmentView.as_view(), name='case-assignment'),
    path('cases/<int:case_id>/update-name/', UpdateCaseNameView.as_view(), name='update-case-name'),
    path("alerts/", AlertListCreateAPIView.as_view(), name="alert-list-create"),
    path("alerts/<int:pk>/", AlertDetailAPIView.as_view(), name="alert-detail"),
    path("alerts/<int:pk>/mark_done/", MarkAlertDoneAPIView.as_view(), name="alert-mark-done"),

    path('cases/<int:pk>/archive/', ArchiveCaseView.as_view(), name='case-archive'),
    path('cases/<int:pk>/restore/', RestoreCaseView.as_view(), name='case-restore'),
    path('cases/<int:pk>/soft_delete/', SoftDeleteCaseView.as_view(), name='case-soft-delete'),
    path("seo/cases/<int:case_id>/", PublicCaseDetailView.as_view(), name="public-case-detail"),

    path("cases/<int:case_id>/notes/", CaseNotesUpdateView.as_view(), name="case-notes-update"),
    path("cases/<int:case_id>/ops-status/", CaseOperationalStatusUpsertView.as_view(), name="case-ops-status-upsert"),
    path("cases/<int:case_id>/ops-status/<int:status_id>/", CaseOperationalStatusDeleteView.as_view(), name="case-ops-status-delete"),

    path("ops-status/", OperationalStatusListView.as_view(), name="ops-status-list"),
        path("cases/<int:case_id>/ops-status/<int:status_id>/update/", 
         CaseOperationalStatusUpdateView.as_view(), 
         name="case-ops-status-update"),

    path('cases/<int:case_id>/update-color/', UpdateCaseColorView.as_view(), name='update-case-color'),
    path('cases/<int:case_id>/priority/', UpdateCasePriorityView.as_view(), name='update-case-priority'),
    path('cases/<int:case_id>/assign-faoud-product/', AssignFaoudProductToCaseView.as_view(), name='assign-faoud-product'),
    path('cases/<int:case_id>/products/<int:product_id>/edit/', EditCaseProductView.as_view(), name='edit-case-product'),
    path('cases/<int:case_id>/product-history/', CaseProductHistoryView.as_view(), name='case-product-history'),
]
