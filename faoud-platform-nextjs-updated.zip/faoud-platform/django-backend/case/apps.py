from django.apps import AppConfig


class CaseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'case'

    def ready(self):
        # Import signals here to ensure they are loaded
        import payments.signals
        import case.signals
        import core.signals
        import leads.signals
        import tracking.signals