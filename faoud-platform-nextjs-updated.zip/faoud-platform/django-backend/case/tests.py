from django.contrib.auth.models import Group, User
from django.test import override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient, APITestCase

from case.models import Alert, Case, ProgressStage, Stage
from supply.models import Bid, Factory
from user.models import AM, BrandOwner


@override_settings(ROOT_URLCONF="shadow.urls")
class BrandOwnerDashboardCaseListAPITest(APITestCase):
    def setUp(self):
        self.client = APIClient()
        self.url = reverse("brand-owner-dashboard-cases")
        self.list_prod_url = "/api/cases/list_prod/"

        self.stage_review = Stage.objects.create(name="Review", order=1)
        self.stage_factory = Stage.objects.create(name="Factory Selection", order=2)

        self.brand_user = User.objects.create_user(username="brand-owner", password="pass")
        self.brand_owner = BrandOwner.objects.create(user=self.brand_user, name="Brand Owner")

        self.other_brand_user = User.objects.create_user(username="other-brand", password="pass")
        self.other_brand_owner = BrandOwner.objects.create(user=self.other_brand_user, name="Other Brand Owner")

        self.am_user = User.objects.create_user(username="account-manager", password="pass")
        self.am = AM.objects.create(
            user=self.am_user,
            name="Assigned AM",
            contact_email="am@example.com",
            contact_phone="9999999999",
        )

        self.case = Case.objects.create(
            brand_owner=self.brand_owner,
            name="Visible Case",
            category="npd_without",
            active=0,
        )
        self.case.am.add(self.am)
        ProgressStage.objects.create(
            case=self.case,
            stage=self.stage_review,
            order_in_timeline=1,
            completion_date=None,
        )
        ProgressStage.objects.create(
            case=self.case,
            stage=self.stage_factory,
            order_in_timeline=2,
            completion_date="2026-03-20",
        )

        self.archived_case = Case.objects.create(
            brand_owner=self.brand_owner,
            name="Archived Case",
            category="npd_without",
            active=1,
        )

        self.other_case = Case.objects.create(
            brand_owner=self.other_brand_owner,
            name="Other Brand Case",
            category="npd_without",
            active=0,
        )

        factory = Factory.objects.create(name="Factory One")
        Bid.objects.create(case=self.case, factory=factory, tag="recommended")
        Bid.objects.create(case=self.case, factory=factory, tag="shortlisted")
        Bid.objects.create(case=self.case, factory=factory, tag="")
        Bid.objects.create(case=self.case, factory=factory, tag=None)
        Bid.objects.create(case=self.other_case, factory=factory, tag="recommended")

    def authenticate(self, user):
        self.client.force_authenticate(user=user)

    def test_brand_owner_receives_only_needed_fields_and_visible_bid_count(self):
        self.authenticate(self.brand_user)

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)
        self.assertIn("results", response.data)
        self.assertEqual(len(response.data["results"]), 1)

        item = response.data["results"][0]
        self.assertEqual(item["id"], self.case.id)
        self.assertEqual(item["name"], "Visible Case")
        self.assertEqual(item["visible_bid_count"], 2)
        self.assertEqual(item["category"], "npd_without")

        self.assertEqual(sorted(item.keys()), [
            "am",
            "category",
            "id",
            "name",
            "product",
            "stages",
            "start_date",
            "visible_bid_count",
        ])
        self.assertEqual(item["am"], [{"id": self.am.id, "name": "Assigned AM"}])
        self.assertNotIn("contact_email", item["am"][0])
        self.assertNotIn("contact_phone", item["am"][0])
        self.assertIsNone(item["product"])

    def test_account_manager_cannot_access_brand_owner_dashboard_case_list(self):
        self.authenticate(self.am_user)

        response = self.client.get(self.url)

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_brand_owner_cannot_access_list_prod_anymore(self):
        self.authenticate(self.brand_user)

        response = self.client.get(self.list_prod_url)

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)


@override_settings(ROOT_URLCONF="shadow.urls")
class CaseAssignmentAPITest(APITestCase):
    def setUp(self):
        self.client = APIClient()

        self.super_group = Group.objects.create(name="superAM")
        self.management_group = Group.objects.create(name="MNGMNT")

        self.privileged_user = User.objects.create_user(username="super-am", password="pass")
        self.privileged_am = AM.objects.create(user=self.privileged_user, name="Super AM")
        self.privileged_user.groups.add(self.super_group)

        self.management_user = User.objects.create_user(username="mgmt-am", password="pass")
        self.management_am = AM.objects.create(user=self.management_user, name="Management AM")
        self.management_user.groups.add(self.management_group)

        self.target_user = User.objects.create_user(username="target-am", password="pass")
        self.target_am = AM.objects.create(user=self.target_user, name="Target AM")

        self.other_user = User.objects.create_user(username="other-am", password="pass")
        self.other_am = AM.objects.create(user=self.other_user, name="Other AM")

        self.normal_user = User.objects.create_user(username="normal-am", password="pass")
        self.normal_am = AM.objects.create(user=self.normal_user, name="Normal AM")

        self.brand_user = User.objects.create_user(username="brand-owner", password="pass")
        self.brand_owner = BrandOwner.objects.create(user=self.brand_user, name="Brand Owner")

        self.case_one = Case.objects.create(
            brand_owner=self.brand_owner,
            name="Case One",
            category="npd_without",
            active=0,
        )
        self.case_one.am.add(self.privileged_am, self.other_am)

        self.case_two = Case.objects.create(
            brand_owner=self.brand_owner,
            name="Case Two",
            category="onboarding",
            active=1,
        )
        self.case_two.am.add(self.management_am, self.other_am)

        self.deleted_case = Case.objects.create(
            brand_owner=self.brand_owner,
            name="Deleted Case",
            category="onboarding",
            active=2,
        )
        self.deleted_case.am.add(self.other_am)

        self.assignment_url = reverse("case-assignment", kwargs={"case_id": self.case_one.id})

    def authenticate(self, user):
        self.client.force_authenticate(user=user)

    def test_privileged_am_can_get_assignment_context(self):
        self.authenticate(self.privileged_user)

        response = self.client.get(self.assignment_url)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["brand_case_count"], 2)
        self.assertEqual({item["id"] for item in response.data["viewer_ams"]}, {self.privileged_am.id, self.other_am.id})
        self.assertTrue(any(item["id"] == self.target_am.id for item in response.data["assignable_ams"]))

    def test_non_privileged_am_cannot_assign_brand_cases(self):
        self.authenticate(self.normal_user)

        response = self.client.post(self.assignment_url, {"am_id": self.target_am.id}, format="json")

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_privileged_assignment_reassigns_all_brand_cases_and_creates_alerts(self):
        self.authenticate(self.privileged_user)

        response = self.client.post(self.assignment_url, {"am_id": self.target_am.id}, format="json")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["brand_case_count"], 2)
        self.assertEqual(set(response.data["affected_case_ids"]), {self.case_one.id, self.case_two.id})

        self.case_one.refresh_from_db()
        self.case_two.refresh_from_db()
        self.deleted_case.refresh_from_db()

        self.assertEqual(set(self.case_one.am.values_list("id", flat=True)), {self.privileged_am.id, self.management_am.id, self.target_am.id})
        self.assertEqual(set(self.case_two.am.values_list("id", flat=True)), {self.privileged_am.id, self.management_am.id, self.target_am.id})
        self.assertEqual(set(self.deleted_case.am.values_list("id", flat=True)), {self.other_am.id})

        alerts = Alert.objects.filter(
            case__in=[self.case_one, self.case_two],
            message="Assigned to Target AM by Super AM.",
        ).order_by("case_id")
        self.assertEqual(alerts.count(), 2)
        self.assertTrue(all("Assigned to Target AM by Super AM." == alert.message for alert in alerts))

    def test_privileged_assignment_can_target_single_case_only(self):
        self.authenticate(self.privileged_user)

        response = self.client.post(
            self.assignment_url,
            {"am_id": self.target_am.id, "scope": "case"},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["scope"], "case")
        self.assertEqual(response.data["affected_case_ids"], [self.case_one.id])

        self.case_one.refresh_from_db()
        self.case_two.refresh_from_db()

        self.assertEqual(set(self.case_one.am.values_list("id", flat=True)), {self.privileged_am.id, self.management_am.id, self.target_am.id})
        self.assertEqual(set(self.case_two.am.values_list("id", flat=True)), {self.management_am.id, self.other_am.id})

        alert = Alert.objects.filter(case=self.case_one).order_by("-id").first()
        self.assertIsNotNone(alert)
        self.assertEqual(alert.message, "Assigned this case to Target AM by Super AM.")

    def test_privileged_unassign_clears_non_privileged_brand_assignees(self):
        self.authenticate(self.privileged_user)

        response = self.client.post(
            self.assignment_url,
            {"action": "unassign", "scope": "brand"},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["action"], "unassign")
        self.assertEqual(set(response.data["affected_case_ids"]), {self.case_one.id, self.case_two.id})

        self.case_one.refresh_from_db()
        self.case_two.refresh_from_db()

        self.assertEqual(set(self.case_one.am.values_list("id", flat=True)), {self.privileged_am.id, self.management_am.id})
        self.assertEqual(set(self.case_two.am.values_list("id", flat=True)), {self.privileged_am.id, self.management_am.id})

        alerts = Alert.objects.filter(
            case__in=[self.case_one, self.case_two],
            message="Unassigned by Super AM.",
        ).order_by("case_id")
        self.assertEqual(alerts.count(), 2)
        self.assertTrue(all("Unassigned by Super AM." == alert.message for alert in alerts))

    def test_privileged_unassign_can_target_single_case_only(self):
        self.authenticate(self.privileged_user)

        response = self.client.post(
            self.assignment_url,
            {"action": "unassign", "scope": "case"},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["scope"], "case")
        self.assertEqual(response.data["action"], "unassign")
        self.assertEqual(response.data["affected_case_ids"], [self.case_one.id])

        self.case_one.refresh_from_db()
        self.case_two.refresh_from_db()

        self.assertEqual(set(self.case_one.am.values_list("id", flat=True)), {self.privileged_am.id, self.management_am.id})
        self.assertEqual(set(self.case_two.am.values_list("id", flat=True)), {self.management_am.id, self.other_am.id})

        alert = Alert.objects.filter(case=self.case_one).order_by("-id").first()
        self.assertIsNotNone(alert)
        self.assertEqual(alert.message, "Unassigned this case by Super AM.")
