# case/serializers_ops.py  (new file or add to an existing one)
from rest_framework import serializers
from .models import OperationalStatus, CaseOperationalStatus

class OperationalStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = OperationalStatus
        fields = ("id", "name", "description", "is_active")

class CaseOperationalStatusSerializer(serializers.ModelSerializer):
    status = OperationalStatusSerializer(read_only=True)
    status_id = serializers.PrimaryKeyRelatedField(
        source="status", queryset=OperationalStatus.objects.all(), write_only=True
    )

    class Meta:
        model = CaseOperationalStatus
        fields = ("status", "status_id", "state", "notes", "updated_by", "updated_at")
        read_only_fields = ("updated_by", "updated_at")
