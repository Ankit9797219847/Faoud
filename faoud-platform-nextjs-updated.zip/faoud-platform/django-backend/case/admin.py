from django.contrib import admin
from .models import Alert, Service, Case, ProgressStage, Stage
from .models import OperationalStatus, CaseOperationalStatus

@admin.register(OperationalStatus)
class OperationalStatusAdmin(admin.ModelAdmin):
    list_display = ("name", "is_active", "updated_at")
    list_filter = ("is_active",)
    search_fields = ("name",)

@admin.register(CaseOperationalStatus)
class CaseOperationalStatusAdmin(admin.ModelAdmin):
    list_display = ("case", "status", "state", "updated_by", "updated_at")
    list_filter = ("state", "status")
    search_fields = ("case__name", "status__name")

class CaseAdmin(admin.ModelAdmin):
    list_display = ('id', 'brand_owner', 'product', 'quantity', 'eta','created_at', 'updated_at')
    list_filter = ('brand_owner', 'product', 'eta')
    ordering = ('-created_at',)
    search_fields = ('name', 'product__name', 'brand_owner__name')
    # Add any other fields you want to display in the list view

admin.site.register(Case, CaseAdmin)

admin.site.register(Service)
admin.site.register(Stage)
admin.site.register(ProgressStage)
admin.site.register(Alert)
