from django.db import models

from supply.models import Bid
from django.contrib.auth.models import User


class Service(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name



class OperationalStatus(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class CaseOperationalStatus(models.Model):
    IN_PROCESS = "in_process"
    DONE = "done"
    STATE_CHOICES = (
        (IN_PROCESS, "In Process"),
        (DONE, "Done"),
    )

    case = models.ForeignKey("case.Case", on_delete=models.CASCADE, related_name="case_operational_statuses")
    status = models.ForeignKey(OperationalStatus, on_delete=models.CASCADE, related_name="case_links")
    state = models.CharField(max_length=20, choices=STATE_CHOICES)
    notes = models.TextField(blank=True)
    updated_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("case", "status")           # one row per status per case
        indexes = [
            models.Index(fields=["case", "state"]),
            models.Index(fields=["status"]),
        ]

    def __str__(self):
        return f"{self.case_id} • {self.status.name} • {self.state}"


class Stage(models.Model):
    name = models.CharField(max_length=100)
    order = models.IntegerField(default=0)  # Order to determine stage progression

    def __str__(self):
        return self.name


class Case(models.Model):

    CATEGORY_CHOICES = [
        ('npd_with', 'NPD with formulation'),
        ('npd_without', 'NPD without formulation'),
        ('onboarding', 'Onboarding a BrandOwner'),
        ('dormantProduct', 'Dormant Product'),
        # Add other categories as needed
    ]
    ACTIVE_CHOICES = (
        (0, "Active"),     # visible everywhere
        (1, "Archived"),   # visible only in “archived” list
        (2, "Deleted"),    # never sent to frontend
    )

    # color coding for cases and leads(white should be included????)
    COLOR_CHOICES = [
        ('red', 'Red'),
        ('black', 'Black'),
        ('green', 'Green')
    ]

    PRIORITY_CHOICES = [
        ("normal", "Normal"),
        ("priority", "Priority"),
        ("inactive", "Inactive"),
        ("dispatched", "Dispatched"),
    ]

    active = models.PositiveSmallIntegerField(
        choices=ACTIVE_CHOICES, default=0, db_index=True
    )
    
    # by default it should be white same as now.
    color = models.CharField(
        max_length=10, choices=COLOR_CHOICES, default='', blank=True, help_text='Color code for the case'
    )
    priority = models.CharField(
        max_length=20,
        choices=PRIORITY_CHOICES,
        default="normal",
        db_index=True,
        help_text="Simple AM-set priority marker for dashboard ranking.",
    )

    brand_owner = models.ForeignKey(
        "user.BrandOwner", on_delete=models.SET_NULL, null=True, blank=True
    )
    start_date = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    name = models.CharField(max_length=255, null=True, blank=True, default = "Unnamed Case")
    services = models.ManyToManyField(Service, blank=True)
    stages = models.ManyToManyField(Stage, through='ProgressStage', blank=True)
    bidSelected = models.ForeignKey(Bid, on_delete=models.SET_NULL, null=True, blank=True, related_name='bid')


    # stages = models.ManyToManyField(Stage, blank=True)
     # Use through to link to ProgressStage
    quantity = models.PositiveIntegerField(null=True, blank=True)
    eta = models.DateField(null=True, blank=True)
    am = models.ManyToManyField("user.AM", related_name="cases_am", blank=True)
    formulation = models.ForeignKey(
        "formulation.Formulation",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    product = models.ForeignKey(
        "product.Product", on_delete=models.CASCADE, related_name="cases_product", null=True, blank=True
    )
    delivery_address = models.ForeignKey(
        "utils.Address",
        on_delete=models.SET_NULL,
        related_name="brand_address",
        null=True,
        blank=True,
    )
    factory = models.ForeignKey(
        "supply.Factory", on_delete=models.SET_NULL, null=True, blank=True
    )
    factory_quote = models.PositiveIntegerField(null=True, blank=True)
    bids = models.ManyToManyField("supply.Bid", related_name="cases", blank=True)
    category = models.CharField(
        max_length=50, choices=CATEGORY_CHOICES, default='npd_without'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_opened_by_am_at = models.DateTimeField(null=True, blank=True, db_index=True)
    subcategory = models.ForeignKey(
        "product.Subcategory",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="cases_subcategory",
    )
    notes = models.TextField(blank=True, default="")  # --- NEW ---
    operational_statuses = models.ManyToManyField(    # --- NEW ---
        OperationalStatus,
        through="CaseOperationalStatus",
        related_name="cases",
        blank=True,
    )

    def __str__(self):
        return f"Case {self.id}"


class ProgressStage(models.Model):
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name="progress_stages")
    completion_date = models.DateField(null=True, blank=True)
    order_in_timeline = models.IntegerField()  # Track the order of the stage in the case's timeline
    stage = models.ForeignKey(Stage, on_delete=models.CASCADE, default=1)

    def __str__(self):
        return f"Progress Stage {self.stage.name} for Case {self.case.id}"




from django.db import models
from django.utils import timezone

class Alert(models.Model):
    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name="alerts")
    created_date = models.DateTimeField(auto_now_add=True)
    done_date = models.DateTimeField(null=True, blank=True)
    is_done = models.BooleanField(default=False)
    message = models.CharField(max_length=255, blank=True, null=True)

    def mark_done(self):
        self.is_done = True
        self.done_date = timezone.now()
        self.save()

    def __str__(self):
        return f"Alert for Case {self.case.id}: {self.message or ''}"


class MachineryFlow(models.Model):
    facility_line = models.IntegerField()  # Adjust field/type as needed
    machinery = models.IntegerField()
    description = models.CharField(max_length=255, null=True, blank=True)
    previous_step = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='next_flow'
    )
    next_step = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='previous_flow'
    )
        
