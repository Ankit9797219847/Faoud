from rest_framework import serializers
from product.models import Product

class MinimalProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['name', 'sku_and_pm', 'picture','benchmark']

    def to_representation(self, instance):
        data = super().to_representation(instance)
        if not data.get('picture'):
            if instance.subcategory and instance.subcategory.image:
                data['picture'] = instance.subcategory.image.url
            elif instance.category and instance.category.image:
                data['picture'] = instance.category.image.url
            else:
                data['picture'] = None
        return data

from .models import Case

class PublicCaseSerializer(serializers.ModelSerializer):
    category_slug = serializers.SerializerMethodField()
    subcategory_slug = serializers.SerializerMethodField()
    product = MinimalProductSerializer(read_only=True)

    class Meta:
        model = Case
        fields = ['id', 'name', 'quantity', 'category_slug', 'subcategory_slug', 'product']

    def get_category_slug(self, obj):
        return obj.product.subcategory.category.slug if obj.product and obj.product.subcategory and obj.product.subcategory.category else None

    def get_subcategory_slug(self, obj):
        return obj.product.subcategory.slug if obj.product and obj.product.subcategory else None
