# core/signals_bus.py
from django.dispatch import Signal

# emitted after registration / lead-finish with onboarding payload
user_onboarded = Signal()