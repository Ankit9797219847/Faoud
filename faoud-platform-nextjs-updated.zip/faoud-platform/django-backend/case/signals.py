# case/signals.py
"""Signals and helpers for onboarding and AM assignment.

- Creates/updates an onboarding Case when a user completes onboarding
- Ensures an initial Stage exists on the Case timeline
- Persists onboarding fields into ChosenAnswer (if matching Questions exist)
- Assigns AMs to newly created Cases and emails the primary AM
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from django.contrib.auth.models import Group
from django.contrib.auth import get_user_model
from django.conf import settings
from django.core.mail import send_mail
from django.db import transaction
from django.db.models import Count
from django.db.models.signals import pre_save, post_save
from django.dispatch import receiver

from case.models import Case, ProgressStage, Stage
from marketing.models import OnboardingData
from product.models import Question, ChosenAnswer
from user.models import AM, BrandOwner

from .signals_bus import user_onboarded

logger = logging.getLogger(__name__)
User = get_user_model()


# -----------------------------
# Small helpers
# -----------------------------

def _coerce_int(val: Optional[str]) -> Optional[int]:
    if val is None or val == "":
        return None
    try:
        return int(str(val).strip())
    except (ValueError, TypeError):
        return None


def _str_or_none(val: Any) -> Optional[str]:
    s = (val or "").strip() if isinstance(val, str) else (str(val).strip() if val is not None else "")
    return s or None


def _ensure_initial_stage(case: Case, default_stage: Stage) -> None:
    """Ensure the initial stage is present (don’t complete it here)."""
    if not case.progress_stages.filter(stage=default_stage).exists():
        ProgressStage.objects.create(
            case=case,
            stage=default_stage,
            order_in_timeline=default_stage.order,
        )


def _create_or_update_answer(
    brand_owner: BrandOwner,
    case: Case,
    question_text_contains: str,
    value: Any,
    *,
    category: str = "onboarding",
) -> None:
    """If a matching Question exists, upsert a ChosenAnswer with the provided value.
    Skips when value is empty/None.
    """
    val = _str_or_none(value)
    if not val:
        return
    q = Question.objects.filter(question_text__icontains=question_text_contains, category=category).first()
    if not q:
        return

    obj, created = ChosenAnswer.objects.get_or_create(
        brand_owner=brand_owner,
        case=case,
        question=q,
        defaults={"answer_text": val},
    )
    if not created and obj.answer_text != val:
        obj.answer_text = val
        obj.save(update_fields=["answer_text"])


# -----------------------------
# Onboarding -> Case creation
# -----------------------------
from typing import Optional, Any
from django.db import transaction
from django.dispatch import receiver
from django.utils import timezone
import logging

logger = logging.getLogger(__name__)


def create_onboarding_flow(user=None, user_id: Optional[int]=None, onboarding_id: Optional[int]=None):
    """
    Accumulate onboarding fields onto the user's onboarding Case and ensure setup.
    Now sources data from the persisted Onboarding row instead of a JSON payload.

    Signal args supported:
      - user (User) or user_id (int)
      - onboarding_id (int, optional): if provided, use that specific onboarding row
    """

    try:
        # ---- Fetch onboarding row(s) ----
        if onboarding_id:
            onboarding = OnboardingData.objects.filter(id=onboarding_id, user_id=user_id).first()
        else:
            # take the latest onboarding row for the user
            onboarding = OnboardingData.objects.filter(user_id=user_id).order_by("-id").first()

        if not onboarding:
            logger.info("[user_onboarded] No onboarding row found for user_id=%s; skipping.", user_id)
            return

        # Helper to safely read either camelCase or snake_case field names
        def _get(obj, *names, default=None):
            for n in names:
                if hasattr(obj, n):
                    val = getattr(obj, n)
                    # treat empty strings like None for our purposes
                    if val is not None and (not isinstance(val, str) or val.strip() != ""):
                        return val
            return default

        # Fast pre-check: if basically everything is missing, skip
        if not any([
            _get(onboarding, "flowType", "flow_type"),
            _get(onboarding, "productCategory", "product_category"),
            _get(onboarding, "productName", "product_name"),
            _get(onboarding, "quantity"),
        ]):
            logger.info("[user_onboarded] Insufficient fields on onboarding row; skipping.")
            return

        # ---- BrandOwner profile required (with fallback by onboarding email) ----
        brand_owner = None
        try:
            if user or user_id:
                u = user or User.objects.get(id=user_id)
                brand_owner = getattr(u, 'brandowner', None)
        except BrandOwner.DoesNotExist:
            brand_owner = None

        if not brand_owner:
            # Fallback: try to resolve BrandOwner by onboarding email if available
            try:
                email_from_onboarding = _str_or_none(_get(onboarding, 'email'))
                if email_from_onboarding:
                    brand_owner = BrandOwner.objects.filter(contact_email__iexact=email_from_onboarding).first()
            except Exception:
                brand_owner = None

        if not brand_owner:
            logger.info("[user_onboarded] No BrandOwner could be resolved; skipping Case creation.")
            return

        # ---- Extract fields from model ----
        flow_type           = _str_or_none(_get(onboarding, "flowType", "flow_type"))
        product_category    = _str_or_none(_get(onboarding, "productCategory", "product_category"))
        product_name        = _str_or_none(_get(onboarding, "productName", "product_name"))
        quantity            = _coerce_int(_get(onboarding, "quantity"))
        instructions        = _str_or_none(_get(onboarding, "instructions"))
        requires_formulation= bool(_get(onboarding, "requiresFormulation", "requires_formulation", default=False))
        selected_factory    = _str_or_none(_get(onboarding, "selectedFactory", "selected_factory"))
        timeline            = _str_or_none(_get(onboarding, "timeline"))
        budget              = _str_or_none(_get(onboarding, "budget"))
        company_name        = _str_or_none(_get(onboarding, "companyName", "company_name"))
        location            = _str_or_none(_get(onboarding, "location"))

        # ---- Optionally enrich BrandOwner with company_name if empty ----
        if company_name and not _str_or_none(brand_owner.name):
            brand_owner.name = company_name
            brand_owner.save(update_fields=["name"])

        # ---- Initial stage ----
        # default_stage = Stage.objects.filter(order=0).first()
        # if not default_stage:
        #     logger.warning("[user_onboarded] No initial Stage(order=0) found.")
        #     return

        # ---- Create/Upsert Case + Answers ----
        with transaction.atomic():
            case = _get_or_create_onboarding_case(brand_owner, product_name)

            if hasattr(case, "quantity") and quantity is not None and (case.quantity != quantity):
                case.quantity = quantity
                case.save(update_fields=["quantity"])

            # _ensure_initial_stage(case, default_stage)

            # Persist onboarding fields into ChosenAnswer (only if matching Questions exist)
            field_map = [
                ("flow", flow_type),
                ("product", product_name),
                ("category", product_category),
                ("quantity", quantity if quantity is not None else None),
                ("instructions", instructions),
                ("formulation", "Yes" if requires_formulation else "No"),
                ("selected factory", selected_factory),
                ("timeline", timeline),
                ("budget", budget),
                ("company", company_name),
                ("location", location),
            ]
            for contains, value in field_map:
                _create_or_update_answer(brand_owner, case, contains, value, category="onboarding")

            logger.info(
                "[user_onboarded] Upserted onboarding Case %s for BrandOwner %s from onboarding_id=%s.",
                case.id, brand_owner.id, onboarding.id
            )

    except Exception:
        # Never blow up the request that fired the signal
        logger.exception("[user_onboarded] Error while creating onboarding flow from DB row")


# -----------------------------
# User activation hook -> fire onboarding pipeline
# -----------------------------

@receiver(pre_save, sender=User)
def _track_prev_is_active(sender, instance, **kwargs):
    """Fetch and stash the previous is_active value on the instance before save."""
    prev = None
    if instance.pk:
        try:
            prev = sender.objects.only("is_active").get(pk=instance.pk).is_active
        except sender.DoesNotExist:
            prev = None
    # Stash on the instance for access in post_save
    setattr(instance, "_prev_is_active", prev)

@receiver(post_save, sender=User)
def _on_user_activation(sender, instance, created: bool, **kwargs):
    """When any user is saved and their is_active turns True for the first time,
    emit the user_onboarded signal so downstream flows (case creation, etc.) run.
    """
    try:
        prev = getattr(instance, "_prev_is_active", None)
        activated_now = bool(instance.is_active) and (created or prev is False)
        if not activated_now:
            return

        # If the BrandOwner already has an onboarding case, don't re-fire
        bo = None
        try:
            bo = instance.brandowner
        except BrandOwner.DoesNotExist:
            bo = None

        if bo and Case.objects.filter(brand_owner=bo, category="onboarding").exists():
            return

        if OnboardingData.objects.filter(user_id=instance.id).exists():
            user_onboarded.send(sender=sender, user=instance)
    except Exception:
        logger.exception("[user_activation] Failed while handling user activation for user_id=%s", getattr(instance, 'id', None))


# -----------------------------
# OnboardingData save hook -> fire onboarding instantly
# -----------------------------

@receiver(post_save, sender=OnboardingData)
def _on_onboarding_saved(sender, instance: OnboardingData, created: bool, **kwargs):
    """Fire the onboarding pipeline immediately when an OnboardingData row is created or updated.

    This removes the dependency on email verification/password change/activation. It's idempotent
    via _get_or_create_onboarding_case, so repeated saves will just upsert answers.
    """
    try:
        # Prefer passing both user (if available) and user_id for robustness
        user = getattr(instance, "user", None)
        user_id = getattr(instance, "user_id", None)
        user_onboarded.send(sender=sender, user=user, user_id=user_id, onboarding_id=instance.id)
    except Exception:
        logger.exception("[onboarding_saved] Failed while firing onboarding for onboarding_id=%s", getattr(instance, 'id', None))

# -----------------------------
# AM assignment on Case creation
# -----------------------------

@receiver(post_save, sender=Case)
def assign_ams_on_create(sender, instance: Case, created: bool, **kwargs):
    if not created:
        return
    if not getattr(settings, "AUTO_ASSIGN_PRIVILEGED_AMS", True):
        return

    # 1) Add all superAMs
    try:
        super_group = Group.objects.get(name="superAM")
        super_am_qs = AM.objects.filter(is_active=True, user__in=super_group.user_set.all())
    except Group.DoesNotExist:
        super_am_qs = AM.objects.none()

    try:
        mgmt_group = Group.objects.get(name="MNGMNT")
        mgmt_am_qs = AM.objects.filter(is_active=True, user__in=mgmt_group.user_set.all())
    except Group.DoesNotExist:
        mgmt_am_qs = AM.objects.none()

    if super_am_qs.exists():
        # Case.am is assumed to be a ManyToMany to AM with related_name='cases_am'
        instance.am.add(*super_am_qs)

    if mgmt_am_qs.exists():
        instance.am.add(*mgmt_am_qs)


def _get_or_create_onboarding_case(brand_owner: BrandOwner, product_name: Optional[str]) -> Case:
    """Idempotently get/create the onboarding Case for a brand owner.
    Uses a stable case name to avoid duplicates.
    """
    base_name = f"{product_name or 'Product'} Onboarding"
    case = Case.objects.filter(brand_owner=brand_owner, name=base_name, category="onboarding").first()
    if case:
        return case
    return Case.objects.create(
        brand_owner=brand_owner,
        name=base_name,
        category="onboarding",
    )
