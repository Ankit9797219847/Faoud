from rest_framework import serializers

from product.models import Product
from user.models import AM

from .models import Case
from .serializers_min import ProgressStageMinSerializer


class BrandOwnerDashboardProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ("id", "name", "eta", "picture")

    def to_representation(self, instance):
        data = super().to_representation(instance)
        if not data.get("picture"):
            if instance.subcategory and instance.subcategory.image:
                data["picture"] = instance.subcategory.image.url
            elif instance.category and instance.category.image:
                data["picture"] = instance.category.image.url
            else:
                data["picture"] = None
        return data


class BrandOwnerDashboardAMSerializer(serializers.ModelSerializer):
    class Meta:
        model = AM
        fields = ("id", "name")


class BrandOwnerDashboardCaseSerializer(serializers.ModelSerializer):
    product = BrandOwnerDashboardProductSerializer(read_only=True)
    am = BrandOwnerDashboardAMSerializer(read_only=True, many=True)
    stages = ProgressStageMinSerializer(source="progress_stages", many=True, read_only=True)
    visible_bid_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = Case
        fields = (
            "id",
            "name",
            "product",
            "stages",
            "start_date",
            "am",
            "category",
            "visible_bid_count",
        )
