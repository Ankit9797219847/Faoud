# case/serializers_am.py
from rest_framework import serializers

from user.utils import has_no_brand_info, is_plain_am, redact_fields
from .models import Case
from .serializers_min import ProductSerializer, AMSerializerMin, ProgressStageMinSerializer
from .serializers_ops import CaseOperationalStatusSerializer

class CaseAMListSerializer(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    am = AMSerializerMin(many=True, read_only=True)
    stages = ProgressStageMinSerializer(source="progress_stages", many=True, read_only=True)
    # Ops status (list) for AM visibility
    operational_status = serializers.SerializerMethodField()
    # Interface fields
    order_id = serializers.SerializerMethodField()
    cost = serializers.SerializerMethodField()
    status = serializers.SerializerMethodField()
    brand_name = serializers.SerializerMethodField()
    brand_id = serializers.SerializerMethodField()
    poc_name = serializers.SerializerMethodField()
    poc_number = serializers.SerializerMethodField()
    poc_email = serializers.SerializerMethodField()
    brand_location = serializers.SerializerMethodField()
    requirement_date = serializers.SerializerMethodField()
    gst_tm_submitted = serializers.SerializerMethodField()
    operations_stage = serializers.SerializerMethodField()
    is_live = serializers.SerializerMethodField()
    factory_selected = serializers.SerializerMethodField()

    class Meta:
        model = Case
        fields = (
            "id", "order_id", "product", "am", "start_date", "stages",
            "cost", "status", "brand_owner", "category",
            "brand_name", "brand_id", "poc_name", "poc_number", "poc_email",
            "requirement_date", "gst_tm_submitted", "operations_stage","brand_location",
            "notes",                    # <-- from Case.notes
            "operational_status",       # <-- list of {status, state, ...}
            "color",
            "priority",
            "updated_at",
            "is_live",
            "factory_selected",
        )
    def to_representation(self, instance):
            data = super().to_representation(instance)
            req = self.context.get("request")
            if req and has_no_brand_info(req.user):
                redact_fields(
                    data,
                    fields=["poc_email", "poc_number", "poc_name", "brand_name", "brand_location"],
                    strategy="drop",
                )
                return data
            if req and is_plain_am(req.user):
                # Correct keys for this serializer:
                redact_fields(
                    data,
                    fields=["poc_email", "poc_number","poc_name",
                            "brand_name"],
                    strategy="mask",  # switch to "drop" if you prefer removing keys
                )
            return data
    
    # ---- AM Interface helpers (safe defaults) ----
    def get_order_id(self, obj):
        # TODO: replace with actual order field if you have it
        # e.g. return obj.order.order_id if hasattr(obj, "order") else None
        return obj.id
    
    def get_cost(self, obj):
        # TODO: decide source (bid summary? product BOM? payment?)
        return "0.00"

    def get_status(self, obj):
        # A readable status for the case (not ops-status).
        # Here: last completed stage name (or "Not Started")
        last = obj.progress_stages.filter(completion_date__isnull=False) \
                                  .order_by("order_in_timeline").last()
        return last.stage.name if last else "Not Started"

    def get_brand_name(self, obj):
        return getattr(getattr(obj, "brand_owner", None), "name", None)

    def get_brand_id(self, obj):
        brands = list(self._brands_qs(obj))
        if not brands:
            return None
        return brands[0].id

    def get_poc_name(self, obj):
        bo = getattr(obj, "brand_owner", None)
        # customize if you store POC on brand_owner; else fallback to user’s name
        brand = getattr(bo, "brands", None).first() if bo else None
        if brand and hasattr(brand, "poc_name"):
            return brand.poc_name
        return None
    
    def get_brand_location(self, obj):
        bo = getattr(obj, "brand_owner", None)
        # customize if you store POC on brand_owner; else fallback to user’s name
        brand = getattr(bo, "brands", None).first() if bo else None
        if brand and hasattr(brand, "office_address"):
            return brand.office_address
        return None

    def get_poc_number(self, obj):
        bo = getattr(obj, "brand_owner", None)
        # customize if you store POC on brand_owner; else fallback to user’s name
        brand = getattr(bo, "brands", None).first() if bo else None
        if brand and hasattr(brand, "poc_number"):
            return brand.poc_number
        if brand and hasattr(brand, "director_number"):
            return brand.director_number
        return None


    def get_poc_email(self, obj):
        bo = getattr(obj, "brand_owner", None)
        # customize if you store POC on brand_owner; else fallback to user’s name
        brand = getattr(bo, "brands", None).first() if bo else None
        if brand and hasattr(brand, "poc_email"):
            return brand.poc_email
        if brand and hasattr(brand, "director_email"):
            return brand.director_email
        return None

    def get_requirement_date(self, obj):
        # TODO: map to real field if exists
        if obj.eta:
            return obj.eta.strftime("%Y-%m-%d")
        return None
    def _brands_qs(self, obj):
        """
        Returns a queryset or list of Brand objects linked to the BrandOwner.
        Safe even if brands aren't linked.
        """
        bo = getattr(obj, "brand_owner", None)
        mgr = getattr(bo, "brands", None) if bo else None
        return mgr.all() if hasattr(mgr, "all") else []

    def get_gst_tm_submitted(self, obj):
        """
        True only if any brand has gst AND any (same or other) brand has tm.
        """
        brands = list(self._brands_qs(obj))
        if not brands:
            return False
        has_gst = any(getattr(b, "gst_certificate") and bool(b.gst_certificate.name) for b in brands)
        has_tm  = any(getattr(b, "tm_certificate")  and bool(b.tm_certificate.name)  for b in brands)

        return has_gst and has_tm

    def get_operations_stage(self, obj):
        """
        Human-friendly summary of ops progress.
        Example: "2 in process • 3 done" or the most-recent ops status name.
        """
        links = list(obj.case_operational_statuses.all())
        if not links:
            return None
        in_p = sum(1 for l in links if l.state == l.IN_PROCESS)
        done = sum(1 for l in links if l.state == l.DONE)
        return f"{in_p} in process • {done} done"

    def get_operational_status(self, obj):
        qs = obj.case_operational_statuses.select_related("status", "updated_by").all()
        return CaseOperationalStatusSerializer(qs, many=True).data

    def get_is_live(self, obj):
        return obj.progress_stages.filter(stage__name="Reviewed", completion_date__isnull=False).exists()

    def get_factory_selected(self, obj):
        return obj.factory_id is not None
