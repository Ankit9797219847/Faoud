from datetime import timezone
from venv import logger
from django.http import HttpResponse
from django.db.models import Count, Q
from django.db import transaction
from rest_framework import viewsets
from rest_framework.generics import ListAPIView
from rest_framework.pagination import PageNumberPagination

from case.serializers_am import CaseAMListSerializer
from case.serializers_bo import BrandOwnerDashboardCaseSerializer
from notifications.models import Notification, NotificationTemplate, UserNotification
from notifications.notif import send_notification
from notifications.tasks import send_notification_task
from .serializers_public import PublicCaseSerializer
from .serializers_min import CaseSerializerMin
from rest_framework.decorators import action

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404

from user.permissions import IsAccountManager, IsBrandOwner, IsFactoryOwner, IsPrivilegedAccountManager
from .models import Case, ProgressStage
from formulation.models import Formulation
from .serializers import (
    AlertSerializer,
    CaseColorUpdateSerializer,
    CasePriorityUpdateSerializer,
    CaseSerializer,
    CaseUpdateSerializer,
)
from user.models import AM, Formulator  # Assuming AM is in the user.models
from user.serializers import AMListSerializer
from .models import Case
from supply.models import Factory
from supply.serializers import FactorySerializer

import io
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfgen import canvas

from rest_framework.permissions import IsAuthenticated
from user.permissions import IsAccountManager, IsBrandOwner
from rest_framework.decorators import permission_classes
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.utils import timezone
from .models import Case, Stage, ProgressStage

from rest_framework.permissions import IsAuthenticated
from core.review import build_review_summary, get_stage_preview, get_stage_summary, publish_case

def mark_case_opened_by_am(case, user):
    if not hasattr(user, "am"):
        return
    case.last_opened_by_am_at = timezone.now()
    case.save(update_fields=["last_opened_by_am_at"])


def generate_placeholder_pdf():
    """Generate a PDF with a nicely styled placeholder message in real-time."""
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # Title
    p.setFont("Helvetica-Bold", 24)
    p.setFillColor(colors.HexColor("#333333"))
    p.drawCentredString(width / 2, height - 150, "FAOUD")

    # Subtitle
    p.setFont("Helvetica", 16)
    p.setFillColor(colors.HexColor("#666666"))
    p.drawCentredString(width / 2, height - 180, "Factory on Cloud")

    # Centered message
    p.setFont("Helvetica", 12)
    p.setFillColor(colors.HexColor("#333333"))
    p.drawCentredString(width / 2, height / 2, "Formulation done!")
    p.drawCentredString(width / 2, height / 2 - 20, "Will be shown here once you generate the Product Order.")

    # Footer message
    p.setFont("Helvetica-Oblique", 10)
    p.setFillColor(colors.HexColor("#999999"))
    p.drawCentredString(width / 2, 50, "We value you, Thank you for joining Faoud, let's build your product superfast!")

    p.showPage()
    p.save()
    
    buffer.seek(0)
    return buffer


class BrandOwnerDashboardPagination(PageNumberPagination):
    page_size = 10
    page_size_query_param = "page_size"
    max_page_size = 50


# Create your views here.
class CaseViews(viewsets.ModelViewSet):
    permission_classes = [ IsAccountManager | IsBrandOwner | IsFactoryOwner]
    queryset = Case.objects.all()
    serializer_class = CaseSerializer
    pagination_class = None
    
    def has_permission(self, request):
        """Check if the request user has the required permissions."""
        user = request.user
        if IsAccountManager().has_permission(request, self):
            return 'account_manager'
        elif IsBrandOwner().has_permission(request, self):
            return 'brand_owner'
        elif IsFactoryOwner().has_permission(request,self):
            return 'factory_owner'
        return None

    def filterPerm(self, request, cases):
        user_role = self.has_permission(request)
        if user_role == 'account_manager':
            return cases.filter(am__in=[request.user.am])
        elif user_role == 'brand_owner':
            return cases.filter(brand_owner=request.user.brandowner).exclude(active=2)
        return cases.none()

    def list_noprod(self, request):
        cases = self.queryset.filter(product=None).exclude(services=None)
        cases = self.filterPerm(request, cases)
        cases = cases.order_by('-start_date')
        case_ser = CaseSerializerMin(cases, many=True)
        return Response({"cases": case_ser.data}, status=status.HTTP_200_OK)

    def list_prod(self, request):
        if not IsAccountManager().has_permission(request, self):
            return Response(
                {"detail": "You do not have permission to access this resource."},
                status=status.HTTP_403_FORBIDDEN,
            )

        cases = self.queryset.filter(active=0).order_by("-start_date")
        cases = self.filterPerm(request, cases)

        # Use richer serializer only for AMs
        user_role = self.has_permission(request)
        if user_role == 'account_manager':
            cases = cases.select_related("brand_owner") \
                        .prefetch_related(
                            "am",
                            "progress_stages__stage",
                            "case_operational_statuses__status",
                            "brand_owner__brands"  # ← REQUIRED for GST/TM check
             )
            ser = CaseAMListSerializer(cases, many=True, context={"request": request})
        else:
            ser = CaseSerializerMin(cases, many=True, context={"request": request})

        return Response({"cases": ser.data}, status=status.HTTP_200_OK)

    def list_brand_owner_dashboard(self, request):
        if not IsBrandOwner().has_permission(request, self):
            return Response(
                {"detail": "You do not have permission to access this resource."},
                status=status.HTTP_403_FORBIDDEN,
            )

        cases = (
            self.queryset.filter(active=0, brand_owner=request.user.brandowner)
            .select_related("product", "product__subcategory", "product__category")
            .prefetch_related("am", "progress_stages__stage")
            .annotate(
                visible_bid_count=Count(
                    "bids_cases",
                    filter=Q(bids_cases__tag__isnull=False) & ~Q(bids_cases__tag=""),
                    distinct=True,
                )
            )
            .order_by("-start_date")
        )

        paginator = BrandOwnerDashboardPagination()
        paginated_cases = paginator.paginate_queryset(cases, request, view=self)
        serializer = BrandOwnerDashboardCaseSerializer(
            paginated_cases,
            many=True,
            context={"request": request},
        )
        return paginator.get_paginated_response(serializer.data)
    
    def list_archived(self, request):
        cases = self.queryset.filter(active=1)
        cases = self.filterPerm(request, cases)
        cases = cases.order_by("-start_date")
        return Response({"cases": CaseSerializerMin(cases, many=True).data})

    def get_case(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        #if a brandowner is calling this function and stage is not above project order, change formulation to a fomulation pdf on which is written that formulation done, complete the payment
        user_role = self.has_permission(request)


        if user_role is None:
            return Response(
                {"error": "You do not have permission to access this case."},
                status=status.HTTP_403_FORBIDDEN,
            )
        

        if user_role == 'brand_owner' and case.category == 'npd_with':
            project_order_stage = Stage.objects.get(name="Orders")  # Assuming this stage exists
            case_stage = case.progress_stages.filter(completion_date__isnull=False).order_by('order_in_timeline').last()
            if case_stage and case_stage.stage.order <= project_order_stage.order:
                # If there's no formulation document, return the placeholder PDF
                if case.formulation and case.formulation.documents:
                    # Back up the original document
                    original_document = case.formulation.documents

                    # Generate the placeholder PDF and assign it temporarily
                    placeholder_pdf = generate_placeholder_pdf()
                    case.formulation.documents.save('formulation_placeholder.pdf', placeholder_pdf, save=False)

                    # Serialize the case with the temporary document
                    case_ser = CaseSerializer(case)

                    # Restore the original document
                    case.formulation.documents = original_document
                    return Response(
                        {"case": case_ser.data, "user_role": user_role},
                        status=status.HTTP_200_OK
                    )
        case_ser = CaseSerializer(case)
        if user_role == 'account_manager':
            mark_case_opened_by_am(case, request.user)
        return Response(
            {"case": case_ser.data, "user_role":user_role} ,
            status=status.HTTP_200_OK
            )

from django.shortcuts import get_object_or_404
from rest_framework.permissions import AllowAny

class PublicCaseDetailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, case_id):
        case = get_object_or_404(Case, id=case_id, active=0)
        
        serializer = PublicCaseSerializer(case)
        return Response(serializer.data)

class ArchiveCaseView(APIView):
    permission_classes = [IsAccountManager | IsBrandOwner]
    def post(self, request, pk):
        case = get_object_or_404(Case, pk=pk)
        case.active = 1
        case.save()
        return Response({"status": "archived"}, status=status.HTTP_200_OK)


class RestoreCaseView(APIView):
    permission_classes = [IsAccountManager | IsBrandOwner]
    def post(self, request, pk):
        case = get_object_or_404(Case, pk=pk)
        case.active = 0
        case.save()
        return Response({"status": "restored"}, status=status.HTTP_200_OK)


class SoftDeleteCaseView(APIView):
    permission_classes = [IsAccountManager | IsBrandOwner]
    def post(self, request, pk):
        case = get_object_or_404(Case, pk=pk)
        case.active = 2
        case.save()
        return Response({"status": "deleted"}, status=status.HTTP_200_OK)
    

class CaseUpdateView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request, case_id, formulator_id):
        case = get_object_or_404(Case, id=case_id)
        formulator = get_object_or_404(Formulator, id=formulator_id)

        if case.product is None:
            return Response(
                {"error": "Add Product before allocating formulator."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if case.formulation is None:
            case.formulation = Formulation.objects.create(product=case.product)
            case.save()

        case.formulation.product.add(case.product)
        case.formulation.formulators.add(formulator)
        case.save()

        serializer = CaseUpdateSerializer(case)
        return Response(serializer.data, status=status.HTTP_200_OK)


class AvailableFactoriesView(APIView):
    def get(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        available_factories = Factory.objects.filter(
            cases__isnull=True
        )  # Factories not yet linked to any case
        serializer = FactorySerializer(available_factories, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class CaseViewSet(viewsets.ModelViewSet):
    queryset = Case.objects.all()
    serializer_class = CaseSerializer


class AssignedCasesView(APIView):
    permission_classes = [IsAccountManager]

    def get(self, request):
        # Get the account manager associated with the current user
        account_manager = get_object_or_404(AM, user=request.user)

        # Filter cases assigned to this account manager
        cases = Case.objects.filter(am=account_manager)

        # Serialize the cases
        serializer = CaseSerializer(cases, many=True)

        return Response({'cases': serializer.data}, status=status.HTTP_200_OK)
    

# class UpdateCaseStageView(APIView):
#     permission_classes = [IsAuthenticated]

#     def post(self, request, case_id):
#         case = get_object_or_404(Case, id=case_id)
#         user = request.user

#         # Determine user role
#         if IsAccountManager().has_permission(request, self):
#             user_role = 'account_manager'
#         elif IsBrandOwner().has_permission(request, self):
#             user_role = 'brand_owner'
#         else:
#             return Response(
#                 {"error": "You do not have permission to update the case stage."},
#                 status=status.HTTP_403_FORBIDDEN
#             )

#         # Get the new stage name from the request
#         new_stage_name = request.data.get('stage_name')
#         if not new_stage_name:
#             return Response(
#                 {"error": "New stage not provided."},
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         # Find the corresponding stage
#         new_stage = Stage.objects.filter(name=new_stage_name).first()
#         if not new_stage:
#             return Response(
#                 {"error": "Invalid stage name."},
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         # Fetch all stages ordered by their 'order' field
#         all_stages = Stage.objects.all().order_by('order')
#         new_stage_order = new_stage.order

#         if user_role == 'brand_owner':
#             # Brand Owners can only mark the next stage as completed
#             completed_stages = case.progress_stages.filter(completion_date__isnull=False).order_by('order_in_timeline')
#             last_completed_stage = completed_stages.last()

#             if last_completed_stage:
#                 expected_order = last_completed_stage.stage.order + 1
#             else:
#                 expected_order = 1  # First stage

#             if new_stage_order != expected_order:
#                 return Response(
#                     {"error": "You can only mark the next stage as completed."},
#                     status=status.HTTP_400_BAD_REQUEST
#                 )

#         # Check if the stage is already completed
#         progress_stage = case.progress_stages.filter(stage=new_stage).first()
#         if progress_stage and progress_stage.completion_date:
#             return Response(
#                 {"error": f"The stage '{new_stage_name}' is already completed."},
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         # If the stage has not been completed yet, create or update the ProgressStage
#         if not progress_stage:
#             progress_stage = ProgressStage.objects.create(
#                 case=case,
#                 stage=new_stage,
#                 order_in_timeline=new_stage.order
#             )

#         # Mark the new stage as completed
#         progress_stage.completion_date = request.data.get('completion_date') or timezone.now().date()
#         progress_stage.save()

#         return Response(
#             {"message": f"Case stage updated to {new_stage_name}."},
#             status=status.HTTP_200_OK
#         )

class UpdateCaseStageView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        user = request.user
        
        # Determine user role
        if IsAccountManager().has_permission(request, self):
            user_role = 'account_manager'
        elif IsBrandOwner().has_permission(request, self):
            user_role = 'brand_owner'
        else:
            return Response(
                {"error": "You do not have permission to update the case stage."},
                status=status.HTTP_403_FORBIDDEN,
            )

        # Get the stage name from the request
        stage_name = request.data.get('stage_name')
        if not stage_name:
            return Response(
                {"error": "Stage name not provided."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Find the stage
        stage = Stage.objects.filter(name=stage_name).first()
        if not stage:
            return Response(
                {"error": "Invalid stage name."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if stage.name == "Reviewed":
            preview = get_stage_preview(case, stage.name)
            return Response(
                {
                    "error": "Use the publish flow to complete Reviewed.",
                    **preview,
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Check if the stage exists in progress stages
        progress_stage = case.progress_stages.filter(stage=stage).first()
        if progress_stage:
            # If the stage is completed, delete it
            progress_stage.delete()
            return Response(
                {"message": f"Stage '{stage_name}' has been deleted."},
                status=status.HTTP_200_OK,
            )
        else:
            # If not completed, mark as completed
            completion_date = request.data.get('completion_date') or timezone.now().date()
            ProgressStage.objects.create(
                case=case,
                stage=stage,
                order_in_timeline=stage.order,
                completion_date=completion_date,
            )
            message = f"Stage '{stage_name}' has been marked as completed."

        # Prepare notification
        return Response(
            {"message": message},
            status=status.HTTP_200_OK,
        )


class CaseStageSummaryAPIView(APIView):
    permission_classes = [IsAccountManager | IsBrandOwner]

    def get(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        return Response(get_stage_summary(case), status=status.HTTP_200_OK)


class CaseStagePreviewAPIView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        stage_name = request.data.get("stage_name")
        if not stage_name:
            return Response({"detail": "stage_name is required."}, status=status.HTTP_400_BAD_REQUEST)
        return Response(get_stage_preview(case, stage_name), status=status.HTTP_200_OK)


class CaseStageTransitionAPIView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        stage_name = request.data.get("stage_name")
        if not stage_name:
            return Response({"detail": "stage_name is required."}, status=status.HTTP_400_BAD_REQUEST)

        preview = get_stage_preview(case, stage_name)
        if not preview["allowed"]:
            return Response(preview, status=status.HTTP_400_BAD_REQUEST)

        if stage_name == "Reviewed":
            try:
                publish_result = publish_case(case, request.user)
            except ValueError as exc:
                return Response(
                    {
                        "detail": "Case is not ready to publish.",
                        "blocking_issues": str(exc).split("; "),
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
            case.refresh_from_db()
            return Response(
                {
                    "detail": "Case made live.",
                    "publish_result": publish_result,
                    "stage_summary": get_stage_summary(case),
                    "review_summary": build_review_summary(case),
                },
                status=status.HTTP_200_OK,
            )

        stage = Stage.objects.filter(name=stage_name).first()
        if not stage:
            return Response({"detail": "Invalid stage name."}, status=status.HTTP_400_BAD_REQUEST)

        progress_stage = case.progress_stages.filter(stage=stage).first()
        mark_complete = request.data.get("mark_complete")
        if mark_complete is None:
            mark_complete = progress_stage is None

        if mark_complete:
            completion_date = request.data.get("completion_date") or timezone.now().date()
            if progress_stage:
                progress_stage.completion_date = completion_date
                progress_stage.order_in_timeline = stage.order
                progress_stage.save(update_fields=["completion_date", "order_in_timeline"])
            else:
                ProgressStage.objects.create(
                    case=case,
                    stage=stage,
                    order_in_timeline=stage.order,
                    completion_date=completion_date,
                )
            detail = f"Stage '{stage_name}' marked as completed."
        else:
            if progress_stage:
                progress_stage.delete()
            detail = f"Stage '{stage_name}' was removed."

        case.refresh_from_db()
        return Response(
            {
                "detail": detail,
                "applied_impacts": preview["impacts"],
                "stage_summary": get_stage_summary(case),
            },
            status=status.HTTP_200_OK,
        )



class GetAvailableStagesView(APIView):
    permission_classes = [IsAccountManager | IsBrandOwner]

    def get(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        if hasattr(request.user, "am"):
            mark_case_opened_by_am(case, request.user)
        all_stages = Stage.objects.all().order_by('order')
        completed_stages = case.progress_stages.filter(completion_date__isnull=False).order_by('order_in_timeline')

        stages = [
            {
                "id": stage.id,
                "name": stage.name,
                "order": stage.order,
                "completed": any(completed_stage.stage == stage for completed_stage in completed_stages),
                "completion_date": next(
                    (completed_stage.completion_date for completed_stage in completed_stages if completed_stage.stage == stage), None
                )
            }
            for stage in all_stages
        ]

        # Determine next stage
        last_completed_stage = completed_stages.last()
        if last_completed_stage:
            next_stage = all_stages.filter(order__gt=last_completed_stage.stage.order).first()
        else:
            next_stage = all_stages.first()

        return Response(
            {"stages": stages, "next_stage": next_stage.name if next_stage else None},
            status=status.HTTP_200_OK
        )






from rest_framework.permissions import IsAuthenticated


class UpdateCaseNameView(APIView):
    permission_classes = [IsBrandOwner]

    def put(self, request, case_id):
        # Get the case
        case = get_object_or_404(Case, id=case_id)

        # Check if the user is a brand owner and owns the case
        if hasattr(request.user, 'brandowner') and case.brand_owner == request.user.brandowner:
            new_name = request.data.get('name')
            if not new_name:
                return Response(
                    {"error": "Name field is required."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Update the name field
            case.name = new_name
            case.save()

            return Response(
                {"message": "Case name updated successfully.", "case_id": case.id, "name": case.name},
                status=status.HTTP_200_OK
            )
        else:
            return Response(
                {"error": "You do not have permission to update this case."},
                status=status.HTTP_403_FORBIDDEN
            )

class CaseUsersView(APIView):
    permission_classes = [IsAuthenticated, IsAccountManager | IsBrandOwner | IsFactoryOwner]

    def get_role(self, obj):
        if hasattr(obj, 'brandowner'):
            return 'Brand Owner'
        elif hasattr(obj, 'am'):
            return 'Account Manager'
        elif hasattr(obj, 'formulator'):
            return 'Formulator'
        elif hasattr(obj, 'factoryowner'):
            return 'Factory Owner'
        return 'Unknown'

    def get(self, request, case_id):
        try:
            case = Case.objects.get(id=case_id)
        except Case.DoesNotExist:
            return Response({'error': 'Case not found.'}, status=404)

        users = []

        # Add Brand Owner if present
        if case.brand_owner and case.brand_owner.user:
            users.append(case.brand_owner.user)

        # Add all Account Managers (AMs) if present
        if case.am.exists():
            for am in case.am.all():
                if am.user:
                    users.append(am.user)

        # Add Factory Owners via associated factories
        if case.factory:
            factory_owner = case.factory.factory_owner
            if factory_owner and factory_owner.user:
                users.append(factory_owner.user)
        
        # Ensure that each user is included only once
        unique_users = list(set(users))

        # Serialize users
        user_data = [
            {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': self.get_role(user),  # Correctly calling the get_role method
            }
            for user in unique_users
        ]

        return Response(user_data)


class CaseAssignmentView(APIView):
    permission_classes = [IsAuthenticated, IsPrivilegedAccountManager]

    def get(self, request, case_id):
        case = get_object_or_404(
            Case.objects.select_related("brand_owner").prefetch_related("am__user"),
            id=case_id,
        )
        viewers = list(case.am.select_related("user").order_by("name", "id"))
        assignable_ams = (
            AM.objects.select_related("user")
            .filter(is_active=True)
            .annotate(load=Count("cases_am", distinct=True))
            .order_by("load", "id")
        )

        return Response(
            {
                "case_id": case.id,
                "brand_owner_id": case.brand_owner_id,
                "brand_case_count": (
                    Case.objects.filter(brand_owner=case.brand_owner).exclude(active=2).count()
                    if case.brand_owner_id
                    else 1
                ),
                "viewer_ams": AMListSerializer(viewers, many=True).data,
                "assignable_ams": AMListSerializer(assignable_ams, many=True).data,
            }
        )

    def post(self, request, case_id):
        case = get_object_or_404(Case.objects.select_related("brand_owner"), id=case_id)
        action = str(request.data.get("action") or "assign").lower()
        if action not in {"assign", "unassign"}:
            return Response(
                {"detail": "action must be either 'assign' or 'unassign'."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        scope = str(request.data.get("scope") or "brand").lower()
        if scope not in {"brand", "case"}:
            return Response({"detail": "scope must be either 'brand' or 'case'."}, status=status.HTTP_400_BAD_REQUEST)

        target_am = None
        am_id = request.data.get("am_id")
        if action == "assign":
            if not am_id:
                return Response({"detail": "am_id is required."}, status=status.HTTP_400_BAD_REQUEST)
            target_am = get_object_or_404(AM.objects.select_related("user"), pk=am_id, is_active=True)

        brand_owner = case.brand_owner
        if not brand_owner:
            return Response({"detail": "This case has no brand owner."}, status=status.HTTP_400_BAD_REQUEST)

        if scope == "case":
            affected_cases = [case]
        else:
            affected_cases = list(
                Case.objects.filter(brand_owner=brand_owner)
                .exclude(active=2)
                .prefetch_related("am__user")
                .order_by("id")
            )
            if not affected_cases:
                affected_cases = [case]

        privileged_ams = list(
            AM.objects.filter(user__groups__name__in=["superAM", "MNGMNT"]).distinct()
        )

        with transaction.atomic():
            for affected_case in affected_cases:
                current_normal_ams = affected_case.am.exclude(user__groups__name__in=["superAM", "MNGMNT"])
                if current_normal_ams.exists():
                    affected_case.am.remove(*current_normal_ams)

                if action == "assign" and target_am and not affected_case.am.filter(pk=target_am.pk).exists():
                    affected_case.am.add(target_am)

                if privileged_ams:
                    affected_case.am.add(*privileged_ams)

                Alert.objects.create(
                    case=affected_case,
                    message=(
                        (
                            f"Assigned this case to {target_am.name} by {request.user.am.name}."
                            if scope == "case"
                            else f"Assigned to {target_am.name} by {request.user.am.name}."
                        )
                        if action == "assign"
                        else (
                            f"Unassigned this case by {request.user.am.name}."
                            if scope == "case"
                            else f"Unassigned by {request.user.am.name}."
                        )
                    ),
                )

        refreshed_case = get_object_or_404(Case.objects.prefetch_related("am__user"), pk=case.pk)
        return Response(
            {
                "case_id": case.id,
                "brand_owner_id": brand_owner.id,
                "action": action,
                "scope": scope,
                "brand_case_count": len(affected_cases),
                "affected_case_ids": [item.id for item in affected_cases],
                "assigned_am": AMListSerializer(target_am).data if target_am else None,
                "viewer_ams": AMListSerializer(
                    refreshed_case.am.select_related("user").order_by("name", "id"),
                    many=True,
                ).data,
                "detail": (
                    (
                        f"Case #{case.id} is now assigned to {target_am.name}."
                        if scope == "case"
                        else f"{len(affected_cases)} case(s) for this brand are now assigned to {target_am.name}."
                    )
                    if action == "assign"
                    else (
                        f"Case #{case.id} has been unassigned."
                        if scope == "case"
                        else f"Cleared non-privileged assignees from {len(affected_cases)} case(s) for this brand."
                    )
                ),
            },
            status=status.HTTP_200_OK,
        )

from case.models import Alert



class AlertListCreateAPIView(APIView):
    """
    GET -> returns a list of alerts (optionally filter by case)
    POST -> creates a new alert
    """

    def get(self, request, *args, **kwargs):
        case_id = request.query_params.get("case", None)
        if case_id:
            alerts = Alert.objects.filter(case_id=case_id)
        else:
            alerts = Alert.objects.all()
        serializer = AlertSerializer(alerts, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        serializer = AlertSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class AlertDetailAPIView(APIView):
    """
    GET    -> returns alert detail
    PUT    -> update alert fully
    PATCH  -> update alert partially
    DELETE -> delete alert
    """

    def get_object(self, pk):
        return get_object_or_404(Alert, pk=pk)

    def get(self, request, pk, *args, **kwargs):
        alert = self.get_object(pk)
        serializer = AlertSerializer(alert)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk, *args, **kwargs):
        alert = self.get_object(pk)
        serializer = AlertSerializer(alert, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def patch(self, request, pk, *args, **kwargs):
        alert = self.get_object(pk)
        serializer = AlertSerializer(alert, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, *args, **kwargs):
        alert = self.get_object(pk)
        alert.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class MarkAlertDoneAPIView(APIView):
    """
    POST -> sets an Alert's `is_done=True` and `done_date=timezone.now()`
    Example endpoint: /api/alerts/<pk>/mark_done/
    """

    def post(self, request, pk, *args, **kwargs):
        alert = get_object_or_404(Alert, pk=pk)
        alert.mark_done()
        serializer = AlertSerializer(alert)
        return Response(serializer.data, status=status.HTTP_200_OK)
    

from .models import Case, OperationalStatus, CaseOperationalStatus
from .serializers_ops import CaseOperationalStatusSerializer, OperationalStatusSerializer
from user.permissions import IsAccountManager

class CaseNotesUpdateView(APIView):
    permission_classes = [IsAccountManager]

    def patch(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        notes = request.data.get("notes", "")
        case.notes = notes
        case.save(update_fields=["notes"])
        return Response({"message": "Notes updated", "notes": case.notes}, status=status.HTTP_200_OK)


class CaseOperationalStatusUpsertView(APIView):
    """
    POST/PATCH /api/cases/<case_id>/ops-status/
    Body: { "status_id": <id>, "state": "in_process"|"done", "notes": "<optional>" }
    Creates or updates the CaseOperationalStatus row (unique per (case,status)).
    """
    permission_classes = [IsAccountManager]

    def post(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        status_obj = get_object_or_404(OperationalStatus, id=request.data.get("status_id"))
        state = request.data.get("state")
        if state not in (CaseOperationalStatus.IN_PROCESS, CaseOperationalStatus.DONE):
            return Response({"error": "Invalid state"}, status=status.HTTP_400_BAD_REQUEST)

        link, created = CaseOperationalStatus.objects.get_or_create(
            case=case, status=status_obj, defaults={"state": state}
        )
        if not created:
            link.state = state
        link.notes = request.data.get("notes", link.notes)
        if hasattr(request.user, "id"):
            link.updated_by = request.user
        link.save()

        return Response(CaseOperationalStatusSerializer(link).data, status=status.HTTP_200_OK)

class CaseOperationalStatusDeleteView(APIView):
    """
    DELETE /api/cases/<case_id>/ops-status/<status_id>/
    Removes the link (reverts to 'none' by deleting the row).
    """
    permission_classes = [IsAccountManager]

    def delete(self, request, case_id, status_id):
        case = get_object_or_404(Case, id=case_id)
        link = get_object_or_404(CaseOperationalStatus, case=case, status_id=status_id)
        link.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class OperationalStatusListView(ListAPIView):
    permission_classes = [IsAccountManager]  # or AllowAny if you prefer
    serializer_class = OperationalStatusSerializer

    def get_queryset(self):
        return OperationalStatus.objects.filter(is_active=True).order_by("name")



class CaseOperationalStatusUpdateView(APIView):
    """
    PATCH /api/cases/<case_id>/ops-status/<status_id>/update/
    Body (any subset):
      {
        "state": "in_process" | "done",
        "notes": "optional free text"
      }
    """
    permission_classes = [IsAccountManager]

    def patch(self, request, case_id, status_id):
        case = get_object_or_404(Case, id=case_id)
        link = get_object_or_404(CaseOperationalStatus, case=case, status_id=status_id)

        state = request.data.get("state", None)
        notes = request.data.get("notes", None)

        if state is None and notes is None:
            return Response(
                {"error": "Provide 'state' and/or 'notes' to update."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        update_fields = []

        if state is not None:
            if state not in (CaseOperationalStatus.IN_PROCESS, CaseOperationalStatus.DONE):
                return Response({"error": "Invalid state"}, status=status.HTTP_400_BAD_REQUEST)
            link.state = state
            update_fields.append("state")

        if notes is not None:
            link.notes = notes
            update_fields.append("notes")

        link.updated_by = getattr(request, "user", None)
        update_fields.extend(["updated_by", "updated_at"])
        link.save(update_fields=update_fields)

        return Response(CaseOperationalStatusSerializer(link).data, status=status.HTTP_200_OK)
    
class UpdateCaseColorView(APIView):
    
    permission_classes = [IsAuthenticated, IsAccountManager]

    def patch(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        serializer = CaseColorUpdateSerializer(case, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Case color updated successfully.", "case": serializer.data},
                status=status.HTTP_200_OK
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UpdateCasePriorityView(APIView):
    permission_classes = [IsAuthenticated, IsAccountManager]

    def patch(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        serializer = CasePriorityUpdateSerializer(case, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Case priority updated successfully.", "case": serializer.data},
                status=status.HTTP_200_OK,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class AssignFaoudProductToCaseView(APIView):
    """
    Assign a Faoud marketplace product to a case by creating a clone.
    This ensures the case has its own independent copy that won't be affected
    by changes to the original Faoud marketplace product.
    """
    permission_classes = [IsAuthenticated, IsAccountManager]

    def patch(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        product_id = request.data.get('product_id')
        
        if not product_id:
            return Response(
                {"error": "product_id is required"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Import here to avoid circular imports
        from product.models import Product
        from product.services import ProductCloningService, ProductVersionValidator
        
        # Get the product and verify it exists
        try:
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return Response(
                {"error": "Product not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Verify it's a Faoud product
        if not product.isFaoud_Product:
            return Response(
                {"error": "Only Faoud marketplace products can be assigned through this endpoint"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Validate the product can be cloned
        is_valid, error_msg = ProductVersionValidator.validate_product_for_cloning(product)
        if not is_valid:
            return Response(
                {"error": error_msg},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Check if case already has a product assigned
        previous_product = None
        if case.product:
            previous_product = {
                "id": case.product.id,
                "name": case.product.name,
                "version_number": case.product.version_number
            }
        
        # Clone the product for this case
        try:
            cloned_product = ProductCloningService.clone_product_for_case(
                original_product=product,
                case=case,
                created_by_user=request.user
            )
        except Exception as e:
            return Response(
                {"error": f"Failed to clone product: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        # Assign the cloned product to the case
        case.product = cloned_product
        case.save(update_fields=['product'])
        
        response_data = {
            "message": "Faoud product cloned and assigned successfully",
            "case_id": case.id,
            "product": {
                "id": cloned_product.id,
                "name": cloned_product.name,
                "sku_and_pm": cloned_product.sku_and_pm,
                "category": cloned_product.category.name if cloned_product.category else None,
                "subcategory": cloned_product.subcategory.name if cloned_product.subcategory else None,
                "picture": cloned_product.picture.url if cloned_product.picture else None,
                "isFaoud_Product": cloned_product.isFaoud_Product,
                "is_original": cloned_product.is_original,
                "version_number": cloned_product.version_number,
                "product_group_id": cloned_product.product_group.id if cloned_product.product_group else None,
            }
        }
        
        if previous_product:
            response_data["warning"] = "Case already had a product assigned. It has been replaced."
            response_data["previous_product"] = previous_product
        
        return Response(response_data, status=status.HTTP_200_OK)

class EditCaseProductView(APIView):
    """
    Edit a product assigned to a case by creating a new version.
    This creates a new product version within the same product group
    while preserving the original and previous versions.
    """
    permission_classes = [IsAuthenticated, IsAccountManager]

    def patch(self, request, case_id, product_id):
        case = get_object_or_404(Case, id=case_id)

        # Import here to avoid circular imports
        from product.models import Product
        from product.services import ProductCloningService, ProductVersionValidator
        from product.serializers import ProductSerializer

        # Verify the product exists and belongs to this case
        try:
            product = Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return Response({"error": "Product not found"}, status=status.HTTP_404_NOT_FOUND)

        # Verify this product is assigned to this case
        if case.product_id != product_id:
            return Response({"error": "This product is not assigned to this case"}, status=status.HTTP_400_BAD_REQUEST)

        # Validate the product can be edited
        is_valid, error_msg = ProductVersionValidator.validate_product_for_editing(product)
        if not is_valid:
            return Response({"error": error_msg}, status=status.HTTP_400_BAD_REQUEST)

        # Determine how many cases use this product (both FK and M2M, to be safe)
        m2m_count = product.cases.count()
        fk_count = Case.objects.filter(product=product).count()
        total_assignments = max(m2m_count, fk_count)

        # Prepare update data
        updated_data = {
            'name': request.data.get('name'),
            'sku_and_pm': request.data.get('sku_and_pm'),
            'quantity': request.data.get('quantity'),
            'eta': request.data.get('eta'),
            'benchmark': request.data.get('benchmark'),
            'modification_notes': request.data.get('modification_notes', ''),
        }
        updated_data = {k: v for k, v in updated_data.items() if v is not None}

        # File upload
        if 'picture' in request.FILES:
            updated_data['picture'] = request.FILES['picture']

        # Optional materials payloads for versioned edits
        if 'raw_materials' in request.data:
            updated_data['raw_materials'] = request.data.get('raw_materials', [])
        if 'packaging_materials' in request.data:
            updated_data['packaging_materials'] = request.data.get('packaging_materials', [])
        
        # Decide whether to clone or edit in-place based on how many cases reference this product
        attached_cases_count = Case.objects.filter(product=product).count()

        if attached_cases_count > 1:
            # Many cases reference this product -> create a new cloned/edited version and attach to this case
            try:
                new_version = ProductCloningService.create_edited_version(
                    existing_product=product,
                    case=case,
                    updated_data=updated_data,
                    user=request.user
                )
            except Exception as e:
                return Response(
                    {"error": f"Failed to create new version: {str(e)}"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR
                )

            # Update case to use new version
            case.product = new_version
            case.save(update_fields=['product'])

            return Response({
                "message": "Product cloned and updated for this case.",
                "previous_version": {
                    "id": product.id,
                    "version_number": product.version_number
                },
                "new_version": {
                    "id": new_version.id,
                    "name": new_version.name,
                    "version_number": new_version.version_number,
                    "product_group_id": new_version.product_group.id if new_version.product_group else None,
                    "modification_notes": new_version.modification_notes
                }
            }, status=status.HTTP_200_OK)
        else:
            # Only this case references the product -> edit in-place
            try:
                # update simple fields
                for field in ('name', 'sku_and_pm', 'quantity', 'eta', 'benchmark', 'modification_notes'):
                    if field in updated_data:
                        setattr(product, field, updated_data[field])

                # picture
                if 'picture' in updated_data:
                    product.picture = updated_data['picture']

                # raw_materials and packaging_materials (attempt to set if the relations exist)
                if 'raw_materials' in updated_data and hasattr(product, 'raw_materials'):
                    try:
                        product.raw_materials.set(updated_data['raw_materials'])
                    except Exception:
                        # If provided as nested objects or invalid ids, ignore here and let higher-level validators handle it
                        pass

                if 'packaging_materials' in updated_data and hasattr(product, 'packaging_materials'):
                    try:
                        product.packaging_materials.set(updated_data['packaging_materials'])
                    except Exception:
                        pass

                product.save()

            except Exception as e:
                return Response({"error": f"Failed to update product in-place: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            return Response({
                "message": "Product updated in-place",
                "product": {
                    "id": product.id,
                    "name": product.name,
                    "version_number": getattr(product, 'version_number', None)
                }
            }, status=status.HTTP_200_OK)


class CaseProductHistoryView(APIView):
    """
    View all product versions that have been assigned to a case over time.
    Shows the evolution of the product for this specific case.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)
        
        # Import here to avoid circular imports
        from product.models import Product
        from product.serializers import ProductVersionMinimalSerializer
        
        # Get all products created for this case
        products = Product.objects.filter(
            created_from_case=case
        ).select_related(
            'category', 'subcategory', 'product_group', 'parent_product'
        ).order_by('version_number')
        
        serializer = ProductVersionMinimalSerializer(products, many=True)
        
        return Response({
            "case_id": case.id,
            "case_name": case.name,
            "current_product": {
                "id": case.product.id,
                "name": case.product.name,
                "version_number": case.product.version_number
            } if case.product else None,
            "product_history": serializer.data,
            "total_versions": products.count()
        }, status=status.HTTP_200_OK)
