from rest_framework import serializers
from product.serializers import ProductSerializer
from user.models import AM
from user.serializers import AMSerializerMin
from .models import Case, ProgressStage, Stage





class ProgressStageMinSerializer(serializers.ModelSerializer):
    stage_name = serializers.CharField(source="stage.name", read_only=True)

    class Meta:
        model = ProgressStage
        fields = ("stage_name", "completion_date", "order_in_timeline")

class CaseSerializerMin(serializers.ModelSerializer):
    product = ProductSerializer(read_only=True)
    am = AMSerializerMin(read_only=True, many=True)
    stages = ProgressStageMinSerializer(source="progress_stages", many=True, read_only=True)

    class Meta:
            model  = Case
            fields = (
                "id", "name", "brand_owner", "product",
                "stages", "start_date", "am",
                "category", "active", "priority"
            )


class CaseNameUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Case
        fields = ['name']  # Include only the editable fields
