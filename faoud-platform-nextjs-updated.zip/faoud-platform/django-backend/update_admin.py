import os

# Base directory of your Django project
base_dir = os.path.dirname(os.path.abspath(__file__))

# App directories and their models
apps_models = {
    "case": ["Service", "Stage", "Case", "ProgressStage"],
    "user": ["BrandOwner", "Formulator", "AM"],
    "product": ["Product", "Questionnaire", "QuestionnaireAnswer", "Question"],
    "supply": ["RMSupplier", "PMSupplier", "Factory", "Bid"],
    "formulation": ["Formulation"],
    "comms": ["Chat"],
    "utils": ["Brand", "Address", "Brief"],
    "materials": ["RawMaterial", "PackagingMaterial"],
}

# Function to update admin.py to register models
def update_admin(app_name, models):
    admin_path = os.path.join(base_dir, app_name, 'admin.py')
    with open(admin_path, 'w') as file:
        file.write("from django.contrib import admin\n")
        file.write("from .models import " + ", ".join(models) + "\n\n")
        for model in models:
            file.write(f"admin.site.register({model})\n")

# Update admin.py for each app
for app, models in apps_models.items():
    update_admin(app, models)
