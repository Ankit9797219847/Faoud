from django.core import signing


UNSUBSCRIBE_TOKEN_SALT = "user.email-preferences.unsubscribe"
UNSUBSCRIBE_TOKEN_MAX_AGE_SECONDS = 60 * 60 * 24 * 14


def build_unsubscribe_token(user):
    return signing.dumps({"user_id": user.id}, salt=UNSUBSCRIBE_TOKEN_SALT)


def load_unsubscribe_token(token):
    payload = signing.loads(
        token,
        salt=UNSUBSCRIBE_TOKEN_SALT,
        max_age=UNSUBSCRIBE_TOKEN_MAX_AGE_SECONDS,
    )
    return payload["user_id"]
