from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("user", "0008_brandowner_self_onboarded"),
    ]

    operations = [
        migrations.AddField(
            model_name="brandowner",
            name="signup_alert_scheduled",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="brandowner",
            name="signup_alert_scheduled_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="brandowner",
            name="signup_alert_sent",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="brandowner",
            name="signup_alert_sent_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="factoryowner",
            name="signup_alert_scheduled",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="factoryowner",
            name="signup_alert_scheduled_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="factoryowner",
            name="signup_alert_sent",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="factoryowner",
            name="signup_alert_sent_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
