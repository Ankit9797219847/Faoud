from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("user", "0007_termsandconditions_termsacceptance"),
    ]

    operations = [
        migrations.AddField(
            model_name="brandowner",
            name="self_onboarded",
            field=models.BooleanField(default=True),
        ),
    ]
