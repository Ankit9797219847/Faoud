from venv import logger
from rest_framework.permissions import BasePermission
from payments.models import UserFeature
from user.models import BrandOwner, FactoryOwner, AM


from rest_framework.permissions import BasePermission


class IsBrandOwner(BasePermission):
    def has_permission(self, request, view):
        if request.user.is_authenticated:
            brandOwner = BrandOwner.objects.filter(user=request.user)
            if brandOwner:
                return True

        return False


class IsAccountManager(BasePermission):
    def has_permission(self, request, view):
        if request.user.is_authenticated:
            am = AM.objects.filter(user=request.user)
            if am:
                return True

        return False

class IsSuperAccountManager(BasePermission):
    def has_permission(self, request, view):
        if request.user.is_authenticated:
            am = AM.objects.filter(user=request.user)
            if request.user.groups.filter(name='superAM').exists() and am:
                return True

        return False
    
class IsMNGMNTAccountManager(BasePermission):
    def has_permission(self, request, view):
        if request.user.is_authenticated:
            am = AM.objects.filter(user=request.user)
            if request.user.groups.filter(name='MNGMNT').exists() and am:
                return True

        return False

class IsPrivilegedAccountManager(BasePermission):
    """
    Permission for SuperAM and ManagementAM (MNGMNT group)
    """
    def has_permission(self, request, view):
        if request.user.is_authenticated:
            am = AM.objects.filter(user=request.user).exists()
            if am and request.user.groups.filter(name__in=['superAM', 'MNGMNT']).exists():
                return True
        return False

class IsNormalAccountManager(BasePermission):
    """
    Permission for normal Account Managers (not in superAM or MNGMNT groups)
    """
    def has_permission(self, request, view):
        if request.user.is_authenticated:
            am = AM.objects.filter(user=request.user).exists()
            if am and not request.user.groups.filter(name__in=['superAM', 'MNGMNT']).exists():
                return True
        return False
    
class IsFactoryOwner(BasePermission):
    def has_permission(self, request, view):
        if request.user.is_authenticated:
            factory_owner = FactoryOwner.objects.filter(user=request.user)
            if factory_owner.exists():
                return True
        return False
    

class HasFeaturePermission(BasePermission):
    def has_permission(self, request, view):
        feature_name = getattr(view, 'required_feature', None)
        if feature_name:
            return UserFeature.objects.filter(
                user=request.user,
                feature__name=feature_name,
                is_active=True
            ).exists()
        return True


def in_group(user, name: str) -> bool:
    return user.is_authenticated and user.groups.filter(name=name).exists()

def is_super_am(user) -> bool:
    # your existing logic for "super account manager"
    return in_group(user, 'superAM') or getattr(user, 'is_superuser', False)

def is_mngmt(user) -> bool:
    return in_group(user, 'MNGMNT')

def is_am(user) -> bool:
    return AM.objects.filter(user=user).exists()