from django.urls import path

from supply.views import CaseListForBiddingView
from .views import (
    AMListView,
    FormulatorListView,
    FactoryOwnerListView,
    IsMNGMNTAMView,
    IsSuperAMView,
    LeadFinishSignupView,
    LoginStatsView,
    LogoutView,
    PasswordResetConfirmView,
    PasswordResetRequestView,
    RegisterView,
    ResendVerificationEmailView,
    LoginView,
    UserDataView,
    VerifyEmailView,
    UpdateEmailPreferencesView,
    UnsubscribeEmailPreferencesView,
    TermsStatusView,
    AcceptTermsView,
    TermsHistoryView,
    PublicLatestTermsView,
    CheckPendingTermsView,
    CSRFCookieView,
)

urlpatterns = [
    path("auth/csrf/", CSRFCookieView.as_view(), name="auth-csrf"),
    path("auth/register/", RegisterView.as_view(), name="register"),
    path("auth/login/", LoginView.as_view(), name="login"),
    path("auth/resend-verification/", ResendVerificationEmailView.as_view(), name="resend-verification"),
    path('formulators/', FormulatorListView.as_view(), name='formulator-list'),
    path('factory-owners/', FactoryOwnerListView.as_view(), name='factory-owner-list'),
    path('cases-for-bidding/', CaseListForBiddingView.as_view(), name='cases-for-bidding'),
    path('user/data/', UserDataView.as_view(), name='user-data'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('request-reset/', PasswordResetRequestView.as_view(), name='request-reset'),
    path('reset/<int:uid>/<str:token>/', PasswordResetConfirmView.as_view(), name='password-reset-confirm'),
    path('verify/<int:uid>/<str:token>/', VerifyEmailView.as_view(), name='verify-email'),
    path('preferences/email/', UpdateEmailPreferencesView.as_view(), name='update-email-preferences'),
    path('preferences/email/unsubscribe/', UnsubscribeEmailPreferencesView.as_view(), name='unsubscribe-email-preferences'),
    path('isShadowhere/', IsSuperAMView.as_view(), name='is-super-account-manager'),
    path('isSanhere/', IsMNGMNTAMView.as_view(), name='is-management-account-manager'),
    path("auth/lead-finish/", LeadFinishSignupView.as_view(), name="lead-finish"),
    path("auth/reset-password-confirm/<int:uid>/<str:token>/", PasswordResetConfirmView.as_view(), name="reset-password-confirm"),
    path('ams/', AMListView.as_view(), name='am-list'),
    path("logins/", LoginStatsView.as_view(), name="login-stats"),
    # Terms & Conditions
    path("terms/status/", TermsStatusView.as_view(), name="terms-status"),
    path("terms/accept/", AcceptTermsView.as_view(), name="terms-accept"),
    path("terms/history/", TermsHistoryView.as_view(), name="terms-history"),
    
    # New Public Terms Paths
    path("terms/public/latest/", PublicLatestTermsView.as_view(), name="terms-public-latest"),
    path("terms/check-pending/", CheckPendingTermsView.as_view(), name="terms-check-pending"),
    # ...

]
