from celery import shared_task
from django.db import transaction
from django.utils import timezone

from notifications.notif import send_html_email

from .models import AM, BrandOwner, FactoryOwner

SIGNUP_ALERT_DELAY_MODEL_MAP = {
    "brand_owner": BrandOwner,
    "factory_owner": FactoryOwner,
}


def get_signup_alert_recipients():
    return list(
        AM.objects.select_related("user")
        .filter(user__email__isnull=False)
        .exclude(user__email="")
        .values_list("user__email", flat=True)
    )


def build_signup_alert_context(role_label, profile):
    user = getattr(profile, "user", None)
    verified = bool(user and user.is_active)
    return {
        "role_label": role_label,
        "profile_name": profile.name or "N/A",
        "contact_email": profile.contact_email or "N/A",
        "contact_phone": profile.contact_phone or "N/A",
        "username": getattr(user, "username", "") or "N/A",
        "created_at": profile.created_at,
        "email_verified": "Yes" if verified else "No",
        "verified": verified,
    }


@shared_task
def send_delayed_signup_alert_task(profile_type, profile_id):
    model = SIGNUP_ALERT_DELAY_MODEL_MAP.get(profile_type)
    if not model:
        return

    profile = model.objects.select_related("user").filter(id=profile_id).first()
    if not profile or profile.signup_alert_sent:
        return

    recipients = get_signup_alert_recipients()
    if not recipients:
        return

    role_label = "Brand Owner" if profile_type == "brand_owner" else "Factory Owner"
    subject = f"[Signup Alert] {role_label} account created - {profile.name or 'Unnamed'}"
    context = build_signup_alert_context(role_label, profile)
    send_html_email(subject, "documents/signup_alert_internal.html", context, recipients)

    with transaction.atomic():
        latest = model.objects.select_for_update().filter(id=profile_id).first()
        if latest and not latest.signup_alert_sent:
            latest.signup_alert_sent = True
            latest.signup_alert_sent_at = timezone.now()
            latest.save(update_fields=["signup_alert_sent", "signup_alert_sent_at"])
