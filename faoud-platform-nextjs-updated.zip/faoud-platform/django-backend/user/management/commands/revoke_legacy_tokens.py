from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Delete all legacy DRF auth tokens after migrating to session-only auth."

    def handle(self, *args, **options):
        try:
            from rest_framework.authtoken.models import Token
        except Exception as exc:
            self.stderr.write(self.style.ERROR(f"Unable to load DRF tokens: {exc}"))
            return

        deleted_count, _ = Token.objects.all().delete()
        self.stdout.write(
            self.style.SUCCESS(f"Deleted {deleted_count} legacy DRF auth token records.")
        )
