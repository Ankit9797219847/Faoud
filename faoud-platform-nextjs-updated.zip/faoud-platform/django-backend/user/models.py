from django.conf import settings
from django.db import models
from django.contrib.auth.models import User
from django.db import models






# Brand Owners Model
class BrandOwner(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
    name = models.CharField(max_length=100)
    contact_phone = models.CharField(max_length=15, blank=True, null=True)
    contact_email = models.EmailField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    brands = models.ManyToManyField(
        "utils.Brand", related_name="brand_owners", blank=True
    )
    cases = models.ManyToManyField("case.Case", related_name="brand_owners", blank=True)
    terms_accepted = models.BooleanField(default=False)
    self_onboarded = models.BooleanField(default=True)
    terms_accepted_at = models.DateTimeField(null=True, blank=True)
    terms_version_accepted = models.CharField(max_length=50, null=True, blank=True)
    marketing_emails = models.BooleanField(default=True)
    operational_emails = models.BooleanField(default=True)
    signup_alert_scheduled = models.BooleanField(default=False)
    signup_alert_scheduled_at = models.DateTimeField(null=True, blank=True)
    signup_alert_sent = models.BooleanField(default=False)
    signup_alert_sent_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.name


class Formulator(models.Model):
    name = models.CharField(max_length=100, default="Formulator")
    age = models.PositiveIntegerField(blank=True, null=True)
    employee_id = models.CharField(max_length=100, blank=True, null=True)
    formulations = models.ManyToManyField(
        "formulation.Formulation", related_name="formulators_formulation", blank=True
    )
    skills = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name


class AM(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
    name = models.CharField(max_length=100)
    contact_phone = models.CharField(max_length=15, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    contact_email = models.EmailField(blank=True, null=True)
    cases = models.ManyToManyField("case.Case", related_name="case_am", blank=True)
    products_worked_on = models.ManyToManyField(
        "product.Product", related_name="ams_products", blank=True
    )
    address = models.TextField(blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    profile_picture = models.ImageField(
        upload_to="profile_pictures/", blank=True, null=True
    )
    date_joined = models.DateTimeField(auto_now_add=True, null=True)
    last_login = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    def __str__(self):
        return self.user.username


# Factory Owners Model
class FactoryOwner(models.Model):

    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)

    name = models.CharField(max_length=100)
    contact_phone = models.CharField(max_length=15, blank=True, null=True)
    contact_email = models.EmailField(blank=True, null=True)
    terms_accepted = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    terms_accepted_at = models.DateTimeField(null=True, blank=True)
    terms_version_accepted = models.CharField(max_length=50, null=True, blank=True)
    factories = models.ManyToManyField(
        "supply.Factory", related_name="factory_owners", blank=True
    )
    cases = models.ManyToManyField("case.Case", related_name="factory_owners", blank=True)
    marketing_emails = models.BooleanField(default=True)
    operational_emails = models.BooleanField(default=True)
    signup_alert_scheduled = models.BooleanField(default=False)
    signup_alert_scheduled_at = models.DateTimeField(null=True, blank=True)
    signup_alert_sent = models.BooleanField(default=False)
    signup_alert_sent_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.name



class LoginEvent(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    role = models.CharField(max_length=30)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.role} @ {self.created_at}"

# --- Versioned Terms & Acceptance Models ---
import hashlib
from django.utils import timezone
from django.core.exceptions import ValidationError

class TermsAndConditions(models.Model):
    SCOPE_GLOBAL = "global"
    SCOPE_BRAND_OWNER = "brand_owner"
    SCOPE_FACTORY_OWNER = "factory_owner"
    SCOPE_CHOICES = [
        (SCOPE_GLOBAL, "Global"),
        (SCOPE_BRAND_OWNER, "Brand Owner"),
        (SCOPE_FACTORY_OWNER, "Factory Owner"),
    ]

    scope = models.CharField(max_length=20, choices=SCOPE_CHOICES)
    version = models.PositiveIntegerField(help_text="Increment for each published change per scope")
    title = models.CharField(max_length=200)
    content = models.TextField(blank=True, null=True)
    file = models.FileField(upload_to='terms_pdfs/', null=True, blank=True, help_text="Optional PDF file for terms")
    is_active = models.BooleanField(default=True, help_text="Only one active per scope")
    created_at = models.DateTimeField(auto_now_add=True)
    published_at = models.DateTimeField(auto_now_add=True)
    content_hash = models.CharField(max_length=64, editable=False)

    class Meta:
        unique_together = ("scope", "version")
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.scope} v{self.version} ({'active' if self.is_active else 'inactive'})"

    def clean(self):
        if not self.content and not self.file:
            raise ValidationError("Either content or a PDF file must be provided.")

    def save(self, *args, **kwargs):
        # Hash content for integrity
        data_to_hash = self.content if self.content else (self.file.name if self.file else "")
        self.content_hash = hashlib.sha256(data_to_hash.encode("utf-8")).hexdigest()
        super().save(*args, **kwargs)
        if self.is_active:
            # Ensure only one active per scope (including global)
            TermsAndConditions.objects.filter(scope=self.scope, is_active=True).exclude(pk=self.pk).update(is_active=False)


class TermsAcceptance(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="terms_acceptances")
    terms = models.ForeignKey(TermsAndConditions, on_delete=models.CASCADE, related_name="acceptances")
    accepted_at = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(null=True, blank=True)
    signature_hash = models.CharField(max_length=128, editable=False)

    class Meta:
        unique_together = ("user", "terms")
        ordering = ["-accepted_at"]

    def __str__(self):
        return f"{self.user_id} accepted {self.terms.scope} v{self.terms.version} @ {self.accepted_at}"

    def save(self, *args, **kwargs):
        creating = self.pk is None
        super().save(*args, **kwargs)
        if creating:
            # Generate immutable signature proof (user id + terms hash + timestamp)
            base = f"{self.user_id}:{self.terms_id}:{self.terms.content_hash}:{int(self.accepted_at.timestamp())}"
            self.signature_hash = hashlib.sha256(base.encode("utf-8")).hexdigest()
            super().save(update_fields=["signature_hash"])
            # Convenience: update legacy fields on role-specific profile if present
            role_profile = None
            if hasattr(self.user, "brandowner"):
                role_profile = getattr(self.user, "brandowner")
            elif hasattr(self.user, "factoryowner"):
                role_profile = getattr(self.user, "factoryowner")
            if role_profile:
                role_profile.terms_accepted = True
                role_profile.terms_accepted_at = timezone.now()
                role_profile.terms_version_accepted = f"v{self.terms.version}"
                role_profile.save(update_fields=["terms_accepted", "terms_accepted_at", "terms_version_accepted"])
