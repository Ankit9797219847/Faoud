
from datetime import datetime, timezone
import json
from django.contrib.auth.models import User
from django.forms import ValidationError
from rest_framework import serializers
from rest_framework.validators import UniqueValidator
from django.contrib.auth.password_validation import validate_password
from user.models import AM, BrandOwner, FactoryOwner, Formulator, TermsAndConditions, TermsAcceptance


class RegisterSerializer(serializers.ModelSerializer):
    terms_accepted = serializers.BooleanField(write_only=True, required=True)  # write_only ensures it's only for input
    password = serializers.CharField(
        write_only=True, required=True, validators=[validate_password]
    )
    password2 = serializers.CharField(write_only=True, required=True)
    faoudOnboarding = serializers.CharField(
        write_only=True, required=False, allow_blank=True
    )


    class Meta:
        model = User
        fields = (
            "username",
            "password",
            "password2",
            "terms_accepted",
            'faoudOnboarding',  
        )

    def validate(self, attrs):
        if attrs["password"] != attrs["password2"]:
            raise serializers.ValidationError(
                {"password": "Password fields didn't match."}
            )
        return attrs
    
    def validate_terms_accepted(self, value):
        if value is not True:
            raise serializers.ValidationError("You must accept the Terms & Conditions.")
        return value

    def create(self, validated_data):
        terms_accepted = validated_data.pop('terms_accepted', False)
        faoud_onboarding_data = validated_data.pop('faoudOnboarding', None)

        

        user = User.objects.create(
            username=validated_data["username"],
        )
        user.set_password(validated_data["password"])
        user.save()
        
        return user


class LoginSerializer(serializers.Serializer):
    # Accepts either username or email; keep password the same
    identifier = serializers.CharField(required=False)
    username = serializers.CharField(required=False)  # fallback for old clients
    password = serializers.CharField()

    def validate(self, attrs):
        ident = attrs.get("identifier") or attrs.get("username")
        if not ident:
            raise serializers.ValidationError({"identifier": "Provide username or email."})
        attrs["identifier"] = ident
        return attrs




class FormulatorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Formulator
        fields = ['id', 'name', 'age', 'employee_id', 'skills']

class BrandOwnerSerializer(serializers.ModelSerializer):
    class Meta:
        model = BrandOwner
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()
    has_created_brand = serializers.SerializerMethodField()
    has_created_factory = serializers.SerializerMethodField()
    role_data = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name', 'email', 'role','has_created_brand','has_created_factory','role_data']

    def get_role(self, obj):
        """
        Determine the role of the user by checking the existence of related models.
        """
        if hasattr(obj, 'brandowner'):
            return 'Brand Owner'
        elif hasattr(obj, 'am'):
            return 'Account Manager'
        elif hasattr(obj, 'formulator'):
            return 'Formulator'
        elif hasattr(obj, 'factoryowner'):
            return 'Factory Owner'
        return 'Unknown'
    
    def get_role_data(self, obj):
        """
        Return the relevant data based on the user's role.
        """
        if hasattr(obj, 'brandowner'):
            return BrandOwnerSerializer(obj.brandowner).data
        elif hasattr(obj, 'am'):
            return AMSerializerMin(obj.am).data
        elif hasattr(obj, 'factoryowner'):
            return FactoryOwnerSerializer(obj.factoryowner).data
        return None
    

    def get_has_created_brand(self, obj):
        """
        Check if the user as a Brand Owner has created any brands.
        """
        if hasattr(obj, 'brandowner'):
            return obj.brandowner.brands.exists()
        return False

    def get_has_created_factory(self, obj):
        """
        Check if the user as a Factory Owner has created any factories.
        """
        if hasattr(obj, 'factoryowner'):
            return obj.factoryowner.factories.exists()
        return False

class UserDataSerializer(serializers.ModelSerializer):
    user = UserSerializer()

    class Meta:
        model = User
        fields = ['user'] 


class FactoryOwnerSerializer(serializers.ModelSerializer):
    class Meta:
        model = FactoryOwner
        fields = '__all__'


class RegisterFactoryOwnerSerializer(serializers.ModelSerializer):
    name = serializers.CharField()
    contact_email = serializers.EmailField()
    contact_phone = serializers.CharField()
    # Ensure terms_accepted is required
    terms_accepted = serializers.BooleanField(required=True)

    class Meta:
        model = FactoryOwner
        fields = ['name', 'contact_phone', 'contact_email', 'terms_accepted']

    def validate_terms_accepted(self, value):
        if not value:
            raise serializers.ValidationError("You must accept the Terms & Conditions.")
        return value
    
    def validate_contact_email(self, value):
        # Check existence in BrandOwner, FactoryOwner, or AM (if relevant)
        if BrandOwner.objects.filter(contact_email=value).exists():
            raise ValidationError("This email is already in use by a BrandOwner.")
        if FactoryOwner.objects.filter(contact_email=value).exists():
            raise ValidationError("This email is already in use by a FactoryOwner.")
        # Do similar checks for AM, etc.
        return value

    def validate_contact_phone(self, value):
        if BrandOwner.objects.filter(contact_phone=value).exists():
            raise ValidationError("This phone is already in use by a BrandOwner.")
        if FactoryOwner.objects.filter(contact_phone=value).exists():
            raise ValidationError("This phone is already in use by a FactoryOwner.")
        return value

    def create(self, validated_data):
        terms_accepted = validated_data.pop('terms_accepted', False)
        factory_owner = FactoryOwner.objects.create(**validated_data)
        factory_owner.terms_accepted = True
        factory_owner.terms_accepted_at = datetime.now(timezone.utc)
        factory_owner.terms_version_accepted = "v1.0"
        factory_owner.save()
        return factory_owner

class AMSerializerMin(serializers.ModelSerializer):

    class Meta:
        model=AM
        fields = '__all__'



class RegisterBOSerializer(serializers.ModelSerializer):
    name = serializers.CharField()
    contact_email = serializers.EmailField()
    contact_phone = serializers.CharField()
    # Ensure terms_accepted is required at this level as well
    terms_accepted = serializers.BooleanField(required=True)

    class Meta:
        model = BrandOwner
        fields = ("name", "contact_email", "contact_phone", "terms_accepted")

    def validate_terms_accepted(self, value):
        if not value:
            raise serializers.ValidationError("You must accept the Terms & Conditions.")
        return value
    
    def validate_contact_email(self, value):
        # Check existence in BrandOwner, FactoryOwner, or AM (if relevant)
        if BrandOwner.objects.filter(contact_email=value).exists():
            raise ValidationError("This email is already in use by a BrandOwner.")
        if FactoryOwner.objects.filter(contact_email=value).exists():
            raise ValidationError("This email is already in use by a FactoryOwner.")
        # Do similar checks for AM, etc.
        return value

    def validate_contact_phone(self, value):
        if BrandOwner.objects.filter(contact_phone=value).exists():
            raise ValidationError("This phone is already in use by a BrandOwner.")
        if FactoryOwner.objects.filter(contact_phone=value).exists():
            raise ValidationError("This phone is already in use by a FactoryOwner.")
        return value

    def create(self, validated_data):
        terms_accepted = validated_data.pop('terms_accepted', False)
        brand_owner = BrandOwner.objects.create(**validated_data)
        brand_owner.terms_accepted = True
        brand_owner.terms_accepted_at = datetime.now(timezone.utc)
        brand_owner.terms_version_accepted = "v1.0"  # Update as needed
        brand_owner.save()
        return brand_owner
    

from rest_framework import serializers
from user.models import AM

class AMListSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField()
    email = serializers.SerializerMethodField()
    load = serializers.IntegerField(read_only=True)  # annotated in view

    class Meta:
        model = AM
        fields = ['id', 'name', 'email', 'is_active', 'load']

    def get_name(self, obj):
        # Prefer AM.name, then linked user.username, then fallback
        return obj.name or (getattr(obj, 'user', None) and obj.user.username) or f"AM #{obj.id}"

    def get_email(self, obj):
        return getattr(obj, 'contact_email', None) or (getattr(obj, 'user', None) and obj.user.email)


# --- Terms & Acceptance Serializers ---
class TermsAndConditionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TermsAndConditions
        fields = ["id", "scope", "version", "title", "content", "file", "is_active", "published_at"]


class TermsAcceptanceSerializer(serializers.ModelSerializer):
    terms = TermsAndConditionsSerializer(read_only=True)

    class Meta:
        model = TermsAcceptance
        fields = ["id", "terms", "accepted_at", "ip_address", "user_agent", "signature_hash"]