from django.contrib.auth.models import User
from django.core import mail
from django.test import override_settings
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient, APITestCase
from unittest.mock import patch

from user.models import AM, BrandOwner, FactoryOwner
from user.privacy import build_unsubscribe_token
from user.tasks import send_delayed_signup_alert_task


@override_settings(ROOT_URLCONF="shadow.urls")
class SessionAuthenticationFlowTests(APITestCase):
    def setUp(self):
        self.client = APIClient(enforce_csrf_checks=True)
        self.password = "strong-pass-123"
        self.user = User.objects.create_user(
            username="secure-user",
            email="secure@example.com",
            password=self.password,
            is_active=True,
        )
        BrandOwner.objects.create(
            user=self.user,
            name="Secure Brand Owner",
            contact_email="secure@example.com",
        )

    def _bootstrap_csrf(self):
        response = self.client.get(reverse("auth-csrf"))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        csrf_token = response.cookies["csrftoken"].value
        self.client.cookies["csrftoken"] = csrf_token
        return csrf_token

    def test_login_sets_session_and_returns_user_without_browser_token(self):
        csrf_token = self._bootstrap_csrf()

        response = self.client.post(
            reverse("login"),
            {"username": self.user.username, "password": self.password},
            format="json",
            HTTP_X_CSRFTOKEN=csrf_token,
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("sessionid", response.cookies)
        self.assertIn("user", response.data)
        self.assertNotIn("token", response.data)

    def test_logout_clears_session(self):
        csrf_token = self._bootstrap_csrf()
        login_response = self.client.post(
            reverse("login"),
            {"username": self.user.username, "password": self.password},
            format="json",
            HTTP_X_CSRFTOKEN=csrf_token,
        )
        self.assertEqual(login_response.status_code, status.HTTP_200_OK)

        # Login can rotate the CSRF token. Refresh it before logout to mirror browser behavior.
        csrf_token = self._bootstrap_csrf()

        response = self.client.post(reverse("logout"), {}, format="json", HTTP_X_CSRFTOKEN=csrf_token)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        me_response = self.client.get(reverse("user-data"))
        self.assertIn(me_response.status_code, {status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN})

    def test_signed_unsubscribe_token_updates_preferences_without_auth_token(self):
        brand_owner = self.user.brandowner
        brand_owner.marketing_emails = True
        brand_owner.save(update_fields=["marketing_emails"])

        response = self.client.post(
            reverse("unsubscribe-email-preferences"),
            {"unsubscribe_token": build_unsubscribe_token(self.user), "marketing_emails": False},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        brand_owner.refresh_from_db()
        self.assertFalse(brand_owner.marketing_emails)

    def test_invalid_unsubscribe_token_is_rejected(self):
        response = self.client.post(
            reverse("unsubscribe-email-preferences"),
            {"unsubscribe_token": "invalid", "marketing_emails": False},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_unverified_login_can_resend_verification_email(self):
        unverified_user = User.objects.create_user(
            username="pending-user",
            email="pending@example.com",
            password="pending-pass-123",
            is_active=False,
        )
        BrandOwner.objects.create(
            user=unverified_user,
            name="Pending Brand Owner",
            contact_email="pending@example.com",
        )

        csrf_token = self._bootstrap_csrf()
        login_response = self.client.post(
            reverse("login"),
            {"username": unverified_user.username, "password": "pending-pass-123"},
            format="json",
            HTTP_X_CSRFTOKEN=csrf_token,
        )

        self.assertEqual(login_response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertIn("not verified", login_response.data["error"].lower())

        resend_response = self.client.post(
            reverse("resend-verification"),
            {"identifier": unverified_user.username},
            format="json",
        )

        self.assertEqual(resend_response.status_code, status.HTTP_200_OK)
        self.assertIn("verification email", resend_response.data["message"].lower())
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("pending@example.com", mail.outbox[0].to)

    def test_resend_verification_rejects_verified_user(self):
        response = self.client.post(
            reverse("resend-verification"),
            {"identifier": self.user.username},
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("already verified", response.data["error"].lower())


@override_settings(ROOT_URLCONF="shadow.urls")
class SignupAlertFlowTests(APITestCase):
    def setUp(self):
        self.am_user = User.objects.create_user(
            username="notify-am",
            email="notify-am@example.com",
            password="secret123",
            is_active=True,
        )
        AM.objects.create(user=self.am_user, name="Notify AM", contact_email="notify-am@example.com")

    def test_brand_owner_creation_schedules_one_delayed_alert(self):
        user = User.objects.create_user(
            username="brand-user",
            email="brand-user@example.com",
            password="secret123",
            is_active=False,
        )

        with patch("user.signals.send_delayed_signup_alert_task.apply_async") as mocked_apply_async:
            with self.captureOnCommitCallbacks(execute=True):
                profile = BrandOwner.objects.create(
                    user=user,
                    name="Brand User",
                    contact_email="brand-user@example.com",
                    contact_phone="+911111111111",
                )

        profile.refresh_from_db()
        self.assertTrue(profile.signup_alert_scheduled)
        self.assertFalse(profile.signup_alert_sent)
        mocked_apply_async.assert_called_once()
        self.assertEqual(mocked_apply_async.call_args.kwargs["countdown"], 600)

        with patch("user.signals.send_delayed_signup_alert_task.apply_async") as mocked_apply_async:
            profile.name = "Brand User Updated"
            profile.save()

        mocked_apply_async.assert_not_called()

    def test_delayed_signup_alert_reports_current_verification_status(self):
        verified_user = User.objects.create_user(
            username="verified-brand",
            email="verified-brand@example.com",
            password="secret123",
            is_active=True,
        )
        with patch("user.signals.send_delayed_signup_alert_task.apply_async"):
            brand_owner = BrandOwner.objects.create(
                user=verified_user,
                name="Verified Brand",
                contact_email="verified-brand@example.com",
            )

        send_delayed_signup_alert_task.run("brand_owner", brand_owner.id)
        brand_owner.refresh_from_db()
        self.assertTrue(brand_owner.signup_alert_sent)
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("Email verified: Yes", mail.outbox[0].body)
        self.assertEqual(len(mail.outbox[0].alternatives), 1)
        html_content, mimetype = mail.outbox[0].alternatives[0]
        self.assertEqual(mimetype, "text/html")
        self.assertIn("Signup Alert", html_content)
        self.assertIn("Verified Brand", html_content)
        self.assertIn("Email verified:", html_content)

        mail.outbox.clear()

        unverified_user = User.objects.create_user(
            username="factory-user",
            email="factory-user@example.com",
            password="secret123",
            is_active=False,
        )
        with patch("user.signals.send_delayed_signup_alert_task.apply_async"):
            factory_owner = FactoryOwner.objects.create(
                user=unverified_user,
                name="Factory User",
                contact_email="factory-user@example.com",
            )

        send_delayed_signup_alert_task.run("factory_owner", factory_owner.id)
        factory_owner.refresh_from_db()
        self.assertTrue(factory_owner.signup_alert_sent)
        self.assertEqual(len(mail.outbox), 1)
        self.assertIn("Email verified: No", mail.outbox[0].body)
        self.assertEqual(len(mail.outbox[0].alternatives), 1)
        html_content, mimetype = mail.outbox[0].alternatives[0]
        self.assertEqual(mimetype, "text/html")
        self.assertIn("Factory User", html_content)


@override_settings(ROOT_URLCONF="shadow.urls", CAPTCHA_ENABLED=False)
class LeadFinishEmailPolicyTests(APITestCase):
    def test_lead_finish_does_not_resend_set_password_email_for_verified_user(self):
        verified_user = User.objects.create_user(
            username="verified-existing",
            email="verified-existing@example.com",
            password="secret123",
            is_active=True,
        )
        BrandOwner.objects.create(
            user=verified_user,
            name="Verified Existing",
            contact_email="verified-existing@example.com",
        )

        with patch("user.views.send_confirm_set_password_email") as mocked_send:
            response = self.client.post(
                reverse("lead-finish"),
                {
                    "email": verified_user.email,
                    "name": "Verified Existing",
                    "user_choice": "BO",
                    "client_id": "client-xyz",
                },
                format="json",
            )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(User.objects.filter(email=verified_user.email).count(), 1)
        mocked_send.assert_not_called()

    def test_lead_finish_resends_set_password_email_for_unverified_user(self):
        unverified_user = User.objects.create_user(
            username="unverified-existing",
            email="unverified-existing@example.com",
            password="secret123",
            is_active=False,
        )
        BrandOwner.objects.create(
            user=unverified_user,
            name="Unverified Existing",
            contact_email="unverified-existing@example.com",
        )

        with patch("user.views.send_confirm_set_password_email") as mocked_send:
            response = self.client.post(
                reverse("lead-finish"),
                {
                    "email": unverified_user.email,
                    "name": "Unverified Existing",
                    "user_choice": "BO",
                    "client_id": "client-abc",
                },
                format="json",
            )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        mocked_send.assert_called_once()
