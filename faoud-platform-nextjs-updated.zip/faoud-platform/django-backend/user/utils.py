from django.contrib.auth.tokens import default_token_generator
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings
def send_verification_email(request, user):
    """
    Generate a one-time token and send a verification link to the user's email.
    The link directs users to the frontend verification page.
    """
    token = default_token_generator.make_token(user)
    uid = user.pk  # You may use django.utils.http.urlsafe_base64_encode for encoding

    # Use the frontend domain instead of the backend API route
    frontend_domain = settings.FRONTEND_URL  # Define this in settings.py
    verify_url = f"{frontend_domain}/verify/{uid}/{token}/"
    
    subject = "Verify Your Email"
    from_email = settings.DEFAULT_FROM_EMAIL
    to_email = user.email

    context = {
        'user_name': user.username,
        'verify_url': verify_url,
    }

    # Render the HTML template for the verification email.
    html_content = render_to_string('documents/verify-email.html', context)
    # Fallback plain text version
    text_content = (
        f"Hello {user.username},\n\n"
        f"Please click the link below to verify your email:\n\n"
        f"{verify_url}\n\n"
        "If you did not sign up for this account, please ignore this email."
    )

    msg = EmailMultiAlternatives(subject, text_content, from_email, [to_email])
    msg.attach_alternative(html_content, "text/html")
    try:
        msg.send()
    except Exception as e:
        print(f"Failed to send verification email to {user.email}: {e}")


def send_confirm_set_password_email(user):
    token = default_token_generator.make_token(user)
    uid = user.pk
    frontend_url = getattr(settings, "FRONTEND_URL", "http://localhost:3000")
    set_url = f"{frontend_url}/set-password/{uid}/{token}"

    ctx = {"user_name": user.username, "set_url": set_url}
    subject = "Confirm your account & set your password"
    text = (
        f"Hi {user.username},\n\n"
        f"Click to confirm your email and set your password:\n{set_url}\n\n"
        "By accepting this you are accepting the terms and condition.\n\n"
        "If you didn’t request this, ignore this email."
    )
    html = render_to_string("documents/confirm-set-password.html", ctx)

    msg = EmailMultiAlternatives(subject, text, settings.DEFAULT_FROM_EMAIL, [user.email])
    msg.attach_alternative(html, "text/html")
    try:
        msg.send()
    except Exception as e:
        print(f"Failed to send email to {user.email}: {e}")


from typing import Iterable, Literal, Dict, Any
from user.models import AM

MaskStrategy = Literal["mask", "drop"]
MASK_TOKEN = "••••"

def is_plain_am(user) -> bool:
    """True if user is an AM without super or MNGMNT role."""
    if not user or not user.is_authenticated:
        return False
    if not AM.objects.filter(user=user).exists():
        return False
    if user.groups.filter(name__in=["superAM", "MNGMNT"]).exists():
        return False
    return True

def has_no_brand_info(user) -> bool:
    if not user or not user.is_authenticated:
        return False
    return user.groups.filter(name="noBrandInfo").exists()

def redact_fields(data: Dict[str, Any], fields: Iterable[str], *, strategy: MaskStrategy = "mask") -> None:
    """
    In-place redaction:
      - 'mask': replace non-empty values with MASK_TOKEN
      - 'drop': remove the key entirely
    """
    if strategy == "drop":
        for f in fields:
            data.pop(f, None)
        return
    # mask
    for f in fields:
        if f in data and data[f] not in (None, "", 0, False):
            data[f] = MASK_TOKEN


# user/utils.py
from .models import BrandOwner, FactoryOwner, AM

def get_role(user):
    if user.groups.filter(name="superAM").exists():
        return "super_am"
    if user.groups.filter(name="MNGMNT").exists():
        return "mngmt_am"
    if AM.objects.filter(user=user).exists():
        return "am"
    if FactoryOwner.objects.filter(user=user).exists():
        return "factory_owner"
    if BrandOwner.objects.filter(user=user).exists():
        return "brand_owner"
    return "other"
