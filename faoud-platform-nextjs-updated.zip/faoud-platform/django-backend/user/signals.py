from django.db import transaction
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
from django.conf import settings

from .models import BrandOwner, FactoryOwner
from .tasks import send_delayed_signup_alert_task


def _schedule_signup_alert(instance, profile_type):
    delay_seconds = int(getattr(settings, "SIGNUP_ALERT_DELAY_SECONDS", 600))
    scheduled_at = timezone.now() + timezone.timedelta(seconds=delay_seconds)

    updated = instance.__class__.objects.filter(
        id=instance.id,
        signup_alert_scheduled=False,
    ).update(
        signup_alert_scheduled=True,
        signup_alert_scheduled_at=scheduled_at,
    )
    if not updated:
        return

    transaction.on_commit(
        lambda: _send_signup_alert_task(profile_type, instance.id, delay_seconds)
    )


def _send_signup_alert_task(profile_type, instance_id, delay_seconds):
    """Send the delayed signup alert task."""
    send_delayed_signup_alert_task.apply_async(
        args=[profile_type, instance_id],
        countdown=delay_seconds,
    )


@receiver(post_save, sender=BrandOwner, dispatch_uid="user.schedule_brand_owner_signup_alert.v1")
def schedule_brand_owner_signup_alert(sender, instance, created, **kwargs):
    if created:
        _schedule_signup_alert(instance, "brand_owner")


@receiver(post_save, sender=FactoryOwner, dispatch_uid="user.schedule_factory_owner_signup_alert.v1")
def schedule_factory_owner_signup_alert(sender, instance, created, **kwargs):
    if created:
        _schedule_signup_alert(instance, "factory_owner")
