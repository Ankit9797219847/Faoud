import json
import logging
from django.shortcuts import get_object_or_404
from django.urls import reverse
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q
from django.core import signing
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.csrf import csrf_exempt

from rest_framework import serializers
from django.contrib.auth.models import User
from marketing.models import OnboardingData
from shadow import settings
from django.utils.decorators import method_decorator

from django_ratelimit.decorators import ratelimit
from user.models import BrandOwner, FactoryOwner, Formulator, LoginEvent, TermsAndConditions, TermsAcceptance  # Adjust according to your models

from case.models import Case
from case.serializers import CaseSerializer
from supply.models import Factory
from user.permissions import IsAccountManager, IsFactoryOwner, IsMNGMNTAccountManager, IsSuperAccountManager
from user.utils import get_role, send_verification_email, send_confirm_set_password_email
from user.privacy import build_unsubscribe_token, load_unsubscribe_token
from .serializers import AMListSerializer, FactoryOwnerSerializer, FormulatorSerializer, RegisterBOSerializer, RegisterFactoryOwnerSerializer, RegisterSerializer, LoginSerializer, UserSerializer, TermsAndConditionsSerializer, TermsAcceptanceSerializer
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.authentication import SessionAuthentication
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi
from django.core.mail import send_mail
from case.signals_bus import user_onboarded
from rest_framework.parsers import MultiPartParser, FormParser

from django.utils.text import slugify
from django.db import transaction
from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings
from user.models import BrandOwner, FactoryOwner, AM, TermsAndConditions, TermsAcceptance
from utils.captcha import (
    CaptchaValidationError,
    is_valid_captcha_proof,
    verify_captcha_or_raise,
)
from supply.models import Factory, Document, Bid
from product.models import Category, Subcategory

User = get_user_model()
logger = logging.getLogger(__name__)


# Define user types
USER_CHOICES = [
    "BO",  # "Brand Owner",
    "AM",  # "Account Manager",
    "FM",  # "Formulator",
    "FO",  # "Factory Owner"
]


# Registration view handling different user types





class LogoutView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        logout(request)
        return Response({"message": "Logged out successfully"}, status=status.HTTP_200_OK)


@method_decorator(ensure_csrf_cookie, name="dispatch")
class CSRFCookieView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def get(self, request):
        return Response({"detail": "CSRF cookie set."}, status=status.HTTP_200_OK)
    

    
class RegisterView(APIView):
    permission_classes = [AllowAny]

    @swagger_auto_schema(
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=["username", "password", "password2", "user_choice"],
            properties={
                "username": openapi.Schema(type=openapi.TYPE_STRING, description="Username of new user"),
                "password": openapi.Schema(type=openapi.TYPE_STRING, description="Password of new user"),
                "password2": openapi.Schema(type=openapi.TYPE_STRING, description="Confirm password"),
                "user_choice": openapi.Schema(
                    type=openapi.TYPE_STRING,
                    enum=USER_CHOICES,  # Enum includes "FO" for Factory Owner
                    description="Type of user",
                ),
                "name": openapi.Schema(type=openapi.TYPE_STRING, description="Name of user"),
                "contact_phone": openapi.Schema(type=openapi.TYPE_STRING, description="Phone number", max_length=15),
                "contact_email": openapi.Schema(type=openapi.TYPE_STRING, description="Email of user"),
            },
        ),
        responses={
            201: openapi.Response(
                description="A successful response",
                schema=openapi.Schema(
                    type=openapi.TYPE_OBJECT,
                    properties={
                        "user": openapi.Schema(
                            type=openapi.TYPE_OBJECT,
                            properties={"username": openapi.Schema(type=openapi.TYPE_STRING, description="Username of new user")},
                        ),
                    },
                ),
            ),

            400: openapi.Response(description="Error response", schema=openapi.Schema(
                type=openapi.TYPE_OBJECT,
                properties={
                    "error": openapi.Schema(type=openapi.TYPE_STRING, description="Error message"),
                    "details": openapi.Schema(type=openapi.TYPE_OBJECT, description="Detailed validation errors")
                }
            ))
        },
    )
    def post(self, request):
        verify_captcha_or_raise(request)

        user_choice = request.data.get("user_choice")
        if user_choice not in USER_CHOICES:
            return Response({"error": "User choice not specified or invalid"}, status=status.HTTP_400_BAD_REQUEST)
        print("user choice" + user_choice)
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            user.email = request.data.get("contact_email")
            user.is_active = False
            user.save()
            faoud_onboarding_data = serializer.validated_data.get('faoudOnboarding')
            try:
                if user_choice == "BO":
                    serializer2 = RegisterBOSerializer(data=request.data)
                    if not serializer2.is_valid():
                        user.delete()
                        return Response(serializer2.errors, status=status.HTTP_400_BAD_REQUEST)
                    brand_owner = serializer2.save()
                    brand_owner.user = user
                    brand_owner.save()

                elif user_choice == "FO":  # Handle FactoryOwner registration
                    serializer2 = RegisterFactoryOwnerSerializer(data=request.data)
                    if not serializer2.is_valid():
                        user.delete()
                        return Response(serializer2.errors, status=status.HTTP_400_BAD_REQUEST)
                    factory_owner = serializer2.save()
                    factory_owner.user = user
                    factory_owner.save()

                if isinstance(faoud_onboarding_data, str):
                    try:
                        faoud_onboarding_data = json.loads(faoud_onboarding_data)
                    except json.JSONDecodeError:
                        # If it fails, you could raise a ValidationError or just set it to None
                        faoud_onboarding_data = None

                if faoud_onboarding_data:
                    user_onboarded.send(
                        sender=self.__class__,
                        user=user,
                        onboarding_data=faoud_onboarding_data
                    )
            except Exception as e:
                user.delete()
                return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
            
            # Auto-accept terms for new user
            try:
                scopes_to_accept = [TermsAndConditions.SCOPE_GLOBAL]
                if user_choice == "BO":
                    scopes_to_accept.append(TermsAndConditions.SCOPE_BRAND_OWNER)
                elif user_choice == "FO":
                    scopes_to_accept.append(TermsAndConditions.SCOPE_FACTORY_OWNER)
                
                active_terms = TermsAndConditions.objects.filter(scope__in=scopes_to_accept, is_active=True)
                
                # Get IP and UA
                ip = request.META.get("HTTP_X_FORWARDED_FOR", request.META.get("REMOTE_ADDR"))
                if ip and "," in ip:
                    ip = ip.split(",")[0].strip()
                ua = request.META.get("HTTP_USER_AGENT")

                for term in active_terms:
                    TermsAcceptance.objects.create(
                        user=user, 
                        terms=term, 
                        ip_address=ip, 
                        user_agent=ua
                    )
            except Exception as e:
                print(f"Error auto-accepting terms: {e}")

            send_verification_email(request, user)

            return Response({"user": serializer.data}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Login view for authenticating users
class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        verify_captcha_or_raise(request)

        serializer = LoginSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        identifier = serializer.validated_data["identifier"].strip()
        password = serializer.validated_data["password"]

        # Resolve user by username OR email (case-insensitive)
        try:
            if "@" in identifier:
                # Email path
                qs = User.objects.filter(email__iexact=identifier)
                count = qs.count()
                if count != 1:
                    # If 0 or >1, we don't reveal which; just say invalid creds
                    return Response({"error": "Invalid credentials"}, status=status.HTTP_400_BAD_REQUEST)
                user_obj = qs.first()
            else:
                # Username path
                user_obj = User.objects.get(username__iexact=identifier)
        except User.DoesNotExist:
            return Response({"error": "Invalid credentials"}, status=status.HTTP_400_BAD_REQUEST)

        # Enforce email verification / activation
        if not user_obj.is_active:
            return Response(
                {"error": "Email not verified. Please check your inbox."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Authenticate using the resolved username
        user = authenticate(request, username=user_obj.username, password=password)
        if user is None:
            return Response({"error": "Invalid credentials"}, status=status.HTTP_400_BAD_REQUEST)

        LoginEvent.objects.create(user=user, role=get_role(user))
        login(request, user)
        user_data = UserSerializer(user).data
        logger.info("User login succeeded for user_id=%s role=%s", user.id, user_data.get("role"))
        return Response({"user": user_data}, status=status.HTTP_200_OK)


class ResendVerificationEmailView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    @method_decorator(ratelimit(key="ip", rate="5/m", block=True))
    def post(self, request):
        identifier = (request.data.get("identifier") or request.data.get("email") or "").strip()
        if not identifier:
            return Response({"error": "Username or email is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            if "@" in identifier:
                user_obj = User.objects.filter(email__iexact=identifier).first()
            else:
                user_obj = User.objects.filter(username__iexact=identifier).first()
        except User.DoesNotExist:
            user_obj = None

        if not user_obj:
            return Response(
                {"message": "If the account exists and is not verified, a new verification email has been sent."},
                status=status.HTTP_200_OK,
            )

        if user_obj.is_active:
            return Response({"error": "This account is already verified."}, status=status.HTTP_400_BAD_REQUEST)

        send_verification_email(request, user_obj)
        return Response(
            {"message": "A new verification email has been sent."},
            status=status.HTTP_200_OK,
        )




# View to list available formulators (restricted to Account Managers)
class FormulatorListView(APIView):
    permission_classes = [IsAccountManager]

    def get(self, request):
        formulators = Formulator.objects.all()
        available_formulators = [formulator for formulator in formulators if formulator.formulations.count() < 3]
        serializer = FormulatorSerializer(available_formulators, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


# View to return basic user data for the authenticated user
class UserDataView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        serializer = UserSerializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)


# View to return FactoryOwner data (restricted to FactoryOwner users)
class FactoryOwnerDataView(APIView):
    permission_classes = [IsAuthenticated, IsFactoryOwner]

    def get(self, request):
        factory_owner = FactoryOwner.objects.get(user=request.user)
        serializer = FactoryOwnerSerializer(factory_owner)
        return Response(serializer.data, status=status.HTTP_200_OK)


class FactoryOwnerListView(APIView):
    permission_classes = [IsAccountManager]

    def get(self, request):
        factory_owners = FactoryOwner.objects.all()
        serializer = FactoryOwnerSerializer(factory_owners, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


# user/views.py
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_decode
from django.contrib.auth.models import User
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

class VerifyEmailView(APIView):
    permission_classes = [AllowAny]  # Anyone can hit this endpoint

    def get(self, request, uid, token):
        try:
            user = User.objects.get(pk=uid)
        except User.DoesNotExist:
            return Response({"error": "Invalid user"}, status=status.HTTP_400_BAD_REQUEST)

        if default_token_generator.check_token(user, token):
            # Mark user as active (email verified)
            user.is_active = True
            user.save()
            return Response({"message": "Email verified successfully."}, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Invalid token"}, status=status.HTTP_400_BAD_REQUEST)



# user/views.py
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.conf import settings
from django.contrib.auth import get_user_model

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny

User = get_user_model()

class PasswordResetRequestView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        verify_captcha_or_raise(request)

        email = request.data.get("email")
        if not email:
            return Response({"error": "Email is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            # For security, do NOT reveal that the email doesn't exist
            return Response({"message": "If the email exists, a reset was sent."}, 
                            status=status.HTTP_200_OK)

        # Generate token and uid
        token = default_token_generator.make_token(user)
        uid = user.pk

        # Use the frontend URL to build the password reset link.
        frontend_url = getattr(settings, "FRONTEND_URL", "http://localhost:3000")
        reset_url = f"{frontend_url}/auth/reset-password/{uid}/{token}"

        subject = "Reset Your Password"
        from_email = settings.DEFAULT_FROM_EMAIL
        to_email = email

        context = {
            'user_name': user.username,
            'reset_url': reset_url,
        }

        # Render the HTML template for the password reset email.
        html_content = render_to_string('documents/forget-pass.html', context)
        # Fallback plain text version.
        text_content = (
            f"Hi {user.username},\n\n"
            f"We received a request to reset your password. To reset your password, please visit the following link:\n"
            f"{reset_url}\n\n"
            "If you did not request a password reset, please ignore this email."
        )

        msg = EmailMultiAlternatives(subject, text_content, from_email, [to_email])
        msg.attach_alternative(html_content, "text/html")
        msg.send()

        return Response({"message": "If the email exists, a reset was sent."}, status=status.HTTP_200_OK)


class PasswordResetConfirmView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, uid, token):
        verify_captcha_or_raise(request)

        password = request.data.get("password")
        if not password:
            return Response({"error": "Password is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            user = User.objects.get(pk=uid)
        except User.DoesNotExist:
            return Response({"error": "Invalid user"}, status=status.HTTP_400_BAD_REQUEST)

        if not default_token_generator.check_token(user, token):
            return Response({"error": "Invalid or expired token"}, status=status.HTTP_400_BAD_REQUEST)

        user.set_password(password)
        user.is_active = True  # verify & activate
        user.save()

        # Auto-accept terms
        try:
            scopes_to_accept = [TermsAndConditions.SCOPE_GLOBAL]
            if BrandOwner.objects.filter(user=user).exists():
                scopes_to_accept.append(TermsAndConditions.SCOPE_BRAND_OWNER)
            elif FactoryOwner.objects.filter(user=user).exists():
                scopes_to_accept.append(TermsAndConditions.SCOPE_FACTORY_OWNER)
            
            active_terms = TermsAndConditions.objects.filter(scope__in=scopes_to_accept, is_active=True)
            
            ip = request.META.get("HTTP_X_FORWARDED_FOR", request.META.get("REMOTE_ADDR"))
            if ip and "," in ip:
                ip = ip.split(",")[0].strip()
            ua = request.META.get("HTTP_USER_AGENT")

            for term in active_terms:
                TermsAcceptance.objects.get_or_create(
                    user=user, 
                    terms=term, 
                    defaults={'ip_address': ip, 'user_agent': ua}
                )
        except Exception as e:
            print(f"Error auto-accepting terms in PasswordResetConfirmView: {e}")

        login(request, user)
        return Response({
            "message": "Password set. Your email is verified and your account is active.",
            "user": UserSerializer(user).data,
        }, status=status.HTTP_200_OK)


class UpdateEmailPreferencesView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = [SessionAuthentication]

    def patch(self, request):
        user = request.user if request.user.is_authenticated else None
        if not user:
            return Response({"error": "Authentication required."}, status=status.HTTP_401_UNAUTHORIZED)

        if hasattr(user, 'brandowner'):
            bo = user.brandowner
            bo.marketing_emails = request.data.get('marketing_emails', bo.marketing_emails)
            bo.operational_emails = request.data.get('operational_emails', bo.operational_emails)
            bo.save(update_fields=["marketing_emails", "operational_emails"])
        elif hasattr(user, 'factoryowner'):
            fo = user.factoryowner
            fo.marketing_emails = request.data.get('marketing_emails', fo.marketing_emails)
            fo.operational_emails = request.data.get('operational_emails', fo.operational_emails)
            fo.save(update_fields=["marketing_emails", "operational_emails"])
        else:
            return Response({"error": "No email preferences found for this user."}, status=status.HTTP_404_NOT_FOUND)

        return Response({"message": "Preferences updated."}, status=status.HTTP_200_OK)

    def _user_from_unsubscribe_token(self, unsubscribe_token):
        if not unsubscribe_token:
            return None
        try:
            user_id = load_unsubscribe_token(unsubscribe_token)
        except signing.BadSignature:
            return None
        except signing.SignatureExpired:
            return None
        return User.objects.filter(pk=user_id).first()


@method_decorator(csrf_exempt, name="dispatch")
class UnsubscribeEmailPreferencesView(UpdateEmailPreferencesView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def post(self, request):
        user = self._user_from_unsubscribe_token(
            request.data.get("unsubscribe_token") or request.query_params.get("token")
        )
        if not user:
            return Response({"error": "Invalid or expired unsubscribe link."}, status=status.HTTP_401_UNAUTHORIZED)

        if hasattr(user, "brandowner"):
            user.brandowner.marketing_emails = False
            user.brandowner.save(update_fields=["marketing_emails"])
        elif hasattr(user, "factoryowner"):
            user.factoryowner.marketing_emails = False
            user.factoryowner.save(update_fields=["marketing_emails"])
        else:
            return Response({"error": "No email preferences found for this user."}, status=status.HTTP_404_NOT_FOUND)

        return Response({"message": "Preferences updated."}, status=status.HTTP_200_OK)


# a view to get if the user is super am
class IsSuperAMView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        am = request.user.am
        if not am:
            return Response({"error": "User is not an Account Manager."}, status=status.HTTP_403_FORBIDDEN)
        is_super_am = request.user.groups.filter(name='superAM').exists()
        return Response({"is_super_am": is_super_am}, status=status.HTTP_200_OK)


class IsMNGMNTAMView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        am = request.user.am
        if not am:
            return Response({"error": "User is not an Account Manager."}, status=status.HTTP_403_FORBIDDEN)
        is_management_am = request.user.groups.filter(name='MNGMNT').exists()
        return Response({"is_management_am": is_management_am}, status=status.HTTP_200_OK)


class LeadFinishSignupView(APIView):
    """
    Called after GetStarted final submit.
    Body: { email, name, user_choice: 'BO'|'FO', client_id, onboarding_id }
        parser_classes = (MultiPartParser, FormParser)
    - Creates or finds a user
    - Creates the correct profile (BrandOwner/FactoryOwner) if missing
    - Links OnboardingData to user
    - Sends a single 'Confirm & Set Password' email (using default_token_generator on user)
            user_choice = request.data.get('user_choice') or 'FO'  # 'BO' or 'FO'
    """
    permission_classes = [AllowAny]
    authentication_classes = []

    @method_decorator(ratelimit(key='ip', rate='10/m', block=True))
    def post(self, request):
        email = (request.data.get('email') or '').strip().lower()
        name = (request.data.get('name') or '').strip()
        user_choice = request.data.get('user_choice')  # 'BO' or 'FO'
        client_id = request.data.get('client_id')
        onboarding_id = request.data.get('onboarding_id')
        captcha_proof = request.data.get('captcha_proof')

        if not email or user_choice not in ('BO', 'FO'):
            return Response({"error": "email and valid user_choice required"}, status=status.HTTP_400_BAD_REQUEST)

        if not is_valid_captcha_proof(captcha_proof, email=email, client_id=client_id):
            logger.warning(
                "Lead finish rejected due to missing or invalid captcha proof: email=%s client_id=%s onboarding_id=%s has_proof=%s",
                email,
                client_id,
                onboarding_id,
                bool(captcha_proof),
            )
            raise CaptchaValidationError()

        send_set_password_email = False
        with transaction.atomic():
            user, created = self._get_or_create_user(email=email, name=name)
            send_set_password_email = not bool(user.is_active)

            # Ensure profile exists
            if user_choice == 'BO':
                bo, _ = BrandOwner.objects.get_or_create(user=user, defaults={
                    "name": name or (email.split('@')[0]),
                    "contact_email": email
                })
            else:
                fo, _ = FactoryOwner.objects.get_or_create(user=user, defaults={
                    "name": name or (email.split('@')[0]),
                    "contact_email": email
                })

            # Link onboarding row(s) to user and pick one payload to fire your signal
            payload = None
            qs = OnboardingData.objects.select_for_update()

            if onboarding_id:
                qs = qs.filter(id=onboarding_id)
            elif client_id:
                qs = qs.filter(client_id=client_id)
            else:
                # FALLBACK: rows created earlier without user, match by email if present
                if email:
                    qs = qs.filter(email__iexact=email)
                else:
                    qs = qs.none()

            matched = list(qs.order_by('-created_at'))
            for row in matched:
                if row.user_id != user.id:
                    row.user = user
                    row.save()

            if matched:
                ob = matched[0]
                payload = {
                    "flowType": ob.flow_type,
                    "productCategory": ob.product_category,
                    "productName": ob.product_name,
                    "quantity": ob.quantity,
                    "instructions": ob.instructions,
                    "requiresFormulation": ob.requires_formulation,
                    "selectedFactory": ob.selected_factory,
                    "selectedCategoryIds": ob.selected_category_ids,
                    "selectedSubcategoryIds": ob.selected_subcategory_ids,
                    "customCategoryText": ob.custom_category_text,
                    "customSubcategoryText": ob.custom_subcategory_text,
                    "timeline": ob.timeline,
                    "budget": ob.budget,
                    "companyName": ob.company_name,
                    "location": ob.location,
                }

            if user_choice == 'FO' and matched:
                self._create_basic_factory_from_onboarding(user=user, onboarding=matched[0], fallback_name=name)

        # Send confirm + set password link only when the user is not verified yet.
        if send_set_password_email:
            self._send_set_password_email(user)

        return Response({
            "user_created": created,
            "username": user.username,
            "next": "check_email"
        }, status=status.HTTP_201_CREATED)

    def _get_or_create_user(self, email: str, name: str):
        try:
            user = User.objects.get(email=email)
            created = False
        except User.DoesNotExist:
            # Generate unique username
            base = slugify(name)[:20] or email.split('@')[0][:20]
            candidate = base or 'user'
            i = 1
            while User.objects.filter(username=candidate).exists():
                i += 1
                candidate = f"{base}{i}"

            user = User.objects.create(
                username=candidate,
                email=email,
                is_active=False,  # will be activated on password set
            )
            user.set_unusable_password()
            user.save()
            created = True
        return user, created

    def _send_set_password_email(self, user):
        # Delegate to shared util to keep a single source of truth
        send_confirm_set_password_email(user)

    def _int_list(self, value):
        if not value:
            return []
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except json.JSONDecodeError:
                value = [item.strip() for item in value.split(",")]
        if not isinstance(value, (list, tuple)):
            return []
        ids = []
        for item in value:
            try:
                ids.append(int(item))
            except (TypeError, ValueError):
                continue
        return ids

    def _join_text(self, *values):
        seen = set()
        parts = []
        for value in values:
            if not value:
                continue
            for item in str(value).split(","):
                cleaned = item.strip()
                key = cleaned.lower()
                if cleaned and key not in seen:
                    seen.add(key)
                    parts.append(cleaned)
        return ", ".join(parts)

    def _create_basic_factory_from_onboarding(self, *, user, onboarding, fallback_name):
        try:
            factory_owner = user.factoryowner
        except FactoryOwner.DoesNotExist:
            factory_owner = None
        if not factory_owner:
            return

        factory_name = (getattr(onboarding, "factory_title", None) or fallback_name or factory_owner.name or "").strip()
        if not factory_name:
            return

        category_ids = self._int_list(getattr(onboarding, "selected_category_ids", []))
        subcategory_ids = self._int_list(getattr(onboarding, "selected_subcategory_ids", []))
        valid_category_ids = list(Category.objects.filter(id__in=category_ids).values_list("id", flat=True))
        valid_subcategory_ids = list(Subcategory.objects.filter(id__in=subcategory_ids).values_list("id", flat=True))

        type_of_products = self._join_text(
            getattr(onboarding, "factory_items", None),
            getattr(onboarding, "custom_category_text", None),
            getattr(onboarding, "custom_subcategory_text", None),
        )

        factory, _ = Factory.objects.get_or_create(
            factory_owner=factory_owner,
            name=factory_name,
            defaults={
                "email": getattr(onboarding, "email", None) or factory_owner.contact_email,
                "phone": getattr(onboarding, "mobile", None) or factory_owner.contact_phone,
                "address": getattr(onboarding, "location", None),
                "type_of_products": type_of_products,
                "verified": False,
            },
        )

        changed_fields = []
        for field, value in [
            ("email", getattr(onboarding, "email", None) or factory_owner.contact_email),
            ("phone", getattr(onboarding, "mobile", None) or factory_owner.contact_phone),
            ("address", getattr(onboarding, "location", None)),
            ("type_of_products", type_of_products),
        ]:
            if value and not getattr(factory, field):
                setattr(factory, field, value)
                changed_fields.append(field)

        if changed_fields:
            factory.save(update_fields=changed_fields)

        if valid_category_ids:
            factory.categories.set(valid_category_ids)
        if valid_subcategory_ids:
            factory.subcategories.set(valid_subcategory_ids)

        factory_owner.factories.add(factory)
        # Re-fire the factory lead after M2M taxonomy is attached.
        factory.save()
from rest_framework import generics, permissions, filters
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Count
from django.db.models import Count
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import generics, filters
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response

class StandardPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 500

class AMListView(generics.ListAPIView):
    serializer_class = AMListSerializer
    permission_classes = [IsSuperAccountManager | IsMNGMNTAccountManager]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'user__username', 'user__email', 'contact_email']
    filterset_fields = {'is_active': ['exact']}
    ordering_fields = ['load', 'id']
    ordering = ['load', 'id']          # default ordering
    pagination_class = StandardPagination

    def get_queryset(self):
        # NO slicing here — just the base queryset
        return (
            AM.objects
              .select_related('user')
              .annotate(load=Count('cases_am', distinct=True))   # ensure related_name is correct
        )

    def list(self, request, *args, **kwargs):
        """
        If ?limit= is present, bypass pagination and return a plain array of the first N
        AFTER applying filters/search/ordering. Otherwise, return paginated.
        """
        qs = self.filter_queryset(self.get_queryset())

        limit = request.query_params.get('limit')
        if limit is not None:
            try:
                n = max(1, min(int(limit), 500))
            except ValueError:
                n = 200
            qs = qs[:n]  # safe to slice now (all filtering/ordering already applied)
            serializer = self.get_serializer(qs, many=True)
            return Response(serializer.data)

        # fall back to paginated
        return super().list(request, *args, **kwargs)
    

# user/views.py
from django.db.models import Count
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import LoginEvent
# user/views.py
from django.db.models import Count
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import LoginEvent

class LoginStatsView(APIView):
    permission_classes = [IsMNGMNTAccountManager | IsSuperAccountManager]

    def get(self, request):
        # 1. Role summary
        role_counts = (
            LoginEvent.objects.values("role")
            .annotate(count=Count("id"))
            .order_by("role")
        )

        # 2. Recent login details (limit for readability)
        recent_events = (
            LoginEvent.objects.select_related("user")
            .order_by("-created_at")[:50]   # latest 50 logins
        )

        logins = [
            {
                "username": ev.user.username,
                "name": getattr(ev.user, "first_name", "") or ev.user.username,
                "role": ev.role,
                "time": ev.created_at.isoformat()
            }
            for ev in recent_events
        ]

        return Response({
            "summary": list(role_counts),
            "recent_logins": logins
        })

# --- Terms & Conditions API Views ---
class TermsStatusView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        role = get_role(request.user)
        scopes = [TermsAndConditions.SCOPE_GLOBAL]
        if role in [TermsAndConditions.SCOPE_BRAND_OWNER, TermsAndConditions.SCOPE_FACTORY_OWNER]:
            scopes.append(role)
        pending_terms = []
        for scope in scopes:
            current = (
                TermsAndConditions.objects.filter(scope=scope, is_active=True)
                .order_by("-version")
                .first()
            )
            if current and not TermsAcceptance.objects.filter(user=request.user, terms=current).exists():
                pending_terms.append(current)
        data = {
            "requires_acceptance": len(pending_terms) > 0,
            "pending_terms": TermsAndConditionsSerializer(pending_terms, many=True).data,
        }
        return Response(data, status=status.HTTP_200_OK)


class AcceptTermsView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        terms_id = request.data.get("terms_id")
        if not terms_id:
            return Response({"error": "terms_id required"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            terms = TermsAndConditions.objects.get(pk=terms_id, is_active=True)
        except TermsAndConditions.DoesNotExist:
            return Response({"error": "Active terms not found"}, status=status.HTTP_404_NOT_FOUND)
        if TermsAcceptance.objects.filter(user=request.user, terms=terms).exists():
            return Response({"detail": "Already accepted"}, status=status.HTTP_200_OK)
        ip = request.META.get("HTTP_X_FORWARDED_FOR", request.META.get("REMOTE_ADDR"))
        if ip and "," in ip:
            ip = ip.split(",")[0].strip()
        ua = request.META.get("HTTP_USER_AGENT")
        acceptance = TermsAcceptance.objects.create(user=request.user, terms=terms, ip_address=ip, user_agent=ua)
        return Response(TermsAcceptanceSerializer(acceptance).data, status=status.HTTP_201_CREATED)


class TermsHistoryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        qs = TermsAcceptance.objects.filter(user=request.user).select_related("terms")
        return Response(TermsAcceptanceSerializer(qs, many=True).data, status=status.HTTP_200_OK)


class PublicLatestTermsView(APIView):
    """
    Allow unauthenticated users to fetch the content of the latest active terms.
    Returns a list of terms based on the role provided.
    """
    permission_classes = [AllowAny]

    def get(self, request):
        role = request.query_params.get('role')
        if not role:
            return Response({"error": "Role is required (BO or FO)"}, status=status.HTTP_400_BAD_REQUEST)
        
        scopes = [TermsAndConditions.SCOPE_GLOBAL]
        if role == 'BO':
            scopes.append(TermsAndConditions.SCOPE_BRAND_OWNER)
        elif role == 'FO':
            scopes.append(TermsAndConditions.SCOPE_FACTORY_OWNER)
        else:
             return Response({"error": "Invalid role. Use BO or FO."}, status=status.HTTP_400_BAD_REQUEST)

        terms_list = []
        for scope in scopes:
            term = TermsAndConditions.objects.filter(scope=scope, is_active=True).order_by('-version').first()
            if term:
                terms_list.append(term)
        
        if not terms_list:
            return Response({"error": "No active terms found"}, status=status.HTTP_404_NOT_FOUND)
        
        serializer = TermsAndConditionsSerializer(terms_list, many=True)
        return Response(serializer.data)


class CheckPendingTermsView(APIView):
    """
    Allow unauthenticated users (login page) to check if they have pending terms to accept.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get("username")
        if not username:
            return Response({"error": "Username is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        # Find user by username or email
        user = User.objects.filter(Q(username__iexact=username) | Q(email__iexact=username)).first()
        
        if not user:
            # Return False to avoid enumeration
            return Response({"requires_acceptance": False})

        # Determine user's role and relevant scopes
        role_scopes = [TermsAndConditions.SCOPE_GLOBAL]
        if BrandOwner.objects.filter(user=user).exists():
            role_scopes.append(TermsAndConditions.SCOPE_BRAND_OWNER)
        elif FactoryOwner.objects.filter(user=user).exists():
            role_scopes.append(TermsAndConditions.SCOPE_FACTORY_OWNER)
        
        # Check for pending terms
        # 1. Get all active terms for these scopes
        active_terms = TermsAndConditions.objects.filter(scope__in=role_scopes, is_active=True)
        
        # 2. Get IDs of terms already accepted by this user
        accepted_terms_ids = TermsAcceptance.objects.filter(user=user).values_list('terms_id', flat=True)
        
        # 3. Filter out accepted terms
        pending_terms = active_terms.exclude(id__in=accepted_terms_ids)
        
        if pending_terms.exists():
            return Response({
                "requires_acceptance": True,
                "pending_terms": TermsAndConditionsSerializer(pending_terms, many=True).data
            })
        
        return Response({"requires_acceptance": False})
