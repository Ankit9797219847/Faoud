from django.contrib import admin
from .models import BrandOwner, FactoryOwner, Formulator, AM, TermsAndConditions, TermsAcceptance

class BrandOwnerAdmin(admin.ModelAdmin):
    list_filter = ('name', 'created_at')

class FactoryOwnerAdmin(admin.ModelAdmin):
    list_filter = ('name', 'created_at')



admin.site.register(BrandOwner, BrandOwnerAdmin)
@admin.register(AM)
class AMAdmin(admin.ModelAdmin):
    list_display = ("id", "user",)
    # IMPORTANT for LeadItemAdmin.autocomplete_fields
    search_fields = (
        "id",
        "user__email",
        "user__first_name",
        "user__last_name",
        "user__username",  # if you have it
    )
admin.site.register(FactoryOwner, FactoryOwnerAdmin)


@admin.register(TermsAndConditions)
class TermsAndConditionsAdmin(admin.ModelAdmin):
    list_display = ("id", "scope", "version", "title", "is_active", "published_at")
    list_filter = ("scope", "is_active")
    search_fields = ("title", "content")
    readonly_fields = ("content_hash", "published_at", "created_at")

@admin.register(TermsAcceptance)
class TermsAcceptanceAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "terms", "accepted_at")
    list_filter = ("terms__scope",)
    search_fields = ("user__username", "user__email", "terms__title")
    readonly_fields = ("signature_hash", "accepted_at")
