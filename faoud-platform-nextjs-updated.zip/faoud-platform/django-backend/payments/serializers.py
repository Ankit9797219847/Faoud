# payments/serializers.py

from rest_framework import serializers
from django.contrib.auth.models import User

# Models
from case.models import Case
from supply.models import Bid
from user.models import BrandOwner
from utils.models import Address
from .models import (
    BrandOwnerPaymentInfo,
    Feature,
    SampleOrder,
    UserFeature,
    Charge,
    Order,
    PaymentLayer
)

# Serializers from other apps
from case.serializers import CaseSerializer
from supply.serializers import BidSerializer, BidWithFactorySerializer
from user.serializers import UserSerializer
from utils.serializers import AddressSerializer


# ------------------------------------------------------------------------------
# Feature / UserFeature / Charge
# ------------------------------------------------------------------------------
class FeatureSerializer(serializers.ModelSerializer):
    class Meta:
        model = Feature
        fields = '__all__'


class UserFeatureSerializer(serializers.ModelSerializer):
    feature = FeatureSerializer(read_only=True)

    class Meta:
        model = UserFeature
        fields = [
            'id', 'user', 'feature', 'is_active', 'price',
            'removable', 'case', 'feature_id', 'quantity'
        ]


class ChargeSerializer(serializers.ModelSerializer):
    feature = UserFeatureSerializer(read_only=True)

    class Meta:
        model = Charge
        fields = [
            'id', 'user', 'feature', 'amount', 'charged_on', 'is_paid'
        ]


# ------------------------------------------------------------------------------
# PaymentLayer / Order
# ------------------------------------------------------------------------------
class PaymentLayerSerializer(serializers.ModelSerializer):
    brandownerpaymentinfo = serializers.PrimaryKeyRelatedField(
        read_only=True  # Make it read-only if it's set automatically in the view
    )

    class Meta:
        model = PaymentLayer
        fields = [
            'id', 'amount', 'layer_type', 'status',
            'created_at', 'brandownerpaymentinfo'
        ]


class OrderSerializer(serializers.ModelSerializer):
    features = UserFeatureSerializer(many=True)
    payment_layers = PaymentLayerSerializer(many=True, read_only=True)
    case = serializers.PrimaryKeyRelatedField(queryset=Case.objects.all())

    class Meta:
        model = Order
        fields = [
            'id', 'order_id', 'case', 'features', 'total_amount',
            'amount_due', 'currency', 'status', 'created_at',
            'expiry_date', 'razorpay_order_id', 'payment_layers'
        ]


# ------------------------------------------------------------------------------
# BrandOwnerPaymentInfo
# ------------------------------------------------------------------------------
class BrandOwnerPaymentInfoSerializer(serializers.ModelSerializer):
    """
    Serializer that always updates or creates the BrandOwnerPaymentInfo
    tied to the request.user's brandowner.
    """

    class Meta:
        model = BrandOwnerPaymentInfo
        fields = [
            'id',
            # 'brand_owner_id',  # REMOVED so we don't take brand_owner ID from frontend
            'gst_number',
            'pan_number',
            'billing_address',
            'shipping_address',
            'contact_number',
            'contact_email',
        ]
        read_only_fields = ['id']

    def create(self, validated_data):
        """
        This method will be called on POST requests.
        We use update_or_create to either update the existing record
        if one exists for this brand_owner, or create a new one if not.
        """
        request = self.context.get('request')
        brand_owner = getattr(request.user, 'brandowner', None)
        if not brand_owner:
            raise serializers.ValidationError("No BrandOwner associated with this user.")

        # Use update_or_create so we avoid duplicates
        instance, _ = BrandOwnerPaymentInfo.objects.update_or_create(
            brand_owner=brand_owner,
            defaults=validated_data
        )
        return instance

    def update(self, instance, validated_data):
        """
        Optional: If you want to support PUT/PATCH explicitly.
        """
        return super().update(instance, validated_data)


# ------------------------------------------------------------------------------
# SampleOrder + various detail serializers
# ------------------------------------------------------------------------------
class SampleOrderSerializer(serializers.ModelSerializer):
    """
    For creating a new SampleOrder, specifying bid_ids and address_id.
    """
    bid_ids = serializers.ListField(
        child=serializers.IntegerField(),
        write_only=True
    )
    address_id = serializers.IntegerField(write_only=True)
    brand_owner = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(), required=False
    )

    class Meta:
        model = SampleOrder
        fields = [
            'id',
            'payment_layer',
            'address_id',
            'brand_owner',
            'case',
            'bid_ids',
            'total_amount',
            'status',
            'created_at',
            'updated_at',
        ]
        read_only_fields = [
            'id', 'total_amount', 'status', 'created_at', 'updated_at'
        ]

    def create(self, validated_data):
        bid_ids = validated_data.pop('bid_ids')
        address_id = validated_data.pop('address_id')
        case = validated_data.get('case')

        # Fetch the Address instance
        address = Address.objects.get(id=address_id)

        # Fetch Bid instances (only those belonging to this Case)
        bids = Bid.objects.filter(id__in=bid_ids, case=case)

        # Assume brand_owner is the user initiating the payment
        brand_owner = self.context['request'].user

        # Create SampleOrder
        sample_order = SampleOrder.objects.create(
            payment_layer=validated_data.get('payment_layer'),
            address=address,
            brand_owner=brand_owner,
            case=case
        )
        # Set the Bids for this SampleOrder
        sample_order.bids.set(bids)
        # Calculate total amount (custom method on model)
        sample_order.calculate_total_amount()
        return sample_order


class SampleOrderSerializerFactoryView(serializers.ModelSerializer):
    """
    Shows SampleOrder data including references to brand_owner, case, and bids.
    """
    address = serializers.StringRelatedField()
    brand_owner = UserSerializer(read_only=True)
    case = CaseSerializer(read_only=True)
    bids = serializers.PrimaryKeyRelatedField(many=True, read_only=True)

    class Meta:
        model = SampleOrder
        fields = [
            'id',
            'order_id',
            'total_amount',
            'status',
            'created_at',
            'updated_at',
            'address',
            'brand_owner',
            'case',
            'bids',
        ]


class SampleOrderSerializerBidView(serializers.ModelSerializer):
    """
    Shows SampleOrder with full bid details (via BidWithFactorySerializer).
    """
    bids = BidWithFactorySerializer(many=True, read_only=True)
    address = AddressSerializer()

    class Meta:
        model = SampleOrder
        fields = [
            'id',
            'payment_layer',
            'address',
            'brand_owner',
            'case',
            'bids',
            'created_at',
            'updated_at',
            'total_amount',
            'status',
        ]


class BidWithSampleOrdersSerializer(serializers.ModelSerializer):
    """
    Shows a Bid along with its associated SampleOrders (nested).
    """
    sample_orders = SampleOrderSerializerFactoryView(
        many=True,
        read_only=True,
        source='sample_orders'
    )

    class Meta:
        model = Bid
        fields = [
            'id',
            'quote',
            'quote_bo',
            'eta',
            'status',
            'tag',
            'sample_paid',
            'sample_orders',  # Nested Sample Orders
        ]
