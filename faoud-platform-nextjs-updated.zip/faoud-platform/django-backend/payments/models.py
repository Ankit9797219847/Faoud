from django.db import models

# Create your models here.
# orders/models.py

from django.db import models
from django.contrib.auth.models import User
from django.core.validators import RegexValidator

from case.models import Case
from user.models import BrandOwner
from utils.models import Address, Brand
class Order(models.Model):
    ORDER_STATUS = (
        ('PENDING', 'Pending'),
        ('PARTIALLY_PAID', 'Partially Paid'),
        ('PAID', 'Paid'),
        ('FAILED', 'Failed'),
        ('EXPIRED', 'Expired'),
    )

    case = models.ForeignKey(Case, on_delete=models.CASCADE, related_name='orders')
    features = models.ManyToManyField('UserFeature', related_name='orders')
    order_id = models.CharField(max_length=100, unique=True)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=9003321)
    amount_due = models.DecimalField(max_digits=15, decimal_places=2)
    status = models.CharField(max_length=15, choices=ORDER_STATUS, default='PENDING')
    currency = models.CharField(max_length=10, default='INR')
    created_at = models.DateTimeField(auto_now_add=True)
    expiry_date = models.DateTimeField()
    razorpay_order_id = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f"Order {self.order_id} for Case {self.case.id}"

    def update_status(self):
        total_paid = self.payment_layers.filter(status='PAID').aggregate(total=models.Sum('amount'))['total'] or 0
        self.amount_due = self.total_amount - total_paid
        if self.amount_due <= 0:
            self.status = 'PAID'
        elif total_paid > 0:
            self.status = 'PARTIALLY_PAID'
        self.save()

    

class Feature(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(max_digits=15, decimal_places=2)

    def __str__(self):
        return self.name

class UserFeature(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    case = models.ForeignKey(Case, on_delete=models.CASCADE,null=True, blank=True)
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE)
    description = models.TextField(null=True, blank=True)
    date = models.DateField(null=True, blank=True)
    price = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    removable = models.BooleanField(default=True)
    date_created = models.DateTimeField(auto_now_add=True)
    quantity = models.IntegerField(default=1)

    class Meta:
        unique_together = ('user', 'case', 'feature')

    def __str__(self):
        return f"{self.user.username} - {self.feature.name} for case {self.case}"

class Charge(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    charged_on = models.DateTimeField(auto_now_add=True)
    is_paid = models.BooleanField(default=False)

    def __str__(self):
        return f"Charge({self.user.username}, {self.amount})"


from django.db import models



class BrandOwnerPaymentInfo(models.Model):
    """
    Stores payment-related details for a BrandOwner.
    """
    brand_owner = models.OneToOneField(
        BrandOwner,
        on_delete=models.CASCADE,
        related_name='payment_info'
    )
    # Example fields:
    gst_number = models.CharField(max_length=15, blank=True, null=True)
    pan_number = models.CharField(max_length=10, blank=True, null=True)
    billing_address = models.ForeignKey(
        Address, 
        on_delete=models.CASCADE, 
        related_name='billing_address_infos',
        default=0
    )
    shipping_address = models.ForeignKey(
        Address, 
        on_delete=models.CASCADE, 
        related_name='shipping_address_infos',
        default=0
    )
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE, related_name='payment_info_brand', default=1)
    # If you need phone or email specifically for invoices
    contact_number = models.CharField(
        max_length=15, 
        blank=True, 
        null=True,
        validators=[RegexValidator(regex=r'^\+?\d{7,15}$')]
    )
    contact_email = models.EmailField(blank=True, null=True)
    # ... Add any other fields required for invoice generation or payment

    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Payment Info for {self.brand_owner.user.username}"

class PaymentLayer(models.Model):
    LAYER_TYPES = (
        ('ADVANCE', 'Advance'),  # Value saved in the backend: 'ADVANCE', Key seen by people: 'Advance'
        ('FINAL', 'Final'),      # Value saved in the backend: 'FINAL', Key seen by people: 'Final'
        ('SAMPLE', 'Sample'),    # Value saved in the backend: 'SAMPLE', Key seen by people: 'Sample'
    )

    ORDER_STATUS = (
        ('PENDING', 'Pending'),
        ('PAID', 'Paid'),
        ('FAILED', 'Failed'),
        ('EXPIRED', 'Expired'),
    )

    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='payment_layers')
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    layer_type = models.CharField(max_length=10, choices=LAYER_TYPES)
    status = models.CharField(max_length=10, choices=ORDER_STATUS, default='PENDING')
    created_at = models.DateTimeField(auto_now_add=True)
    expiry_date = models.DateTimeField()
    razorpay_payment_id = models.CharField(max_length=100, blank=True, null=True)
    razorpay_order_id = models.CharField(max_length=100, blank=True, null=True)
    razorpay_signature = models.CharField(max_length=100, blank=True, null=True)

    notes = models.JSONField(default=dict, blank=True)  # or models.JSONField if using Django 3.1+
    brandownerpaymentinfo = models.ForeignKey(BrandOwnerPaymentInfo, on_delete=models.CASCADE, blank=True, null=True)

    def __str__(self):
        return f"{self.layer_type} Payment of {self.amount} for Order {self.order.order_id}"


from django.db import models
from django.contrib.auth.models import User
from decimal import Decimal
from case.models import Case
from supply.models import Bid
from utils.models import Address

class SampleOrder(models.Model):
    payment_layer = models.OneToOneField(
        'PaymentLayer',
        on_delete=models.CASCADE,
        related_name='sample_order'
    )
    address = models.ForeignKey(
        Address,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='sample_orders'
    )
    brand_owner = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='sample_orders'
    )
    case = models.ForeignKey(
        Case,
        on_delete=models.CASCADE,
        related_name='sample_orders'
    )
    bids = models.ManyToManyField(
        Bid,
        related_name='sample_orders'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    total_amount = models.DecimalField(max_digits=15, decimal_places=2, default=Decimal('0.00'))
    status = models.CharField(max_length=20, choices=(
        ('CREATED', 'Created'),
        ('PROCESSING', 'Processing'),
        ('COMPLETED', 'Completed'),
        ('FAILED', 'Failed'),
    ), default='CREATED')

    def __str__(self):
        return f"SampleOrder {self.id} for Case {self.case.id} by {self.brand_owner.username}"

    def calculate_total_amount(self):
        """
        Calculates the total amount based on the associated bids.
        This method can be customized based on your business logic.
        """
        total = self.bids.aggregate(total=models.Sum('quote_bo'))['total'] or Decimal('0.00')
        self.total_amount = total
        self.save()


class ServicePayment(models.Model):
    """
    Payment model for ServiceRequests.
    Reuses existing Razorpay integration patterns from PaymentLayer.
    One payment per ServiceRequest (upfront payment model).
    """
    PAYMENT_STATUS_CHOICES = [
        ('CREATED', 'Created'),
        ('PENDING', 'Pending'),
        ('SUCCEEDED', 'Succeeded'),
        ('FAILED', 'Failed'),
        ('REFUNDED', 'Refunded'),
    ]

    PROVIDER_CHOICES = [
        ('RAZORPAY', 'Razorpay'),
        ('STRIPE', 'Stripe'),
    ]

    # Link to ServiceRequest (OneToOne for upfront payment model)
    service_request = models.OneToOneField(
        'services.ServiceRequest',
        on_delete=models.CASCADE,
        related_name='payment'
    )
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='service_payments'
    )

    # Amount details
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    currency = models.CharField(max_length=10, default='INR')

    # Status
    status = models.CharField(
        max_length=20,
        choices=PAYMENT_STATUS_CHOICES,
        default='CREATED',
        db_index=True
    )

    # Payment provider details (following PaymentLayer pattern)
    provider = models.CharField(
        max_length=20,
        choices=PROVIDER_CHOICES,
        default='RAZORPAY'
    )
    provider_order_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        help_text="Razorpay order_id or Stripe payment_intent_id"
    )
    provider_payment_id = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        help_text="Razorpay payment_id"
    )
    provider_signature = models.CharField(
        max_length=255,
        blank=True,
        null=True,
        help_text="Razorpay signature for verification"
    )

    # Metadata storage
    meta = models.JSONField(
        default=dict,
        blank=True,
        help_text="Raw payload from provider"
    )

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Service Payment'
        verbose_name_plural = 'Service Payments'
        indexes = [
            models.Index(fields=['status', 'created_at']),
            models.Index(fields=['provider_order_id']),
        ]

    def __str__(self):
        return f"ServicePayment#{self.pk} - {self.amount} {self.currency} ({self.status})"

    def mark_succeeded(self, payment_id=None, signature=None, meta=None):
        """Mark payment as succeeded and update related fields."""
        from django.utils import timezone
        self.status = 'SUCCEEDED'
        self.paid_at = timezone.now()
        if payment_id:
            self.provider_payment_id = payment_id
        if signature:
            self.provider_signature = signature
        if meta:
            self.meta = meta
        self.save()

    def mark_failed(self, meta=None):
        """Mark payment as failed."""
        self.status = 'FAILED'
        if meta:
            self.meta = meta
        self.save()

