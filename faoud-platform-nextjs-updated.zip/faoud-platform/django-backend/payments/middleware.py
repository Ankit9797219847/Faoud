# payments/middleware.py

from django.shortcuts import redirect
from django.contrib import messages
from django.urls import reverse
from .models import UserFeature

class FeatureAccessMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        resolver_match = getattr(request, "resolver_match", None)
        view_func = getattr(resolver_match, "func", None)
        required_feature = getattr(view_func, "required_feature", None)
        if required_feature and request.user.is_authenticated:
            has_feature = UserFeature.objects.filter(
                user=request.user,
                feature__name=required_feature,
                is_active=True
            ).exists()
            if not has_feature:
                messages.error(request, "Can't use feature because you are not paying for it.")
                return redirect(reverse('payments:checkout'))
        return self.get_response(request)
