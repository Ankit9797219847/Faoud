from django.core.management.base import BaseCommand
from django.utils import timezone

from payments.models import Order



class Command(BaseCommand):
    help = 'Expire orders that have passed their expiry date'

    def handle(self, *args, **kwargs):
        expired_orders = Order.objects.filter(
            expiry_date__lt=timezone.now(), status='PENDING'
        )
        count = expired_orders.update(status='EXPIRED')
        self.stdout.write(f'Expired {count} orders')