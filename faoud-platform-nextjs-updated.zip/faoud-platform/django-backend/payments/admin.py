from django.contrib import admin

from payments.models import Order

# Register your models here.





from django.contrib import admin
from .models import BrandOwnerPaymentInfo, Feature, PaymentLayer, SampleOrder, ServicePayment, UserFeature, Charge
admin.site.register(Order)
admin.site.register(PaymentLayer)
admin.site.register(BrandOwnerPaymentInfo)
admin.site.register(ServicePayment)

@admin.register(Feature)
class FeatureAdmin(admin.ModelAdmin):
    list_display = ('name', 'price','id')
    search_fields = ('name',)
    ordering = ('-price',)

@admin.register(UserFeature)
class UserFeatureAdmin(admin.ModelAdmin):
    list_display = ('user', 'feature', 'is_active',)
    list_filter = ('is_active',)
    search_fields = ('user__username', 'feature__name')
    ordering = ('-id',)

@admin.register(Charge)
class ChargeAdmin(admin.ModelAdmin):
    list_display = ('user', 'feature', 'amount', 'is_paid', 'charged_on')
    list_filter = ('is_paid', 'charged_on')
    search_fields = ('user__username', 'feature__name') 
    ordering = ('-charged_on',)

@admin.register(SampleOrder)
class SampleOrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'payment_layer', 'brand_owner', 'case', 'total_amount', 'status', 'created_at']
    list_filter = ['status', 'payment_layer']
    search_fields = ['order__order_id', 'brand_owner__username', 'case__id']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ('-created_at',)