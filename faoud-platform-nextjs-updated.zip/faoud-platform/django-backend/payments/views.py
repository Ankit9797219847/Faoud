# orders/views.py

from decimal import Decimal
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
import razorpay
import hmac
import hashlib
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.conf import settings
from django.utils import timezone
from datetime import timedelta

from supply.models import Bid
from supply.views import DeselectFactoryView
from user.models import BrandOwner

custom_formulas = {
    'advance': lambda total, prev_amounts: (total - prev_amounts['token_amount']) * Decimal('0.5'),
    'final': lambda total, prev_amounts: total - sum(prev_amounts.values()),
}

import razorpay
from io import BytesIO
from django.core.files.base import ContentFile

from utils.models import Address, Address, Brand, Document
from .models import BrandOwnerPaymentInfo, Case, Order, Feature, PaymentLayer, SampleOrder, ServicePayment
from .serializers import BidWithSampleOrdersSerializer, BrandOwnerPaymentInfoSerializer, FeatureSerializer, SampleOrderSerializer, SampleOrderSerializerBidView

from payments.utils import can_toggle_active, generate_invoice, update_user_feature
from user.permissions import IsAccountManager, IsBrandOwner, IsFactoryOwner
from .models import Order, Case
from .serializers import OrderSerializer
from rest_framework.permissions import AllowAny
from razorpay.errors import SignatureVerificationError

from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import Feature, UserFeature, Charge
from .serializers import FeatureSerializer, UserFeatureSerializer, ChargeSerializer
from rest_framework.permissions import IsAuthenticated
# payments/views.py


class VerifyPaymentAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        data = request.data
        params_dict = {
            'razorpay_order_id': data.get('razorpay_order_id'),
            'razorpay_payment_id': data.get('razorpay_payment_id'),
            'razorpay_signature': data.get('razorpay_signature'),
        }

        try:
            # Verify the payment signature
            client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
            client.utility.verify_payment_signature(params_dict)

            # Existing layered-payment flow
            payment_layer = PaymentLayer.objects.filter(
                razorpay_order_id=params_dict['razorpay_order_id']
            ).first()

            if payment_layer:
                payment_layer.status = 'PAID'
                payment_layer.razorpay_payment_id = params_dict['razorpay_payment_id']
                payment_layer.razorpay_signature = params_dict['razorpay_signature']
                payment_layer.save()

                # Update Order status
                payment_layer.order.update_status()

                if payment_layer.layer_type == 'SAMPLE':
                    bid_ids = payment_layer.notes.get('bid_ids', [])
                    Bid.objects.filter(id__in=bid_ids).update(sample_paid=True, status ='SAMPLE_ORDERED')

                return Response({'status': 'success'})

            # Service-request payment flow
            service_payment = ServicePayment.objects.filter(
                provider_order_id=params_dict['razorpay_order_id']
            ).first()

            if service_payment:
                if service_payment.status != 'SUCCEEDED':
                    service_payment.mark_succeeded(
                        payment_id=params_dict['razorpay_payment_id'],
                        signature=params_dict['razorpay_signature']
                    )

                service_request = service_payment.service_request
                if service_request.status == 'AWAITING_PAYMENT':
                    service_request.transition_to(
                        'PAID',
                        note='Payment verified via /api/verify-payment/'
                    )
                    service_request.transition_to(
                        'IN_REVIEW',
                        note='Auto-transitioned after payment'
                    )

                return Response({'status': 'success'})

            return Response({'status': 'failure', 'error': 'Payment record not found'}, status=404)

        except SignatureVerificationError:
            return Response({'status': 'failure'}, status=400)


class PaymentWebhookAPIView(APIView):
    permission_classes = [AllowAny]  # Allow Razorpay to access this endpoint

    def post(self, request):
        webhook_secret = settings.RAZORPAY_WEBHOOK_SECRET
        received_signature = request.META.get('HTTP_X_RAZORPAY_SIGNATURE')
        body = request.body

        generated_signature = hmac.new(
            webhook_secret.encode(), body, hashlib.sha256
        ).hexdigest()

        if hmac.compare_digest(received_signature, generated_signature):
            event = request.data.get('event')
            payload = request.data.get('payload', {})
            payment_entity = payload.get('payment', {}).get('entity', {})
            order_id = payment_entity.get('order_id')

            # First try to find Order (existing flow)
            order = Order.objects.filter(razorpay_order_id=order_id).first()
            
            if order:
                # Existing Order payment flow
                if event == 'payment.captured':
                    order.status = 'PAID'
                    order.razorpay_payment_id = payment_entity.get('id')
                    order.save()
                elif event == 'payment.failed':
                    order.status = 'FAILED'
                    order.save()
                return Response(status=status.HTTP_200_OK)

            # Try ServicePayment (new services flow)
            service_payment = ServicePayment.objects.filter(provider_order_id=order_id).first()
            
            if service_payment:
                if event == 'payment.captured':
                    service_payment.mark_succeeded(
                        payment_id=payment_entity.get('id'),
                        meta=payment_entity
                    )
                    # Update service request status
                    service_request = service_payment.service_request
                    if service_request.status == 'AWAITING_PAYMENT':
                        service_request.transition_to(
                            'PAID',
                            note='Payment confirmed via webhook'
                        )
                        # Auto-transition to IN_REVIEW
                        service_request.transition_to(
                            'IN_REVIEW',
                            note='Auto-transitioned after payment confirmation'
                        )
                elif event == 'payment.failed':
                    service_payment.mark_failed(meta=payment_entity)
                return Response(status=status.HTTP_200_OK)

            # Order not found in either system
            return Response({'error': 'Order not found'}, status=404)

            return Response(status=status.HTTP_200_OK)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)




class CaseOrdersAPIView(APIView):
    def get(self, request, case_id):
        try:
            # Fetch all orders related to the case
            orders = Order.objects.filter(case__id=case_id).order_by('-created_at')
            serializer = OrderSerializer(orders, many=True)  # Serialize multiple orders
            return Response(serializer.data)
        except Case.DoesNotExist:
            return Response({'error': 'Case not found.'}, status=404)
        


class BrandOwnerTransactionsAPIView(APIView):
    permission_classes = [IsBrandOwner]

    def get(self, request):
        # Get the logged-in brand owner
        brand_owner = request.user.brandowner
        
        # Fetch all cases associated with this brand owner
        cases = Case.objects.filter(brand_owner=brand_owner)
        
        if not cases.exists():
            return Response({'error': 'No cases found for this brand owner.'}, status=status.HTTP_404_NOT_FOUND)

        # Fetch all orders related to these cases
        orders = Order.objects.filter(case__in=cases)

        # Serialize the orders
        serializer = OrderSerializer(orders, many=True)
        
        return Response(serializer.data, status=status.HTTP_200_OK)


class FeatureViewSet(viewsets.ModelViewSet):
    queryset = Feature.objects.all()
    serializer_class = FeatureSerializer
    permission_classes = [IsAccountManager | IsBrandOwner]


class UserFeatureListView(APIView):
    permission_classes = [IsBrandOwner | IsAccountManager]

    def get(self, request, case_id):

        if not hasattr(request.user, 'am'):
            user_features = UserFeature.objects.filter(case_id=case_id, user=request.user)
            data = [
                {
                    "id": uf.id,
                    "feature_name": uf.feature.name,
                    "description": uf.description,
                    "date": uf.date,
                    "price": uf.price,
                    "is_active": uf.is_active,
                    "quantity" : uf.quantity,
                    "removable": uf.removable
                }
                for uf in user_features
            ]
            return Response(data)
        else:
            user_features = UserFeature.objects.filter(case_id=case_id)
            data = [
                {
                    "id": uf.id,
                    "feature_name": uf.feature.name,
                    "description": uf.description,
                    "date": uf.date,
                    "price": uf.price,
                    "is_active": uf.is_active,
                    "quantity" : uf.quantity,
                    "removable": uf.removable
                }
                for uf in user_features
            ]
            return Response(data)


class ToggleUserFeatureActiveView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, user_feature_id):
        user_feature = UserFeature.objects.get(id=user_feature_id, user=request.user)
        if can_toggle_active(user_feature):
            user_feature.is_active = not user_feature.is_active
            user_feature.save()
            return Response({'status': 'UserFeature toggled successfully'})
        return Response({'error': 'Feature is not removable'}, status=400)

class EditUserFeaturePriceView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request, user_feature_id):
        user_feature = UserFeature.objects.get(id=user_feature_id)
        price = request.data.get('price')

        try:
            update_user_feature(request.user, user_feature, {'price': price})
            return Response({'status': 'Price updated successfully'})
        except PermissionError as e:
            return Response({'error': str(e)}, status=403)
class UserFeatureViewSet(viewsets.ModelViewSet):
    queryset = UserFeature.objects.all()
    serializer_class = UserFeatureSerializer
    permission_classes = [IsBrandOwner]


    def get_queryset(self):

        case_id = self.request.query_params.get('case_id')
        caseobj = get_object_or_404(Case, id = case_id)
        if case_id:
            queryset = queryset.filter(case=caseobj)
        return UserFeature.objects.filter(user=self.request.user)


    def get_queryset(self):
        return UserFeature.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
        # Create a charge
        Charge.objects.create(
            user=self.request.user,
            feature=serializer.validated_data['feature'],
            amount=serializer.validated_data['feature'].price
        )

    @action(detail=True, methods=['post'])
    def deactivate(self, request, pk=None):
        user_feature = self.get_object()
        user_feature.is_active = False
        user_feature.save()
        return Response({'status': 'feature deactivated'})
    
    @action(detail=True, methods=['post'])
    def request_removal(self, request, pk=None):
        user_feature = self.get_object()
        if user_feature.is_active:
            user_feature.is_active = False
            user_feature.save()
            return Response({'status': 'Feature deactivated'})
        else:
            return Response({'status': 'Feature already inactive'}, status=400)

class ChargeViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Charge.objects.all()
    serializer_class = ChargeSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Charge.objects.filter(user=self.request.user)
    

    # payments/views.py

# View to add a feature
class AddFeatureAPIView(APIView):
    permission_classes = [IsBrandOwner]

    def post(self, request):
        feature_id = request.data.get('feature_id')
        if not feature_id:
            return Response({'error': 'Feature ID is required.'}, status=400)

        try:
            user_feature = get_object_or_404(UserFeature, id = feature_id)
            # if not user_feature.removable:
            #     return Response({'error': 'This is out of reach.'}, status=404)

            if not user_feature.is_active:
                user_feature.is_active = True
                user_feature.save()
                return Response({'status': 'Feature reactivated successfully', 'feature': feature_id})
            else:
                return Response({'status': 'Feature is already active for user'}, status=400)

        except Feature.DoesNotExist:
            return Response({'error': 'Feature not found'}, status=404)

# View to remove a feature
class RemoveFeatureAPIView(APIView):
    permission_classes = [IsBrandOwner]

    def post(self, request):
        feature_id = request.data.get('feature_id')
        if not feature_id:
            return Response({'error': 'Feature ID is required.'}, status=400)

        try:
            user_feature = get_object_or_404(UserFeature, id = feature_id)

            if not user_feature.removable:
                return Response({'error': 'This is out of reach.'}, status=404)
            if user_feature.feature.name == 'Manufacturing Cost':
                    # Assuming `case_id` and `factory_id` are available in `user_feature` or another way
                    case_id = user_feature.case.id
                    factory_id = user_feature.case.factory.id if user_feature.case.factory else None

                    # Deselect the factory if it exists
                    if case_id and factory_id:
                        DeselectFactoryView().post(request, case_id=case_id, factory_id=factory_id)

            if user_feature.is_active:
                user_feature.is_active = False
                user_feature.save()
                return Response({'status': 'Feature removed successfully', 'feature': feature_id})
            else:
                return Response({'status': 'Feature is already inactive'}, status=200)
        except UserFeature.DoesNotExist:
            return Response({'error': 'Feature not found for user'}, status=404)

# View to deactivate a feature
class DeactivateFeatureAPIView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request, pk=None):
        user_feature = get_object_or_404(UserFeature, pk=pk, user=request.user)
        user_feature.is_active = False
        user_feature.save()
        return Response({'status': 'Feature deactivated'})

# View to request feature removal
class RequestRemovalFeatureAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, pk=None):
        user_feature = get_object_or_404(UserFeature, pk=pk, user=request.user)
        if user_feature.is_active:
            user_feature.is_active = False
            user_feature.save()
            return Response({'status': 'Feature deactivated'})
        else:
            return Response({'status': 'Feature already inactive'}, status=400)

class InvoiceAPIView(APIView):
    permission_classes = [IsBrandOwner | IsAccountManager]

    def get(self, request, order_id):
        try:
            order = Order.objects.get(order_id=order_id)
            if order.case.brand_owner.user != request.user and not request.user.is_staff:
                return Response({'error': 'Unauthorized'}, status=403)
        except Order.DoesNotExist:
            return Response({'error': 'Order not found.'}, status=404)

        pdf_buffer = generate_invoice(order)
        response = HttpResponse(pdf_buffer, content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="Invoice_{order.order_id}.pdf"'
        return response
    



from .utils import calculate_payment_amounts, get_brand_owner_payment_info, set_feature_non_removable

class SetFeatureNonRemovableView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request, case_id):
        feature_name = request.data.get("feature_name")  # Get feature name from request body
        if not feature_name:
            return Response({"status": "error", "message": "Feature name is required."}, status=400)

        result = set_feature_non_removable(user=request.user, case_id=case_id, feature_name=feature_name)
        return Response(result)
    


# class InitiateTokenPaymentAPIView(APIView):
#     permission_classes = [IsAccountManager| IsBrandOwner]

#     def post(self, request):
#         case_id = request.data.get('case_id')
#         token_amount = request.data.get('token_amount', 1)  # Default token amount

#         # Validate and fetch case
#         case = get_object_or_404(Case, id=case_id)
#         amounts = calculate_payment_amounts( case, formulas=custom_formulas)


#         # Calculate total amount from features
#         user_features = UserFeature.objects.filter(case_id=case_id)
#         token_amount = amounts['token_amount']
#         total_amount = amounts['total_amount']

#         # Create Order if not exists
#         order, created = Order.objects.get_or_create(
#             case=case,
#             defaults={
#                 'order_id': 'order_' + str(int(timezone.now().timestamp())),
#                 'total_amount': total_amount,
#                 'expiry_date': timezone.now() + timedelta(days=5),
#             }
#         )
#         order.features.set(user_features)
#         order.save()

#         # Delete any existing payment layer for the specified case that is in 'PENDING' status
#         PaymentLayer.objects.filter(order=order, layer_type='TOKEN', status='PENDING').delete()

#         # Now create a new payment layer after deleting old ones
#         token_payment = PaymentLayer.objects.create(
#             order=order,
#             amount=token_amount,  # Replace with dynamic calculation as needed
#             layer_type='TOKEN',
#             status='PENDING',
#             created_at=timezone.now(),
#             expiry_date = timezone.now() + timedelta(minutes=5),

#         )
#         # Create Razorpay Order
#         client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
#         razorpay_order = client.order.create({
#             'amount': int(float(token_amount) * 100),  # Amount in paisa
#             'currency': 'INR',
#             'receipt': str(token_payment.id),  # Convert to string
#             'payment_capture': '1',
#         })

#         # Save Razorpay order ID
#         token_payment.razorpay_order_id = razorpay_order['id']
#         token_payment.save()

#         # Return payment details
#         data = {
#             'razorpay_order_id': razorpay_order['id'],
#             'razorpay_key_id': settings.RAZORPAY_KEY_ID,
#             'amount': token_amount,
#             'currency': 'INR',
#             'order_id': order.order_id,
#             'payment_layer_id': token_payment.id,
#             'layer_type': 'TOKEN',
#             'expiry_date': token_payment.expiry_date,
#         }
#         return Response(data)


# In payments/views.py (or orders/views.py):
class InitiateTokenPaymentAPIView(APIView):
    permission_classes = [IsAccountManager| IsBrandOwner]

    def post(self, request):
        return Response({'detail': 'Token is not used anymore.'}, status=400)

class InitiateAdvancePaymentAPIView(APIView):
    permission_classes = [IsAccountManager | IsBrandOwner]

    def post(self, request):
        order_id = request.data.get('order_id')
        override_amount = request.data.get('override_amount')
        case_id = request.data.get('case_id')

        # Fetch Order
        order = get_object_or_404(Order, order_id=order_id)
        case = get_object_or_404(Case, id = case_id)

        

        # Check if user is an Account Manager
        if hasattr(request.user, 'am'):
            # Calculate default advance amount (half of the remaining amount)
            default_advance_amount = order.amount_due / 2

            # Use override amount if provided
            advance_amount = float(override_amount) if override_amount else default_advance_amount

            brand_owner_payment_info = get_brand_owner_payment_info(order)

            # Create Advance PaymentLayer
            advance_payment = PaymentLayer.objects.create(
                order=order,
                amount=advance_amount,
                layer_type='ADVANCE',
                expiry_date=timezone.now() + timedelta(days=3),  # Advance payment expiry
                brandownerpaymentinfo=brand_owner_payment_info 
            )

            data = {
                'payment_layer_id': advance_payment.id,
                'amount': advance_amount,
                'expiry_date': advance_payment.expiry_date,
                'layer_type': 'ADVANCE',
                'order_id': order.order_id,
                'status': 'Payment layer created successfully by Account Manager.',
            }
            return Response(data, status=status.HTTP_201_CREATED)

        # Check if user is a Brand Owner
        elif hasattr(request.user, 'brandowner'):

            amounts = calculate_payment_amounts(case, formulas=custom_formulas)
            advance_amount = amounts['advance_amount']


            # Check if an advance payment layer exists
            advance_payment = PaymentLayer.objects.filter(order=order, layer_type='ADVANCE').latest('created_at')
            if not advance_payment:
                return Response({
                    'detail': 'Awaiting verification by Account Manager. Please check back later.'
                }, status=status.HTTP_400_BAD_REQUEST)
            
            advance_payment.amount = advance_amount
            advance_payment.save()

            # Create Razorpay Order
            client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
            razorpay_order = client.order.create({
                'amount': int(float(advance_payment.amount) * 100),  # Amount in paisa
                'currency': 'INR',
                'receipt': str(advance_payment.id),
                'payment_capture': '1',
            })

            # Save Razorpay order ID
            brand_owner_payment_info = get_brand_owner_payment_info(order)
            advance_payment.razorpay_order_id = razorpay_order['id']
            advance_payment.save()

            # Return payment details
            data = {
                'razorpay_order_id': razorpay_order['id'],
                'razorpay_key_id': settings.RAZORPAY_KEY_ID,
                'amount': advance_payment.amount,
                'currency': 'INR',
                'order_id': order.order_id,
                'payment_layer_id': advance_payment.id,
                'layer_type': advance_payment.layer_type,
                'expiry_date': advance_payment.expiry_date,
            }
            return Response(data)

        # If neither Account Manager nor Brand Owner
        return Response({'detail': 'Unauthorized'}, status=status.HTTP_403_FORBIDDEN)


class InitiateFinalPaymentAPIView(APIView):
    permission_classes = [IsAccountManager |  IsBrandOwner]

    def post(self, request):
        order_id = request.data.get('order_id')
        case_id = request.data.get('case_id')

        # Fetch Order
        order = get_object_or_404(Order, order_id=order_id)
        case = get_object_or_404(Case, id=case_id)
        amounts = calculate_payment_amounts(case, formulas=custom_formulas)

        # Calculate remaining amount
        final_amount = amounts['final_amount']
        brand_owner_payment_info = get_brand_owner_payment_info(order)

        # Create Final PaymentLayer
        final_payment = PaymentLayer.objects.create(
            order=order,
            amount=final_amount,
            layer_type='FINAL',
            expiry_date=timezone.now() + timedelta(days=5),  # Final payment expiry
            brandownerpaymentinfo=brand_owner_payment_info

        )

        # Create Razorpay Order
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        razorpay_order = client.order.create({
            'amount': int(float(final_amount) * 100),  # Amount in paisa
            'currency': 'INR',
            'receipt': str(final_payment.id),
            'payment_capture': '1',
        })

        # Save Razorpay order ID
        final_payment.razorpay_order_id = razorpay_order['id']
        final_payment.save()

        # Return payment details
        data = {
            'razorpay_order_id': razorpay_order['id'],
            'razorpay_key_id': settings.RAZORPAY_KEY_ID,
            'amount': final_amount,
            'currency': 'INR',
            'order_id': order.order_id,
            'payment_layer_id': final_payment.id,
            'layer_type': 'FINAL',
            'expiry_date': final_payment.expiry_date,
        }
        return Response(data)


class InitiateExtraPaymentAPIView(APIView):
    permission_classes = [IsAccountManager]

    def post(self, request):
        order_id = request.data.get('order_id')
        extra_amount = request.data.get('extra_amount')

        if not extra_amount:
            return Response({'error': 'Extra amount is required.'}, status=400)

        # Fetch Order
        order = get_object_or_404(Order, order_id=order_id)

        # Create Extra PaymentLayer
        extra_payment = PaymentLayer.objects.create(
            order=order,
            amount=float(extra_amount),
            layer_type='EXTRA',
            expiry_date=timezone.now() + timedelta(days=5),
        )

        # Create Razorpay Order
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        razorpay_order = client.order.create({
            'amount': int(float(extra_amount) * 100),  # Amount in paisa
            'currency': 'INR',
            'receipt': str(extra_payment.id),
            'payment_capture': '1',
        })

        # Save Razorpay order ID
        extra_payment.razorpay_order_id = razorpay_order['id']
        extra_payment.save()

        # Return payment details
        data = {
            'razorpay_order_id': razorpay_order['id'],
            'razorpay_key_id': settings.RAZORPAY_KEY_ID,
            'amount': extra_amount,
            'currency': 'INR',
            'order_id': order.order_id,
            'payment_layer_id': extra_payment.id,
            'layer_type': 'EXTRA',
            'expiry_date': extra_payment.expiry_date,
        }
        return Response(data)


from django.db.models import Sum

class OrderStatusAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, case_id):
        try:
            # Attempt to retrieve the latest order for the case
            order = Order.objects.filter(case__id=case_id).latest('created_at')

            # Recalculate amounts based on the current features and payments
            case = order.case
            user_features = UserFeature.objects.filter(case_id=case_id)

            # Recalculate total amounts
            amounts = calculate_payment_amounts(case, formulas=custom_formulas)

            # Calculate the total amount paid so far
            total_paid = PaymentLayer.objects.filter(order=order, status='PAID').aggregate(
                total_paid=Sum('amount')
            )['total_paid'] or 0

            # Update the order's total_amount and amount_due
            order.total_amount = amounts['total_amount']
            order.amount_due = amounts['total_amount'] - total_paid
            order.save()

            # Serialize and return the updated order data
            serializer = OrderSerializer(order)
            return Response(serializer.data)

        except Order.DoesNotExist:
            # Create a new order if none exist for the given case
            case = get_object_or_404(Case, id=case_id)
            user_features = UserFeature.objects.filter(case_id=case_id)

            # Define a unique order ID and expiry date
            order_id = 'order_' + str(int(timezone.now().timestamp()))
            expiry_date = timezone.now() + timedelta(days=5)

            # Calculate total amount from features
            amounts = calculate_payment_amounts(case, formulas=custom_formulas)

            # Create a new order
            order = Order.objects.create(
                case=case,
                order_id=order_id,
                total_amount=amounts['total_amount'],
                amount_due=amounts['total_amount'],
                expiry_date=expiry_date,
            )
            order.features.set(user_features)
            order.save()

            serializer = OrderSerializer(order)
            return Response(serializer.data)

        

class PaymentLayerStateMachine:
    def __init__(self, order):
        self.order = order

    def can_initiate_advance(self):
        return True

    def can_initiate_final(self):
        return self.order.payment_layers.filter(layer_type='ADVANCE', status='PAID').exists()

    def can_request_extra(self):
        return self.order.status == 'PARTIALLY_PAID' or self.order.status == 'PAID'


class DeletePendingTransactionView(APIView):
    def delete(self, request, order_id):
        try:
            # Delete pending transactions excluding the 'FINAL' PaymentLayer
            ifFinalLayerPendingExists = PaymentLayer.objects.filter(
                order__order_id=order_id,
                status='PENDING',
                layer_type = 'FINAL'
            ).exists()
            

            deleted_count, _ = PaymentLayer.objects.filter(
                order__order_id=order_id,
                status='PENDING'
            ).exclude(layer_type='ADVANCE').delete()


            
            order_o = get_object_or_404(Order, order_id=order_id)
            case = order_o.case
            total_amounts = calculate_payment_amounts(case, formulas=custom_formulas)
            final_payment = total_amounts['final_amount']
                
            already_paid_final = PaymentLayer.objects.filter(
                order=order_o, layer_type='FINAL', status='PAID'
            ).exists()

            if ifFinalLayerPendingExists and not already_paid_final:
                PaymentLayer.objects.create(
                    order=order_o,
                    layer_type='FINAL',
                    amount=final_payment,
                    status='PENDING',
                    expiry_date=timezone.now() + timedelta(days=30)
                )

            
            if deleted_count > 0:
                return Response({"status": "Deleted pending transactions"}, status=status.HTTP_204_NO_CONTENT)
            else:
                return Response({"status": "No pending transactions found"}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class IsFeatureRemovableAPIView(APIView):
    permission_classes = [IsBrandOwner]

    def get(self, request, feature_name):
        if feature_name == "manufacturing":
            feature1 = get_object_or_404(Feature, name = "Manufacturing Cost")
            case_id = request.query_params.get('case_id')
            case = get_object_or_404(Case, id = case_id)
            user_feature = get_object_or_404(UserFeature, feature =  feature1, user=request.user, case = case)
            is_removable = user_feature.removable
            return Response({'is_removable': is_removable}) 


class FeaturePaidForAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, case_id, feature_id):
        # Fetch the case and feature objects
        case = get_object_or_404(Case, id=case_id)
        feature = get_object_or_404(Feature, id= feature_id)
        user_feature = get_object_or_404(UserFeature, user=request.user, case = case,  feature=feature)

        if not user_feature:
            return Response({'feature_available': False, 'message': 'Feature is not available due to completed payment.'})

        # Check if a payment layer of type 'ADVANCE' or 'FINAL' exists for this case and is marked as 'PAID'
        advance_paid = PaymentLayer.objects.filter(order__case=case, layer_type='ADVANCE', status='PAID').exists()
        final_paid = PaymentLayer.objects.filter(order__case=case, layer_type='FINAL', status='PAID').exists()

        # Check if the feature is available based on payment status
        if advance_paid or final_paid:
            return Response({'feature_available': True, 'message': 'Feature is available due to completed payment.'})
        else:
            return Response({'feature_available': False, 'message': 'Feature is not available. Payment not completed.'}, status=status.HTTP_400_BAD_REQUEST)
# brand_owner_payment_info/views.py

class BrandOwnerPaymentInfoViewSet(viewsets.ModelViewSet):
    queryset = BrandOwnerPaymentInfo.objects.all()
    serializer_class = BrandOwnerPaymentInfoSerializer
    permission_classes = [IsBrandOwner]

    def get_queryset(self):
        """
        Only return PaymentInfo belonging to the current user's BrandOwner.
        """
        qs = super().get_queryset()
        brand_owner = BrandOwner.objects.get(user=self.request.user)
        return qs.filter(brand_owner=brand_owner)

    def perform_create(self, serializer):
        """
        Attach brand_owner, brand, addresses on create. 
        The serializer's create() method calls update_or_create already.
        """
        brand_owner = BrandOwner.objects.get(user=self.request.user)
        brand_id = self.request.data.get("brand")
        billing_address_id = self.request.data.get("billing_address")
        shipping_address_id = self.request.data.get("shipping_address")

        # Validate brand
        brand = None
        if brand_id:
            brand = Brand.objects.filter(
                id=brand_id
                # If your Brand model has a foreign key to BrandOwner, filter by that as well
            ).first()

        # Validate billing address
        billing_address = None
        if billing_address_id:
            billing_address = Address.objects.filter(
                id=billing_address_id, 
                brand_owner=brand_owner
            ).first()
            if not billing_address:
                raise ValueError("Invalid billing address selected.")

        # Validate shipping address
        shipping_address = None
        if shipping_address_id:
            shipping_address = Address.objects.filter(
                id=shipping_address_id, 
                brand_owner=brand_owner
            ).first()
            if not shipping_address:
                raise ValueError("Invalid shipping address selected.")

        # Now call serializer.save(...) which triggers the create(...) in the serializer
        instance = serializer.save(
            brand_owner=brand_owner,
            brand=brand,
            billing_address=billing_address,
            shipping_address=shipping_address
        )

        # Optionally auto-fill GST number from brand
        if brand and brand.gst_number:
            instance.gst_number = brand.gst_number
            instance.save()

    def perform_update(self, serializer):
        """
        If you're still using PUT/PATCH, keep the brand/address logic here.
        """
        brand_owner = BrandOwner.objects.get(user=self.request.user)
        brand_id = self.request.data.get("brand")
        billing_address_id = self.request.data.get("billing_address")
        shipping_address_id = self.request.data.get("shipping_address")

        brand = None
        if brand_id:
            brand = Brand.objects.filter(id=brand_id).first()

        billing_address = None
        if billing_address_id:
            billing_address = Address.objects.filter(
                id=billing_address_id, 
                brand_owner=brand_owner
            ).first()
            if not billing_address:
                raise ValueError("Invalid billing address selected.")

        shipping_address = None
        if shipping_address_id:
            shipping_address = Address.objects.filter(
                id=shipping_address_id, 
                brand_owner=brand_owner
            ).first()
            if not shipping_address:
                raise ValueError("Invalid shipping address selected.")

        instance = serializer.save(
            brand_owner=brand_owner,
            brand=brand,
            billing_address=billing_address,
            shipping_address=shipping_address
        )

        if brand and brand.gst_number:
            instance.gst_number = brand.gst_number
            instance.save()


class InitiateSamplePaymentAPIView(APIView):
    permission_classes = [IsAuthenticated, IsBrandOwner]  # Adjust permissions as needed

    def post(self, request):
        case_id = request.data.get('case_id')
        bid_ids = request.data.get('bid_ids', [])
        address_id = request.data.get('address_id')

        if not all([case_id, bid_ids, address_id]):
            return Response({'error': 'case_id, bid_ids, and address_id are required.'}, status=status.HTTP_400_BAD_REQUEST)

        # Validate and fetch case, bids, and address
        case = get_object_or_404(Case, id=case_id, brand_owner=request.user.brandowner)
        bids = Bid.objects.filter(id__in=bid_ids, case=case)

        if not bids.exists():
            return Response({'error': 'No valid bids found for these IDs.'}, status=status.HTTP_400_BAD_REQUEST)

        # Calculate total sample cost
        total_amount = sum([float(b.quote_bo) for b in bids])

        # Create or get existing order for this case if not existing
        order, created = Order.objects.get_or_create(
            case=case,
            defaults={
                'order_id': 'order_' + str(int(timezone.now().timestamp())),
                'total_amount': total_amount,
                'amount_due': total_amount,
                'expiry_date': timezone.now() + timedelta(days=5),
            }
        )
        if created:
            order.save()

        # Create PaymentLayer for SAMPLE
        sample_payment = PaymentLayer.objects.create(
            order=order,
            amount=Decimal(str(total_amount)),
            layer_type='SAMPLE',
            status='PENDING',
            created_at=timezone.now(),
            expiry_date=timezone.now() + timedelta(minutes=30),
            notes={
                'bid_ids': bid_ids,
                'address_id': address_id
            }
        )

        # Create Razorpay Order
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        razorpay_order = client.order.create({
            'amount': int(total_amount * 100),  # Amount in paisa
            'currency': 'INR',
            'receipt': str(sample_payment.id),
            'payment_capture': '1',
        })

        # Save Razorpay order ID
        sample_payment.razorpay_order_id = razorpay_order['id']
        sample_payment.save()

        # Return payment details to frontend
        data = {
            'razorpay_order_id': razorpay_order['id'],
            'razorpay_key_id': settings.RAZORPAY_KEY_ID,
            'amount': total_amount,
            'currency': 'INR',
            'order_id': order.order_id,
            'payment_layer_id': sample_payment.id,
            'layer_type': 'SAMPLE',
            'expiry_date': sample_payment.expiry_date,
        }

        return Response(data, status=status.HTTP_201_CREATED)
class FactoryOwnerSampleOrdersAPIView(APIView):

        permission_classes = [IsAuthenticated]

        def get(self, request, *args, **kwargs):
            bid_id = request.query_params.get('bidId')
            if not bid_id:
                # If there's no bidId in the query params, you can decide how to handle it:
                # Return an empty response, or a 400 Bad Request, etc.
                return Response(
                    {"detail": "bidId query parameter is required."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Filter SampleOrders that have this bid in their M2M field
            sample_orders = SampleOrder.objects.filter(bids__id=bid_id)

            serializer = SampleOrderSerializerBidView(sample_orders, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
