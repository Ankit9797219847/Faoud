# orders/urls.py

from django.urls import include, path
from .views import (
    AddFeatureAPIView,
    BrandOwnerPaymentInfoViewSet,
    BrandOwnerTransactionsAPIView,
    CaseOrdersAPIView,
    ChargeViewSet,
    DeactivateFeatureAPIView,
    DeletePendingTransactionView,
    EditUserFeaturePriceView,
    FactoryOwnerSampleOrdersAPIView,
    FeaturePaidForAPIView,
    FeatureViewSet,
    InitiateExtraPaymentAPIView,
    InitiateFinalPaymentAPIView,
    InitiateSamplePaymentAPIView,
    InvoiceAPIView,
    IsFeatureRemovableAPIView,
    RemoveFeatureAPIView,
    RequestRemovalFeatureAPIView,
    SetFeatureNonRemovableView,
    ToggleUserFeatureActiveView,
    UserFeatureListView,
    UserFeatureViewSet,
    VerifyPaymentAPIView,
    PaymentWebhookAPIView,
    OrderStatusAPIView,
    InitiateTokenPaymentAPIView,        # Added new view imports
    InitiateAdvancePaymentAPIView,
)
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r'features', FeatureViewSet, basename='feature')
# router.register(r'user-features', UserFeatureViewSet, basename='user-features')
router.register(r'charges', ChargeViewSet, basename='charge')


router.register(r'brand-owner-payment-info', BrandOwnerPaymentInfoViewSet, basename='brand-owner-payment-info')

urlpatterns = [
    path('', include(router.urls)),
    
    # Existing Payment and Order URLs
    path('verify-payment/', VerifyPaymentAPIView.as_view(), name='verify_payment'),
    path('payment-webhook/', PaymentWebhookAPIView.as_view(), name='payment_webhook'),
    path('order-status/<str:case_id>/', OrderStatusAPIView.as_view(), name='order_status'),
    path('case-orders/<str:case_id>/', CaseOrdersAPIView.as_view(), name='case_orders'),
    path('brandowner-transactions/', BrandOwnerTransactionsAPIView.as_view(), name='brandowner_transactions'),
    path('invoice/<str:order_id>/', InvoiceAPIView.as_view(), name='invoice'),
    
    # Feature Management URLs
    path('user-features/add-feature/', AddFeatureAPIView.as_view(), name='add_feature'),
    path('user-features/remove-feature/', RemoveFeatureAPIView.as_view(), name='remove_feature'),
    path('user-features/deactivate/<int:pk>/', DeactivateFeatureAPIView.as_view(), name='deactivate_feature'),
    path('user-features/request-removal/<int:pk>/', RequestRemovalFeatureAPIView.as_view(), name='request_removal_feature'),
    path('user-features/<str:case_id>/', UserFeatureListView.as_view(), name='user_feature_list'),
    path('toggle-feature-active/<int:user_feature_id>/', ToggleUserFeatureActiveView.as_view(), name='toggle_user_feature_active'),
    path('edit-feature-price/<int:user_feature_id>/', EditUserFeaturePriceView.as_view(), name='edit_user_feature_price'),
    path('set-feature-non-removable/<int:case_id>/', SetFeatureNonRemovableView.as_view(), name='set_feature_non_removable'),
    
    # New Layered Payment APIs
    path('payments/initiate-token-payment/', InitiateTokenPaymentAPIView.as_view(), name='initiate_token_payment'),
    path('transactions/<str:order_id>/delete-pending/', DeletePendingTransactionView.as_view(), name='delete_pending_transaction'),
    path('payments/initiate-advance-payment/', InitiateAdvancePaymentAPIView.as_view(), name='initiate_advance_payment'),
    path('payments/initiate-final-payment/', InitiateFinalPaymentAPIView.as_view(), name='initiate_final_payment'),
    path('payments/initiate-extra-payment/', InitiateExtraPaymentAPIView.as_view(), name='initiate_extra_payment'),
    path('factory-owner/sample-orders/', FactoryOwnerSampleOrdersAPIView.as_view(), name='factory-owner-sample-orders'),
    
 
    path('payments/initiate-sample-payment/', InitiateSamplePaymentAPIView.as_view(), name='initiate-sample-payment'),

    # Additional Order Status URL (if needed)
    path('orders/case/<int:case_id>/', OrderStatusAPIView.as_view(), name='order_status_case'),

    path('features/<str:feature_name>/is_removable/', IsFeatureRemovableAPIView.as_view(), name='is_feature_removable'),
    path('api/featurepaidfor/<int:case_id>/<int:feature_id>/', FeaturePaidForAPIView.as_view(), name='feature-paid-for'),
]
