from datetime import timedelta
from decimal import Decimal
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.shortcuts import get_object_or_404
from django.utils import timezone  # Correct import

from django.core.files.base import ContentFile

from case.models import ProgressStage, Stage
from materials.models import BillOfMaterials
from notifications.notif import send_notification
from payments.utils import calculate_payment_amounts
from payments.models import PaymentLayer
from supply.models import Bid
from supply.views import bindingCasewithFactory
from tracking.models import FDA, PM, RM, Artwork, Manufacturing
from utils.models import Address, Dispatch, Document
from .models import BrandOwnerPaymentInfo, Case, Feature, Order, SampleOrder, UserFeature

import threading
from functools import wraps

_signal_lock = threading.local()

def prevent_recursion(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if getattr(_signal_lock, 'flag', False):
            return
        _signal_lock.flag = True
        try:
            return func(*args, **kwargs)
        finally:
            _signal_lock.flag = False
    return wrapper

# Custom formulas for payment calculations
custom_formulas = {
    'advance': lambda total, prev_amounts: (total - prev_amounts['token_amount']) * Decimal('0.5'),
    'final': lambda total, prev_amounts: total - sum(prev_amounts.values()),
}

# Signal to create user features when a Case is created
@receiver(post_save, sender=Case)
def create_user_features(sender, instance, created, **kwargs):
    if created:
        features = Feature.objects.all()
        for feature in features:
            # Activate "Faoud Platform" and make it non-removable
            if feature.name == "Faoud Recommened":
                UserFeature.objects.create(
                    user=instance.brand_owner.user,
                    case=instance,
                    feature=feature,
                    description=feature.description,
                    is_active=True,
                    removable=False,
                    price=feature.price if feature.price > 0 else 0
                )

            # If category is 'npd_without', activate "Formulation Included" and make it non-removable
            if feature.name == "Formulation Included" and instance.category == 'npd_without':
                UserFeature.objects.create(
                    user=instance.brand_owner.user,
                    case=instance,
                    feature=feature,
                    description=feature.description,
                    is_active=True,
                    removable=False,
                    price=feature.price if feature.price > 0 else 0
                )

# Signal to handle factory selection changes
@receiver(post_save, sender=Case)
def handle_factory_selection(sender, instance, **kwargs):
    """
    Signal fired BEFORE saving the Case.
    Checks if the factory field has changed from None -> Some Factory.
    If yes, create an ADVANCE PaymentLayer automatically.
    """
    if instance.pk:  # Means the Case already exists in DB
        previous_instance = Case.objects.get(pk=instance.pk)

        # Has the factory changed from None to a specific factory?
        if instance.factory:
            # -- Your existing "Manufacturing Cost" feature logic here --
            try:
                manufacturing_feature = Feature.objects.get(name="Manufacturing Cost")
                user_feature, created = UserFeature.objects.get_or_create(
                    user=instance.brand_owner.user,
                    case=instance,
                    feature=manufacturing_feature,
                    defaults={
                        'description': manufacturing_feature.description,
                        'is_active': True,
                        'removable': True,
                        'price': instance.bidSelected.quote_bo ,
                        'quantity' : instance.quantity
                    }
                )
                # ... similarly for RM Procurement, PM Procurement, etc.
                # (Keeping your existing logic as-is.)
                rm_feature = Feature.objects.get(name="RM Procurement")
                rm_feature_user, created = UserFeature.objects.get_or_create(
                        user=instance.brand_owner.user,
                        case=instance,
                        feature=rm_feature,
                        defaults={
                            'description': rm_feature.description,
                            'is_active': False,
                            'removable': True,
                            'price': rm_feature.price
                        }
                    )
                fda_feature = Feature.objects.get(name="FDA Approval")
                fda_feature, created = UserFeature.objects.get_or_create(
                        user=instance.brand_owner.user,
                        case=instance,
                        feature=fda_feature,
                        defaults={
                            'description': fda_feature.description,
                            'is_active': False,
                            'removable': True,
                            'price': fda_feature.price
                        }
                    )
                
                art_work_feature = Feature.objects.get(name="Artwork Creation")
                art_work_feature, created = UserFeature.objects.get_or_create(
                        user=instance.brand_owner.user,
                        case=instance,
                        feature=art_work_feature,
                        defaults={
                            'description': art_work_feature.description,
                            'is_active': False,
                            'removable': True,
                            'price': art_work_feature.price
                        }
                    )
                pm_feature = Feature.objects.get(name="PM Procurement")
                pm_feature_user, created = UserFeature.objects.get_or_create(
                        user=instance.brand_owner.user,
                        case=instance,
                        feature=pm_feature,
                        defaults={
                            'description': pm_feature.description,
                            'is_active': False,
                            'removable': True,
                            'price': pm_feature.price
                        }
                    )
                if not created:
                        pm_feature_user.price = pm_feature.price
                        rm_feature_user.price = rm_feature.price
                        user_feature.is_active = True
                        user_feature.removable = True
                        user_feature.price = instance.bidSelected.quote_bo 
                        user_feature.quantity = instance.quantity   
                        user_feature.save()
                        pm_feature_user.save()
                        rm_feature_user.save()
                        fda_feature.save()
                        art_work_feature.save()

            except Feature.DoesNotExist:
                pass


            #
            # -------- Create or Update an Order, then create ADVANCE PaymentLayer --------
            #
            # Calculate amounts with your custom formulas
            from payments.views import custom_formulas  # or wherever custom_formulas is defined
            amounts = calculate_payment_amounts(instance, formulas=custom_formulas)
            advance_amount = amounts.get('advance_amount', Decimal('0.00'))
            total_amount = amounts.get('total_amount', Decimal('0.00'))

            # Get or create an Order for this Case
            order, created_order = Order.objects.get_or_create(
                case=instance,
                defaults={
                    'order_id': 'order_' + str(int(timezone.now().timestamp())),
                    'total_amount': total_amount,
                    'amount_due': total_amount,
                    'expiry_date': timezone.now() + timedelta(days=5),
                }
            )
            if not created_order:
                # If the order already existed, we may want to update total_amount/amount_due
                order.total_amount = total_amount
                # If you want to recalc how much is still due, subtract any paid layers:
                order.amount_due = total_amount
                order.save()

            # Associate the user features with the order
            user_features = UserFeature.objects.filter(case=instance)
            order.features.set(user_features)
            order.save()

            # Check if an ADVANCE PaymentLayer already exists (e.g., skip creation if it does)
            advance_exists = PaymentLayer.objects.filter(
                order=order,
                layer_type='ADVANCE',
                status__in=['PENDING', 'PAID']
            ).exists()

            if not advance_exists:
                PaymentLayer.objects.create(
                    order=order,
                    amount=advance_amount,
                    layer_type='ADVANCE',
                    status='PENDING',
                    expiry_date=timezone.now() + timedelta(days=7),
                )

# Signal on any UserFeature update to update the advance payment layer if already created, and delete if manufacturing feature is deactivated@receiver(post_save, sender=UserFeature)
@receiver(post_save, sender=UserFeature)
@prevent_recursion
def update_existing_advance_layer(sender, instance, **kwargs):
    """
    Updates ADVANCE PaymentLayer ONLY if it exists and Manufacturing Cost changes.
    Does NOT create a new layer.
    """
    try:
        if instance.feature.name == "Manufacturing Cost":
            case = instance.case
            order = Order.objects.filter(case=case).first()
            
            if order:
                # Check for existing ADVANCE layer
                advance_layer = PaymentLayer.objects.filter(
                    order=order,
                    layer_type='ADVANCE'
                ).first()
                
                if advance_layer:
                    # Recalculate advance amount based on updated Manufacturing Cost
                    amounts = calculate_payment_amounts(case, formulas=custom_formulas)
                    advance_amount = amounts.get('advance_amount', Decimal('0.00'))
                    
                    # Update existing layer
                    advance_layer.amount = advance_amount
                    advance_layer.expiry_date = timezone.now() + timedelta(days=7)
                    advance_layer.save()

    except Exception as e:
        # Handle exceptions appropriately (e.g., log the error)
        print(f"Error in update_advance_payment_layer: {e}")





# Signal to handle deactivation of manufacturing feature
@receiver(post_save, sender=UserFeature)
def handle_manufacturing_feature_deactivation(sender, instance, **kwargs):
    if instance.feature.name == "Manufacturing Cost" and not instance.is_active:
        case = instance.case
        # Deselect the factory
        case.factory = None
        case.bidSelected = None
        instance.delete()
        # Avoid triggering signals again
        case.save(update_fields=['factory', 'bidSelected'])

        # if the manufacturing feature is deactivated, delete the advance payment layer
        order = Order.objects.filter(case=case).first()
        advance_payment_layer = PaymentLayer.objects.filter(
            order=order,
            layer_type='ADVANCE'
        ).first()
        if advance_payment_layer:
            advance_payment_layer.delete()
        


        try:
            orders_stage = Stage.objects.get(name="Orders")
            orders_progress = ProgressStage.objects.filter(case=case, stage=orders_stage).first()
            if orders_progress:
                # Option A: Delete it entirely
                orders_progress.delete()

        except Stage.DoesNotExist:
            pass

        try : 
            tracking_stage = Stage.objects.get(name="Tracking")
            tracking_progress = ProgressStage.objects.filter(case=case, stage=tracking_stage).first()
            if tracking_progress:
                tracking_progress.delete()
        except Stage.DoesNotExist:
            pass


        # 3) Grey-out or un-grey certain Dashboards based on purchased features
        #



# Signal to handle advance payment
@receiver(post_save, sender=PaymentLayer)
def handle_advance_payment(sender, instance, created, **kwargs):
    if instance.status == 'PAID' and instance.layer_type == 'ADVANCE':
        case = instance.order.case
        bindingCasewithFactory(case.id)
        # 1) Make all UserFeatures non-removable for this case and user
        UserFeature.objects.filter(
            user=case.brand_owner.user,
            case=case
        ).update(removable=False)

        # 2) Mark the "Order" stage as completed
        try:
            order_stage = Stage.objects.get(name="Orders")
            tracking_stage = Stage.objects.get(name="Tracking")
        except Stage.DoesNotExist:
            order_stage = None
            tracking_stage = None

        if order_stage:
            progress_stage, _ = ProgressStage.objects.get_or_create(
                case=case,
                stage=order_stage,
                defaults={
                    'order_in_timeline': order_stage.order,
                    'completion_date': timezone.now().date(),
                }
            )
            track_stage_obj, _ = ProgressStage.objects.get_or_create(
                case=case,
                stage=tracking_stage,
                defaults={
                    'order_in_timeline': tracking_stage.order,
                }
            )
            if not progress_stage.completion_date:
                progress_stage.completion_date = timezone.now().date()
                progress_stage.save()
                track_stage_obj.save()

        # 3) Grey-out or un-grey certain Dashboards based on purchased features
        #
        # --- (A) RM ---
        try:
            rm_feature = Feature.objects.get(name="RM Procurement")
            rm_user_feature = UserFeature.objects.filter(
                user=case.brand_owner.user,
                case=case,
                feature=rm_feature
            ).first()

            # Ensure at least one RM object exists for this Case.
            if not RM.objects.filter(case=case).exists():
                RM.objects.create(case=case, status='not_started')

            # When advance payment is made, days feild of manufacturing needs to be updated with current day - the case.bidSelected.eta
            bid_selected = case.bidSelected
            if bid_selected:
                eta_date = bid_selected.eta
                manufacturing, created = Manufacturing.objects.get_or_create(case=case)
                manufacturing.start_date = timezone.now().date()
                manufacturing.eta_date = eta_date
                manufacturing.save()


            # Update greyout based on feature activity
            if rm_user_feature and rm_user_feature.is_active:
                RM.objects.filter(case=case).update(greyout=False)
            else:
                RM.objects.filter(case=case).update(greyout=True)

        except Feature.DoesNotExist:
            # If the feature doesn't exist, ensure the RM object is created but grey it out
            if not RM.objects.filter(case=case).exists():
                RM.objects.create(case=case, status='not_started')
            RM.objects.filter(case=case).update(greyout=True)

        # --- (A) PM ---
        try:
            pm_feature = Feature.objects.get(name="PM Procurement")
            pm_user_feature = UserFeature.objects.filter(
                user=case.brand_owner.user,
                case=case,
                feature=pm_feature
            ).first()

            if not PM.objects.filter(case=case).exists():
                PM.objects.create(case=case, status='not_started')

            if pm_user_feature and pm_user_feature.is_active:
                PM.objects.filter(case=case).update(greyout=False)
            else:
                PM.objects.filter(case=case).update(greyout=True)

        except Feature.DoesNotExist:
            if not PM.objects.filter(case=case).exists():
                PM.objects.create(case=case, status='not_started')
            PM.objects.filter(case=case).update(greyout=True)

        # --- (A) FDA ---
        try:
            fda_feature = Feature.objects.get(name="FDA Approval")
            fda_user_feature = UserFeature.objects.filter(
                user=case.brand_owner.user,
                case=case,
                feature=fda_feature
            ).first()

            if not FDA.objects.filter(case=case).exists():
                FDA.objects.create(case=case, status='not_started')

            if fda_user_feature and fda_user_feature.is_active:
                FDA.objects.filter(case=case).update(greyout=False)
            else:
                FDA.objects.filter(case=case).update(greyout=True)

        except Feature.DoesNotExist:
            if not FDA.objects.filter(case=case).exists():
                FDA.objects.create(case=case, status='not_started')
            FDA.objects.filter(case=case).update(greyout=True)

        # --- (A) Artwork ---
        try:
            artwork_feature = Feature.objects.get(name="Artwork Creation")
            artwork_user_feature = UserFeature.objects.filter(
                user=case.brand_owner.user,
                case=case,
                feature=artwork_feature
            ).first()

            if not Artwork.objects.filter(case=case).exists():
                Artwork.objects.create(case=case)

            if artwork_user_feature and artwork_user_feature.is_active:
                Artwork.objects.filter(case=case).update(greyout=False)
            else:
                Artwork.objects.filter(case=case).update(greyout=True)

        except Feature.DoesNotExist:
            if not Artwork.objects.filter(case=case).exists():
                Artwork.objects.create(case=case)
            Artwork.objects.filter(case=case).update(greyout=True)


# Signal to add a non-removable feature when BOM is updated
@receiver(post_save, sender=BillOfMaterials)
def add_non_removable_feature_on_bom_update(sender, instance, created, **kwargs):
    """
    Signal to automatically add a non-removable feature to UserFeature whenever
    a Bill of Materials (BOM) instance is created or updated.
    """
    # Retrieve the brand owner associated with the product in BOM
    brand_owner_user = instance.brand_owner.user

    try:
        # Retrieve or create the non-removable feature (e.g., "BOM Charges")
        feature = Feature.objects.get(name="BOM Charges")

        # Create or update the UserFeature with removable=False
        user_feature, created = UserFeature.objects.get_or_create(
            user=brand_owner_user,
            case=instance.product.cases.first(),  # Assumes BOM is tied to a specific case through product
            feature=feature,
            defaults={
                'description': feature.description,
                'is_active': True,
                'removable': False,  # Ensure this feature is non-removable
                'price': instance.total_cost
            }
        )

        # If the feature already exists, ensure it is active and non-removable
        if not created:
            user_feature.is_active = True
            user_feature.removable = False
            user_feature.price = instance.total_cost
            user_feature.save()

    except Feature.DoesNotExist:
        # Handle missing feature case if necessary
        print("Feature 'BOM Charges' does not exist in the database.")

# Signal to add a document when a PaymentLayer is marked as PAID
@receiver(post_save, sender=PaymentLayer)
def add_po_document_on_payment(sender, instance, created, **kwargs):
    """
    Signal to add a document to the Case whenever a PaymentLayer is marked as PAID.
    """
    if instance.status == 'PAID':
        case = instance.order.case
        # Call the utility function to generate the appropriate document
        document_file, document_type = generate_document_by_type(instance)

        if document_file and document_type:
            # Create the Document instance
            Document.objects.create(
                case=case,
                document_type=document_type,
                file=document_file,
            )

# Utility function to generate documents based on payment layer type
from django.template.loader import render_to_string
from django.core.files.base import ContentFile
from weasyprint import HTML
from decimal import Decimal
from django.core.files.base import ContentFile
from django.template.loader import render_to_string



def generate_document_by_type(payment_layer,bid=None):
    """
    Generates a GST-compliant invoice PDF after payment based on the payment layer type.
    Returns a file object (ContentFile) and the document type.
    """
    from io import BytesIO
    from decimal import Decimal
    from django.template.loader import render_to_string
    from django.core.files.base import ContentFile
    from weasyprint import HTML
    
    # Document type mapping
    document_type_mapping = {
        'TOKEN': 'TOKEN_PO',  # After token payment, you might issue a proforma invoice
        'ADVANCE': 'ADVANCE_PO',
        'FINAL': 'FINAL_PO',
        'SAMPLE': 'SAMPLE_PO'      # After final payment, generate a final tax invoice
    }

    document_type = document_type_mapping.get(payment_layer.layer_type)
    if not document_type:
        return None, None

    order = payment_layer.order
    case = order.case
    product_name = case.product.name if case.product else "N/A"
    sku = case.product.sku_and_pm if case.product else "N/A"

    # -------------------------------------------------------
    # SELLER (Supplier) Details (GST requirement)
    # -------------------------------------------------------
    seller = {
        'name': "Faoud Pvt. Ltd.",  # Your legal entity name
        'address': "Turbhe Industrial, Navi Mumbai, Maharastra - 400076",  # Complete business address
        'gstin': "29AABCU9603R1ZP",  # Your GST Number
    }

    # -------------------------------------------------------
    # BUYER (Recipient) Details
    # -------------------------------------------------------
    brand_owner = case.brand_owner
    
    # If you are storing brand info in brand_owner.brands, pick the first or a specific brand
    first_brand = brand_owner.brands.first() if brand_owner.brands.exists() else None
    
    buyer = {
        'name': first_brand.legal_entity if first_brand and hasattr(first_brand, 'company_name') else "Template Company Name",
        'gstin': first_brand.gst_number if first_brand and first_brand.gst_number else None,
        'address': (first_brand.office_address 
                    if first_brand and first_brand.office_address 
                    else "Not provided"),
    }

    # -------------------------------------------------------
    # Fetch Payment Info for this brand_owner 
    # (assuming you only store one record per brand_owner, or you get the latest, etc.)
    # -------------------------------------------------------
    brand_owner_payment_info = BrandOwnerPaymentInfo.objects.filter(
        brand_owner=brand_owner
    ).first()

    # If present, we pick its addresses (otherwise fallback)
    if brand_owner_payment_info and brand_owner_payment_info.billing_address:
        # Convert your Address model instance into a string if needed:
        billing_address_obj = brand_owner_payment_info.billing_address
        billing_address = f"{billing_address_obj.street}, {billing_address_obj.city}, {billing_address_obj.country} - {billing_address_obj.zip_code}"
    else:
        # fallback logic if not found
        billing_address = buyer['address']   # or use order.billing_address

    if brand_owner_payment_info and brand_owner_payment_info.shipping_address:
        shipping_address_obj = brand_owner_payment_info.shipping_address
        shipping_address = f"{shipping_address_obj.street}, {shipping_address_obj.city}, {shipping_address_obj.country} - {shipping_address_obj.zip_code}"
    else:
        # fallback logic if not found
        shipping_address = buyer['address']  # or use order.shipping_address

    # -------------------------------------------------------
    # Invoice Serial Number & Date
    # -------------------------------------------------------
    invoice_number = f"{document_type}_{order.id}"
    if len(invoice_number) > 16:
        invoice_number = invoice_number[:16]

    invoice_date = payment_layer.created_at.strftime("%Y-%m-%d")

    # -------------------------------------------------------
    # Determine if IGST or CGST+SGST based on states
    # For simplicity, we assume seller/buyer are same state => no IGST
    # -------------------------------------------------------
    from decimal import Decimal
    seller_state = "Maharashtra"
    buyer_state = "Maharashtra"
    place_of_supply = buyer_state

    use_igst = (seller_state != buyer_state)
    cgst_rate = Decimal('9.0')
    sgst_rate = Decimal('9.0')
    igst_rate = Decimal('18.0')

    # -------------------------------------------------------
    # Gather line items from order
    # -------------------------------------------------------
    if document_type == 'SAMPLE_PO' and bid is not None:
        # Generate invoice for this single bid
        product_name = bid.case.product.name if bid.case and bid.case.product else 'Sample Product'
        cost = bid.quote_bo
        shipping_cost = 0  # Set to 0 or fetch actual if available
        total_amount = cost + shipping_cost

        invoice_number = f"{document_type}_Bid_{bid.id}"
        if len(invoice_number) > 16:
            invoice_number = invoice_number[:16]

        items = [{
            'product_name': product_name,
            'quantity': 1,
            'cost': cost,
            'shipping_cost': shipping_cost,
            'total': total_amount,
        }]

        context = {
            'document_type': document_type,
            'invoice_number': invoice_number,
            'invoice_date': invoice_date,
            'seller': seller,
            'buyer': buyer,
            'billing_address': billing_address,
            'shipping_address': shipping_address,
            'items': items,
            'product_name': product_name,
            'cost': cost,
            'shipping_cost': shipping_cost,
            'total_amount': total_amount,
        }

    else:
        user_features = order.features.all()
        items = []
        subtotal = Decimal('0.00')

        for uf in user_features:
            qty = uf.quantity
            price = uf.price
            line_total = price * qty
            hsn_code = '30049099'
            items.append({
                'description': uf.feature.name,
                'hsn': hsn_code,
                'quantity': qty,
                'unit_price': price,
                'line_total': line_total,
            })
            subtotal += line_total

        discount_amount = Decimal('0.00')
        taxable_amount = subtotal - discount_amount

        if use_igst:
            cgst_amount = Decimal('0.00')
            sgst_amount = Decimal('0.00')
            igst_amount = (taxable_amount * igst_rate / Decimal('100')).quantize(Decimal('0.01'))
            total_amount = taxable_amount + igst_amount
        else:
            igst_amount = Decimal('0.00')
            cgst_amount = (taxable_amount * cgst_rate / Decimal('100')).quantize(Decimal('0.01'))
            sgst_amount = (taxable_amount * sgst_rate / Decimal('100')).quantize(Decimal('0.01'))
            total_amount = taxable_amount + cgst_amount + sgst_amount

        reverse_charge = "No"

        context = {
            'document_type': document_type,
            'invoice_number': invoice_number,
            'invoice_date': invoice_date,
            'seller': seller,
            'buyer': buyer,
            'billing_address': billing_address,
            'shipping_address': shipping_address,
            'place_of_supply': place_of_supply,
            'items': items,
            'subtotal': subtotal,
            'discount_amount': discount_amount,
            'taxable_amount': taxable_amount,
            'cgst_rate': cgst_rate,
            'sgst_rate': sgst_rate,
            'igst_rate': igst_rate,
            'cgst_amount': cgst_amount,
            'sgst_amount': sgst_amount,
            'igst_amount': igst_amount,
            'total_amount': total_amount,
            'reverse_charge': reverse_charge,
            'product_name': product_name,
            'sku': sku,
            'authorized_signatory': "John Doe (Director)",
        }

    # -------------------------------------------------------
    # Pick Template
    # -------------------------------------------------------
    template_mapping = {
        'TAX_INVOICE': 'documents/tax_invoice.html',
        'PROFORMA_INVOICE': 'documents/proforma_invoice.html',
        'ADVANCE_INVOICE': 'documents/proforma_invoice.html',
        'SAMPLE_PO': 'documents/sample_invoice.html',
    }
    template_path = template_mapping.get(document_type, 'documents/tax_invoice.html')

    # Render PDF
    html_content = render_to_string(template_path, context)
    pdf_file = HTML(string=html_content).write_pdf()

    file_name = f"{document_type}_Case_{case.id}.pdf"
    document_file = ContentFile(pdf_file, name=file_name)

    return document_file, document_type


# Signal to add final payment layer when a Dispatch is created
@receiver(post_save, sender=Dispatch)
def add_final_payment_layer(sender, instance, created, **kwargs):
    if created:
        case = instance.case

        # Check if a final payment already exists for this case
        if not PaymentLayer.objects.filter(order__case=case, layer_type='FINAL').exists():
            try:
                # Calculate the remaining amount to be paid
                total_amounts = calculate_payment_amounts(case, formulas=custom_formulas)
                final_payment = total_amounts['final_amount']

                order_o = get_object_or_404(Order, case=case)

                if final_payment > 0:
                    # Create the final payment layer

                    final_payment_exists = PaymentLayer.objects.filter(
                        order=order_o,
                        layer_type='FINAL',
                        status__in=['PENDING', 'PAID']
                    ).exists()

                    if not final_payment_exists:
                        PaymentLayer.objects.create(
                            order=order_o,  # Assuming Case has an `order` relation
                            layer_type='FINAL',
                            amount=final_payment,
                            status='PENDING',  # Default status
                            expiry_date=timezone.now() + timedelta(days=30)
                        )
            except Exception as e:
                print(f"Error creating final PaymentLayer: {e}")

@receiver(post_save, sender=PaymentLayer)
def create_sample_order_on_payment(sender, instance, created, **kwargs):
    if not created:
        if instance.layer_type == 'SAMPLE' and instance.status == 'PAID':
            if not hasattr(instance, 'sample_order'):
                bid_ids = instance.notes.get('bid_ids', [])
                bids = Bid.objects.filter(id__in=bid_ids, case=instance.order.case)

                if not bids.exists():
                    return
                
                bids.update(status='SAMPLE_ORDERED')

                for bid in bids:
                    bid.sample_paid = True
                    bid.save()

                address_id = instance.notes.get('address_id')
                address = Address.objects.get(id=address_id) if address_id else None
                brand_owner = instance.order.case.brand_owner.user

                sample_order = SampleOrder.objects.create(
                    payment_layer=instance,
                    address=address,
                    brand_owner=brand_owner,
                    case=instance.order.case
                )
                sample_order.bids.set(bids)
                sample_order.calculate_total_amount()

                # ⬇️ Generate separate invoices for each bid
                for bid in bids:
                    document_file, document_type = generate_document_by_type(instance, bid=bid)
                    if document_file and document_type:
                        Document.objects.create(
                            case=instance.order.case,
                            document_type=document_type,
                            file=document_file,
                            bid_id=bid
                        )
