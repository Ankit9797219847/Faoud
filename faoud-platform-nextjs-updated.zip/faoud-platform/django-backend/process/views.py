from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .models import FacilityLine, MachineryFlow, SubcategoryParameter, Machinery
from .serializers import (
    FacilityLineSerializer,
    MachineryFlowSerializer,
    SubcategoryParameterSerializer,
    MachinerySerializer
)

# Create your views here.

class SubcategoryParameterListView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    def get(self, request, subcategory_id):
        params = SubcategoryParameter.objects.filter(subcategory_id=subcategory_id)
        serializer = SubcategoryParameterSerializer(params, many=True)
        return Response(serializer.data)

class FacilityLineView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk=None):
        if pk is not None:
            try:
                facility_line = FacilityLine.objects.get(pk=pk)
            except FacilityLine.DoesNotExist:
                return Response(status=status.HTTP_404_NOT_FOUND)
            serializer = FacilityLineSerializer(facility_line)
            return Response(serializer.data)

        # Optional filtering by factory and subcategory
        factory_id = request.query_params.get('factory')
        subcategory_id = request.query_params.get('subcategory')
        
        queryset = FacilityLine.objects.all()
        if factory_id:
            queryset = queryset.filter(factory_id=factory_id)
        if subcategory_id:
            queryset = queryset.filter(subcategories__id=subcategory_id)  # Correct filtering
        
        serializer = FacilityLineSerializer(queryset, many=True)
        return Response(serializer.data)



    def post(self, request):
        serializer = FacilityLineSerializer(data=request.data)
        if serializer.is_valid():
            instance = serializer.save()
            return Response(FacilityLineSerializer(instance).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def put(self, request, pk):
        try:
            facility_line = FacilityLine.objects.get(pk=pk)
        except FacilityLine.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = FacilityLineSerializer(facility_line, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class MachineryFlowView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk=None):
        if pk is not None:
            try:
                machinery_flow = MachineryFlow.objects.get(pk=pk)
            except MachineryFlow.DoesNotExist:
                return Response(status=status.HTTP_404_NOT_FOUND)
            serializer = MachineryFlowSerializer(machinery_flow)
            return Response(serializer.data)
        # Handle GET for list with optional filtering by facility_line
        facility_line_id = request.query_params.get('facility_line')
        queryset = MachineryFlow.objects.all()
        if facility_line_id is not None:
            queryset = queryset.filter(facility_line_id=facility_line_id)
        serializer = MachineryFlowSerializer(queryset, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = MachineryFlowSerializer(data=request.data)
        if serializer.is_valid():
            # Step 1: Save the new machinery flow
            new_flow = serializer.save()

            # Step 2: Fetch all existing flows (excluding the newly created one) for this facility line
            existing_flows = MachineryFlow.objects.filter(
                facility_line=new_flow.facility_line
            ).exclude(id=new_flow.id).order_by('id')  # Using 'id' as ordering criterion

            # Step 3: If there are existing flows, update the last one to link to the new one
            if existing_flows.exists():
                last_flow = existing_flows.last()
                last_flow.next_step = new_flow
                last_flow.save()

                new_flow.previous_step = last_flow
                new_flow.save()

            # No previous flows? This new flow's previous and next are already None by default
            return Response(MachineryFlowSerializer(new_flow).data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def delete(self, request, pk):
        try:
            flow = MachineryFlow.objects.get(pk=pk)
        except MachineryFlow.DoesNotExist:
            return Response({'error': 'Unit operation not found.'}, status=status.HTTP_404_NOT_FOUND)

        # Rewire previous and next flows if needed
        if flow.previous_step:
            flow.previous_step.next_step = flow.next_step
            flow.previous_step.save()
        if flow.next_step:
            flow.next_step.previous_step = flow.previous_step
            flow.next_step.save()

        flow.delete()
        return Response({'message': 'Deleted successfully'}, status=status.HTTP_204_NO_CONTENT)

    def put(self, request, pk):
        try:
            machinery_flow = MachineryFlow.objects.get(pk=pk)
        except MachineryFlow.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = MachineryFlowSerializer(machinery_flow, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class MachineryListView(APIView):
        permission_classes = [permissions.IsAuthenticated]

        def get(self, request):
            facility_line_id = request.query_params.get('facility_line')
            category_id = request.query_params.get('category')

            # If facility_line is provided
            if facility_line_id:
                try:
                    facility_line = FacilityLine.objects.get(pk=facility_line_id)
                except FacilityLine.DoesNotExist:
                    # If facility line not found, return all machinery
                    machinery = Machinery.objects.all()
                    serializer = MachinerySerializer(machinery, many=True)
                    return Response(serializer.data)

                # Get all subcategories in the facility line
                subcategories = facility_line.subcategories.all()
                # Get all unique categories from those subcategories
                category_ids = subcategories.values_list('category_id', flat=True).distinct()

                # Machinery already in the facility line (via MachineryFlow)
                machinery_in_line_ids = MachineryFlow.objects.filter(
                    facility_line=facility_line
                ).values_list('machinery_id', flat=True).distinct()

                # If category is also provided, show all machinery of that category + categories of facility line
                if category_id:
                    # Combine the provided category and the facility line's categories
                    combined_category_ids = set(category_ids)
                    combined_category_ids.add(int(category_id))
                    machinery_qs = Machinery.objects.filter(category_id__in=combined_category_ids)
                else:
                    # Machinery for all categories of subcategories in the facility line
                    machinery_qs = Machinery.objects.filter(category_id__in=category_ids)

                facility_line_machinery = machinery_qs.filter(id__in=machinery_in_line_ids)
                other_machinery = machinery_qs.exclude(id__in=machinery_in_line_ids)
                machinery = list(facility_line_machinery) + list(other_machinery)

                # If no machinery found, return all
                if not machinery:
                    machinery = Machinery.objects.all()

                serializer = MachinerySerializer(machinery, many=True)
                return Response(serializer.data)

            # If only category is provided
            if category_id:
                machinery = list(Machinery.objects.filter(category_id=category_id))
                # If no machinery found, return all
                if not machinery:
                    machinery = Machinery.objects.all()
                serializer = MachinerySerializer(machinery, many=True)
                return Response(serializer.data)

            # Default: return all machinery
            machinery = Machinery.objects.all()
            serializer = MachinerySerializer(machinery, many=True)
            return Response(serializer.data)
