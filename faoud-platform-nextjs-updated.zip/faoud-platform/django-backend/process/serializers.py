from rest_framework import serializers

from product.models import Subcategory
from .models import FacilityLine, Machinery, MachineryFlow, SubcategoryParameter

class FacilityLineSerializer(serializers.ModelSerializer):
    subcategories = serializers.PrimaryKeyRelatedField(
        many=True,
        queryset=Subcategory.objects.all()
    )
    subcategory_names = serializers.SerializerMethodField()

    class Meta:
        model = FacilityLine
        fields = ['id', 'factory', 'subcategories', 'parameters', 'subcategory_names', 'name']

    def get_subcategory_names(self, obj):
        return [sub.name for sub in obj.subcategories.all()]

    def create(self, validated_data):
        subcategories = validated_data.pop('subcategories', [])
        facility_line = FacilityLine.objects.create(**validated_data)

        # Set many-to-many field
        facility_line.subcategories.set(subcategories)

        # Merge parameters from all subcategories
        param_dict = {}
        for sub in subcategories:
            sub_params = SubcategoryParameter.objects.filter(subcategory=sub)
            for param in sub_params:
                param_dict[param.name] = param.default_value or ''

        facility_line.parameters = param_dict
        facility_line.save()

        return facility_line

    def update(self, instance, validated_data):
        subcategories = validated_data.pop('subcategories', None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        if subcategories is not None:
            instance.subcategories.set(subcategories)

        instance.save()
        return instance



class MachinerySerializer(serializers.ModelSerializer):
    class Meta:
        model = Machinery
        fields = '__all__'
class MachineryFlowSerializer(serializers.ModelSerializer):
    machinery = serializers.PrimaryKeyRelatedField(queryset=Machinery.objects.all())

    class Meta:
        model = MachineryFlow
        fields = '__all__'

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        # Replace machinery ID with nested dictionary for GET requests
        representation['machinery'] = MachinerySerializer(instance.machinery).data
        return representation

class SubcategoryParameterSerializer(serializers.ModelSerializer):
    class Meta:
        model = SubcategoryParameter
        fields = '__all__'

