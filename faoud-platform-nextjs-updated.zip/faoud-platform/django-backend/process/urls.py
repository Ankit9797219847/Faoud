from django.urls import path
from .views import SubcategoryParameterListView, FacilityLineView, MachineryFlowView, MachineryListView

urlpatterns = [
    path('subcategory/<int:subcategory_id>/parameters/', SubcategoryParameterListView.as_view()),
    path('facility-line/', FacilityLineView.as_view()),
    path('facility-line/<int:pk>/', FacilityLineView.as_view()),  # GET/PUT for detail
    path('machinery-flow/', MachineryFlowView.as_view()),
    path('machinery-flow/<int:pk>/', MachineryFlowView.as_view()),  # GET/PUT for detail
    path('machinery/', MachineryListView.as_view()),
]