from django.db import models

# Create your models here.

class SubcategoryParameter(models.Model):
    """
    Stores valid parameter names (and optional defaults/types) for a given Subcategory.
    Manage these in Django admin.
    """
    subcategory = models.ForeignKey(
        'product.Subcategory',
        on_delete=models.CASCADE,
        related_name='process_parameters'  # Add a unique related_name
    )
    name = models.CharField(max_length=100)
    data_type = models.CharField(max_length=50, blank=True, null=True)   # e.g., 'int', 'str', 'float'
    default_value = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f"{self.subcategory} - {self.name}"
    

class Machinery(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    machinery_image = models.ImageField(upload_to='machinery_images/', blank=True, null=True)
    category = models.ForeignKey(
    'product.Category',
    on_delete=models.CASCADE,
    related_name='machinery_categories',
    null=True,
    blank=True
        )
    # Add other machinery definitions

    def __str__(self):
        return self.name
class FacilityLine(models.Model):
    factory = models.ForeignKey('supply.Factory', on_delete=models.CASCADE, related_name='facility_lines')
    subcategories = models.ManyToManyField('product.Subcategory', blank=True, related_name='facility_lines')
    parameters = models.JSONField(default=dict, blank=True)   # evolving param sets
    name = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f"{self.factory.name} - {self.name or 'Unnamed Line'}"
class MachineryFlow(models.Model):
    facility_line = models.ForeignKey(FacilityLine, on_delete=models.CASCADE, related_name='machinery_flows')
    machinery = models.ForeignKey(Machinery, on_delete=models.CASCADE)
    description = models.TextField(blank=True, null=True)    # custom user-defined
    previous_step = models.OneToOneField(
        'self',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='next_step_reverse'  # Updated related_name
    )
    next_step = models.OneToOneField(
        'self',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='previous_step_reverse'  # Updated related_name
    )
    product_name = models.CharField(max_length=100, blank=True, null=True)


    def __str__(self):
        return f"{self.machinery.name} in {self.facility_line}"