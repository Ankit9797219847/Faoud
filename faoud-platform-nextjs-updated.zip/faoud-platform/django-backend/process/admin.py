from django.contrib import admin
from .models import FacilityLine, Machinery, MachineryFlow, SubcategoryParameter

admin.site.register(FacilityLine)
admin.site.register(MachineryFlow)
admin.site.register(SubcategoryParameter)
admin.site.register(Machinery)
