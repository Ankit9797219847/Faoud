from django.urls import path
from .views import UploadFormulationView

urlpatterns = [
    # Other URL patterns...
    path('cases/<int:case_id>/upload-formulation/', UploadFormulationView.as_view(), name='upload-formulation'),
]
