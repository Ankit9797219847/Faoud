from django.db import models

class Formulation(models.Model):
    briefs = models.ManyToManyField('utils.Brief', related_name='formulations_brief', blank=True)
    product = models.ForeignKey('product.Product', on_delete=models.CASCADE, related_name='formulations_product', blank=True)
    formulators = models.ManyToManyField('user.Formulator', related_name='formulations_formulator', blank=True)
    documents = models.FileField(upload_to='media/formulation_documents/', blank=True, null=True)  # Stores PDFs

    def __str__(self):
        return f"Formulation {self.id}"