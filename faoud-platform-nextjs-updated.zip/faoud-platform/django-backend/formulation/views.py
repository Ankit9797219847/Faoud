from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404

from case.models import Case
from .models import Formulation
from user.permissions import IsBrandOwner, IsAccountManager

class UploadFormulationView(APIView):
    permission_classes = [IsBrandOwner | IsAccountManager]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request, case_id):
        case = get_object_or_404(Case, id=case_id)

        # Check if a product is associated with the case
        if not case.product:
            return Response({"error": "No product associated with this case. Please add a product before uploading formulation."}, 
                            status=status.HTTP_400_BAD_REQUEST)

        # Check if a formulation file is provided
        if 'formulation' not in request.FILES:
            return Response({"error": "No formulation file provided."}, status=status.HTTP_400_BAD_REQUEST)

        # Create or update the formulation record for the case
        formulation, created = Formulation.objects.get_or_create(product=case.product)
        formulation.documents = request.FILES['formulation']
        # formulation.documents =  request.build_absolute_uri(case.formulation.documents.url)
        formulation.save()

        # Associate the formulation with the case if it's not already linked
        case.formulation = formulation
        case.save()

        return Response({"message": "Formulation uploaded successfully."}, status=status.HTTP_200_OK)
