from rest_framework import serializers

from formulation.models import Formulation
from product.serializers import ProductSerializer
from user.serializers import FormulatorSerializer
from utils.serializers import BriefSerializer

class FormulationSerializer(serializers.ModelSerializer):
    briefs = BriefSerializer(many=True, read_only=True)
    product = ProductSerializer(read_only=True)
    formulators = FormulatorSerializer(many=True, read_only=True)

    class Meta:
        model = Formulation
        fields = [
            'id',
            'briefs',
            'product',
            'formulators',
            'documents',
        ]