from django.contrib import admin
from .models import Formulation

admin.site.register(Formulation)
