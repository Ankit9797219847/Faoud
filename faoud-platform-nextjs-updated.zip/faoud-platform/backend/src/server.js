require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth');
const marketplaceRoutes = require('./routes/marketplace');
const orderRoutes = require('./routes/orders');
const rfqRoutes = require('./routes/rfq');
const leadRoutes = require('./routes/leads');
const blogRoutes = require('./routes/blog');
// Ops console (Account Manager / Brand Owner / Factory Owner), ported from
// the shadow-api Django backend into this Express app.
const caseRoutes = require('./routes/cases');
const stageRoutes = require('./routes/stages');
const opsStatusRoutes = require('./routes/ops-status');
const caseAssignmentRoutes = require('./routes/case-assignment');
const alertRoutes = require('./routes/alerts');
const managementRoutes = require('./routes/management');
const bidRoutes = require('./routes/bids');
const userRoutes = require('./routes/user');
const paymentRoutes = require('./routes/payments');
const documentRoutes = require('./routes/documents');
const factoryProfileRoutes = require('./routes/factory-profile');
// Phase 2 of the shadow-api port: product catalog/versioning, the branching
// intake questionnaire, formulation, and materials/BOM.
const productRoutes = require('./routes/products');
const questionRoutes = require('./routes/questions');
const materialRoutes = require('./routes/materials');
const formulationRoutes = require('./routes/formulation');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json({ limit: '2mb' }));
app.use(morgan('combined'));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300 });
app.use('/api/', limiter);

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'faoud-backend' }));

app.use('/api/auth', authRoutes);
app.use('/api/marketplace', marketplaceRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/rfqs', rfqRoutes);
app.use('/api/leads', leadRoutes);
app.use('/api/blog', blogRoutes);
app.use('/api/cases', caseRoutes);
app.use('/api/cases', stageRoutes);
app.use('/api/cases', opsStatusRoutes);
app.use('/api/cases', caseAssignmentRoutes);
app.use('/api/alerts', alertRoutes);
app.use('/api/management', managementRoutes);
app.use('/api/bids', bidRoutes);
app.use('/api/user', userRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/factories', factoryProfileRoutes);
app.use('/api/products', productRoutes);
app.use('/api/questions', questionRoutes);
app.use('/api/materials', materialRoutes);
app.use('/api/formulation', formulationRoutes);

app.use((req, res) => res.status(404).json({ error: 'Route not found.' }));

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error.' });
});

app.listen(PORT, () => console.log(`🚀 Faoud backend running on port ${PORT}`));
