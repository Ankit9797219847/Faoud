-- Faoud Platform Database Schema
-- PostgreSQL

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ========== USERS & ROLES ==========
-- 'account_manager' and 'formulator' added when the shadow-api ops console
-- (case tracking / bidding / AM workspace) was merged into this backend.
-- 'brand' and 'factory' are reused for both the public marketplace AND the
-- ops console (Brand Owner / Factory Owner) so a single account works for
-- both sides of the product.
CREATE TYPE user_role AS ENUM ('brand', 'factory', 'supplier', 'admin', 'account_manager', 'formulator');
CREATE TYPE order_status AS ENUM ('quote_requested', 'quoted', 'confirmed', 'in_production', 'quality_check', 'dispatched', 'delivered', 'cancelled');
CREATE TYPE rfq_status AS ENUM ('open', 'quoted', 'closed');

-- Case-tracking / ops-console status types (ported from shadow-api)
CREATE TYPE case_priority AS ENUM ('normal', 'priority', 'inactive', 'dispatched');
CREATE TYPE case_active_state AS ENUM ('active', 'archived', 'deleted');
-- Matches supply.models.Bid.STATUS_CHOICES exactly
CREATE TYPE bid_status AS ENUM ('in_review', 'rejected', 'accepted', 'locked', 'sample_ordered');
-- Matches case.models.CaseOperationalStatus.STATE_CHOICES
CREATE TYPE ops_status_state AS ENUM ('in_process', 'done');
-- AM's private triage tag on a bid (Bid.tag in shadow-api — no fixed choice
-- set existed in the source; this is a reasonable inferred set)
CREATE TYPE bid_tag AS ENUM ('shortlisted', 'not_shortlisted', 'best_value', 'backup');

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    company_name VARCHAR(255),
    role user_role NOT NULL DEFAULT 'brand',
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Extra profile fields used by the ops console (ported from user.models:
-- BrandOwner/AM/FactoryOwner all had these or equivalents). Kept on `users`
-- directly rather than as separate one-to-one profile tables, to keep the
-- port simple — shadow-api's separate BrandOwner/AM/FactoryOwner "employee
-- id", "skills", "date_of_birth" etc. fields were left out as low-value for
-- an MVP ops console.
ALTER TABLE users ADD COLUMN terms_accepted BOOLEAN DEFAULT FALSE;
ALTER TABLE users ADD COLUMN terms_accepted_at TIMESTAMP;
ALTER TABLE users ADD COLUMN terms_version_accepted INTEGER;
ALTER TABLE users ADD COLUMN marketing_emails BOOLEAN DEFAULT TRUE;
ALTER TABLE users ADD COLUMN operational_emails BOOLEAN DEFAULT TRUE;
-- Maps to shadow-api's Django 'superAM' / 'MNGMNT' groups (IsPrivilegedAccountManager).
-- Privileged AMs are auto-added as a viewer on every case they touch via
-- assignment, and are the only ones who can reassign a case's primary AM.
ALTER TABLE users ADD COLUMN is_privileged_am BOOLEAN DEFAULT FALSE;

CREATE TABLE login_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    role user_role NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Ported from user.models.TermsAndConditions / TermsAcceptance
CREATE TABLE terms_and_conditions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scope VARCHAR(20) NOT NULL, -- 'global' | 'brand_owner' | 'factory_owner'
    version INTEGER NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE terms_acceptances (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    terms_id UUID REFERENCES terms_and_conditions(id) ON DELETE CASCADE,
    accepted_at TIMESTAMP DEFAULT NOW(),
    ip_address VARCHAR(64)
);

-- ========== FACTORIES ==========
-- Extended with the real profile fields from supply.models.Factory (GST,
-- director/POC contacts, licenses, capacity, etc.) beyond the original
-- marketplace-only columns.
CREATE TABLE factories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    factory_owner_id UUID REFERENCES users(id) ON DELETE SET NULL,
    factory_name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL, -- nutraceuticals, cosmetics, food, home care etc.
    city VARCHAR(100),
    state VARCHAR(100),
    moq INTEGER,
    turnaround_days INTEGER,
    certifications TEXT[], -- e.g. {GMP, ISO, FDA}
    description TEXT,
    verified BOOLEAN DEFAULT FALSE,
    gst_number VARCHAR(20),
    legal_entity VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(255),
    address TEXT,
    website VARCHAR(255),
    type_of_products TEXT,
    licenses TEXT,
    capacity INTEGER,
    exports_supported BOOLEAN DEFAULT FALSE,
    director_name VARCHAR(100),
    director_phone VARCHAR(20),
    director_email VARCHAR(255),
    poc_name VARCHAR(100),
    poc_phone VARCHAR(20),
    poc_email VARCHAR(255),
    operational_since INTEGER,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ========== MARKETPLACE PRODUCTS (ready to manufacture) ==========
CREATE TABLE marketplace_products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    factory_id UUID REFERENCES factories(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    description TEXT,
    base_price NUMERIC(12,2),
    moq INTEGER,
    lead_time_days INTEGER,
    image_url TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ========== ORDERS ==========
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_number VARCHAR(50) UNIQUE NOT NULL,
    brand_id UUID REFERENCES users(id),
    factory_id UUID REFERENCES factories(id),
    product_id UUID REFERENCES marketplace_products(id),
    quantity INTEGER NOT NULL,
    status order_status DEFAULT 'quote_requested',
    total_amount NUMERIC(12,2),
    expected_delivery DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE order_status_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    status order_status NOT NULL,
    note TEXT,
    changed_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

-- ========== RFQ (Request for Quote) - suppliers/custom sourcing ==========
CREATE TABLE rfqs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    brand_id UUID REFERENCES users(id),
    category VARCHAR(100) NOT NULL,
    product_spec TEXT NOT NULL,
    target_quantity INTEGER,
    budget_range VARCHAR(100),
    status rfq_status DEFAULT 'open',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE rfq_quotes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rfq_id UUID REFERENCES rfqs(id) ON DELETE CASCADE,
    factory_id UUID REFERENCES factories(id),
    quoted_price NUMERIC(12,2),
    lead_time_days INTEGER,
    message TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ========== CONTACT / CONSULTATION LEADS ==========
CREATE TABLE leads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(20),
    company_name VARCHAR(255),
    interest VARCHAR(100), -- formulation, consultation, quotes, general
    message TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ========== BLOG ==========
CREATE TABLE blog_posts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    excerpt TEXT,
    content TEXT NOT NULL,
    author VARCHAR(255),
    published BOOLEAN DEFAULT FALSE,
    published_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ========== OPS CONSOLE: CASES (ported from shadow-api's `case` app) ==========
-- A "case" is the internal ledger entry an Account Manager runs a brand's
-- product through (NPD, onboarding, dormant-product revival, etc.), distinct
-- from a marketplace `order`.
CREATE TABLE cases (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) DEFAULT 'Unnamed Case',
    category VARCHAR(50) DEFAULT 'npd_without', -- npd_with | npd_without | onboarding | dormantProduct
    priority case_priority DEFAULT 'normal',
    color VARCHAR(10) DEFAULT '',
    active case_active_state DEFAULT 'active',
    brand_id UUID REFERENCES users(id) ON DELETE SET NULL,
    factory_id UUID REFERENCES factories(id) ON DELETE SET NULL,
    bid_selected_id UUID, -- FK added after `bids` is created, see below
    quantity INTEGER,
    eta DATE,
    notes TEXT DEFAULT '',
    last_opened_by_am_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Many-to-many: which Account Manager(s) are assigned to a case.
-- (ported from case.models.Case.am / user.models.AM.cases)
CREATE TABLE case_am_assignments (
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    am_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (case_id, am_user_id)
);

-- ---------- Stage engine (ported from case.models.Stage / ProgressStage) ----------
-- Ordered checklist of named stages a case moves through. `order = 0` is the
-- "FactorySelection" stage, which supply.views.CaseListForBiddingView uses
-- to decide which cases are open for factory bidding.
CREATE TABLE stages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    "order" INTEGER NOT NULL
);

CREATE TABLE case_progress_stages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    stage_id UUID REFERENCES stages(id) ON DELETE CASCADE,
    order_in_timeline INTEGER NOT NULL,
    completion_date DATE,
    UNIQUE (case_id, stage_id)
);

-- ---------- Operational status checklist (ported from case.models.OperationalStatus / CaseOperationalStatus) ----------
CREATE TABLE operational_statuses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT DEFAULT '',
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE case_operational_statuses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    status_id UUID REFERENCES operational_statuses(id) ON DELETE CASCADE,
    state ops_status_state NOT NULL,
    notes TEXT DEFAULT '',
    updated_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (case_id, status_id)
);

-- ---------- Alerts (ported from case.models.Alert) ----------
CREATE TABLE alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    message VARCHAR(255),
    is_done BOOLEAN DEFAULT FALSE,
    done_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ---------- Bids (ported from supply.models.Bid) ----------
CREATE TABLE bids (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    factory_id UUID REFERENCES factories(id) ON DELETE CASCADE,
    quote NUMERIC(15,2) DEFAULT 0, -- factory's real quote
    quote_bo NUMERIC(15,2) DEFAULT 0, -- quote as shown to the brand owner
    eta DATE,
    sample_paid BOOLEAN DEFAULT FALSE,
    status bid_status DEFAULT 'in_review',
    tag bid_tag, -- AM's private triage tag; only tagged bids are shown to the Brand Owner (anonymized)
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

ALTER TABLE cases ADD CONSTRAINT fk_cases_bid_selected FOREIGN KEY (bid_selected_id) REFERENCES bids(id) ON DELETE SET NULL;

-- ---------- Category / Subcategory catalog (ported from product.models.Category/Subcategory) ----------
-- shadow-api's product app is a much larger system (ProductGroup versioning,
-- a dynamic Question/AnswerOption onboarding questionnaire engine, RM/PM
-- costing tables tied to the materials app) that was NOT ported — only the
-- Category/Subcategory catalog, since it's the dependency
-- CaseListForBiddingView needs for real factory↔case eligibility matching.
CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    slug VARCHAR(100) UNIQUE
);

CREATE TABLE subcategories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id UUID REFERENCES categories(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE,
    auto_bid BOOLEAN DEFAULT FALSE,
    UNIQUE (category_id, name)
);

-- Which subcategories a factory is capable of / eligible to bid on
-- (ported from the factory↔category relationship supply.views checks
-- against in CaseListForBiddingView).
CREATE TABLE factory_subcategories (
    factory_id UUID REFERENCES factories(id) ON DELETE CASCADE,
    subcategory_id UUID REFERENCES subcategories(id) ON DELETE CASCADE,
    PRIMARY KEY (factory_id, subcategory_id)
);

ALTER TABLE cases ADD COLUMN subcategory_id UUID REFERENCES subcategories(id) ON DELETE SET NULL;

CREATE INDEX idx_subcategories_category ON subcategories(category_id);
CREATE INDEX idx_factory_subcategories_subcat ON factory_subcategories(subcategory_id);
CREATE INDEX idx_cases_subcategory ON cases(subcategory_id);

INSERT INTO categories (name, slug) VALUES
    ('Nutraceuticals', 'nutraceuticals'),
    ('Cosmetics', 'cosmetics'),
    ('Food & Beverage', 'food-beverage'),
    ('Home Care', 'home-care');

CREATE INDEX idx_factories_category ON factories(category);
CREATE INDEX idx_factories_owner ON factories(factory_owner_id);
CREATE INDEX idx_products_category ON marketplace_products(category);
CREATE INDEX idx_orders_brand ON orders(brand_id);
CREATE INDEX idx_orders_factory ON orders(factory_id);
CREATE INDEX idx_rfqs_category ON rfqs(category);
CREATE INDEX idx_cases_brand ON cases(brand_id);
CREATE INDEX idx_cases_factory ON cases(factory_id);
CREATE INDEX idx_case_am_assignments_am ON case_am_assignments(am_user_id);
CREATE INDEX idx_progress_stages_case ON case_progress_stages(case_id);
CREATE INDEX idx_case_ops_status_case ON case_operational_statuses(case_id);
CREATE INDEX idx_alerts_case ON alerts(case_id);
CREATE INDEX idx_alerts_open ON alerts(is_done) WHERE is_done = FALSE;
CREATE INDEX idx_bids_case ON bids(case_id);
CREATE INDEX idx_bids_factory ON bids(factory_id);

-- ---------- Payments (ported from payments.models.Order / PaymentLayer) ----------
-- The full payments app also has Feature/UserFeature/Charge (add-on service
-- billing) and a ServicePayment flow tied to the `services` app — neither
-- was ported (see README). This covers the core case-payment flow:
-- an AM opens an Order for a case, splits it into ADVANCE/FINAL/SAMPLE
-- PaymentLayers, and the Brand Owner pays each layer via Razorpay.
CREATE TYPE payment_status AS ENUM ('PENDING', 'PAID', 'PARTIALLY_PAID', 'EXPIRED', 'CANCELLED');
CREATE TYPE payment_layer_type AS ENUM ('ADVANCE', 'FINAL', 'SAMPLE');

CREATE TABLE payment_orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id VARCHAR(100) UNIQUE NOT NULL,
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    total_amount NUMERIC(15,2) NOT NULL,
    amount_due NUMERIC(15,2) NOT NULL,
    status payment_status DEFAULT 'PENDING',
    currency VARCHAR(10) DEFAULT 'INR',
    razorpay_order_id VARCHAR(100),
    expiry_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE payment_layers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID REFERENCES payment_orders(id) ON DELETE CASCADE,
    amount NUMERIC(15,2) NOT NULL,
    layer_type payment_layer_type NOT NULL,
    status payment_status DEFAULT 'PENDING',
    razorpay_order_id VARCHAR(100),
    razorpay_payment_id VARCHAR(100),
    razorpay_signature VARCHAR(200),
    notes JSONB DEFAULT '{}',
    expiry_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_payment_orders_case ON payment_orders(case_id);
CREATE INDEX idx_payment_layers_order ON payment_layers(order_id);
CREATE INDEX idx_payment_layers_razorpay_order ON payment_layers(razorpay_order_id);

-- ---------- Documents (generic file/document metadata row; ported from the
-- pattern used by supply.Document / uploads app. Actual file BYTES are not
-- stored here — see README "File storage" for the S3 wiring you plug in.) ----------
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_type VARCHAR(30) NOT NULL, -- 'factory' | 'case' | 'brand_owner'
    owner_id UUID NOT NULL,
    label VARCHAR(255),
    storage_key TEXT, -- S3 object key once storage is configured
    uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_documents_owner ON documents(owner_type, owner_id); (ported from real shadow-api stage
-- names visible in the codebase: "FactorySelection" at order 0, "Orders",
-- and "Reviewed" as the publish stage; the stages in between are inferred
-- to fill a sensible NPD timeline, since they were seeded via Django data
-- migrations not present in the shared codebase). ----------
INSERT INTO stages (name, "order") VALUES
    ('FactorySelection', 0),
    ('Briefing', 1),
    ('Formulation', 2),
    ('Sampling', 3),
    ('Orders', 4),
    ('Production', 5),
    ('Quality Check', 6),
    ('Dispatch', 7),
    ('Reviewed', 8);

INSERT INTO operational_statuses (name, description) VALUES
    ('GST Verified', 'Brand''s GST documentation has been checked.'),
    ('Trademark Verified', 'Brand''s trademark documentation has been checked.'),
    ('Sample Dispatched', 'A physical sample has been sent to the brand.'),
    ('Payment Received', 'Case-related payment has been confirmed.');

-- ============================================================
-- Phase 2 (product/questionnaire/materials) — see product_materials_migration.sql
-- for the commented version. Included here so a fresh DB gets everything
-- from a single schema.sql run.
-- Phase 2 of the shadow-api port: product questionnaire engine, product
-- catalog/versioning, formulation, and materials/BOM.
-- Run once against an existing database (schema.sql + ops_console_migration.sql
-- must already be applied). This file is additive only.

-- ========== PRODUCT GROUPS & PRODUCTS (ported from product.models.ProductGroup/Product) ==========
CREATE TABLE product_groups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    product_type VARCHAR(100),
    last_version_number INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    original_product_id UUID, -- FK added after products exists
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    sku_and_pm VARCHAR(100),
    quantity INTEGER DEFAULT 0,
    eta DATE,
    benchmark TEXT,
    picture_url TEXT,
    is_faoud_product BOOLEAN DEFAULT FALSE, -- true = original marketplace product
    category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
    subcategory_id UUID REFERENCES subcategories(id) ON DELETE SET NULL,
    brand_id UUID REFERENCES users(id) ON DELETE SET NULL,
    product_group_id UUID REFERENCES product_groups(id) ON DELETE SET NULL,
    version_number INTEGER DEFAULT 1,
    is_original BOOLEAN DEFAULT FALSE, -- true = the original Faoud marketplace product in its group
    parent_product_id UUID REFERENCES products(id) ON DELETE SET NULL, -- cloned-from product
    created_from_case_id UUID REFERENCES cases(id) ON DELETE SET NULL,
    modification_notes TEXT,
    version_created_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

ALTER TABLE product_groups ADD CONSTRAINT fk_product_groups_original FOREIGN KEY (original_product_id) REFERENCES products(id) ON DELETE SET NULL;

-- Many-to-many: which cases a product is attached to (product.models.Product.cases)
CREATE TABLE product_cases (
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    PRIMARY KEY (product_id, case_id)
);

CREATE TABLE product_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    name VARCHAR(100),
    storage_key TEXT,
    uploaded_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_products_group ON products(product_group_id, version_number);
CREATE INDEX idx_products_original ON products(is_original, is_faoud_product);
CREATE INDEX idx_products_case ON products(created_from_case_id);
CREATE INDEX idx_products_category ON products(category_id);

-- ========== QUESTIONNAIRE ENGINE (ported from product.models.Question/AnswerOption/ChosenAnswer) ==========
-- Powers the branching NPD/onboarding/reorder/dormant-product intake flow.
CREATE TYPE question_type AS ENUM ('MC', 'SA', 'LA', 'FU', 'DS', 'YN');
CREATE TYPE question_category AS ENUM ('npd_without', 'npd_with', 'reorder', 'onboarding', 'dormantProduct');

CREATE TABLE questions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category question_category DEFAULT 'npd_without',
    question_text TEXT DEFAULT '',
    starting_question BOOLEAN DEFAULT FALSE,
    question_type question_type DEFAULT 'SA',
    next_question_id UUID REFERENCES questions(id) ON DELETE SET NULL,
    is_case_specific BOOLEAN DEFAULT FALSE,
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    created_by_am BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE answer_options (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    option_text TEXT,
    next_question_id UUID REFERENCES questions(id) ON DELETE CASCADE
);

-- Question.options M2M (which options a question offers, distinct from
-- AnswerOption.next_question which drives branching)
CREATE TABLE question_answer_options (
    question_id UUID REFERENCES questions(id) ON DELETE CASCADE,
    answer_option_id UUID REFERENCES answer_options(id) ON DELETE CASCADE,
    PRIMARY KEY (question_id, answer_option_id)
);

CREATE TABLE chosen_answers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    brand_owner_id UUID REFERENCES users(id) ON DELETE SET NULL,
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    question_id UUID REFERENCES questions(id) ON DELETE CASCADE,
    answer_text TEXT,
    answer_file_key TEXT,
    is_case_specific BOOLEAN DEFAULT FALSE,
    order_index INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE chosen_answer_selected_options (
    chosen_answer_id UUID REFERENCES chosen_answers(id) ON DELETE CASCADE,
    answer_option_id UUID REFERENCES answer_options(id) ON DELETE CASCADE,
    PRIMARY KEY (chosen_answer_id, answer_option_id)
);

CREATE INDEX idx_questions_category_start ON questions(category, starting_question);
CREATE INDEX idx_questions_case ON questions(case_id);
CREATE INDEX idx_chosen_answers_case ON chosen_answers(case_id, order_index);
CREATE INDEX idx_answer_options_next ON answer_options(next_question_id);

-- ========== FORMULATION (ported from formulation.models.Formulation) ==========
CREATE TABLE formulations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    document_key TEXT, -- S3 key of the uploaded formulation PDF
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE formulation_formulators (
    formulation_id UUID REFERENCES formulations(id) ON DELETE CASCADE,
    formulator_id UUID REFERENCES users(id) ON DELETE CASCADE, -- role = 'formulator'
    PRIMARY KEY (formulation_id, formulator_id)
);

ALTER TABLE cases ADD COLUMN formulation_id UUID REFERENCES formulations(id) ON DELETE SET NULL;

-- ========== MATERIALS: suppliers, raw/packaging materials, BOM (ported from materials app + supply RM/PMSupplier) ==========
CREATE TABLE rm_suppliers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    contact_email VARCHAR(255),
    contact_phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE pm_suppliers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    contact_email VARCHAR(255),
    contact_phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE raw_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) DEFAULT 'Raw Material',
    iupac_name VARCHAR(255),
    price NUMERIC(10,2) DEFAULT 0,
    old_price NUMERIC(10,2),
    latest_price NUMERIC(10,2),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE raw_material_suppliers (
    raw_material_id UUID REFERENCES raw_materials(id) ON DELETE CASCADE,
    rm_supplier_id UUID REFERENCES rm_suppliers(id) ON DELETE CASCADE,
    PRIMARY KEY (raw_material_id, rm_supplier_id)
);

CREATE TABLE packaging_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) DEFAULT 'Packaging Material',
    current_status TEXT,
    price NUMERIC(10,2) DEFAULT 0,
    old_price NUMERIC(10,2),
    latest_price NUMERIC(10,2),
    material_shape VARCHAR(100) DEFAULT 'Material Shape',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE packaging_material_suppliers (
    packaging_material_id UUID REFERENCES packaging_materials(id) ON DELETE CASCADE,
    pm_supplier_id UUID REFERENCES pm_suppliers(id) ON DELETE CASCADE,
    PRIMARY KEY (packaging_material_id, pm_supplier_id)
);

-- product <-> material association with a price snapshot + chosen supplier
-- (ported from product.models.ProductRawMaterial / ProductPackagingMaterial)
CREATE TABLE product_raw_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    raw_material_id UUID REFERENCES raw_materials(id) ON DELETE CASCADE,
    price NUMERIC(10,2) NOT NULL DEFAULT 0,
    supplier_id UUID REFERENCES rm_suppliers(id) ON DELETE SET NULL,
    UNIQUE (product_id, raw_material_id)
);

CREATE TABLE product_packaging_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    packaging_material_id UUID REFERENCES packaging_materials(id) ON DELETE CASCADE,
    price NUMERIC(10,2) NOT NULL DEFAULT 0,
    supplier_id UUID REFERENCES pm_suppliers(id) ON DELETE SET NULL,
    UNIQUE (product_id, packaging_material_id)
);

-- Bill of Materials (ported from materials.models.BillOfMaterials*)
CREATE TABLE bill_of_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    brand_owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
    total_cost NUMERIC(12,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (product_id, brand_owner_id)
);

CREATE TABLE bom_raw_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bom_id UUID REFERENCES bill_of_materials(id) ON DELETE CASCADE,
    raw_material_id UUID REFERENCES raw_materials(id) ON DELETE CASCADE,
    quantity NUMERIC(10,2) DEFAULT 0,
    price_per_unit NUMERIC(10,2) DEFAULT 0,
    UNIQUE (bom_id, raw_material_id)
);

CREATE TABLE bom_packaging_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bom_id UUID REFERENCES bill_of_materials(id) ON DELETE CASCADE,
    packaging_material_id UUID REFERENCES packaging_materials(id) ON DELETE CASCADE,
    quantity NUMERIC(10,2) DEFAULT 0,
    price_per_unit NUMERIC(10,2) DEFAULT 0,
    UNIQUE (bom_id, packaging_material_id)
);

CREATE INDEX idx_prm_product ON product_raw_materials(product_id);
CREATE INDEX idx_ppm_product ON product_packaging_materials(product_id);
CREATE INDEX idx_bom_product ON bill_of_materials(product_id);

-- ========== Parameters / POM — subcategory-level costed spec fields (ported from product.models.Parameter/POM) ==========
CREATE TABLE parameters (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subcategory_id UUID REFERENCES subcategories(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    unit VARCHAR(50),
    description TEXT,
    default_price NUMERIC(10,2),
    default_quantity NUMERIC(10,2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE case_parameters (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    parameter_id UUID REFERENCES parameters(id) ON DELETE CASCADE,
    is_active BOOLEAN DEFAULT TRUE,
    price NUMERIC(10,2),
    quantity NUMERIC(10,2),
    value VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (case_id, parameter_id)
);

CREATE INDEX idx_parameters_subcategory ON parameters(subcategory_id);
CREATE INDEX idx_case_parameters_case ON case_parameters(case_id);

-- ========== Starter seed: a minimal npd_without question tree ==========
DO $$
DECLARE
  q1 UUID; q2 UUID; q3 UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM questions WHERE category = 'npd_without' AND starting_question = TRUE) THEN
    INSERT INTO questions (category, question_text, starting_question, question_type)
      VALUES ('npd_without', 'What is the working name of your product?', TRUE, 'SA') RETURNING id INTO q1;
    INSERT INTO questions (category, question_text, question_type)
      VALUES ('npd_without', 'Do you already have a formulation for this product?', 'YN') RETURNING id INTO q2;
    INSERT INTO questions (category, question_text, question_type)
      VALUES ('npd_without', 'Describe the target consumer and use case.', 'LA') RETURNING id INTO q3;

    UPDATE questions SET next_question_id = q2 WHERE id = q1;
    UPDATE questions SET next_question_id = q3 WHERE id = q2;
  END IF;
END $$;
