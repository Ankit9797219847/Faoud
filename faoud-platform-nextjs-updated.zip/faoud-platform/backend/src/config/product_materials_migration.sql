-- Phase 2 of the shadow-api port: product questionnaire engine, product
-- catalog/versioning, formulation, and materials/BOM.
-- Run once against an existing database (schema.sql + ops_console_migration.sql
-- must already be applied). This file is additive only.

-- ========== PRODUCT GROUPS & PRODUCTS (ported from product.models.ProductGroup/Product) ==========
CREATE TABLE product_groups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    product_type VARCHAR(100),
    last_version_number INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    original_product_id UUID, -- FK added after products exists
    created_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    sku_and_pm VARCHAR(100),
    quantity INTEGER DEFAULT 0,
    eta DATE,
    benchmark TEXT,
    picture_url TEXT,
    is_faoud_product BOOLEAN DEFAULT FALSE, -- true = original marketplace product
    category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
    subcategory_id UUID REFERENCES subcategories(id) ON DELETE SET NULL,
    brand_id UUID REFERENCES users(id) ON DELETE SET NULL,
    product_group_id UUID REFERENCES product_groups(id) ON DELETE SET NULL,
    version_number INTEGER DEFAULT 1,
    is_original BOOLEAN DEFAULT FALSE, -- true = the original Faoud marketplace product in its group
    parent_product_id UUID REFERENCES products(id) ON DELETE SET NULL, -- cloned-from product
    created_from_case_id UUID REFERENCES cases(id) ON DELETE SET NULL,
    modification_notes TEXT,
    version_created_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

ALTER TABLE product_groups ADD CONSTRAINT fk_product_groups_original FOREIGN KEY (original_product_id) REFERENCES products(id) ON DELETE SET NULL;

-- Many-to-many: which cases a product is attached to (product.models.Product.cases)
CREATE TABLE product_cases (
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    PRIMARY KEY (product_id, case_id)
);

CREATE TABLE product_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    name VARCHAR(100),
    storage_key TEXT,
    uploaded_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_products_group ON products(product_group_id, version_number);
CREATE INDEX idx_products_original ON products(is_original, is_faoud_product);
CREATE INDEX idx_products_case ON products(created_from_case_id);
CREATE INDEX idx_products_category ON products(category_id);

-- ========== QUESTIONNAIRE ENGINE (ported from product.models.Question/AnswerOption/ChosenAnswer) ==========
-- Powers the branching NPD/onboarding/reorder/dormant-product intake flow.
CREATE TYPE question_type AS ENUM ('MC', 'SA', 'LA', 'FU', 'DS', 'YN');
CREATE TYPE question_category AS ENUM ('npd_without', 'npd_with', 'reorder', 'onboarding', 'dormantProduct');

CREATE TABLE questions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category question_category DEFAULT 'npd_without',
    question_text TEXT DEFAULT '',
    starting_question BOOLEAN DEFAULT FALSE,
    question_type question_type DEFAULT 'SA',
    next_question_id UUID REFERENCES questions(id) ON DELETE SET NULL,
    is_case_specific BOOLEAN DEFAULT FALSE,
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    created_by_am BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE answer_options (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    option_text TEXT,
    next_question_id UUID REFERENCES questions(id) ON DELETE CASCADE
);

-- Question.options M2M (which options a question offers, distinct from
-- AnswerOption.next_question which drives branching)
CREATE TABLE question_answer_options (
    question_id UUID REFERENCES questions(id) ON DELETE CASCADE,
    answer_option_id UUID REFERENCES answer_options(id) ON DELETE CASCADE,
    PRIMARY KEY (question_id, answer_option_id)
);

CREATE TABLE chosen_answers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    brand_owner_id UUID REFERENCES users(id) ON DELETE SET NULL,
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    question_id UUID REFERENCES questions(id) ON DELETE CASCADE,
    answer_text TEXT,
    answer_file_key TEXT,
    is_case_specific BOOLEAN DEFAULT FALSE,
    order_index INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE chosen_answer_selected_options (
    chosen_answer_id UUID REFERENCES chosen_answers(id) ON DELETE CASCADE,
    answer_option_id UUID REFERENCES answer_options(id) ON DELETE CASCADE,
    PRIMARY KEY (chosen_answer_id, answer_option_id)
);

CREATE INDEX idx_questions_category_start ON questions(category, starting_question);
CREATE INDEX idx_questions_case ON questions(case_id);
CREATE INDEX idx_chosen_answers_case ON chosen_answers(case_id, order_index);
CREATE INDEX idx_answer_options_next ON answer_options(next_question_id);

-- ========== FORMULATION (ported from formulation.models.Formulation) ==========
CREATE TABLE formulations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    document_key TEXT, -- S3 key of the uploaded formulation PDF
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE formulation_formulators (
    formulation_id UUID REFERENCES formulations(id) ON DELETE CASCADE,
    formulator_id UUID REFERENCES users(id) ON DELETE CASCADE, -- role = 'formulator'
    PRIMARY KEY (formulation_id, formulator_id)
);

ALTER TABLE cases ADD COLUMN formulation_id UUID REFERENCES formulations(id) ON DELETE SET NULL;

-- ========== MATERIALS: suppliers, raw/packaging materials, BOM (ported from materials app + supply RM/PMSupplier) ==========
CREATE TABLE rm_suppliers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    contact_email VARCHAR(255),
    contact_phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE pm_suppliers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    contact_email VARCHAR(255),
    contact_phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE raw_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) DEFAULT 'Raw Material',
    iupac_name VARCHAR(255),
    price NUMERIC(10,2) DEFAULT 0,
    old_price NUMERIC(10,2),
    latest_price NUMERIC(10,2),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE raw_material_suppliers (
    raw_material_id UUID REFERENCES raw_materials(id) ON DELETE CASCADE,
    rm_supplier_id UUID REFERENCES rm_suppliers(id) ON DELETE CASCADE,
    PRIMARY KEY (raw_material_id, rm_supplier_id)
);

CREATE TABLE packaging_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) DEFAULT 'Packaging Material',
    current_status TEXT,
    price NUMERIC(10,2) DEFAULT 0,
    old_price NUMERIC(10,2),
    latest_price NUMERIC(10,2),
    material_shape VARCHAR(100) DEFAULT 'Material Shape',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE packaging_material_suppliers (
    packaging_material_id UUID REFERENCES packaging_materials(id) ON DELETE CASCADE,
    pm_supplier_id UUID REFERENCES pm_suppliers(id) ON DELETE CASCADE,
    PRIMARY KEY (packaging_material_id, pm_supplier_id)
);

-- product <-> material association with a price snapshot + chosen supplier
-- (ported from product.models.ProductRawMaterial / ProductPackagingMaterial)
CREATE TABLE product_raw_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    raw_material_id UUID REFERENCES raw_materials(id) ON DELETE CASCADE,
    price NUMERIC(10,2) NOT NULL DEFAULT 0,
    supplier_id UUID REFERENCES rm_suppliers(id) ON DELETE SET NULL,
    UNIQUE (product_id, raw_material_id)
);

CREATE TABLE product_packaging_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    packaging_material_id UUID REFERENCES packaging_materials(id) ON DELETE CASCADE,
    price NUMERIC(10,2) NOT NULL DEFAULT 0,
    supplier_id UUID REFERENCES pm_suppliers(id) ON DELETE SET NULL,
    UNIQUE (product_id, packaging_material_id)
);

-- Bill of Materials (ported from materials.models.BillOfMaterials*)
CREATE TABLE bill_of_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    brand_owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
    total_cost NUMERIC(12,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (product_id, brand_owner_id)
);

CREATE TABLE bom_raw_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bom_id UUID REFERENCES bill_of_materials(id) ON DELETE CASCADE,
    raw_material_id UUID REFERENCES raw_materials(id) ON DELETE CASCADE,
    quantity NUMERIC(10,2) DEFAULT 0,
    price_per_unit NUMERIC(10,2) DEFAULT 0,
    UNIQUE (bom_id, raw_material_id)
);

CREATE TABLE bom_packaging_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bom_id UUID REFERENCES bill_of_materials(id) ON DELETE CASCADE,
    packaging_material_id UUID REFERENCES packaging_materials(id) ON DELETE CASCADE,
    quantity NUMERIC(10,2) DEFAULT 0,
    price_per_unit NUMERIC(10,2) DEFAULT 0,
    UNIQUE (bom_id, packaging_material_id)
);

CREATE INDEX idx_prm_product ON product_raw_materials(product_id);
CREATE INDEX idx_ppm_product ON product_packaging_materials(product_id);
CREATE INDEX idx_bom_product ON bill_of_materials(product_id);

-- ========== Parameters / POM — subcategory-level costed spec fields (ported from product.models.Parameter/POM) ==========
CREATE TABLE parameters (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    subcategory_id UUID REFERENCES subcategories(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    unit VARCHAR(50),
    description TEXT,
    default_price NUMERIC(10,2),
    default_quantity NUMERIC(10,2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE case_parameters (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    parameter_id UUID REFERENCES parameters(id) ON DELETE CASCADE,
    is_active BOOLEAN DEFAULT TRUE,
    price NUMERIC(10,2),
    quantity NUMERIC(10,2),
    value VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (case_id, parameter_id)
);

CREATE INDEX idx_parameters_subcategory ON parameters(subcategory_id);
CREATE INDEX idx_case_parameters_case ON case_parameters(case_id);

-- ========== Starter seed: a minimal npd_without question tree ==========
-- (real shadow-api trees were seeded via Django data migrations not present
-- in the shared codebase — this gives the flow something to run against out
-- of the box; add real trees via the AM console.)
DO $$
DECLARE
  q1 UUID; q2 UUID; q3 UUID;
  opt_yes UUID; opt_no UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM questions WHERE category = 'npd_without' AND starting_question = TRUE) THEN
    INSERT INTO questions (category, question_text, starting_question, question_type)
      VALUES ('npd_without', 'What is the working name of your product?', TRUE, 'SA') RETURNING id INTO q1;
    INSERT INTO questions (category, question_text, question_type)
      VALUES ('npd_without', 'Do you already have a formulation for this product?', 'YN') RETURNING id INTO q2;
    INSERT INTO questions (category, question_text, question_type)
      VALUES ('npd_without', 'Describe the target consumer and use case.', 'LA') RETURNING id INTO q3;

    UPDATE questions SET next_question_id = q2 WHERE id = q1;
    UPDATE questions SET next_question_id = q3 WHERE id = q2;
  END IF;
END $$;
