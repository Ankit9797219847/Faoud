-- Incremental migration: run this against an ALREADY-MIGRATED database to
-- add or upgrade the ops console (Account Manager / Brand Owner / Factory
-- Owner: cases, the Stage engine, operational-status checklist, AM
-- assignment, and the full bidding flow) ported in from shadow-api.
--
-- Safe to run whether your DB has none of this yet, or has the earlier
-- (smaller) version of the ops console — everything below uses
-- IF NOT EXISTS / ADD COLUMN IF NOT EXISTS guards.
--
-- If you're setting up a brand-new database instead, just run schema.sql —
-- it already includes everything below.

ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'account_manager';
ALTER TYPE user_role ADD VALUE IF NOT EXISTS 'formulator';

DO $$ BEGIN
    CREATE TYPE case_priority AS ENUM ('normal', 'priority', 'inactive', 'dispatched');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE case_active_state AS ENUM ('active', 'archived', 'deleted');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE bid_status AS ENUM ('in_review', 'rejected', 'accepted', 'locked', 'sample_ordered');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE ops_status_state AS ENUM ('in_process', 'done');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE bid_tag AS ENUM ('shortlisted', 'not_shortlisted', 'best_value', 'backup');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- If you're upgrading from the earlier, smaller ops-console pass: that
-- version's `bids.status` used a different bid_status enum with different
-- values ('submitted','accepted','rejected','withdrawn'). Postgres can't
-- redefine an enum in place, so if that's your situation, back up any
-- existing bids rows, then run:
--   ALTER TABLE bids RENAME COLUMN status TO status_old;
--   ALTER TABLE bids ADD COLUMN status bid_status DEFAULT 'in_review';
--   -- map status_old -> status by hand, then:
--   ALTER TABLE bids DROP COLUMN status_old;

ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_accepted BOOLEAN DEFAULT FALSE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_accepted_at TIMESTAMP;
ALTER TABLE users ADD COLUMN IF NOT EXISTS terms_version_accepted INTEGER;
ALTER TABLE users ADD COLUMN IF NOT EXISTS marketing_emails BOOLEAN DEFAULT TRUE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS operational_emails BOOLEAN DEFAULT TRUE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_privileged_am BOOLEAN DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS login_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    role user_role NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS terms_and_conditions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scope VARCHAR(20) NOT NULL,
    version INTEGER NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS terms_acceptances (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    terms_id UUID REFERENCES terms_and_conditions(id) ON DELETE CASCADE,
    accepted_at TIMESTAMP DEFAULT NOW(),
    ip_address VARCHAR(64)
);

ALTER TABLE factories ADD COLUMN IF NOT EXISTS factory_owner_id UUID REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE factories ADD COLUMN IF NOT EXISTS gst_number VARCHAR(20);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS legal_entity VARCHAR(100);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS phone VARCHAR(20);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS email VARCHAR(255);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS address TEXT;
ALTER TABLE factories ADD COLUMN IF NOT EXISTS website VARCHAR(255);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS type_of_products TEXT;
ALTER TABLE factories ADD COLUMN IF NOT EXISTS licenses TEXT;
ALTER TABLE factories ADD COLUMN IF NOT EXISTS capacity INTEGER;
ALTER TABLE factories ADD COLUMN IF NOT EXISTS exports_supported BOOLEAN DEFAULT FALSE;
ALTER TABLE factories ADD COLUMN IF NOT EXISTS director_name VARCHAR(100);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS director_phone VARCHAR(20);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS director_email VARCHAR(255);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS poc_name VARCHAR(100);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS poc_phone VARCHAR(20);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS poc_email VARCHAR(255);
ALTER TABLE factories ADD COLUMN IF NOT EXISTS operational_since INTEGER;
ALTER TABLE factories ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW();

CREATE TABLE IF NOT EXISTS cases (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) DEFAULT 'Unnamed Case',
    category VARCHAR(50) DEFAULT 'npd_without',
    priority case_priority DEFAULT 'normal',
    color VARCHAR(10) DEFAULT '',
    active case_active_state DEFAULT 'active',
    brand_id UUID REFERENCES users(id) ON DELETE SET NULL,
    factory_id UUID REFERENCES factories(id) ON DELETE SET NULL,
    bid_selected_id UUID,
    quantity INTEGER,
    eta DATE,
    notes TEXT DEFAULT '',
    last_opened_by_am_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
-- If upgrading from the earlier pass, drop columns that no longer exist:
ALTER TABLE cases DROP COLUMN IF EXISTS stage;
ALTER TABLE cases DROP COLUMN IF EXISTS open_for_bidding;
ALTER TABLE cases ADD COLUMN IF NOT EXISTS bid_selected_id UUID;

CREATE TABLE IF NOT EXISTS case_am_assignments (
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    am_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT NOW(),
    PRIMARY KEY (case_id, am_user_id)
);

CREATE TABLE IF NOT EXISTS stages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    "order" INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS case_progress_stages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    stage_id UUID REFERENCES stages(id) ON DELETE CASCADE,
    order_in_timeline INTEGER NOT NULL,
    completion_date DATE,
    UNIQUE (case_id, stage_id)
);

CREATE TABLE IF NOT EXISTS operational_statuses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT DEFAULT '',
    is_active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS case_operational_statuses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    status_id UUID REFERENCES operational_statuses(id) ON DELETE CASCADE,
    state ops_status_state NOT NULL,
    notes TEXT DEFAULT '',
    updated_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (case_id, status_id)
);

CREATE TABLE IF NOT EXISTS alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    message VARCHAR(255),
    is_done BOOLEAN DEFAULT FALSE,
    done_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bids (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    factory_id UUID REFERENCES factories(id) ON DELETE CASCADE,
    quote NUMERIC(15,2) DEFAULT 0,
    quote_bo NUMERIC(15,2) DEFAULT 0,
    eta DATE,
    sample_paid BOOLEAN DEFAULT FALSE,
    status bid_status DEFAULT 'in_review',
    tag bid_tag,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
-- If upgrading from the earlier pass ('amount'/'message' columns):
ALTER TABLE bids ADD COLUMN IF NOT EXISTS quote NUMERIC(15,2) DEFAULT 0;
ALTER TABLE bids ADD COLUMN IF NOT EXISTS quote_bo NUMERIC(15,2) DEFAULT 0;
ALTER TABLE bids ADD COLUMN IF NOT EXISTS sample_paid BOOLEAN DEFAULT FALSE;
ALTER TABLE bids ADD COLUMN IF NOT EXISTS tag bid_tag;
ALTER TABLE bids ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT NOW();

DO $$ BEGIN
    ALTER TABLE cases ADD CONSTRAINT fk_cases_bid_selected FOREIGN KEY (bid_selected_id) REFERENCES bids(id) ON DELETE SET NULL;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE INDEX IF NOT EXISTS idx_factories_owner ON factories(factory_owner_id);
CREATE INDEX IF NOT EXISTS idx_cases_brand ON cases(brand_id);
CREATE INDEX IF NOT EXISTS idx_cases_factory ON cases(factory_id);
CREATE INDEX IF NOT EXISTS idx_case_am_assignments_am ON case_am_assignments(am_user_id);
CREATE INDEX IF NOT EXISTS idx_progress_stages_case ON case_progress_stages(case_id);
CREATE INDEX IF NOT EXISTS idx_case_ops_status_case ON case_operational_statuses(case_id);
CREATE INDEX IF NOT EXISTS idx_alerts_case ON alerts(case_id);
CREATE INDEX IF NOT EXISTS idx_alerts_open ON alerts(is_done) WHERE is_done = FALSE;
CREATE INDEX IF NOT EXISTS idx_bids_case ON bids(case_id);
CREATE INDEX IF NOT EXISTS idx_bids_factory ON bids(factory_id);

INSERT INTO stages (name, "order")
SELECT * FROM (VALUES
    ('FactorySelection', 0),
    ('Briefing', 1),
    ('Formulation', 2),
    ('Sampling', 3),
    ('Orders', 4),
    ('Production', 5),
    ('Quality Check', 6),
    ('Dispatch', 7),
    ('Reviewed', 8)
) AS v(name, "order")
WHERE NOT EXISTS (SELECT 1 FROM stages WHERE stages.name = v.name);

INSERT INTO operational_statuses (name, description)
SELECT * FROM (VALUES
    ('GST Verified', 'Brand''s GST documentation has been checked.'),
    ('Trademark Verified', 'Brand''s trademark documentation has been checked.'),
    ('Sample Dispatched', 'A physical sample has been sent to the brand.'),
    ('Payment Received', 'Case-related payment has been confirmed.')
) AS v(name, description)
WHERE NOT EXISTS (SELECT 1 FROM operational_statuses WHERE operational_statuses.name = v.name);

-- ---------- Category / Subcategory catalog + factory eligibility ----------
CREATE TABLE IF NOT EXISTS categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) UNIQUE NOT NULL,
    slug VARCHAR(100) UNIQUE
);

CREATE TABLE IF NOT EXISTS subcategories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id UUID REFERENCES categories(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE,
    auto_bid BOOLEAN DEFAULT FALSE,
    UNIQUE (category_id, name)
);

CREATE TABLE IF NOT EXISTS factory_subcategories (
    factory_id UUID REFERENCES factories(id) ON DELETE CASCADE,
    subcategory_id UUID REFERENCES subcategories(id) ON DELETE CASCADE,
    PRIMARY KEY (factory_id, subcategory_id)
);

ALTER TABLE cases ADD COLUMN IF NOT EXISTS subcategory_id UUID REFERENCES subcategories(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_subcategories_category ON subcategories(category_id);
CREATE INDEX IF NOT EXISTS idx_factory_subcategories_subcat ON factory_subcategories(subcategory_id);
CREATE INDEX IF NOT EXISTS idx_cases_subcategory ON cases(subcategory_id);

INSERT INTO categories (name, slug)
SELECT * FROM (VALUES
    ('Nutraceuticals', 'nutraceuticals'),
    ('Cosmetics', 'cosmetics'),
    ('Food & Beverage', 'food-beverage'),
    ('Home Care', 'home-care')
) AS v(name, slug)
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE categories.name = v.name);

-- ---------- Payments (Razorpay) + Documents ----------
DO $$ BEGIN
    CREATE TYPE payment_status AS ENUM ('PENDING', 'PAID', 'PARTIALLY_PAID', 'EXPIRED', 'CANCELLED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE payment_layer_type AS ENUM ('ADVANCE', 'FINAL', 'SAMPLE');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS payment_orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id VARCHAR(100) UNIQUE NOT NULL,
    case_id UUID REFERENCES cases(id) ON DELETE CASCADE,
    total_amount NUMERIC(15,2) NOT NULL,
    amount_due NUMERIC(15,2) NOT NULL,
    status payment_status DEFAULT 'PENDING',
    currency VARCHAR(10) DEFAULT 'INR',
    razorpay_order_id VARCHAR(100),
    expiry_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_layers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID REFERENCES payment_orders(id) ON DELETE CASCADE,
    amount NUMERIC(15,2) NOT NULL,
    layer_type payment_layer_type NOT NULL,
    status payment_status DEFAULT 'PENDING',
    razorpay_order_id VARCHAR(100),
    razorpay_payment_id VARCHAR(100),
    razorpay_signature VARCHAR(200),
    notes JSONB DEFAULT '{}',
    expiry_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_type VARCHAR(30) NOT NULL,
    owner_id UUID NOT NULL,
    label VARCHAR(255),
    storage_key TEXT,
    uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_payment_orders_case ON payment_orders(case_id);
CREATE INDEX IF NOT EXISTS idx_payment_layers_order ON payment_layers(order_id);
CREATE INDEX IF NOT EXISTS idx_payment_layers_razorpay_order ON payment_layers(razorpay_order_id);
CREATE INDEX IF NOT EXISTS idx_documents_owner ON documents(owner_type, owner_id);
