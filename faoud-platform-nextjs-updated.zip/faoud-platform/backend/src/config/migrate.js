const fs = require('fs');
const path = require('path');
const pool = require('./db');

async function migrate() {
  try {
    const sql = fs.readFileSync(path.join(__dirname, 'schema.sql')).toString();
    await pool.query(sql);
    console.log('✅ Migration completed successfully.');
  } catch (err) {
    console.error('❌ Migration failed:', err.message);
  } finally {
    await pool.end();
  }
}

migrate();
