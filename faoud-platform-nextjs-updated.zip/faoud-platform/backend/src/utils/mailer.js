const nodemailer = require('nodemailer');

let transporter = null;
function getTransporter() {
  if (!process.env.SMTP_HOST) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 587,
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: process.env.SMTP_USER
        ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD }
        : undefined
    });
  }
  return transporter;
}

// sendMail() — used throughout the ops console (case assignment, alerts,
// bid acceptance) as the equivalent of shadow-api's `notifications` app
// email dispatch. Until SMTP_* is set in .env, this just logs instead of
// sending, so the rest of the app works exactly the same either way.
async function sendMail({ to, subject, text, html }) {
  const t = getTransporter();
  if (!t) {
    console.log(`[mailer] SMTP not configured — would have sent "${subject}" to ${to}`);
    return { sent: false, reason: 'not_configured' };
  }
  try {
    await t.sendMail({ from: process.env.SMTP_FROM_EMAIL || 'notifications@faoud.com', to, subject, text, html });
    return { sent: true };
  } catch (err) {
    console.error('[mailer] send failed:', err.message);
    return { sent: false, reason: 'send_failed' };
  }
}

module.exports = { sendMail };
