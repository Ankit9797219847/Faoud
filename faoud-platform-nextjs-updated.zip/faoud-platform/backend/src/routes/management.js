const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/management/brands  (Account Manager: every brand on the ledger)
// Ported from shadow-api's management/brands/ endpoint.
router.get('/brands', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.full_name AS name, u.company_name, u.is_verified, u.created_at,
              COUNT(c.id) AS case_count
       FROM users u
       LEFT JOIN cases c ON c.brand_id = u.id AND c.active = 'active'
       WHERE u.role = 'brand'
       GROUP BY u.id
       ORDER BY u.created_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load brands.' });
  }
});

// GET /api/management/factories  (Account Manager: every factory on the ledger)
router.get('/factories', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT f.*, COUNT(c.id) AS active_case_count
       FROM factories f
       LEFT JOIN cases c ON c.factory_id = f.id AND c.active = 'active'
       GROUP BY f.id
       ORDER BY f.created_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load factories.' });
  }
});

// GET /api/management/operational-statuses  (ported from OperationalStatusListView)
router.get('/operational-statuses', authenticate, authorize('account_manager', 'admin'), async (_req, res) => {
  try {
    const result = await pool.query('SELECT * FROM operational_statuses WHERE is_active = TRUE ORDER BY name');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load operational statuses.' });
  }
});

// GET /api/management/categories  (ported from product.models.Category/Subcategory listing)
router.get('/categories', authenticate, async (_req, res) => {
  try {
    const cats = await pool.query('SELECT * FROM categories ORDER BY name');
    const subs = await pool.query('SELECT * FROM subcategories ORDER BY name');
    const withSubs = cats.rows.map((c) => ({
      ...c,
      subcategories: subs.rows.filter((s) => s.category_id === c.id)
    }));
    res.json(withSubs);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load categories.' });
  }
});

// PUT /api/management/factories/:factoryId/subcategories  (AM sets which
// subcategories a factory is eligible to bid on)
router.put(
  '/factories/:factoryId/subcategories',
  authenticate,
  authorize('account_manager', 'admin'),
  async (req, res) => {
    const { subcategory_ids } = req.body;
    if (!Array.isArray(subcategory_ids)) {
      return res.status(400).json({ error: 'subcategory_ids must be an array.' });
    }
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('DELETE FROM factory_subcategories WHERE factory_id = $1', [req.params.factoryId]);
      for (const subId of subcategory_ids) {
        await client.query(
          'INSERT INTO factory_subcategories (factory_id, subcategory_id) VALUES ($1, $2)',
          [req.params.factoryId, subId]
        );
      }
      await client.query('COMMIT');
      res.json({ message: 'Factory eligibility updated.', subcategory_ids });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error(err);
      res.status(500).json({ error: 'Could not update factory eligibility.' });
    } finally {
      client.release();
    }
  }
);

module.exports = router;
