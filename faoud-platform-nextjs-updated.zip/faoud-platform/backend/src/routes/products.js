// Ported from shadow-api's product.views: ProductViewSet, ProductGroupViewSet,
// FaoudProductViewSet, ProductListView, PublicFaoudProductsView.
const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/products?case_id=&brand_id=&is_faoud_product=
router.get('/', authenticate, async (req, res) => {
  const { case_id, brand_id, is_faoud_product } = req.query;
  const clauses = [];
  const params = [];
  if (case_id) {
    params.push(case_id);
    clauses.push(`p.id IN (SELECT product_id FROM product_cases WHERE case_id = $${params.length})`);
  }
  if (brand_id) {
    params.push(brand_id);
    clauses.push(`p.brand_id = $${params.length}`);
  }
  if (is_faoud_product !== undefined) {
    params.push(is_faoud_product === 'true');
    clauses.push(`p.is_faoud_product = $${params.length}`);
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  try {
    const result = await pool.query(
      `SELECT p.*, c.name AS category_name, s.name AS subcategory_name
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
       LEFT JOIN subcategories s ON s.id = p.subcategory_id
       ${where} ORDER BY p.created_at DESC`,
      params
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load products.' });
  }
});

// GET /api/products/public — public Faoud marketplace products (no auth)
// (ported from PublicFaoudProductsView)
router.get('/public', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, name, sku_and_pm, picture_url, benchmark, category_id, subcategory_id
       FROM products WHERE is_faoud_product = TRUE ORDER BY created_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load public products.' });
  }
});

// GET /api/products/:id
router.get('/:id', authenticate, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM products WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Product not found.' });
    const cases = await pool.query('SELECT case_id FROM product_cases WHERE product_id = $1', [req.params.id]);
    res.json({ ...result.rows[0], case_ids: cases.rows.map((r) => r.case_id) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load product.' });
  }
});

// POST /api/products — create a product (AM only; brand product creation
// happens implicitly through the questionnaire/case flow in shadow-api)
router.post('/', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const {
    name, sku_and_pm, quantity, eta, benchmark, picture_url,
    category_id, subcategory_id, brand_id, is_faoud_product, case_id
  } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await client.query(
      `INSERT INTO products (name, sku_and_pm, quantity, eta, benchmark, picture_url, category_id, subcategory_id, brand_id, is_faoud_product, is_original, version_number)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10, TRUE, 1) RETURNING *`,
      [name, sku_and_pm, quantity || 0, eta || null, benchmark, picture_url, category_id || null, subcategory_id || null, brand_id || null, !!is_faoud_product]
    );
    const product = result.rows[0];
    if (case_id) {
      await client.query('INSERT INTO product_cases (product_id, case_id) VALUES ($1, $2)', [product.id, case_id]);
    }
    await client.query('COMMIT');
    res.status(201).json(product);
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Could not create product.' });
  } finally {
    client.release();
  }
});

// PUT /api/products/:id
router.put('/:id', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const fields = ['name', 'sku_and_pm', 'quantity', 'eta', 'benchmark', 'picture_url', 'category_id', 'subcategory_id'];
  const sets = [];
  const params = [];
  fields.forEach((f) => {
    if (req.body[f] !== undefined) {
      params.push(req.body[f]);
      sets.push(`${f} = $${params.length}`);
    }
  });
  if (sets.length === 0) return res.status(400).json({ error: 'No fields to update.' });
  params.push(req.params.id);
  try {
    const result = await pool.query(`UPDATE products SET ${sets.join(', ')} WHERE id = $${params.length} RETURNING *`, params);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Product not found.' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not update product.' });
  }
});

// POST /api/products/:id/clone — version a product into a new copy
// (ported from the ProductGroup versioning flow: parent_product/version_number/created_from_case)
router.post('/:id/clone', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { case_id, modification_notes } = req.body;
  const client = await pool.connect();
  try {
    const orig = await client.query('SELECT * FROM products WHERE id = $1', [req.params.id]);
    if (orig.rows.length === 0) return res.status(404).json({ error: 'Product not found.' });
    const p = orig.rows[0];

    await client.query('BEGIN');
    let groupId = p.product_group_id;
    if (!groupId) {
      const group = await client.query(
        `INSERT INTO product_groups (name, original_product_id, last_version_number) VALUES ($1,$2,1) RETURNING id`,
        [p.name, p.id]
      );
      groupId = group.rows[0].id;
      await client.query('UPDATE products SET product_group_id = $1, is_original = TRUE WHERE id = $2', [groupId, p.id]);
    }
    const groupRow = await client.query('SELECT last_version_number FROM product_groups WHERE id = $1', [groupId]);
    const nextVersion = (groupRow.rows[0]?.last_version_number || 1) + 1;

    const clone = await client.query(
      `INSERT INTO products (name, sku_and_pm, quantity, eta, benchmark, picture_url, category_id, subcategory_id, brand_id,
        product_group_id, version_number, parent_product_id, created_from_case_id, modification_notes, version_created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14, NOW()) RETURNING *`,
      [p.name, p.sku_and_pm, p.quantity, p.eta, p.benchmark, p.picture_url, p.category_id, p.subcategory_id, p.brand_id,
        groupId, nextVersion, p.id, case_id || null, modification_notes || null]
    );
    await client.query('UPDATE product_groups SET last_version_number = $1 WHERE id = $2', [nextVersion, groupId]);
    if (case_id) {
      await client.query('INSERT INTO product_cases (product_id, case_id) VALUES ($1, $2)', [clone.rows[0].id, case_id]);
    }
    await client.query('COMMIT');
    res.status(201).json(clone.rows[0]);
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Could not clone product.' });
  } finally {
    client.release();
  }
});

// GET /api/products/groups/:groupId — all versions in a product group
// (ported from ProductGroupViewSet)
router.get('/groups/:groupId', authenticate, async (req, res) => {
  try {
    const group = await pool.query('SELECT * FROM product_groups WHERE id = $1', [req.params.groupId]);
    if (group.rows.length === 0) return res.status(404).json({ error: 'Product group not found.' });
    const versions = await pool.query(
      'SELECT * FROM products WHERE product_group_id = $1 ORDER BY version_number DESC',
      [req.params.groupId]
    );
    res.json({ ...group.rows[0], versions: versions.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load product group.' });
  }
});

module.exports = router;
