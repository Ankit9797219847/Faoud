const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// POST /api/rfqs  (brand posts a request for quote)
router.post('/', authenticate, authorize('brand', 'admin'), async (req, res) => {
  const { category, product_spec, target_quantity, budget_range } = req.body;
  if (!category || !product_spec) {
    return res.status(400).json({ error: 'category and product_spec are required.' });
  }
  try {
    const result = await pool.query(
      `INSERT INTO rfqs (brand_id, category, product_spec, target_quantity, budget_range)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [req.user.id, category, product_spec, target_quantity || null, budget_range || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create RFQ.' });
  }
});

// GET /api/rfqs  (factories browse open RFQs; brand sees their own)
router.get('/', authenticate, async (req, res) => {
  try {
    let query, params;
    if (req.user.role === 'brand') {
      query = 'SELECT * FROM rfqs WHERE brand_id = $1 ORDER BY created_at DESC';
      params = [req.user.id];
    } else {
      query = "SELECT * FROM rfqs WHERE status = 'open' ORDER BY created_at DESC";
      params = [];
    }
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch RFQs.' });
  }
});

// POST /api/rfqs/:id/quotes  (factory responds with a quote)
router.post('/:id/quotes', authenticate, authorize('factory', 'admin'), async (req, res) => {
  const { quoted_price, lead_time_days, message } = req.body;
  try {
    const factory = await pool.query('SELECT id FROM factories WHERE user_id = $1', [req.user.id]);
    if (factory.rows.length === 0) {
      return res.status(400).json({ error: 'Complete your factory profile before quoting.' });
    }
    const result = await pool.query(
      `INSERT INTO rfq_quotes (rfq_id, factory_id, quoted_price, lead_time_days, message)
       VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [req.params.id, factory.rows[0].id, quoted_price, lead_time_days, message]
    );
    await pool.query("UPDATE rfqs SET status = 'quoted' WHERE id = $1", [req.params.id]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not submit quote.' });
  }
});

// GET /api/rfqs/:id/quotes  (brand views quotes received on their RFQ)
router.get('/:id/quotes', authenticate, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT q.*, f.factory_name, f.city, f.state FROM rfq_quotes q
       JOIN factories f ON f.id = q.factory_id WHERE q.rfq_id = $1 ORDER BY q.created_at ASC`,
      [req.params.id]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch quotes.' });
  }
});

module.exports = router;
