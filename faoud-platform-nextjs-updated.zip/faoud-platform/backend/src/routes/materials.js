// Ported from shadow-api's materials.views: RMSupplierViewSet, PMSupplierViewSet,
// RawMaterialViewSet, PackagingMaterialViewSet, BrandOwnerRaw/PackagingMaterialViewSet,
// BillOfMaterialsViewSet (get_bom_by_case / update_by_case).
const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// ---------- Suppliers (AM only) ----------
router.get('/rm-suppliers', authenticate, authorize('account_manager', 'admin'), async (_req, res) => {
  const r = await pool.query('SELECT * FROM rm_suppliers ORDER BY name');
  res.json(r.rows);
});
router.post('/rm-suppliers', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { name, contact_email, contact_phone } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required.' });
  const r = await pool.query(
    'INSERT INTO rm_suppliers (name, contact_email, contact_phone) VALUES ($1,$2,$3) RETURNING *',
    [name, contact_email, contact_phone]
  );
  res.status(201).json(r.rows[0]);
});

router.get('/pm-suppliers', authenticate, authorize('account_manager', 'admin'), async (_req, res) => {
  const r = await pool.query('SELECT * FROM pm_suppliers ORDER BY name');
  res.json(r.rows);
});
router.post('/pm-suppliers', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { name, contact_email, contact_phone } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required.' });
  const r = await pool.query(
    'INSERT INTO pm_suppliers (name, contact_email, contact_phone) VALUES ($1,$2,$3) RETURNING *',
    [name, contact_email, contact_phone]
  );
  res.status(201).json(r.rows[0]);
});

// ---------- Raw materials (AM manages; brand/AM can view) ----------
router.get('/raw-materials', authenticate, async (_req, res) => {
  const r = await pool.query('SELECT * FROM raw_materials ORDER BY name');
  res.json(r.rows);
});
router.post('/raw-materials', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { name, iupac_name, price } = req.body;
  const r = await pool.query(
    'INSERT INTO raw_materials (name, iupac_name, price) VALUES ($1,$2,$3) RETURNING *',
    [name || 'Raw Material', iupac_name, price || 0]
  );
  res.status(201).json(r.rows[0]);
});
router.put('/raw-materials/:id', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { name, iupac_name, price } = req.body;
  const r = await pool.query(
    `UPDATE raw_materials SET name = COALESCE($1,name), iupac_name = COALESCE($2,iupac_name),
     old_price = price, latest_price = COALESCE($3, latest_price), price = COALESCE($3, price), updated_at = NOW()
     WHERE id = $4 RETURNING *`,
    [name, iupac_name, price, req.params.id]
  );
  if (r.rows.length === 0) return res.status(404).json({ error: 'Raw material not found.' });
  res.json(r.rows[0]);
});

// ---------- Packaging materials ----------
router.get('/packaging-materials', authenticate, async (_req, res) => {
  const r = await pool.query('SELECT * FROM packaging_materials ORDER BY name');
  res.json(r.rows);
});
router.post('/packaging-materials', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { name, current_status, price, material_shape } = req.body;
  const r = await pool.query(
    'INSERT INTO packaging_materials (name, current_status, price, material_shape) VALUES ($1,$2,$3,$4) RETURNING *',
    [name || 'Packaging Material', current_status, price || 0, material_shape || 'Material Shape']
  );
  res.status(201).json(r.rows[0]);
});
router.put('/packaging-materials/:id', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { name, current_status, price, material_shape } = req.body;
  const r = await pool.query(
    `UPDATE packaging_materials SET name = COALESCE($1,name), current_status = COALESCE($2,current_status),
     old_price = price, latest_price = COALESCE($3, latest_price), price = COALESCE($3, price), material_shape = COALESCE($4, material_shape)
     WHERE id = $5 RETURNING *`,
    [name, current_status, price, material_shape, req.params.id]
  );
  if (r.rows.length === 0) return res.status(404).json({ error: 'Packaging material not found.' });
  res.json(r.rows[0]);
});

// ---------- Product <-> material pricing (brand/AM can view for a case's product) ----------
// GET /api/materials/product-raw-materials?case_id=
router.get('/product-raw-materials', authenticate, async (req, res) => {
  const { case_id, product_id } = req.query;
  try {
    let productId = product_id;
    if (case_id && !productId) {
      const pc = await pool.query('SELECT product_id FROM product_cases WHERE case_id = $1 LIMIT 1', [case_id]);
      productId = pc.rows[0]?.product_id;
    }
    if (!productId) return res.json([]);
    const r = await pool.query(
      `SELECT prm.*, rm.name, rm.iupac_name FROM product_raw_materials prm
       JOIN raw_materials rm ON rm.id = prm.raw_material_id WHERE prm.product_id = $1`,
      [productId]
    );
    res.json(r.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load product raw materials.' });
  }
});

// GET /api/materials/product-packaging-materials?case_id=
router.get('/product-packaging-materials', authenticate, async (req, res) => {
  const { case_id, product_id } = req.query;
  try {
    let productId = product_id;
    if (case_id && !productId) {
      const pc = await pool.query('SELECT product_id FROM product_cases WHERE case_id = $1 LIMIT 1', [case_id]);
      productId = pc.rows[0]?.product_id;
    }
    if (!productId) return res.json([]);
    const r = await pool.query(
      `SELECT ppm.*, pm.name FROM product_packaging_materials ppm
       JOIN packaging_materials pm ON pm.id = ppm.packaging_material_id WHERE ppm.product_id = $1`,
      [productId]
    );
    res.json(r.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load product packaging materials.' });
  }
});

// POST /api/materials/product-raw-materials — attach a raw material to a product with a price (AM)
router.post('/product-raw-materials', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { product_id, raw_material_id, price, supplier_id } = req.body;
  try {
    const r = await pool.query(
      `INSERT INTO product_raw_materials (product_id, raw_material_id, price, supplier_id) VALUES ($1,$2,$3,$4)
       ON CONFLICT (product_id, raw_material_id) DO UPDATE SET price = EXCLUDED.price, supplier_id = EXCLUDED.supplier_id
       RETURNING *`,
      [product_id, raw_material_id, price, supplier_id || null]
    );
    res.status(201).json(r.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not attach raw material.' });
  }
});

router.post('/product-packaging-materials', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { product_id, packaging_material_id, price, supplier_id } = req.body;
  try {
    const r = await pool.query(
      `INSERT INTO product_packaging_materials (product_id, packaging_material_id, price, supplier_id) VALUES ($1,$2,$3,$4)
       ON CONFLICT (product_id, packaging_material_id) DO UPDATE SET price = EXCLUDED.price, supplier_id = EXCLUDED.supplier_id
       RETURNING *`,
      [product_id, packaging_material_id, price, supplier_id || null]
    );
    res.status(201).json(r.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not attach packaging material.' });
  }
});

// ---------- Bill of Materials by case ----------
// GET /api/materials/cases/:caseId/bom — builds/refreshes the BOM from the
// product's current raw/packaging materials, like get_bom_by_case
router.get('/cases/:caseId/bom', authenticate, async (req, res) => {
  const client = await pool.connect();
  try {
    const caseRes = await client.query('SELECT * FROM cases WHERE id = $1', [req.params.caseId]);
    if (caseRes.rows.length === 0) return res.status(404).json({ error: 'Case not found.' });
    const brandOwnerId = caseRes.rows[0].brand_id;

    const pc = await client.query('SELECT product_id FROM product_cases WHERE case_id = $1 LIMIT 1', [req.params.caseId]);
    if (pc.rows.length === 0) return res.status(404).json({ error: 'No product associated with this case.' });
    const productId = pc.rows[0].product_id;

    await client.query('BEGIN');
    let bom = await client.query(
      'SELECT * FROM bill_of_materials WHERE product_id = $1 AND brand_owner_id = $2',
      [productId, brandOwnerId]
    );
    if (bom.rows.length === 0) {
      bom = await client.query(
        'INSERT INTO bill_of_materials (product_id, brand_owner_id) VALUES ($1,$2) RETURNING *',
        [productId, brandOwnerId]
      );
    }
    const bomId = bom.rows[0].id;

    const rawMaterials = await client.query('SELECT * FROM product_raw_materials WHERE product_id = $1', [productId]);
    for (const rm of rawMaterials.rows) {
      await client.query(
        `INSERT INTO bom_raw_materials (bom_id, raw_material_id, price_per_unit) VALUES ($1,$2,$3)
         ON CONFLICT (bom_id, raw_material_id) DO NOTHING`,
        [bomId, rm.raw_material_id, rm.price]
      );
    }
    const packagingMaterials = await client.query('SELECT * FROM product_packaging_materials WHERE product_id = $1', [productId]);
    for (const pm of packagingMaterials.rows) {
      await client.query(
        `INSERT INTO bom_packaging_materials (bom_id, packaging_material_id, price_per_unit) VALUES ($1,$2,$3)
         ON CONFLICT (bom_id, packaging_material_id) DO NOTHING`,
        [bomId, pm.packaging_material_id, pm.price]
      );
    }

    const totalRes = await client.query(
      `SELECT
         COALESCE((SELECT SUM(quantity * price_per_unit) FROM bom_raw_materials WHERE bom_id = $1), 0) +
         COALESCE((SELECT SUM(quantity * price_per_unit) FROM bom_packaging_materials WHERE bom_id = $1), 0) AS total`,
      [bomId]
    );
    await client.query('UPDATE bill_of_materials SET total_cost = $1 WHERE id = $2', [totalRes.rows[0].total, bomId]);
    await client.query('COMMIT');

    const bomRaw = await pool.query(
      `SELECT brm.*, rm.name FROM bom_raw_materials brm JOIN raw_materials rm ON rm.id = brm.raw_material_id WHERE brm.bom_id = $1`,
      [bomId]
    );
    const bomPackaging = await pool.query(
      `SELECT bpm.*, pm.name FROM bom_packaging_materials bpm JOIN packaging_materials pm ON pm.id = bpm.packaging_material_id WHERE bpm.bom_id = $1`,
      [bomId]
    );
    res.json({ id: bomId, product_id: productId, total_cost: totalRes.rows[0].total, raw_materials: bomRaw.rows, packaging_materials: bomPackaging.rows });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Could not build bill of materials.' });
  } finally {
    client.release();
  }
});

// PUT /api/materials/cases/:caseId/bom — set quantities/prices on BOM line items
// Body: { raw_materials: [{id, quantity, price_per_unit}], packaging_materials: [...] }
// (ported from update_by_case)
router.put('/cases/:caseId/bom', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { raw_materials = [], packaging_materials = [] } = req.body;
  const client = await pool.connect();
  try {
    const pc = await client.query('SELECT product_id FROM product_cases WHERE case_id = $1 LIMIT 1', [req.params.caseId]);
    if (pc.rows.length === 0) return res.status(404).json({ error: 'No product associated with this case.' });
    const caseRes = await client.query('SELECT brand_id FROM cases WHERE id = $1', [req.params.caseId]);
    const bomRes = await client.query(
      'SELECT id FROM bill_of_materials WHERE product_id = $1 AND brand_owner_id = $2',
      [pc.rows[0].product_id, caseRes.rows[0].brand_id]
    );
    if (bomRes.rows.length === 0) return res.status(404).json({ error: 'BOM not found — call GET first to initialize it.' });
    const bomId = bomRes.rows[0].id;

    await client.query('BEGIN');
    for (const rm of raw_materials) {
      await client.query(
        'UPDATE bom_raw_materials SET quantity = $1, price_per_unit = $2 WHERE id = $3 AND bom_id = $4',
        [rm.quantity, rm.price_per_unit, rm.id, bomId]
      );
    }
    for (const pm of packaging_materials) {
      await client.query(
        'UPDATE bom_packaging_materials SET quantity = $1, price_per_unit = $2 WHERE id = $3 AND bom_id = $4',
        [pm.quantity, pm.price_per_unit, pm.id, bomId]
      );
    }
    const totalRes = await client.query(
      `SELECT
         COALESCE((SELECT SUM(quantity * price_per_unit) FROM bom_raw_materials WHERE bom_id = $1), 0) +
         COALESCE((SELECT SUM(quantity * price_per_unit) FROM bom_packaging_materials WHERE bom_id = $1), 0) AS total`,
      [bomId]
    );
    await client.query('UPDATE bill_of_materials SET total_cost = $1 WHERE id = $2', [totalRes.rows[0].total, bomId]);
    await client.query('COMMIT');
    res.json({ id: bomId, total_cost: totalRes.rows[0].total });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Could not update bill of materials.' });
  } finally {
    client.release();
  }
});

module.exports = router;
