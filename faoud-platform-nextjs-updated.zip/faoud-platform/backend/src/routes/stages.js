const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

async function isAM(userId) {
  // In this merged schema every 'account_manager' role user is implicitly
  // an AM profile (shadow-api kept a separate AM model; we didn't need a
  // separate table since the role column already carries that meaning).
  const r = await pool.query('SELECT role FROM users WHERE id = $1', [userId]);
  return r.rows[0]?.role === 'account_manager' || r.rows[0]?.role === 'admin';
}

// GET /api/cases/:caseId/stages  (ported from GetAvailableStagesView)
router.get('/:caseId/stages', authenticate, authorize('account_manager', 'brand', 'admin'), async (req, res) => {
  try {
    const stagesRes = await pool.query('SELECT * FROM stages ORDER BY "order" ASC');
    const progressRes = await pool.query(
      `SELECT cps.*, s.name, s.order as stage_order FROM case_progress_stages cps
       JOIN stages s ON s.id = cps.stage_id
       WHERE cps.case_id = $1 AND cps.completion_date IS NOT NULL
       ORDER BY cps.order_in_timeline ASC`,
      [req.params.caseId]
    );
    const completed = progressRes.rows;

    if (await isAM(req.user.id)) {
      await pool.query('UPDATE cases SET last_opened_by_am_at = NOW() WHERE id = $1', [req.params.caseId]);
    }

    const stages = stagesRes.rows.map((stage) => {
      const match = completed.find((c) => c.stage_id === stage.id);
      return {
        id: stage.id,
        name: stage.name,
        order: stage.order,
        completed: !!match,
        completion_date: match ? match.completion_date : null
      };
    });

    const lastCompleted = completed[completed.length - 1];
    const nextStage = lastCompleted
      ? stagesRes.rows.find((s) => s.order > lastCompleted.stage_order)
      : stagesRes.rows[0];

    res.json({ stages, next_stage: nextStage ? nextStage.name : null });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load stages.' });
  }
});

// POST /api/cases/:caseId/stages  (ported from UpdateCaseStageView)
// Body: { stage_name, completion_date? }
// Toggles the stage: if already completed, un-completes it; otherwise marks it complete.
router.post('/:caseId/stages', authenticate, authorize('account_manager', 'brand', 'admin'), async (req, res) => {
  const { stage_name, completion_date } = req.body;
  if (!stage_name) return res.status(400).json({ error: 'stage_name is required.' });

  try {
    const stageRes = await pool.query('SELECT * FROM stages WHERE name = $1', [stage_name]);
    if (stageRes.rows.length === 0) return res.status(400).json({ error: 'Invalid stage name.' });
    const stage = stageRes.rows[0];

    if (stage.name === 'Reviewed') {
      return res.status(400).json({
        error: "Use the publish flow to complete 'Reviewed' (not ported in this pass)."
      });
    }

    const existing = await pool.query(
      'SELECT * FROM case_progress_stages WHERE case_id = $1 AND stage_id = $2',
      [req.params.caseId, stage.id]
    );

    if (existing.rows.length > 0) {
      await pool.query('DELETE FROM case_progress_stages WHERE id = $1', [existing.rows[0].id]);
      return res.json({ message: `Stage '${stage_name}' has been deleted.` });
    }

    await pool.query(
      `INSERT INTO case_progress_stages (case_id, stage_id, order_in_timeline, completion_date)
       VALUES ($1, $2, $3, $4)`,
      [req.params.caseId, stage.id, stage.order, completion_date || new Date()]
    );
    res.json({ message: `Stage '${stage_name}' has been marked as completed.` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not update stage.' });
  }
});

module.exports = router;
