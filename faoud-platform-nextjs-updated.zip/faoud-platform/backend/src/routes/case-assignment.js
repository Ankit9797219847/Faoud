const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');
const { sendMail } = require('../utils/mailer');

const router = express.Router();

function requirePrivilegedAM(req, res, next) {
  if (req.user.role !== 'account_manager' && req.user.role !== 'admin') {
    return res.status(403).json({ detail: 'Account manager access required.' });
  }
  // req.privileged is filled by the query below where needed; admins always count as privileged.
  next();
}

async function amRow(userId) {
  const r = await pool.query('SELECT id, full_name, is_privileged_am, role FROM users WHERE id = $1', [userId]);
  return r.rows[0];
}

// GET /api/cases/:caseId/assignment  (ported from CaseAssignmentView.get)
router.get('/:caseId/assignment', authenticate, requirePrivilegedAM, async (req, res) => {
  const me = await amRow(req.user.id);
  if (!me || (!me.is_privileged_am && me.role !== 'admin')) {
    return res.status(403).json({ detail: 'Only privileged Account Managers can view assignment.' });
  }

  try {
    const caseRes = await pool.query('SELECT * FROM cases WHERE id = $1', [req.params.caseId]);
    if (caseRes.rows.length === 0) return res.status(404).json({ detail: 'Case not found.' });
    const caseRow = caseRes.rows[0];

    const viewers = await pool.query(
      `SELECT u.id, u.full_name AS name, u.email FROM case_am_assignments a
       JOIN users u ON u.id = a.am_user_id
       WHERE a.case_id = $1 ORDER BY u.full_name`,
      [req.params.caseId]
    );

    // "load" = how many cases each AM currently carries, lowest first — same
    // load-balancing hint shadow-api surfaced in the assignment picker.
    const assignable = await pool.query(
      `SELECT u.id, u.full_name AS name, u.email, COUNT(a.case_id) AS load
       FROM users u
       LEFT JOIN case_am_assignments a ON a.am_user_id = u.id
       WHERE u.role = 'account_manager'
       GROUP BY u.id
       ORDER BY load ASC, u.id ASC`
    );

    let brandCaseCount = 1;
    if (caseRow.brand_id) {
      const c = await pool.query(
        "SELECT COUNT(*) FROM cases WHERE brand_id = $1 AND active != 'deleted'",
        [caseRow.brand_id]
      );
      brandCaseCount = Number(c.rows[0].count);
    }

    res.json({
      case_id: caseRow.id,
      brand_owner_id: caseRow.brand_id,
      brand_case_count: brandCaseCount,
      viewer_ams: viewers.rows,
      assignable_ams: assignable.rows
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load assignment data.' });
  }
});

// POST /api/cases/:caseId/assignment  (ported from CaseAssignmentView.post)
// Body: { action: 'assign'|'unassign', scope: 'brand'|'case', am_id? }
router.post('/:caseId/assignment', authenticate, requirePrivilegedAM, async (req, res) => {
  const me = await amRow(req.user.id);
  if (!me || (!me.is_privileged_am && me.role !== 'admin')) {
    return res.status(403).json({ detail: 'Only privileged Account Managers can reassign cases.' });
  }

  const action = (req.body.action || 'assign').toLowerCase();
  const scope = (req.body.scope || 'brand').toLowerCase();
  if (!['assign', 'unassign'].includes(action)) {
    return res.status(400).json({ detail: "action must be either 'assign' or 'unassign'." });
  }
  if (!['brand', 'case'].includes(scope)) {
    return res.status(400).json({ detail: "scope must be either 'brand' or 'case'." });
  }

  let targetAM = null;
  if (action === 'assign') {
    if (!req.body.am_id) return res.status(400).json({ detail: 'am_id is required.' });
    const t = await pool.query(
      "SELECT id, full_name AS name, email FROM users WHERE id = $1 AND role = 'account_manager'",
      [req.body.am_id]
    );
    if (t.rows.length === 0) return res.status(404).json({ detail: 'Account Manager not found.' });
    targetAM = t.rows[0];
  }

  const client = await pool.connect();
  try {
    const caseRes = await client.query('SELECT * FROM cases WHERE id = $1', [req.params.caseId]);
    if (caseRes.rows.length === 0) return res.status(404).json({ detail: 'Case not found.' });
    const caseRow = caseRes.rows[0];
    if (!caseRow.brand_id) {
      return res.status(400).json({ detail: 'This case has no brand owner.' });
    }

    let affectedCases;
    if (scope === 'case') {
      affectedCases = [caseRow];
    } else {
      const r = await client.query(
        "SELECT * FROM cases WHERE brand_id = $1 AND active != 'deleted' ORDER BY id",
        [caseRow.brand_id]
      );
      affectedCases = r.rows.length ? r.rows : [caseRow];
    }

    const privileged = await client.query(
      "SELECT id, full_name AS name FROM users WHERE role = 'account_manager' AND is_privileged_am = TRUE"
    );

    await client.query('BEGIN');
    for (const c of affectedCases) {
      // Remove all non-privileged AMs currently on the case
      await client.query(
        `DELETE FROM case_am_assignments
         WHERE case_id = $1
           AND am_user_id IN (SELECT id FROM users WHERE role = 'account_manager' AND is_privileged_am = FALSE)`,
        [c.id]
      );

      if (action === 'assign' && targetAM) {
        await client.query(
          `INSERT INTO case_am_assignments (case_id, am_user_id) VALUES ($1, $2)
           ON CONFLICT DO NOTHING`,
          [c.id, targetAM.id]
        );
      }

      for (const p of privileged.rows) {
        await client.query(
          `INSERT INTO case_am_assignments (case_id, am_user_id) VALUES ($1, $2)
           ON CONFLICT DO NOTHING`,
          [c.id, p.id]
        );
      }

      const message =
        action === 'assign'
          ? scope === 'case'
            ? `Assigned this case to ${targetAM.name} by ${me.full_name}.`
            : `Assigned to ${targetAM.name} by ${me.full_name}.`
          : scope === 'case'
          ? `Unassigned this case by ${me.full_name}.`
          : `Unassigned by ${me.full_name}.`;

      await client.query('INSERT INTO alerts (case_id, message) VALUES ($1, $2)', [c.id, message]);
    }
    await client.query('COMMIT');

    if (action === 'assign' && targetAM) {
      const t = await pool.query('SELECT email FROM users WHERE id = $1', [targetAM.id]);
      if (t.rows[0]?.email) {
        sendMail({
          to: t.rows[0].email,
          subject: `You've been assigned ${affectedCases.length} case(s) on Faoud`,
          text: `${me.full_name} assigned you to ${affectedCases.length} case(s). Log in to the ops console to view them.`
        }).catch(() => {});
      }
    }

    const refreshedViewers = await client.query(
      `SELECT u.id, u.full_name AS name, u.email FROM case_am_assignments a
       JOIN users u ON u.id = a.am_user_id
       WHERE a.case_id = $1 ORDER BY u.full_name`,
      [caseRow.id]
    );

    res.json({
      case_id: caseRow.id,
      brand_owner_id: caseRow.brand_id,
      action,
      scope,
      brand_case_count: affectedCases.length,
      affected_case_ids: affectedCases.map((c) => c.id),
      assigned_am: targetAM,
      viewer_ams: refreshedViewers.rows,
      detail:
        action === 'assign'
          ? scope === 'case'
            ? `Case #${caseRow.id} is now assigned to ${targetAM.name}.`
            : `${affectedCases.length} case(s) for this brand are now assigned to ${targetAM.name}.`
          : scope === 'case'
          ? `Case #${caseRow.id} has been unassigned.`
          : `Cleared non-privileged assignees from ${affectedCases.length} case(s) for this brand.`
    });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Could not update assignment.' });
  } finally {
    client.release();
  }
});

module.exports = router;
