const express = require('express');
const { v4: uuidv4 } = require('uuid');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

function generateOrderNumber() {
  return 'FAO-' + Date.now().toString(36).toUpperCase() + '-' + uuidv4().slice(0, 4).toUpperCase();
}

// POST /api/orders  (brand places an order / requests a quote)
router.post('/', authenticate, authorize('brand', 'admin'), async (req, res) => {
  const { factory_id, product_id, quantity, notes } = req.body;
  if (!factory_id || !quantity) {
    return res.status(400).json({ error: 'factory_id and quantity are required.' });
  }
  try {
    const order_number = generateOrderNumber();
    const result = await pool.query(
      `INSERT INTO orders (order_number, brand_id, factory_id, product_id, quantity, notes, status)
       VALUES ($1,$2,$3,$4,$5,$6,'quote_requested') RETURNING *`,
      [order_number, req.user.id, factory_id, product_id || null, quantity, notes || null]
    );
    const order = result.rows[0];
    await pool.query(
      `INSERT INTO order_status_history (order_id, status, note, changed_by) VALUES ($1,$2,$3,$4)`,
      [order.id, 'quote_requested', 'Order created', req.user.id]
    );
    res.status(201).json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create order.' });
  }
});

// GET /api/orders  (brand: own orders, factory: incoming orders, admin: all)
router.get('/', authenticate, async (req, res) => {
  try {
    let query, params;
    if (req.user.role === 'brand') {
      query = 'SELECT * FROM orders WHERE brand_id = $1 ORDER BY created_at DESC';
      params = [req.user.id];
    } else if (req.user.role === 'factory') {
      const factory = await pool.query('SELECT id FROM factories WHERE user_id = $1', [req.user.id]);
      if (factory.rows.length === 0) return res.json([]);
      query = 'SELECT * FROM orders WHERE factory_id = $1 ORDER BY created_at DESC';
      params = [factory.rows[0].id];
    } else {
      query = 'SELECT * FROM orders ORDER BY created_at DESC LIMIT 200';
      params = [];
    }
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch orders.' });
  }
});

// GET /api/orders/:id  (with status history)
router.get('/:id', authenticate, async (req, res) => {
  try {
    const order = await pool.query('SELECT * FROM orders WHERE id = $1', [req.params.id]);
    if (order.rows.length === 0) return res.status(404).json({ error: 'Order not found.' });
    const history = await pool.query(
      'SELECT * FROM order_status_history WHERE order_id = $1 ORDER BY created_at ASC',
      [req.params.id]
    );
    res.json({ ...order.rows[0], history: history.rows });
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch order.' });
  }
});

// PATCH /api/orders/:id/status  (factory/admin updates status)
router.patch('/:id/status', authenticate, authorize('factory', 'admin'), async (req, res) => {
  const { status, note } = req.body;
  const validStatuses = ['quote_requested','quoted','confirmed','in_production','quality_check','dispatched','delivered','cancelled'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: 'Invalid status value.' });
  }
  try {
    const result = await pool.query(
      'UPDATE orders SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
      [status, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Order not found.' });
    await pool.query(
      'INSERT INTO order_status_history (order_id, status, note, changed_by) VALUES ($1,$2,$3,$4)',
      [req.params.id, status, note || null, req.user.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Could not update order status.' });
  }
});

module.exports = router;
