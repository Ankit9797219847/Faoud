const express = require('express');
const crypto = require('crypto');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// --- Razorpay client -------------------------------------------------------
// Lazily constructed so the server can boot without credentials. Every
// route below checks razorpayClient() first and returns 501 with a clear
// message if RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET aren't set yet — add
// them to backend/.env (see .env.example) once you have your Razorpay
// credentials, no code changes needed.
let Razorpay;
function razorpayClient() {
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return null;
  if (!Razorpay) Razorpay = require('razorpay'); // only require()'d once actually configured
  return new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET
  });
}

function notConfigured(res) {
  return res.status(501).json({
    error:
      'Payment gateway not configured. Add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET to backend/.env, then restart the server.'
  });
}

// POST /api/payments/orders  (AM opens a payment Order for a case)
router.post('/orders', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { case_id, total_amount, expiry_days } = req.body;
  if (!case_id || total_amount == null) {
    return res.status(400).json({ error: 'case_id and total_amount are required.' });
  }
  try {
    const orderId = `ORD-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    const expiry = new Date(Date.now() + (expiry_days || 7) * 86400000);
    const result = await pool.query(
      `INSERT INTO payment_orders (order_id, case_id, total_amount, amount_due, expiry_date)
       VALUES ($1, $2, $3, $3, $4) RETURNING *`,
      [orderId, case_id, total_amount, expiry]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create payment order.' });
  }
});

// GET /api/payments/case/:caseId/orders  (ported from CaseOrdersAPIView)
router.get('/case/:caseId/orders', authenticate, async (req, res) => {
  const result = await pool.query(
    `SELECT po.*, json_agg(pl.* ORDER BY pl.created_at) FILTER (WHERE pl.id IS NOT NULL) AS layers
     FROM payment_orders po
     LEFT JOIN payment_layers pl ON pl.order_id = po.id
     WHERE po.case_id = $1
     GROUP BY po.id
     ORDER BY po.created_at DESC`,
    [req.params.caseId]
  );
  res.json(result.rows);
});

// GET /api/payments/transactions  (ported from BrandOwnerTransactionsAPIView
// — every PAID layer across the Brand Owner's own cases)
router.get('/transactions', authenticate, authorize('brand'), async (req, res) => {
  const result = await pool.query(
    `SELECT pl.*, po.order_id, c.name AS case_name FROM payment_layers pl
     JOIN payment_orders po ON po.id = pl.order_id
     JOIN cases c ON c.id = po.case_id
     WHERE c.brand_id = $1 AND pl.status = 'PAID'
     ORDER BY pl.created_at DESC`,
    [req.user.id]
  );
  res.json(result.rows);
});

// POST /api/payments/orders/:orderId/advance  (AM step of
// InitiateAdvancePaymentAPIView — opens an ADVANCE layer at half the amount
// due, or an AM-specified override_amount)
router.post('/orders/:orderId/advance', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  try {
    const orderRes = await pool.query('SELECT * FROM payment_orders WHERE id = $1', [req.params.orderId]);
    if (orderRes.rows.length === 0) return res.status(404).json({ error: 'Order not found.' });
    const order = orderRes.rows[0];
    const amount = req.body.override_amount || Number(order.amount_due) / 2;
    const expiry = new Date(Date.now() + 3 * 86400000);
    const result = await pool.query(
      `INSERT INTO payment_layers (order_id, amount, layer_type, expiry_date)
       VALUES ($1, $2, 'ADVANCE', $3) RETURNING *`,
      [order.id, amount, expiry]
    );
    res.status(201).json({ ...result.rows[0], status_message: 'Payment layer created successfully by Account Manager.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create advance payment layer.' });
  }
});

// POST /api/payments/orders/:orderId/final  (ported from
// InitiateFinalPaymentAPIView — shadow-api computes `final_amount` via a
// pricing-formula engine in core/utils that wasn't ported; the AM supplies
// the amount directly here instead)
router.post('/orders/:orderId/final', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { amount } = req.body;
  if (amount == null) return res.status(400).json({ error: 'amount is required.' });
  try {
    const orderRes = await pool.query('SELECT * FROM payment_orders WHERE id = $1', [req.params.orderId]);
    if (orderRes.rows.length === 0) return res.status(404).json({ error: 'Order not found.' });
    const expiry = new Date(Date.now() + 5 * 86400000);
    const result = await pool.query(
      `INSERT INTO payment_layers (order_id, amount, layer_type, expiry_date)
       VALUES ($1, $2, 'FINAL', $3) RETURNING *`,
      [req.params.orderId, amount, expiry]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create final payment layer.' });
  }
});

// POST /api/payments/layers/:layerId/checkout  (Brand Owner step — creates
// the actual Razorpay order for a layer, ported from the BO branch of
// InitiateAdvancePaymentAPIView / InitiateFinalPaymentAPIView)
router.post('/layers/:layerId/checkout', authenticate, authorize('brand'), async (req, res) => {
  const razorpay = razorpayClient();
  if (!razorpay) return notConfigured(res);

  try {
    const layerRes = await pool.query(
      `SELECT pl.*, po.order_id AS human_order_id FROM payment_layers pl
       JOIN payment_orders po ON po.id = pl.order_id WHERE pl.id = $1`,
      [req.params.layerId]
    );
    if (layerRes.rows.length === 0) return res.status(404).json({ error: 'Payment layer not found.' });
    const layer = layerRes.rows[0];

    const razorpayOrder = await razorpay.orders.create({
      amount: Math.round(Number(layer.amount) * 100), // paisa
      currency: 'INR',
      receipt: String(layer.id),
      payment_capture: 1
    });

    await pool.query('UPDATE payment_layers SET razorpay_order_id = $1 WHERE id = $2', [
      razorpayOrder.id,
      layer.id
    ]);

    res.json({
      razorpay_order_id: razorpayOrder.id,
      razorpay_key_id: process.env.RAZORPAY_KEY_ID,
      amount: layer.amount,
      currency: 'INR',
      order_id: layer.human_order_id,
      payment_layer_id: layer.id,
      layer_type: layer.layer_type,
      expiry_date: layer.expiry_date
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create Razorpay order.' });
  }
});

// POST /api/payments/verify  (ported from VerifyPaymentAPIView — the
// ServicePayment/service_request branch was dropped since the `services`
// app wasn't ported)
router.post('/verify', authenticate, async (req, res) => {
  const razorpay = razorpayClient();
  if (!razorpay) return notConfigured(res);

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ status: 'failure', error: 'Missing Razorpay parameters.' });
  }

  const expectedSignature = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  if (expectedSignature !== razorpay_signature) {
    return res.status(400).json({ status: 'failure' });
  }

  try {
    const layerRes = await pool.query('SELECT * FROM payment_layers WHERE razorpay_order_id = $1', [
      razorpay_order_id
    ]);
    if (layerRes.rows.length === 0) {
      return res.status(404).json({ status: 'failure', error: 'Payment record not found' });
    }
    const layer = layerRes.rows[0];

    await pool.query(
      `UPDATE payment_layers SET status = 'PAID', razorpay_payment_id = $1, razorpay_signature = $2 WHERE id = $3`,
      [razorpay_payment_id, razorpay_signature, layer.id]
    );

    // Roll the order's amount_due down and flip its status.
    const orderRes = await pool.query('SELECT * FROM payment_orders WHERE id = $1', [layer.order_id]);
    const order = orderRes.rows[0];
    const newDue = Math.max(0, Number(order.amount_due) - Number(layer.amount));
    await pool.query('UPDATE payment_orders SET amount_due = $1, status = $2 WHERE id = $3', [
      newDue,
      newDue === 0 ? 'PAID' : 'PARTIALLY_PAID',
      order.id
    ]);

    if (layer.layer_type === 'SAMPLE') {
      const bidIds = (layer.notes && layer.notes.bid_ids) || [];
      if (bidIds.length) {
        await pool.query(`UPDATE bids SET sample_paid = TRUE, status = 'sample_ordered' WHERE id = ANY($1::uuid[])`, [
          bidIds
        ]);
      }
    }

    res.json({ status: 'success' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ status: 'failure', error: 'Could not verify payment.' });
  }
});

// POST /api/payments/webhook  (ported from PaymentWebhookAPIView — public,
// authenticated via Razorpay's webhook signature header instead of a JWT)
router.post('/webhook', express.json({ type: '*/*' }), async (req, res) => {
  const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!webhookSecret) return notConfigured(res);

  const signature = req.headers['x-razorpay-signature'];
  const expected = crypto
    .createHmac('sha256', webhookSecret)
    .update(JSON.stringify(req.body))
    .digest('hex');

  if (signature !== expected) {
    return res.status(400).json({ error: 'Invalid webhook signature.' });
  }

  try {
    const paymentEntity = req.body?.payload?.payment?.entity;
    const orderId = paymentEntity?.order_id;
    if (orderId) {
      await pool.query(
        `UPDATE payment_orders SET razorpay_order_id = razorpay_order_id WHERE razorpay_order_id = $1`,
        [orderId]
      );
    }
    res.json({ status: 'ok' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Webhook processing failed.' });
  }
});

module.exports = router;
