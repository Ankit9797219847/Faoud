// Ported from shadow-api's formulation.views.UploadFormulationView, plus the
// payment-gated document swap that lived in case.views (Brand Owners see a
// placeholder until they've paid the case's advance payment layer).
const express = require('express');
const multer = require('multer');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

let s3Client;
function getS3() {
  if (!process.env.S3_BUCKET || !process.env.S3_ACCESS_KEY_ID) return null;
  if (!s3Client) {
    const { S3Client } = require('@aws-sdk/client-s3');
    s3Client = new S3Client({
      region: process.env.S3_REGION || 'ap-south-1',
      endpoint: process.env.S3_ENDPOINT || undefined,
      credentials: {
        accessKeyId: process.env.S3_ACCESS_KEY_ID,
        secretAccessKey: process.env.S3_SECRET_ACCESS_KEY
      }
    });
  }
  return s3Client;
}

function notConfigured(res) {
  return res.status(501).json({
    error: 'File storage not configured. Add S3_BUCKET, S3_ACCESS_KEY_ID, and S3_SECRET_ACCESS_KEY to backend/.env.'
  });
}

// POST /api/formulation/cases/:caseId/upload — AM/formulator uploads the
// formulation PDF, creating or replacing the Formulation row for the case's product.
router.post(
  '/cases/:caseId/upload',
  authenticate,
  authorize('account_manager', 'formulator', 'admin'),
  upload.single('formulation'),
  async (req, res) => {
    const s3 = getS3();
    if (!s3) return notConfigured(res);
    if (!req.file) return res.status(400).json({ error: 'No formulation file provided.' });

    const client = await pool.connect();
    try {
      const pc = await client.query('SELECT product_id FROM product_cases WHERE case_id = $1 LIMIT 1', [req.params.caseId]);
      if (pc.rows.length === 0) {
        return res.status(400).json({ error: 'No product associated with this case. Add a product before uploading formulation.' });
      }
      const productId = pc.rows[0].product_id;

      const { PutObjectCommand } = require('@aws-sdk/client-s3');
      const key = `formulation/${req.params.caseId}/${Date.now()}-${req.file.originalname}`;
      await s3.send(new PutObjectCommand({ Bucket: process.env.S3_BUCKET, Key: key, Body: req.file.buffer, ContentType: req.file.mimetype }));

      await client.query('BEGIN');
      let formulation = await client.query('SELECT * FROM formulations WHERE product_id = $1', [productId]);
      if (formulation.rows.length === 0) {
        formulation = await client.query(
          'INSERT INTO formulations (product_id, document_key) VALUES ($1,$2) RETURNING *',
          [productId, key]
        );
      } else {
        formulation = await client.query(
          'UPDATE formulations SET document_key = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
          [key, formulation.rows[0].id]
        );
      }
      await client.query('UPDATE cases SET formulation_id = $1 WHERE id = $2', [formulation.rows[0].id, req.params.caseId]);
      await client.query('COMMIT');

      res.json({ message: 'Formulation uploaded successfully.', formulation: formulation.rows[0] });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error(err);
      res.status(500).json({ error: 'Upload failed.' });
    } finally {
      client.release();
    }
  }
);

// GET /api/formulation/cases/:caseId — fetch the formulation document link.
// Brand Owners only get the real file once the case's ADVANCE payment layer
// is PAID; otherwise they get a placeholder flag (ported from the
// payment-gated formulation document swap in case.views).
router.get('/cases/:caseId', authenticate, async (req, res) => {
  try {
    const caseRes = await pool.query('SELECT formulation_id, brand_id FROM cases WHERE id = $1', [req.params.caseId]);
    if (caseRes.rows.length === 0) return res.status(404).json({ error: 'Case not found.' });
    const { formulation_id: formulationId, brand_id: brandId } = caseRes.rows[0];
    if (!formulationId) return res.status(404).json({ error: 'No formulation uploaded for this case yet.' });

    const formulation = await pool.query('SELECT * FROM formulations WHERE id = $1', [formulationId]);
    const isBrandOwner = req.user.role === 'brand' && req.user.id === brandId;

    if (isBrandOwner) {
      const paidAdvance = await pool.query(
        `SELECT 1 FROM payment_layers pl
         JOIN payment_orders po ON po.id = pl.order_id
         WHERE po.case_id = $1 AND pl.layer_type = 'ADVANCE' AND pl.status = 'PAID' LIMIT 1`,
        [req.params.caseId]
      );
      if (paidAdvance.rows.length === 0) {
        return res.json({ placeholder: true, message: 'Pay the case advance to unlock the formulation document.' });
      }
    }

    const s3 = getS3();
    let url = null;
    if (s3 && formulation.rows[0].document_key) {
      const { GetObjectCommand } = require('@aws-sdk/client-s3');
      const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
      url = await getSignedUrl(s3, new GetObjectCommand({ Bucket: process.env.S3_BUCKET, Key: formulation.rows[0].document_key }), { expiresIn: 3600 });
    }
    res.json({ placeholder: false, ...formulation.rows[0], url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load formulation.' });
  }
});

// POST /api/formulation/cases/:caseId/formulators — assign formulator(s) to the case's formulation
router.post('/cases/:caseId/formulators', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { formulator_id } = req.body;
  try {
    const caseRes = await pool.query('SELECT formulation_id FROM cases WHERE id = $1', [req.params.caseId]);
    if (caseRes.rows.length === 0 || !caseRes.rows[0].formulation_id) {
      return res.status(400).json({ error: 'Case has no formulation yet — upload one first.' });
    }
    await pool.query(
      'INSERT INTO formulation_formulators (formulation_id, formulator_id) VALUES ($1,$2) ON CONFLICT DO NOTHING',
      [caseRes.rows[0].formulation_id, formulator_id]
    );
    res.status(201).json({ message: 'Formulator assigned.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not assign formulator.' });
  }
});

module.exports = router;
