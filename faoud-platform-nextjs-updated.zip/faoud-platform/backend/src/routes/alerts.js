const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/alerts?case=<id>  (ported from AlertListCreateAPIView.get)
// Account Managers see alerts scoped to their assigned cases; ?case= filters further.
router.get('/', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  try {
    const caseId = req.query.case;
    const params = [req.user.id];
    let where = 'a.am_user_id = $1';
    let sql = `SELECT al.* FROM alerts al JOIN case_am_assignments a ON a.case_id = al.case_id WHERE ${where}`;
    if (caseId) {
      params.push(caseId);
      sql += ` AND al.case_id = $2`;
    }
    sql += ' ORDER BY al.created_at DESC';
    const result = await pool.query(sql, params);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load alerts.' });
  }
});

// POST /api/alerts  (ported from AlertListCreateAPIView.post)
router.post('/', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { case_id, message } = req.body;
  if (!case_id) return res.status(400).json({ error: 'case_id is required.' });
  try {
    const result = await pool.query('INSERT INTO alerts (case_id, message) VALUES ($1, $2) RETURNING *', [
      case_id,
      message || null
    ]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create alert.' });
  }
});

// GET /api/alerts/:id  (ported from AlertDetailAPIView.get)
router.get('/:id', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const result = await pool.query('SELECT * FROM alerts WHERE id = $1', [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ error: 'Alert not found.' });
  res.json(result.rows[0]);
});

// PUT/PATCH /api/alerts/:id  (ported from AlertDetailAPIView.put/patch)
router.put('/:id', authenticate, authorize('account_manager', 'admin'), updateAlert);
router.patch('/:id', authenticate, authorize('account_manager', 'admin'), updateAlert);

async function updateAlert(req, res) {
  const { message, is_done } = req.body;
  const result = await pool.query(
    `UPDATE alerts SET
       message = COALESCE($1, message),
       is_done = COALESCE($2, is_done),
       done_date = CASE WHEN $2 = TRUE THEN NOW() ELSE done_date END
     WHERE id = $3 RETURNING *`,
    [message ?? null, is_done ?? null, req.params.id]
  );
  if (result.rows.length === 0) return res.status(404).json({ error: 'Alert not found.' });
  res.json(result.rows[0]);
}

// DELETE /api/alerts/:id  (ported from AlertDetailAPIView.delete)
router.delete('/:id', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const result = await pool.query('DELETE FROM alerts WHERE id = $1 RETURNING id', [req.params.id]);
  if (result.rows.length === 0) return res.status(404).json({ error: 'Alert not found.' });
  res.status(204).send();
});

// POST /api/alerts/:id/mark_done  (ported from MarkAlertDoneAPIView)
router.post('/:id/mark_done', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const result = await pool.query(
    'UPDATE alerts SET is_done = TRUE, done_date = NOW() WHERE id = $1 RETURNING *',
    [req.params.id]
  );
  if (result.rows.length === 0) return res.status(404).json({ error: 'Alert not found.' });
  res.json(result.rows[0]);
});

module.exports = router;
