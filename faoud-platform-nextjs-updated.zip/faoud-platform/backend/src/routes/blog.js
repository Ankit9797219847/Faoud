const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/blog  (public, published posts only)
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, title, slug, excerpt, author, published_at FROM blog_posts
       WHERE published = TRUE ORDER BY published_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch blog posts.' });
  }
});

// GET /api/blog/:slug
router.get('/:slug', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM blog_posts WHERE slug = $1 AND published = TRUE',
      [req.params.slug]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Post not found.' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch post.' });
  }
});

// POST /api/blog  (admin only)
router.post('/', authenticate, authorize('admin'), async (req, res) => {
  const { title, slug, excerpt, content, author, published } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO blog_posts (title, slug, excerpt, content, author, published, published_at)
       VALUES ($1,$2,$3,$4,$5,$6, CASE WHEN $6 THEN NOW() ELSE NULL END) RETURNING *`,
      [title, slug, excerpt, content, author, !!published]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create post.' });
  }
});

module.exports = router;
