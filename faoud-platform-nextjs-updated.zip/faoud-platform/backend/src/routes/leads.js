const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// POST /api/leads  (public contact / "Talk to our Consultant" / "Get Formulation" forms)
router.post('/', async (req, res) => {
  const { name, email, phone, company_name, interest, message } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: 'Name and email are required.' });
  }
  try {
    const result = await pool.query(
      `INSERT INTO leads (name, email, phone, company_name, interest, message)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [name, email, phone || null, company_name || null, interest || 'general', message || null]
    );
    res.status(201).json({ message: "Thanks — we'll be in touch shortly.", lead: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not submit your request.' });
  }
});

// GET /api/leads  (admin only — view incoming leads)
router.get('/', authenticate, authorize('admin'), async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM leads ORDER BY created_at DESC LIMIT 500');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch leads.' });
  }
});

module.exports = router;
