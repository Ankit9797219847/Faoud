const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');
const { sendMail } = require('../utils/mailer');

const router = express.Router();



// POST /api/bids  (ported from supply.views.BidViewSet create — a Factory
// Owner submits a bid: quote, eta)
router.post('/', authenticate, authorize('factory'), async (req, res) => {
  const { case_id, quote, eta, sample_paid } = req.body;
  if (!case_id || quote == null) {
    return res.status(400).json({ error: 'case_id and quote are required.' });
  }
  try {
    const factory = await pool.query('SELECT id FROM factories WHERE factory_owner_id = $1 OR user_id = $1', [
      req.user.id
    ]);
    if (factory.rows.length === 0) {
      return res.status(400).json({ error: 'No factory profile found for this account.' });
    }
    const result = await pool.query(
      `INSERT INTO bids (case_id, factory_id, quote, quote_bo, eta, sample_paid)
       VALUES ($1, $2, $3, $3, $4, $5) RETURNING *`,
      [case_id, factory.rows[0].id, quote, eta || null, !!sample_paid]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not submit bid.' });
  }
});

// GET /api/cases/:caseId/bids  (ported from ManageBidsView.get — AM view of all bids on a case)
router.get('/case/:caseId', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const result = await pool.query(
    `SELECT b.*, f.factory_name FROM bids b JOIN factories f ON f.id = b.factory_id
     WHERE b.case_id = $1 ORDER BY b.quote ASC`,
    [req.params.caseId]
  );
  res.json(result.rows);
});

// PATCH /api/bids/:bidId/tag  (ported from ManageBidsView.patch — AM tags a bid)
router.patch('/:bidId/tag', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const allowed = ['shortlisted', 'not_shortlisted', 'best_value', 'backup'];
  if (!allowed.includes(req.body.tag)) {
    return res.status(400).json({ error: 'Invalid tag.' });
  }
  const result = await pool.query('UPDATE bids SET tag = $1, updated_at = NOW() WHERE id = $2 RETURNING *', [
    req.body.tag,
    req.params.bidId
  ]);
  if (result.rows.length === 0) return res.status(404).json({ error: 'Bid not found.' });
  res.json({ message: `Bid ${req.params.bidId} tagged as ${req.body.tag}.` });
});

function anonymizeFactory(row) {
  // Ported from supply/help.py's anonymize_factory_data — hides factory
  // identity from the Brand Owner until they've picked a winner.
  return {
    id: row.factory_id,
    name: `Bid ${String(row.id).slice(0, 6).toUpperCase()}`,
    quote_bo: row.quote_bo,
    eta: row.eta,
    tag: row.tag,
    status: row.status
  };
}

// GET /api/cases/:caseId/brand-bids  (ported from BrandOwnerBidsView — only
// AM-tagged bids are visible, and factory identity is anonymized)
router.get('/case/:caseId/brand', authenticate, authorize('brand'), async (req, res) => {
  const caseCheck = await pool.query('SELECT id FROM cases WHERE id = $1 AND brand_id = $2', [
    req.params.caseId,
    req.user.id
  ]);
  if (caseCheck.rows.length === 0) return res.status(404).json({ error: 'Case not found.' });

  const result = await pool.query(
    `SELECT * FROM bids WHERE case_id = $1 AND tag IS NOT NULL ORDER BY quote_bo ASC`,
    [req.params.caseId]
  );
  res.json(result.rows.map(anonymizeFactory));
});

// (Factory Owner's own bid history is served from /api/user/bids — see routes/user.js)

// POST /api/cases/:caseId/factory/:factoryId  (ported from UpdateCaseWithFactoryView
// — accepting a bid: assigns the factory to the case and locks every other bid)
router.post(
  '/case/:caseId/accept/:bidId',
  authenticate,
  authorize('account_manager', 'admin'),
  async (req, res) => {
    const client = await pool.connect();
    try {
      const bidRes = await client.query('SELECT * FROM bids WHERE id = $1 AND case_id = $2', [
        req.params.bidId,
        req.params.caseId
      ]);
      if (bidRes.rows.length === 0) return res.status(404).json({ error: 'Bid not found for this case.' });
      const bid = bidRes.rows[0];

      await client.query('BEGIN');
      await client.query('UPDATE bids SET status = $1, updated_at = NOW() WHERE case_id = $2', [
        'locked',
        req.params.caseId
      ]);
      await client.query('UPDATE bids SET status = $1, updated_at = NOW() WHERE id = $2', ['accepted', bid.id]);
      await client.query(
        'UPDATE cases SET factory_id = $1, bid_selected_id = $2, updated_at = NOW() WHERE id = $3',
        [bid.factory_id, bid.id, req.params.caseId]
      );
      await client.query('COMMIT');

      const winner = await pool.query(
        `SELECT u.email FROM factories f JOIN users u ON u.id = COALESCE(f.factory_owner_id, f.user_id)
         WHERE f.id = $1`,
        [bid.factory_id]
      );
      if (winner.rows[0]?.email) {
        sendMail({
          to: winner.rows[0].email,
          subject: 'Your bid has been accepted on Faoud',
          text: `Your bid on case #${req.params.caseId} was accepted. Log in to the ops console for next steps.`
        }).catch(() => {});
      }

      res.json({ message: 'Factory assigned from accepted bid.', bid_id: bid.id, factory_id: bid.factory_id });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error(err);
      res.status(500).json({ error: 'Could not accept bid.' });
    } finally {
      client.release();
    }
  }
);

module.exports = router;
