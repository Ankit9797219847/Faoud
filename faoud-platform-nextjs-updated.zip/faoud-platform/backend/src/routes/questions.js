// Ported from shadow-api's product.views.QuestionView + the case-specific
// question views (CaseSpecificQuestionsView, SubmitCaseSpecificAnswerView,
// AddCaseSpecificQuestionView). Drives the branching NPD/onboarding intake
// questionnaire that creates a new case.
const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/questions?category=npd_without — starting question(s) for a category
// (ported from QuestionView.listQuestions)
router.get('/', authenticate, async (req, res) => {
  const category = req.query.category || 'npd_without';
  try {
    const q = await pool.query(
      'SELECT * FROM questions WHERE category = $1 AND starting_question = TRUE',
      [category]
    );
    if (q.rows.length === 0) {
      return res.status(404).json({ error: 'No starting question found for this category.' });
    }
    res.json({ questions: await withOptions(q.rows) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load questions.' });
  }
});

// GET /api/questions/:id
router.get('/:id', authenticate, async (req, res) => {
  try {
    const q = await pool.query('SELECT * FROM questions WHERE id = $1', [req.params.id]);
    if (q.rows.length === 0) return res.status(404).json({ error: 'Question not found.' });
    const [withOpts] = await withOptions(q.rows);
    res.json(withOpts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load question.' });
  }
});

// POST /api/questions/new-case?category=npd_without
// Creates a new case at stage 0 and returns the first question.
// (ported from QuestionView.newCase)
router.post('/new-case', authenticate, authorize('brand'), async (req, res) => {
  const category = req.query.category || req.body.category || 'npd_without';
  const client = await pool.connect();
  try {
    const firstQ = await client.query(
      'SELECT * FROM questions WHERE starting_question = TRUE AND category = $1',
      [category]
    );
    if (firstQ.rows.length === 0) {
      return res.status(404).json({ error: 'No starting question found for this category.' });
    }

    const stageRes = await client.query('SELECT * FROM stages WHERE "order" = 0');
    if (stageRes.rows.length === 0) return res.status(404).json({ error: 'Initial stage not found.' });
    const defaultStage = stageRes.rows[0];

    // Randomly assign a privileged AM, like shadow-api's superAM group filter
    const amRes = await client.query(
      "SELECT id FROM users WHERE role = 'account_manager' AND is_privileged_am = TRUE"
    );
    const ams = amRes.rows.length > 0
      ? amRes.rows
      : (await client.query("SELECT id FROM users WHERE role = 'account_manager'")).rows;
    if (ams.length === 0) {
      return res.status(404).json({ error: 'No Account Managers available.' });
    }
    const assignedAm = ams[Math.floor(Math.random() * ams.length)];

    await client.query('BEGIN');
    const caseRes = await client.query(
      `INSERT INTO cases (brand_id, category, name) VALUES ($1, $2, $3) RETURNING *`,
      [req.user.id, category, 'Unnamed Case']
    );
    const newCase = caseRes.rows[0];

    await client.query(
      'INSERT INTO case_am_assignments (case_id, am_user_id) VALUES ($1, $2)',
      [newCase.id, assignedAm.id]
    );
    await client.query(
      `INSERT INTO case_progress_stages (case_id, stage_id, order_in_timeline, completion_date)
       VALUES ($1, $2, $3, $4)`,
      [newCase.id, defaultStage.id, defaultStage.order, req.body.completion_date || new Date()]
    );
    await client.query('COMMIT');

    res.status(201).json({
      questions: await withOptions(firstQ.rows),
      case: newCase.id
    });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Could not start a new case.' });
  } finally {
    client.release();
  }
});

// POST /api/questions/choose-answer
// Body: { question, case, answer_text?, selected_options?: [] }
// Answers one question and returns the next question (branches on selected
// option for MC questions). (ported from QuestionView.chooseAnswer)
router.post('/choose-answer', authenticate, authorize('brand'), async (req, res) => {
  const { question: questionId, case: caseId, answer_text, selected_options = [] } = req.body;
  try {
    const qRes = await pool.query('SELECT * FROM questions WHERE id = $1', [questionId]);
    if (qRes.rows.length === 0) return res.status(404).json({ error: 'Question not found.' });
    const question = qRes.rows[0];

    const caseRes = await pool.query('SELECT * FROM cases WHERE id = $1', [caseId]);
    if (caseRes.rows.length === 0) return res.status(404).json({ error: 'Case not found.' });

    const answerRes = await pool.query(
      `INSERT INTO chosen_answers (brand_owner_id, case_id, question_id) VALUES ($1, $2, $3) RETURNING *`,
      [req.user.id, caseId, questionId]
    );
    const chosenAnswer = answerRes.rows[0];

    let nextQuestionId = null;

    if (['SA', 'LA', 'DS', 'YN'].includes(question.question_type)) {
      await pool.query('UPDATE chosen_answers SET answer_text = $1 WHERE id = $2', [answer_text, chosenAnswer.id]);
      nextQuestionId = question.next_question_id;
    } else if (question.question_type === 'MC') {
      for (const optionId of selected_options) {
        const optRes = await pool.query('SELECT * FROM answer_options WHERE id = $1', [optionId]);
        if (optRes.rows.length > 0) {
          const option = optRes.rows[0];
          await pool.query(
            'INSERT INTO chosen_answer_selected_options (chosen_answer_id, answer_option_id) VALUES ($1, $2)',
            [chosenAnswer.id, optionId]
          );
          if (option.next_question_id) nextQuestionId = option.next_question_id;
        }
      }
    }

    if (!nextQuestionId) return res.json({ message: 'No more questions' });

    const nextQ = await pool.query('SELECT * FROM questions WHERE id = $1', [nextQuestionId]);
    res.status(201).json({ next_question: (await withOptions(nextQ.rows))[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not record answer.' });
  }
});

// GET /api/questions/continue-case?case=<id>
// (ported from QuestionView.continueCase)
router.get('/continue-case', authenticate, authorize('brand'), async (req, res) => {
  const caseId = req.query.case;
  try {
    const caseRes = await pool.query('SELECT * FROM cases WHERE id = $1', [caseId]);
    if (caseRes.rows.length === 0) return res.status(404).json({ error: 'Case not found.' });
    if (caseRes.rows[0].brand_id !== req.user.id) {
      return res.status(403).json({ error: 'This case does not belong to you.' });
    }

    const lastAnswerRes = await pool.query(
      `SELECT ca.*, q.question_type FROM chosen_answers ca
       JOIN questions q ON q.id = ca.question_id
       WHERE ca.case_id = $1 ORDER BY ca.order_index DESC, ca.created_at DESC LIMIT 1`,
      [caseId]
    );

    let nextQuestionId = null;
    if (lastAnswerRes.rows.length > 0) {
      const last = lastAnswerRes.rows[0];
      if (last.question_type === 'MC') {
        const optRes = await pool.query(
          `SELECT ao.next_question_id FROM chosen_answer_selected_options caso
           JOIN answer_options ao ON ao.id = caso.answer_option_id
           WHERE caso.chosen_answer_id = $1 LIMIT 1`,
          [last.id]
        );
        nextQuestionId = optRes.rows[0]?.next_question_id || null;
      } else {
        const qRes = await pool.query('SELECT next_question_id FROM questions WHERE id = $1', [last.question_id]);
        nextQuestionId = qRes.rows[0]?.next_question_id || null;
      }
    }

    if (!nextQuestionId) {
      return res.json({ message: 'No more questions', case_id: caseId });
    }
    const nextQ = await pool.query('SELECT * FROM questions WHERE id = $1', [nextQuestionId]);
    res.json({ questions: (await withOptions(nextQ.rows))[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not continue case.' });
  }
});

// POST /api/questions/submit-answers
// Body: { category, answers: [{ question, question_type, answer_text?, selected_options? }] }
// Bulk-submits a full answer set at once and creates the case.
// (ported from QuestionView.submitAnswers)
router.post('/submit-answers', authenticate, authorize('brand'), async (req, res) => {
  const { category = 'npd_without', answers = [] } = req.body;
  const client = await pool.connect();
  try {
    const stageRes = await client.query('SELECT * FROM stages WHERE "order" = 0');
    if (stageRes.rows.length === 0) return res.status(404).json({ error: 'Initial stage not found.' });

    await client.query('BEGIN');
    const caseRes = await client.query(
      `INSERT INTO cases (brand_id, category, name) VALUES ($1, $2, 'Unnamed Case') RETURNING *`,
      [req.user.id, category]
    );
    const newCase = caseRes.rows[0];
    await client.query(
      `INSERT INTO case_progress_stages (case_id, stage_id, order_in_timeline, completion_date)
       VALUES ($1, $2, 0, NOW())`,
      [newCase.id, stageRes.rows[0].id]
    );

    const savedAnswers = [];
    for (let i = 0; i < answers.length; i++) {
      const a = answers[i];
      const qRes = await client.query('SELECT * FROM questions WHERE id = $1', [a.question]);
      if (qRes.rows.length === 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: `Question ${a.question} not found.` });
      }
      const question = qRes.rows[0];
      const ansRes = await client.query(
        `INSERT INTO chosen_answers (brand_owner_id, case_id, question_id, order_index, answer_text)
         VALUES ($1, $2, $3, $4, $5) RETURNING *`,
        [req.user.id, newCase.id, question.id, i, ['SA', 'LA', 'DS', 'YN'].includes(question.question_type) ? a.answer_text : null]
      );
      const chosenAnswer = ansRes.rows[0];
      if (question.question_type === 'MC' && Array.isArray(a.selected_options)) {
        for (const optId of a.selected_options) {
          await client.query(
            'INSERT INTO chosen_answer_selected_options (chosen_answer_id, answer_option_id) VALUES ($1, $2)',
            [chosenAnswer.id, optId]
          );
        }
      }
      savedAnswers.push({ id: chosenAnswer.id, question: question.id, question_text: question.question_text, order_index: i });
    }

    await client.query('COMMIT');
    res.status(201).json({ message: 'Case created successfully', case_id: newCase.id, answers: savedAnswers });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Could not submit answers.' });
  } finally {
    client.release();
  }
});

// GET /api/questions/cases/:caseId/answers — full answer history for a case
// (ported from CaseAnswersView)
router.get('/cases/:caseId/answers', authenticate, async (req, res) => {
  try {
    const answers = await pool.query(
      `SELECT ca.*, q.question_text, q.question_type FROM chosen_answers ca
       JOIN questions q ON q.id = ca.question_id
       WHERE ca.case_id = $1 ORDER BY ca.order_index ASC, ca.created_at ASC`,
      [req.params.caseId]
    );
    res.json(answers.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load answers.' });
  }
});

// ---------- Case-specific questions (AM adds bespoke questions to one case) ----------
// GET /api/questions/cases/:caseId/specific-questions (ported from CaseSpecificQuestionsView)
router.get('/cases/:caseId/specific-questions', authenticate, async (req, res) => {
  try {
    const q = await pool.query(
      'SELECT * FROM questions WHERE case_id = $1 AND is_case_specific = TRUE',
      [req.params.caseId]
    );
    res.json(await withOptions(q.rows));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load case-specific questions.' });
  }
});

// POST /api/questions/cases/add-specific-question (ported from AddCaseSpecificQuestionView)
router.post('/cases/add-specific-question', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { case_id, question_text, question_type = 'SA' } = req.body;
  if (!case_id || !question_text) return res.status(400).json({ error: 'case_id and question_text are required.' });
  try {
    const q = await pool.query(
      `INSERT INTO questions (case_id, question_text, question_type, is_case_specific, created_by_am)
       VALUES ($1, $2, $3, TRUE, TRUE) RETURNING *`,
      [case_id, question_text, question_type]
    );
    res.status(201).json(q.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not add case-specific question.' });
  }
});

// POST /api/questions/cases/submit-specific-answer (ported from SubmitCaseSpecificAnswerView)
router.post('/cases/submit-specific-answer', authenticate, authorize('brand'), async (req, res) => {
  const { case_id, question_id, answer_text } = req.body;
  try {
    const a = await pool.query(
      `INSERT INTO chosen_answers (brand_owner_id, case_id, question_id, answer_text, is_case_specific)
       VALUES ($1, $2, $3, $4, TRUE) RETURNING *`,
      [req.user.id, case_id, question_id, answer_text]
    );
    res.status(201).json(a.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not submit answer.' });
  }
});

// Attaches each question's offered AnswerOptions (Question.options M2M)
async function withOptions(questionRows) {
  const out = [];
  for (const q of questionRows) {
    const opts = await pool.query(
      `SELECT ao.* FROM question_answer_options qao
       JOIN answer_options ao ON ao.id = qao.answer_option_id
       WHERE qao.question_id = $1`,
      [q.id]
    );
    out.push({ ...q, options: opts.rows });
  }
  return out;
}

module.exports = router;
