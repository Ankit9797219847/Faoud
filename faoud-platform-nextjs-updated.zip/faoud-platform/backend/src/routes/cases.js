const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

async function caseStageInfo(caseId) {
  const r = await pool.query(
    `SELECT s.name, s.order FROM case_progress_stages cps
     JOIN stages s ON s.id = cps.stage_id
     WHERE cps.case_id = $1 AND cps.completion_date IS NOT NULL
     ORDER BY cps.order_in_timeline DESC LIMIT 1`,
    [caseId]
  );
  return r.rows[0] || null;
}

// GET /api/cases/list_assigned  (Account Manager: cases assigned to them)
// Ported from shadow-api's cases/list_assigned/ (AssignedCasesView).
router.get('/list_assigned', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT c.*, u.full_name AS brand_name, f.factory_name
       FROM cases c
       JOIN case_am_assignments a ON a.case_id = c.id
       LEFT JOIN users u ON u.id = c.brand_id
       LEFT JOIN factories f ON f.id = c.factory_id
       WHERE a.am_user_id = $1 AND c.active = 'active'
       ORDER BY c.updated_at DESC`,
      [req.user.id]
    );
    const cases = await Promise.all(
      result.rows.map(async (c) => ({ ...c, stage: (await caseStageInfo(c.id))?.name || 'Unstaged' }))
    );
    res.json({ cases });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load assigned cases.' });
  }
});

// GET /api/cases/list_brand_owner_dashboard  (Brand Owner: their own cases)
router.get('/list_brand_owner_dashboard', authenticate, authorize('brand'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT c.*, f.factory_name
       FROM cases c
       LEFT JOIN factories f ON f.id = c.factory_id
       WHERE c.brand_id = $1 AND c.active = 'active'
       ORDER BY c.updated_at DESC`,
      [req.user.id]
    );
    const cases = await Promise.all(
      result.rows.map(async (c) => ({ ...c, stage: (await caseStageInfo(c.id))?.name || 'Unstaged' }))
    );
    res.json({ cases });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load your cases.' });
  }
});

// GET /api/cases/list_archived  (ported from CaseViews.list_archived)
router.get('/list_archived', authenticate, authorize('account_manager', 'brand', 'admin'), async (req, res) => {
  try {
    const filter = req.user.role === 'brand' ? 'AND c.brand_id = $2' : '';
    const params = req.user.role === 'brand' ? ["archived", req.user.id] : ['archived'];
    const result = await pool.query(
      `SELECT c.* FROM cases c WHERE c.active = $1 ${filter} ORDER BY c.created_at DESC`,
      params
    );
    res.json({ cases: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load archived cases.' });
  }
});

// GET /api/cases/bidding  (ported from supply.views.CaseListForBiddingView)
// Real rule: cases whose "FactorySelection" stage (order 0) is completed,
// which don't have a factory assigned yet, AND whose subcategory the
// requesting factory is registered as eligible for
// (factory_subcategories) — matches shadow-api's category/subcategory
// eligibility filter. A case with no subcategory set is shown to everyone
// (nothing to match against yet).
router.get('/bidding', authenticate, authorize('factory'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT DISTINCT c.id, c.name, c.category, c.subcategory_id, c.quantity, c.eta, c.created_at
       FROM cases c
       JOIN case_progress_stages cps ON cps.case_id = c.id
       JOIN stages s ON s.id = cps.stage_id
       LEFT JOIN factory_subcategories fs
         ON fs.subcategory_id = c.subcategory_id AND fs.factory_id IN (
           SELECT id FROM factories WHERE factory_owner_id = $1 OR user_id = $1
         )
       WHERE s."order" = 0
         AND cps.completion_date IS NOT NULL
         AND c.factory_id IS NULL
         AND c.active = 'active'
         AND (c.subcategory_id IS NULL OR fs.subcategory_id IS NOT NULL)
       ORDER BY c.created_at DESC`,
      [req.user.id]
    );
    res.json({ results: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load open cases.' });
  }
});

// POST /api/cases  (Account Manager creates a case)
router.post('/', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { name, category, brand_id, quantity, eta, notes, subcategory_id } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO cases (name, category, brand_id, quantity, eta, notes, subcategory_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [
        name || 'Unnamed Case',
        category || 'npd_without',
        brand_id || null,
        quantity || null,
        eta || null,
        notes || '',
        subcategory_id || null
      ]
    );
    const caseRow = result.rows[0];
    await pool.query('INSERT INTO case_am_assignments (case_id, am_user_id) VALUES ($1, $2)', [
      caseRow.id,
      req.user.id
    ]);
    res.status(201).json(caseRow);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create case.' });
  }
});

// GET /api/cases/:id  (ported from CaseViews.get_case — the payment-gated
// "formulation placeholder PDF" swap for un-paid Brand Owners was NOT ported;
// see README)
router.get('/:id', authenticate, authorize('account_manager', 'brand', 'factory', 'admin'), async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM cases WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Case not found.' });
    const caseRow = result.rows[0];

    if (req.user.role === 'brand' && caseRow.brand_id !== req.user.id) {
      return res.status(403).json({ error: 'You do not have permission to access this case.' });
    }

    const stage = await caseStageInfo(req.params.id);
    if (req.user.role === 'account_manager') {
      await pool.query('UPDATE cases SET last_opened_by_am_at = NOW() WHERE id = $1', [req.params.id]);
    }
    res.json({ case: { ...caseRow, stage: stage?.name || 'Unstaged' }, user_role: req.user.role });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load case.' });
  }
});

// POST /api/cases/:id/archive  (ported from ArchiveCaseView)
router.post('/:id/archive', authenticate, authorize('account_manager', 'brand', 'admin'), async (req, res) => {
  await pool.query("UPDATE cases SET active = 'archived', updated_at = NOW() WHERE id = $1", [req.params.id]);
  res.json({ status: 'archived' });
});

// POST /api/cases/:id/restore  (ported from RestoreCaseView)
router.post('/:id/restore', authenticate, authorize('account_manager', 'brand', 'admin'), async (req, res) => {
  await pool.query("UPDATE cases SET active = 'active', updated_at = NOW() WHERE id = $1", [req.params.id]);
  res.json({ status: 'restored' });
});

// POST /api/cases/:id/soft-delete  (ported from SoftDeleteCaseView)
router.post('/:id/soft-delete', authenticate, authorize('account_manager', 'brand', 'admin'), async (req, res) => {
  await pool.query("UPDATE cases SET active = 'deleted', updated_at = NOW() WHERE id = $1", [req.params.id]);
  res.json({ status: 'deleted' });
});

// PUT /api/cases/:id/name  (ported from UpdateCaseNameView — Brand Owner only, must own the case)
router.put('/:id/name', authenticate, authorize('brand'), async (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'Name field is required.' });
  const result = await pool.query(
    'UPDATE cases SET name = $1, updated_at = NOW() WHERE id = $2 AND brand_id = $3 RETURNING id, name',
    [name, req.params.id, req.user.id]
  );
  if (result.rows.length === 0) {
    return res.status(403).json({ error: 'You do not have permission to update this case.' });
  }
  res.json({ message: 'Case name updated successfully.', case_id: result.rows[0].id, name: result.rows[0].name });
});

// PATCH /api/cases/:id/notes  (ported from CaseNotesUpdateView)
router.patch('/:id/notes', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const notes = req.body.notes || '';
  await pool.query('UPDATE cases SET notes = $1, updated_at = NOW() WHERE id = $2', [notes, req.params.id]);
  res.json({ message: 'Notes updated', notes });
});

// PATCH /api/cases/:id/color  (ported from UpdateCaseColorView)
router.patch('/:id/color', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const result = await pool.query(
    'UPDATE cases SET color = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
    [req.body.color || '', req.params.id]
  );
  if (result.rows.length === 0) return res.status(404).json({ error: 'Case not found.' });
  res.json({ message: 'Case color updated successfully.', case: result.rows[0] });
});

// PATCH /api/cases/:id/priority  (ported from UpdateCasePriorityView)
router.patch('/:id/priority', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const allowed = ['normal', 'priority', 'inactive', 'dispatched'];
  if (!allowed.includes(req.body.priority)) {
    return res.status(400).json({ priority: ['Invalid priority.'] });
  }
  const result = await pool.query(
    'UPDATE cases SET priority = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
    [req.body.priority, req.params.id]
  );
  if (result.rows.length === 0) return res.status(404).json({ error: 'Case not found.' });
  res.json({ message: 'Case priority updated successfully.', case: result.rows[0] });
});

// GET /api/cases/:id/users  (ported from CaseUsersView)
router.get('/:id/users', authenticate, authorize('account_manager', 'brand', 'factory', 'admin'), async (req, res) => {
  try {
    const caseRes = await pool.query('SELECT * FROM cases WHERE id = $1', [req.params.id]);
    if (caseRes.rows.length === 0) return res.status(404).json({ error: 'Case not found.' });
    const caseRow = caseRes.rows[0];

    const userIds = new Set();
    if (caseRow.brand_id) userIds.add(caseRow.brand_id);

    const ams = await pool.query('SELECT am_user_id FROM case_am_assignments WHERE case_id = $1', [req.params.id]);
    ams.rows.forEach((r) => userIds.add(r.am_user_id));

    if (caseRow.factory_id) {
      const fo = await pool.query('SELECT factory_owner_id FROM factories WHERE id = $1', [caseRow.factory_id]);
      if (fo.rows[0]?.factory_owner_id) userIds.add(fo.rows[0].factory_owner_id);
    }

    if (userIds.size === 0) return res.json([]);
    const users = await pool.query(
      `SELECT id, email, full_name, role FROM users WHERE id = ANY($1::uuid[])`,
      [Array.from(userIds)]
    );
    const roleLabel = { account_manager: 'Account Manager', brand: 'Brand Owner', factory: 'Factory Owner' };
    res.json(users.rows.map((u) => ({ ...u, role_label: roleLabel[u.role] || u.role })));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load case users.' });
  }
});

module.exports = router;
