const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

const EDITABLE_FIELDS = [
  'factory_name',
  'category',
  'city',
  'state',
  'moq',
  'turnaround_days',
  'description',
  'gst_number',
  'legal_entity',
  'phone',
  'email',
  'address',
  'website',
  'type_of_products',
  'licenses',
  'capacity',
  'exports_supported',
  'director_name',
  'director_phone',
  'director_email',
  'poc_name',
  'poc_phone',
  'poc_email',
  'operational_since'
];

// GET /api/factories/me  (Factory Owner: their own factory profile(s))
router.get('/me', authenticate, authorize('factory'), async (req, res) => {
  const result = await pool.query(
    'SELECT * FROM factories WHERE factory_owner_id = $1 OR user_id = $1 ORDER BY created_at',
    [req.user.id]
  );
  res.json(result.rows);
});

// PATCH /api/factories/:id  (Factory Owner: update their own factory profile)
router.patch('/:id', authenticate, authorize('factory'), async (req, res) => {
  const owns = await pool.query(
    'SELECT id FROM factories WHERE id = $1 AND (factory_owner_id = $2 OR user_id = $2)',
    [req.params.id, req.user.id]
  );
  if (owns.rows.length === 0) {
    return res.status(403).json({ error: 'You do not have permission to edit this factory.' });
  }

  const updates = [];
  const values = [];
  let i = 1;
  for (const field of EDITABLE_FIELDS) {
    if (req.body[field] !== undefined) {
      updates.push(`${field} = $${i}`);
      values.push(req.body[field]);
      i++;
    }
  }
  if (updates.length === 0) return res.status(400).json({ error: 'No editable fields provided.' });

  values.push(req.params.id);
  const result = await pool.query(
    `UPDATE factories SET ${updates.join(', ')}, updated_at = NOW() WHERE id = $${i} RETURNING *`,
    values
  );
  res.json(result.rows[0]);
});

// GET /api/factories/:id/subcategories  (which subcategories this factory is eligible for)
router.get('/:id/subcategories', authenticate, async (req, res) => {
  const result = await pool.query(
    `SELECT s.*, c.name AS category_name FROM factory_subcategories fs
     JOIN subcategories s ON s.id = fs.subcategory_id
     JOIN categories c ON c.id = s.category_id
     WHERE fs.factory_id = $1`,
    [req.params.id]
  );
  res.json(result.rows);
});

module.exports = router;
