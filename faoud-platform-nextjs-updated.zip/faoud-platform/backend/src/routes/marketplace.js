const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/marketplace/products?category=nutraceuticals&search=...
router.get('/products', async (req, res) => {
  const { category, search } = req.query;
  let query = `SELECT p.*, f.factory_name, f.city, f.state
               FROM marketplace_products p
               JOIN factories f ON f.id = p.factory_id
               WHERE p.is_active = TRUE`;
  const params = [];

  if (category && category !== 'all') {
    params.push(category);
    query += ` AND p.category = $${params.length}`;
  }
  if (search) {
    params.push(`%${search}%`);
    query += ` AND p.title ILIKE $${params.length}`;
  }
  query += ' ORDER BY p.created_at DESC LIMIT 100';

  try {
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch marketplace products.' });
  }
});

// GET /api/marketplace/products/:id
router.get('/products/:id', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT p.*, f.factory_name, f.city, f.state, f.certifications, f.turnaround_days
       FROM marketplace_products p JOIN factories f ON f.id = p.factory_id
       WHERE p.id = $1`,
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Product not found.' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch product.' });
  }
});

// POST /api/marketplace/products  (factory only)
router.post('/products', authenticate, authorize('factory', 'admin'), async (req, res) => {
  const { title, category, description, base_price, moq, lead_time_days, image_url } = req.body;
  try {
    const factory = await pool.query('SELECT id FROM factories WHERE user_id = $1', [req.user.id]);
    if (factory.rows.length === 0) {
      return res.status(400).json({ error: 'Complete your factory profile before listing products.' });
    }
    const result = await pool.query(
      `INSERT INTO marketplace_products (factory_id, title, category, description, base_price, moq, lead_time_days, image_url)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [factory.rows[0].id, title, category, description, base_price, moq, lead_time_days, image_url]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not create listing.' });
  }
});

// GET /api/marketplace/factories?category=cosmetics
router.get('/factories', async (req, res) => {
  const { category } = req.query;
  let query = 'SELECT * FROM factories WHERE verified = TRUE';
  const params = [];
  if (category && category !== 'all') {
    params.push(category);
    query += ` AND category = $${params.length}`;
  }
  query += ' ORDER BY created_at DESC';
  try {
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Could not fetch factories.' });
  }
});

module.exports = router;
