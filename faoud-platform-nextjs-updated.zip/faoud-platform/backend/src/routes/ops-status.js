const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// POST /api/cases/:caseId/ops-status  (ported from CaseOperationalStatusUpsertView)
// Body: { status_id, state: 'in_process'|'done', notes? }
router.post('/:caseId/ops-status', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { status_id, state, notes } = req.body;
  if (!['in_process', 'done'].includes(state)) {
    return res.status(400).json({ error: 'Invalid state' });
  }
  try {
    const statusCheck = await pool.query('SELECT id FROM operational_statuses WHERE id = $1', [status_id]);
    if (statusCheck.rows.length === 0) return res.status(404).json({ error: 'Status not found.' });

    const existing = await pool.query(
      'SELECT * FROM case_operational_statuses WHERE case_id = $1 AND status_id = $2',
      [req.params.caseId, status_id]
    );

    let row;
    if (existing.rows.length > 0) {
      const r = await pool.query(
        `UPDATE case_operational_statuses SET state = $1, notes = COALESCE($2, notes),
         updated_by = $3, updated_at = NOW() WHERE id = $4 RETURNING *`,
        [state, notes, req.user.id, existing.rows[0].id]
      );
      row = r.rows[0];
    } else {
      const r = await pool.query(
        `INSERT INTO case_operational_statuses (case_id, status_id, state, notes, updated_by)
         VALUES ($1, $2, $3, $4, $5) RETURNING *`,
        [req.params.caseId, status_id, state, notes || '', req.user.id]
      );
      row = r.rows[0];
    }
    res.json(row);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not update operational status.' });
  }
});

// DELETE /api/cases/:caseId/ops-status/:statusId  (ported from CaseOperationalStatusDeleteView)
router.delete('/:caseId/ops-status/:statusId', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  try {
    const result = await pool.query(
      'DELETE FROM case_operational_statuses WHERE case_id = $1 AND status_id = $2 RETURNING id',
      [req.params.caseId, req.params.statusId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not found.' });
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not delete operational status link.' });
  }
});

// PATCH /api/cases/:caseId/ops-status/:statusId  (ported from CaseOperationalStatusUpdateView)
router.patch('/:caseId/ops-status/:statusId', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  const { state, notes } = req.body;
  if (state === undefined && notes === undefined) {
    return res.status(400).json({ error: "Provide 'state' and/or 'notes' to update." });
  }
  if (state !== undefined && !['in_process', 'done'].includes(state)) {
    return res.status(400).json({ error: 'Invalid state' });
  }
  try {
    const result = await pool.query(
      `UPDATE case_operational_statuses SET
         state = COALESCE($1, state),
         notes = COALESCE($2, notes),
         updated_by = $3,
         updated_at = NOW()
       WHERE case_id = $4 AND status_id = $5 RETURNING *`,
      [state ?? null, notes ?? null, req.user.id, req.params.caseId, req.params.statusId]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not found.' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not update operational status.' });
  }
});

// GET /api/cases/:caseId/ops-status  (list all links for a case — not in
// shadow-api as a dedicated endpoint, but the AM case-detail page needs it)
router.get('/:caseId/ops-status', authenticate, authorize('account_manager', 'admin'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT cos.*, os.name, os.description FROM case_operational_statuses cos
       JOIN operational_statuses os ON os.id = cos.status_id
       WHERE cos.case_id = $1`,
      [req.params.caseId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load operational statuses for case.' });
  }
});

module.exports = router;
