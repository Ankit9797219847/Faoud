const express = require('express');
const multer = require('multer');
const pool = require('../config/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

// Lazily constructed, same pattern as routes/payments.js — the app boots
// fine with no S3 credentials; only the upload route is blocked until then.
let s3Client;
function getS3() {
  if (!process.env.S3_BUCKET || !process.env.S3_ACCESS_KEY_ID) return null;
  if (!s3Client) {
    const { S3Client } = require('@aws-sdk/client-s3');
    s3Client = new S3Client({
      region: process.env.S3_REGION || 'ap-south-1',
      endpoint: process.env.S3_ENDPOINT || undefined,
      credentials: {
        accessKeyId: process.env.S3_ACCESS_KEY_ID,
        secretAccessKey: process.env.S3_SECRET_ACCESS_KEY
      }
    });
  }
  return s3Client;
}

function notConfigured(res) {
  return res.status(501).json({
    error:
      'File storage not configured. Add S3_BUCKET, S3_ACCESS_KEY_ID, and S3_SECRET_ACCESS_KEY to backend/.env, then restart the server.'
  });
}

// POST /api/documents  (multipart upload: file, owner_type, owner_id, label)
router.post('/', authenticate, upload.single('file'), async (req, res) => {
  const s3 = getS3();
  if (!s3) return notConfigured(res);
  if (!req.file) return res.status(400).json({ error: 'No file provided.' });

  const { owner_type, owner_id, label } = req.body;
  if (!owner_type || !owner_id) {
    return res.status(400).json({ error: 'owner_type and owner_id are required.' });
  }

  try {
    const { PutObjectCommand } = require('@aws-sdk/client-s3');
    const key = `${owner_type}/${owner_id}/${Date.now()}-${req.file.originalname}`;
    await s3.send(
      new PutObjectCommand({
        Bucket: process.env.S3_BUCKET,
        Key: key,
        Body: req.file.buffer,
        ContentType: req.file.mimetype
      })
    );

    const result = await pool.query(
      `INSERT INTO documents (owner_type, owner_id, label, storage_key, uploaded_by)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [owner_type, owner_id, label || req.file.originalname, key, req.user.id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Upload failed.' });
  }
});

// GET /api/documents?owner_type=&owner_id=  (list + a presigned read URL per document)
router.get('/', authenticate, async (req, res) => {
  const { owner_type, owner_id } = req.query;
  if (!owner_type || !owner_id) {
    return res.status(400).json({ error: 'owner_type and owner_id query params are required.' });
  }
  const result = await pool.query(
    'SELECT * FROM documents WHERE owner_type = $1 AND owner_id = $2 ORDER BY created_at DESC',
    [owner_type, owner_id]
  );

  const s3 = getS3();
  if (!s3) return res.json(result.rows.map((d) => ({ ...d, url: null })));

  const { GetObjectCommand } = require('@aws-sdk/client-s3');
  const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
  const withUrls = await Promise.all(
    result.rows.map(async (d) => ({
      ...d,
      url: await getSignedUrl(s3, new GetObjectCommand({ Bucket: process.env.S3_BUCKET, Key: d.storage_key }), {
        expiresIn: 3600
      })
    }))
  );
  res.json(withUrls);
});

module.exports = router;
