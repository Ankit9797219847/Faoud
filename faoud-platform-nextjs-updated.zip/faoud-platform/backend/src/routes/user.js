const express = require('express');
const pool = require('../config/db');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();

// GET /api/user/bids  (Factory Owner: bids they've placed)
// Ported from shadow-api's supply.views.UserBidsView.
router.get('/bids', authenticate, authorize('factory'), async (req, res) => {
  try {
    const factories = await pool.query(
      'SELECT id FROM factories WHERE factory_owner_id = $1 OR user_id = $1',
      [req.user.id]
    );
    if (factories.rows.length === 0) {
      return res.status(404).json({ error: 'No factories found for the user' });
    }
    const result = await pool.query(
      `SELECT b.*, c.name AS case_name FROM bids b
       JOIN cases c ON c.id = b.case_id
       WHERE b.factory_id = ANY($1::uuid[])
       ORDER BY b.created_at DESC`,
      [factories.rows.map((f) => f.id)]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load your bids.' });
  }
});

module.exports = router;
