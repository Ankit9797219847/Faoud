const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const pool = require('../config/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// POST /api/auth/signup
router.post(
  '/signup',
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
    body('full_name').notEmpty().withMessage('Full name required'),
    body('role').isIn(['brand', 'factory', 'supplier']).withMessage('Invalid role')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { email, password, full_name, company_name, role, phone } = req.body;

    try {
      const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
      if (existing.rows.length > 0) {
        return res.status(409).json({ error: 'An account with this email already exists.' });
      }

      const password_hash = await bcrypt.hash(password, 12);

      const result = await pool.query(
        `INSERT INTO users (email, phone, password_hash, full_name, company_name, role)
         VALUES ($1, $2, $3, $4, $5, $6)
         RETURNING id, email, full_name, role, company_name, created_at`,
        [email, phone, password_hash, full_name, company_name, role]
      );

      const user = result.rows[0];
      const token = jwt.sign({ id: user.id, role: user.role, email: user.email }, process.env.JWT_SECRET, {
        expiresIn: '7d'
      });

      res.status(201).json({ user, token });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Something went wrong while creating your account.' });
    }
  }
);

// POST /api/auth/login
// Accepts either `email` (original marketplace login) or `identifier`
// (email — the ops console frontend, ported from shadow-api, calls it
// "username or email" since Django supported both; this backend only has
// email accounts, so `identifier` is treated as an email here).
router.post(
  '/login',
  [body('password').notEmpty()],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const email = req.body.email || req.body.identifier;
    const { password } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required.' });

    try {
      const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
      if (result.rows.length === 0) {
        return res.status(401).json({ error: 'Invalid email or password.' });
      }

      const user = result.rows[0];
      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: 'Invalid email or password.' });
      }

      const token = jwt.sign({ id: user.id, role: user.role, email: user.email }, process.env.JWT_SECRET, {
        expiresIn: '7d'
      });

      delete user.password_hash;
      res.json({ user, token });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Something went wrong while logging in.' });
    }
  }
);

// GET /api/auth/me
// Ported equivalent of shadow-api's /api/user/data/ — returns the signed-in
// user's profile plus their role, in the shape the ops console dashboards
// expect (see frontend/lib/auth.js).
router.get('/me', authenticate, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, email, full_name, company_name, role, phone, is_verified, created_at FROM users WHERE id = $1',
      [req.user.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'User not found.' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not load user data.' });
  }
});

// POST /api/auth/logout
// JWTs are stateless here (no server-side session to invalidate) — this
// endpoint exists so the frontend has a symmetrical call to clear its cookie
// against, matching the shape of shadow-api's session-based /api/logout/.
router.post('/logout', authenticate, (req, res) => {
  res.json({ message: 'Logged out successfully' });
});

module.exports = router;
