# Faoud Platform — Full Stack Rebuild

Backend: Node.js/Express + PostgreSQL. Frontend: Next.js + Tailwind.

## What's included
- Auth (signup/login, JWT, roles: brand / factory / supplier / admin / account_manager / formulator)
- Marketplace (products + factories, filter/search)
- Orders (create, track status, history log)
- RFQs (post request, factories quote back)
- Leads (contact / consultation forms)
- Blog (list + single post)
- Public homepage matching Faoud's structure
- **Ops console** (`/am/*`, `/brand/dashboard`, `/factory/dashboard`) — ported
  in from the shadow-api Django backend + its faoud-frontend ops-console UI.
  See "Ops console merge" below.

## What is NOT yet included (next phase)

**Infrastructure slots — code is written, just needs your credentials.**
Every one of these is wired up so the app boots and runs fine without them,
and fails gracefully (HTTP 501 with a clear message, not a crash) on the
specific action that needs them, until you fill in `backend/.env`:

| Feature | Env vars (see `backend/.env.example`) | Where the code lives |
|---|---|---|
| Razorpay payments (advance/final case payments) | `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` | `backend/src/routes/payments.js` |
| Email notifications | `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM_EMAIL` | `backend/src/utils/mailer.js` |
| File/document storage (S3-compatible) | `S3_BUCKET`, `S3_REGION`, `S3_ACCESS_KEY_ID`, `S3_SECRET_ACCESS_KEY`, `S3_ENDPOINT` | `backend/src/routes/documents.js` |

Drop in your Razorpay keys and the payment flow (`POST /api/payments/orders`
→ `/advance` or `/final` → Brand Owner `/layers/:id/checkout` → Razorpay
Checkout on the frontend → `POST /api/payments/verify`) works end to end —
no code changes needed. Same for SMTP and S3.

**Not yet ported from shadow-api** (real code gaps, not infra — see the
"Ops console merge" and "Product/questionnaire/materials merge" sections for
what *is* done):
- The "Reviewed" stage's publish flow (`core.review` — blocking-issue
  validation before a case goes live)
- Feature/UserFeature/Charge add-on billing and the ServicePayment flow
  (both live in `payments`, tied to the `services` app, which wasn't ported)
- Sample order tracking, Marketing/lead-scoring funnel, Comms, Insights
- Admin panel frontend (backend routes exist for most entities already)
- Real-time chat support
- A pixel-identical clone of the live www.faoud.com UI — this repo matches
  shadow-api's *behavior*, not a scrape of the live site's current design

## Product / questionnaire / materials merge

The remaining core of shadow-api's `product`, `formulation`, and `materials`
apps has now been ported in:

- **Questionnaire engine**: the branching NPD/onboarding/reorder/dormant-
  product intake flow — `questions`, `answer_options`, `chosen_answers` —
  ported from `product.models.Question/AnswerOption/ChosenAnswer` and
  `product.views.QuestionView` (`newCase`, `chooseAnswer`, `continueCase`,
  `submitAnswers`) plus the case-specific question views, into
  `backend/src/routes/questions.js`. A Brand Owner starts a case by picking a
  category at `/brand/new-case`, which walks the same branching tree the
  Django backend served (`POST /api/questions/new-case`, `choose-answer`,
  `continue-case`, `submit-answers`).
- **Product catalog + versioning**: `products`/`product_groups`, ported from
  `product.models.Product/ProductGroup` (grouping, version numbers,
  `parent_product`/`created_from_case`/`modification_notes` for cloned case-
  specific copies) into `backend/src/routes/products.js`, including a
  `/clone` endpoint that reproduces the versioning flow.
- **Formulation**: upload/fetch a case's formulation PDF, ported from
  `formulation.views.UploadFormulationView` into
  `backend/src/routes/formulation.js` — including the payment-gated document
  swap that was previously a listed gap: Brand Owners only get the real file
  once the case's ADVANCE payment layer is `PAID`, otherwise they get a
  placeholder message (this logic lived in `case.views` in shadow-api).
- **Materials & BOM**: RM/PM suppliers, `raw_materials`/`packaging_materials`,
  product↔material pricing, and Bill of Materials build/update-by-case,
  ported from `materials.views` (`RawMaterialViewSet`,
  `PackagingMaterialViewSet`, `BillOfMaterialsViewSet.get_bom_by_case` /
  `update_by_case`) into `backend/src/routes/materials.js`. AMs manage the
  catalog at `/am/materials`; the BOM's total cost shows on both the AM and
  Brand Owner case detail pages.

Not ported in this pass from the wider `product` app: `Parameter`/`POM`
subcategory-level costed spec fields have tables (`parameters`,
`case_parameters`) but no routes yet, and the CKEditor-rich category/
subcategory description fields were left as plain text.

**If you already have a database from before this merge**, run
`backend/src/config/product_materials_migration.sql` once to add the new
tables (schema.sql is CREATE-only and meant for fresh databases, but already
includes everything below for new installs).

## Ops console merge

The Account Manager / Brand Owner / Factory Owner ops console was originally
a separate Django backend (`shadow-api`, ~34,000 lines across 18 apps) plus a
separate Next.js frontend (`faoud-frontend`). The core operational loop —
the actual flow between AM, Brand Owner, and Factory Owner around a case —
has been ported in depth:

- **Case lifecycle**: create, get, archive/restore/soft-delete, rename,
  notes, color, priority — ported from `case.views` (`CaseViews`,
  `ArchiveCaseView`, `RestoreCaseView`, `SoftDeleteCaseView`,
  `UpdateCaseNameView`, `CaseNotesUpdateView`, `UpdateCaseColorView`,
  `UpdateCasePriorityView`) into `backend/src/routes/cases.js`.
- **Stage engine**: an ordered `stages` table (seeded with
  FactorySelection → Briefing → Formulation → Sampling → Orders →
  Production → Quality Check → Dispatch → Reviewed) and a
  `case_progress_stages` join table track which stages are complete, ported
  from `case.models.Stage`/`ProgressStage` and `UpdateCaseStageView` /
  `GetAvailableStagesView` into `backend/src/routes/stages.js`.
- **Operational status checklist**: a separate per-case checklist (GST
  verified, trademark verified, etc.) independent of the stage timeline,
  ported from `CaseOperationalStatus*` views into `backend/src/routes/ops-status.js`.
- **AM assignment**: the real privileged-AM logic — reassigning a case
  reassigns every case for that brand by default (`scope=brand`), privileged
  AMs (`is_privileged_am`, replacing shadow-api's Django `superAM`/`MNGMNT`
  groups) stay on every case as viewers, and each reassignment logs an
  alert — ported from `CaseAssignmentView` into `backend/src/routes/case-assignment.js`.
- **Bidding**: cases open for bidding are computed the *real* way — stage
  "FactorySelection" completed and no factory assigned yet (ported from
  `supply.views.CaseListForBiddingView`), not a simple flag. Factories
  submit a `quote`; AMs tag bids (shortlisted / best value / backup) via
  `ManageBidsView`; only tagged bids are shown to the Brand Owner, and
  factory identity is anonymized until a winner is picked (ported from
  `BrandOwnerBidsView` + `supply/help.py`'s `anonymize_factory_data`);
  accepting a bid assigns the factory and locks every other bid on the case
  (ported from `UpdateCaseWithFactoryView`) — all in `backend/src/routes/bids.js`.
- **Case users**: who's on a case (Brand Owner, AMs, Factory Owner), ported
  from `CaseUsersView`.
- **Factory profile**: extended with the real fields from `supply.models.Factory`
  (GST, director/POC contacts, licenses, capacity, exports, etc.).

Roles: `brand` and `factory` accounts are shared between the public
marketplace and the ops console — the same login also unlocks a case
workspace for those roles. `account_manager` is a new role for internal ops
staff; `is_privileged_am` marks the senior AMs (shadow-api's `superAM`/
`MNGMNT` Django groups).

The dashboards now include real sub-pages, not just one screen each:
- **AM**: `/am/dashboard` (assigned cases + alerts), `/am/brands` (brand workspace),
  `/am/cases/[id]` (the actual case cockpit — stage timeline you can toggle,
  operational-status checklist, AM assignment/reassignment, bid review with
  tagging and accept).
- **Brand Owner**: `/brand/dashboard` (case list), `/brand/cases/[id]`
  (stage progress, factory, documents), `/brand/payments` (payment history).
- **Factory Owner**: `/factory/dashboard` (open cases to bid on + your bid
  history), `/factory/profile` (factory profile editor).

The public landing page (`pages/index.js`) was checked directly against the
live www.faoud.com and now matches its actual section structure: hero,
"What We Manufacture", the 4-block services grid, trusted-by strip, Brand/
Factory gateway CTA, "Seamless Dashboard Experience", stats, "Who Uses
Faoud", the manufacturing-growth feature grid, blog teaser, and closing CTA.
Copy is paraphrased rather than copied verbatim; company logos in the
trusted-by strip are shown as text placeholders since I don't have rights to
the actual logo image files — drop real ones into `public/assets/` and swap
the `<span>`s for `<img>`s when you have them.

**If you already have a running database**, run
`backend/src/config/ops_console_migration.sql` once to add the new tables/
enum values (schema.sql is CREATE-only and meant for fresh databases).

---

## Getting this running — iPad-friendly path (no local terminal needed)

### 1. Push this code to GitHub
- Create a new **private** repo on github.com (works fine in Safari)
- Upload this whole folder using GitHub's "Add file → Upload files" in the browser, or:
- Open **GitHub Codespaces** (github.com → your repo → Code → Codespaces → Create) — this gives you a full VS Code + terminal in the browser, works on iPad. Run:
  ```
  git add . && git commit -m "initial commit" && git push
  ```

### 2. Test it locally in Codespaces (optional but recommended)
Inside the Codespaces terminal:
```
docker-compose up --build
```
Then open the forwarded port 3000 to see the site live, port 4000 for the API health check (`/api/health`).

### 3. Deploy to AWS

**Easiest path (fully browser-based, ideal for iPad): AWS Amplify + RDS**

1. **Database** — AWS Console → RDS → Create database → PostgreSQL → free tier (db.t3.micro) → note the endpoint, username, password.
2. Once created, run the migration once. Easiest way without a terminal: use Codespaces (connects to RDS since RDS can be made publicly accessible temporarily), run `npm install && npm run migrate` in `/backend`, pointing `.env` at the RDS endpoint.
3. **Backend** — AWS Console → Elastic Beanstalk → Create application → Node.js platform → upload `backend` folder as a zip (Elastic Beanstalk builds it directly, no CLI needed) → set environment variables (DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, JWT_SECRET, FRONTEND_URL) in Configuration → Software.
4. **Frontend** — AWS Console → Amplify → Host web app → Connect your GitHub repo → select `frontend` folder as the app root → Amplify auto-detects Next.js and builds/deploys on every push → set `NEXT_PUBLIC_API_URL` env var to your Elastic Beanstalk backend URL.
5. **Domain** — Route 53 → point your domain (e.g. www.faoud.com) at the Amplify app (CNAME) and optionally at Elastic Beanstalk for `api.faoud.com`.

This entire path (RDS, Elastic Beanstalk, Amplify, Route 53) is done through the AWS Console in a browser — no local machine needed.

**Alternative:** Railway.app (since you've used it before) can host backend + Postgres + frontend in a few clicks with GitHub auto-deploy, then point your domain's DNS at Railway. Simpler than AWS if you want something live today; AWS gives more control for production scale.

---

## Environment variables

**backend/.env** (see `.env.example`):
```
DB_HOST=<your RDS endpoint>
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=<your password>
DB_NAME=faoud
DB_SSL=true
JWT_SECRET=<generate a long random string>
FRONTEND_URL=https://www.faoud.com
```

**frontend** (Amplify environment variables):
```
NEXT_PUBLIC_API_URL=https://api.faoud.com/api
```

## Local dev (Codespaces or any machine)
```
docker-compose up --build
```
Then run migrations once:
```
docker exec -it faoud-clone-backend-1 npm run migrate
```

## API summary
| Method | Route | Purpose |
|---|---|---|
| POST | /api/auth/signup | Create account |
| POST | /api/auth/login | Login |
| GET | /api/marketplace/products | List products (filter by category/search) |
| POST | /api/marketplace/products | Factory creates a listing |
| GET | /api/marketplace/factories | List verified factories |
| POST | /api/orders | Brand creates order/quote request |
| GET | /api/orders | List orders (role-aware) |
| PATCH | /api/orders/:id/status | Factory updates order status |
| POST | /api/rfqs | Brand posts RFQ |
| POST | /api/rfqs/:id/quotes | Factory submits quote |
| POST | /api/leads | Contact/consultation form |
| GET | /api/blog | List published posts |
| POST | /api/questions/new-case?category= | Start a case with the branching intake questionnaire |
| POST | /api/questions/choose-answer | Answer a question, get the next one |
| POST | /api/questions/submit-answers | Bulk-submit a full answer set, creates the case |
| GET/POST | /api/products | List/create products |
| POST | /api/products/:id/clone | Version a product into a new copy |
| GET | /api/materials/cases/:caseId/bom | Get/build a case's Bill of Materials |
| POST | /api/formulation/cases/:caseId/upload | AM uploads the formulation PDF for a case |
| GET | /api/formulation/cases/:caseId | Fetch formulation (payment-gated for Brand Owners) |
