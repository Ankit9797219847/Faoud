import Link from 'next/link';
import { useState } from 'react';
import Cookies from 'js-cookie';
import { roleHome } from '../lib/roles';

export default function Layout({ children }) {
  const [menuOpen, setMenuOpen] = useState(false);
  // Lightweight logged-in check (cookie only, no API call) just to decide
  // whether the header shows "Login" or a link into the AM/Brand/Factory ops
  // console workspace ported from shadow-api.
  const role = typeof window !== 'undefined' ? Cookies.get('faoud_role') : null;

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-navy/10 bg-sand/95 backdrop-blur sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="font-display text-2xl text-navy tracking-tight">
            Faoud
          </Link>

          <nav className="hidden md:flex items-center gap-8 font-body text-sm text-ink/80">
            <Link href="/" className="hover:text-teal transition">Home</Link>
            <Link href="/marketplace" className="hover:text-teal transition">Marketplace</Link>
            <Link href="/manufacture/orders" className="hover:text-teal transition">Live Orders</Link>
            <Link href="/blog" className="hover:text-teal transition">Blog</Link>
            <Link href="/contact" className="hover:text-teal transition">Contact</Link>
          </nav>

          <div className="hidden md:flex items-center gap-3">
            {role ? (
              <Link
                href={roleHome(role)}
                className="text-sm font-medium text-navy border border-navy/20 rounded-full px-4 py-2 hover:bg-navy hover:text-sand transition"
              >
                Workspace
              </Link>
            ) : (
              <Link
                href="/login"
                className="text-sm font-medium text-navy border border-navy/20 rounded-full px-4 py-2 hover:bg-navy hover:text-sand transition"
              >
                Login
              </Link>
            )}
            <Link
              href="/signup"
              className="text-sm font-medium bg-clay text-white rounded-full px-4 py-2 hover:opacity-90 transition"
            >
              Join Now
            </Link>
          </div>

          <button className="md:hidden text-navy" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
            <span className="text-2xl">{menuOpen ? '✕' : '☰'}</span>
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden px-6 pb-4 flex flex-col gap-3 text-ink/80">
            <Link href="/marketplace">Marketplace</Link>
            <Link href="/manufacture/orders">Live Orders</Link>
            <Link href="/blog">Blog</Link>
            <Link href="/contact">Contact</Link>
            <Link href="/login">Login</Link>
            <Link href="/signup" className="text-clay font-medium">Join Now</Link>
          </div>
        )}
      </header>

      <main className="flex-1">{children}</main>

      <footer className="bg-navy text-sand/80 mt-24">
        <div className="max-w-6xl mx-auto px-6 py-14 grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <div className="font-display text-xl text-white mb-3">Faoud</div>
            <p className="text-sm leading-relaxed">
              India's factory-on-cloud for FMCG brands and manufacturing partners across the country.
            </p>
          </div>
          <div>
            <div className="text-white font-medium mb-3 text-sm">Explore</div>
            <ul className="space-y-2 text-sm">
              <li><Link href="/marketplace">Product Marketplace</Link></li>
              <li><Link href="/manufacture/orders">Live Orders</Link></li>
              <li><Link href="/blog">Blog</Link></li>
              <li><Link href="/privacy-policy">Privacy Policy</Link></li>
            </ul>
          </div>
          <div>
            <div className="text-white font-medium mb-3 text-sm">Get in touch</div>
            <ul className="space-y-2 text-sm">
              <li>sales@faoud.com</li>
              <li>+91 98205 10399</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/10 py-6 text-center text-xs text-sand/50">
          © {new Date().getFullYear()} Faoud. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
