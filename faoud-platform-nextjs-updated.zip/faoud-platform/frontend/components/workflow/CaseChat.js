import { useEffect, useState, useCallback } from 'react';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

// GET/POST /cases/<id>/messages/  — ported from comms.views (case-scoped
// chat). currentUserRole 'brand' is the only role gated by ChatPermission
// (bo_can_message_fo); AM and Factory can always send.
export default function CaseChat({ caseId, currentUserRole, showPermissionToggle }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [canMessage, setCanMessage] = useState(true);

  const load = useCallback(async () => {
    if (!caseId) return;
    try {
      const res = await djangoApi.get(`/cases/${caseId}/messages/`);
      setMessages(res.data || []);
    } catch {
      // non-fatal — chat is a secondary panel
    }
    try {
      const perm = await djangoApi.get(`/cases/${caseId}/chat-permission/`);
      setCanMessage(perm.data?.bo_can_message_fo ?? true);
    } catch {
      setCanMessage(true);
    }
  }, [caseId]);

  useEffect(() => {
    load();
    const interval = setInterval(load, 8000);
    return () => clearInterval(interval);
  }, [load]);

  async function send() {
    if (!text.trim()) return;
    setBusy(true);
    setError(null);
    try {
      await ensureCsrfCookie();
      await djangoApi.post(`/cases/${caseId}/messages/`, { message: text.trim() });
      setText('');
      await load();
    } catch (e) {
      setError(e.response?.data?.detail || 'Could not send message.');
    } finally {
      setBusy(false);
    }
  }

  async function togglePermission() {
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/cases/${caseId}/chat-permission/`, { bo_can_message_fo: !canMessage });
      setCanMessage((v) => !v);
    } catch {
      // non-fatal
    }
  }

  const locked = currentUserRole === 'brand' && !canMessage;

  return (
    <section>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-display text-lg text-ink">Messages</h2>
        {showPermissionToggle && (
          <button onClick={togglePermission} className="text-xs text-muted underline">
            {canMessage ? 'Disable Brand ↔ Factory chat' : 'Enable Brand ↔ Factory chat'}
          </button>
        )}
      </div>
      <div className="rounded-sm border border-line bg-panel p-4 text-sm">
        <div className="mb-3 max-h-64 space-y-2 overflow-y-auto">
          {messages.length === 0 && <p className="text-xs text-muted">No messages yet.</p>}
          {messages.map((m) => (
            <div key={m.id} className="rounded-sm bg-white/60 px-3 py-2 text-xs">
              <span className="text-muted">{new Date(m.timestamp).toLocaleString()}</span>
              <p className="text-ink">{m.message}</p>
            </div>
          ))}
        </div>
        {error && <p className="mb-2 text-danger text-xs">{error}</p>}
        {locked ? (
          <p className="text-xs text-muted">Messaging the Factory Owner is currently disabled for this case.</p>
        ) : (
          <div className="flex gap-2">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Write a message…"
              className="flex-1 rounded-sm border border-line px-3 py-1.5 text-xs"
              onKeyDown={(e) => e.key === 'Enter' && send()}
            />
            <button
              onClick={send}
              disabled={busy || !text.trim()}
              className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper hover:opacity-90 disabled:opacity-50"
            >
              Send
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
