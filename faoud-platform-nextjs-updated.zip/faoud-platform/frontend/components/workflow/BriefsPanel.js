import { useEffect, useState, useCallback } from 'react';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

// GET    /cases/<id>/briefs/   -> list briefs for this case (AM only)
// POST   /brief/create/        -> body includes `case`
// PUT    /brief/<id>/          -> update
// DELETE /brief/<id>/          -> delete
export default function BriefsPanel({ caseId }) {
  const [briefs, setBriefs] = useState([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      const res = await djangoApi.get(`/cases/${caseId}/briefs/`);
      setBriefs(Array.isArray(res.data) ? res.data : []);
    } catch (e) {
      setError(e.response?.data?.error || 'Could not load briefs.');
    }
  }, [caseId]);

  useEffect(() => {
    load();
  }, [load]);

  async function addBrief() {
    if (!text.trim()) return;
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.post('/brief/create/', { case: caseId, brief: text });
      setText('');
      await load();
    } catch (e) {
      setError(e.response?.data?.error || 'Could not add brief.');
    } finally {
      setBusy(false);
    }
  }

  async function removeBrief(id) {
    if (!confirm('Delete this brief?')) return;
    try {
      await ensureCsrfCookie();
      await djangoApi.delete(`/brief/${id}/`);
      await load();
    } catch (e) {
      alert('Could not delete brief.');
    }
  }

  return (
    <section>
      <h2 className="mb-3 font-display text-lg text-ink">Briefs</h2>
      {error && <p className="mb-3 text-sm text-danger">{error}</p>}
      <div className="flex flex-col gap-2">
        {briefs.map((b) => (
          <div key={b.id} className="flex items-start justify-between gap-3 rounded-sm border border-line bg-panel px-4 py-2.5 text-sm">
            <div>
              <p className="text-ink">{b.brief}</p>
              <p className="mt-1 font-mono text-[11px] text-muted">
                {b.added_by || 'Unknown'} · {b.date}
              </p>
            </div>
            <button onClick={() => removeBrief(b.id)} className="text-danger underline decoration-line underline-offset-4">
              Delete
            </button>
          </div>
        ))}
        {briefs.length === 0 && <p className="text-sm text-muted">No briefs yet.</p>}
      </div>
      <div className="mt-3 flex items-center gap-2">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="New brief note…"
          className="flex-1 rounded-sm border border-line px-3 py-2 text-sm"
        />
        <button
          onClick={addBrief}
          disabled={busy}
          className="rounded-sm bg-ink px-4 py-2 text-xs font-medium text-paper hover:opacity-90 disabled:opacity-50"
        >
          Add
        </button>
      </div>
    </section>
  );
}
