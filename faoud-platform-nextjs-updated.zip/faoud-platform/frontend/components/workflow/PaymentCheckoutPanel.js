import { useState } from 'react';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

function loadRazorpayScript() {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

// Ported from the payments.views checkout flow: create an Order for the
// case (if one doesn't exist yet), add an ADVANCE or FINAL payment layer,
// then open Razorpay Checkout with the returned order, and verify the
// signature server-side once it succeeds.
export default function PaymentCheckoutPanel({ caseId }) {
  const [amount, setAmount] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  async function pay(layerType) {
    if (!amount || Number(amount) <= 0) {
      setError('Enter an amount first.');
      return;
    }
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      await ensureCsrfCookie();

      const orderRes = await djangoApi.post('/payments/orders', {
        case_id: caseId,
        total_amount: amount
      });
      const orderId = orderRes.data.id;

      const layerPath = layerType === 'ADVANCE' ? 'advance' : 'final';
      const layerRes = await djangoApi.post(`/payments/orders/${orderId}/${layerPath}`, { amount });

      if (!layerRes.data.razorpay_configured) {
        setMessage(
          layerRes.data.warning ||
            'Payments aren\u2019t configured yet on this deployment — the order was recorded, but Razorpay Checkout isn\u2019t available.'
        );
        return;
      }

      const scriptLoaded = await loadRazorpayScript();
      if (!scriptLoaded) {
        setError('Could not load Razorpay Checkout. Check your connection and try again.');
        return;
      }

      const rzp = new window.Razorpay({
        key: layerRes.data.razorpay_key_id,
        amount: layerRes.data.razorpay_order.amount,
        currency: layerRes.data.razorpay_order.currency,
        order_id: layerRes.data.razorpay_order.id,
        name: 'Faoud Industries',
        description: `${layerType === 'ADVANCE' ? 'Advance' : 'Final'} payment`,
        handler: async (response) => {
          try {
            await djangoApi.post('/payments/verify', {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature
            });
            setMessage('Payment verified — thank you.');
          } catch (e) {
            setError(e.response?.data?.detail || 'Payment succeeded but verification failed. Contact support.');
          }
        },
        modal: { ondismiss: () => setBusy(false) }
      });
      rzp.open();
    } catch (e) {
      setError(e.response?.data?.detail || 'Could not start checkout.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <section>
      <h2 className="mb-3 font-display text-lg text-ink">Payments</h2>
      <div className="rounded-sm border border-line bg-panel p-4 text-sm">
        {message && <p className="mb-2 text-teal">{message}</p>}
        {error && <p className="mb-2 text-danger">{error}</p>}
        <label className="mb-2 block text-xs text-muted">
          Amount (₹)
          <input
            type="number"
            min="1"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="mt-1 block w-full rounded-sm border border-line px-3 py-1.5 text-sm"
          />
        </label>
        <div className="flex gap-2">
          <button
            onClick={() => pay('ADVANCE')}
            disabled={busy}
            className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper hover:opacity-90 disabled:opacity-50"
          >
            Pay Advance
          </button>
          <button
            onClick={() => pay('FINAL')}
            disabled={busy}
            className="rounded-sm border border-line px-3 py-1.5 text-xs font-medium text-ink hover:border-ink/40 disabled:opacity-50"
          >
            Pay Final
          </button>
        </div>
      </div>
    </section>
  );
}
