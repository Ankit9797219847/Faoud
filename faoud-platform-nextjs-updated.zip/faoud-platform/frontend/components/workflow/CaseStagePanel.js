import { useState } from 'react';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

// GET  /cases/<id>/stages/            -> { stages: [...], next_stage }
// POST /cases/<id>/stage-transition/  -> { detail, applied_impacts, stage_summary }  (AM only)
export default function CaseStagePanel({ caseId, stages, canTransition, onChanged }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  async function transition(stageName, markComplete) {
    setBusy(true);
    setError(null);
    try {
      await ensureCsrfCookie();
      await djangoApi.post(`/cases/${caseId}/stage-transition/`, {
        stage_name: stageName,
        mark_complete: markComplete
      });
      onChanged?.();
    } catch (e) {
      setError(e.response?.data?.detail || 'Could not update this stage.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <section>
      <h2 className="mb-3 font-display text-lg text-ink">Stage timeline</h2>
      {error && <p className="mb-3 text-sm text-danger">{error}</p>}
      <ol className="flex flex-col gap-2">
        {stages.map((s) => (
          <li key={s.id}>
            {canTransition ? (
              <button
                onClick={() => transition(s.name, !s.completed)}
                disabled={busy}
                className={`flex w-full items-center gap-3 rounded-sm border px-4 py-2.5 text-left text-sm transition-colors ${
                  s.completed
                    ? 'border-teal/30 bg-teal/5 text-ink'
                    : 'border-line bg-panel text-muted hover:border-ink/30'
                }`}
              >
                <span className={`h-2 w-2 rounded-full ${s.completed ? 'bg-teal' : 'bg-line'}`} aria-hidden="true" />
                {s.name}
                {s.completed && s.completion_date && (
                  <span className="ml-auto font-mono text-[11px] text-muted">
                    {new Date(s.completion_date).toLocaleDateString()}
                  </span>
                )}
              </button>
            ) : (
              <div
                className={`flex items-center gap-3 rounded-sm border px-4 py-2.5 text-sm ${
                  s.completed ? 'border-teal/30 bg-teal/5 text-ink' : 'border-line bg-panel text-muted'
                }`}
              >
                <span className={`h-2 w-2 rounded-full ${s.completed ? 'bg-teal' : 'bg-line'}`} aria-hidden="true" />
                {s.name}
                {s.completed && s.completion_date && (
                  <span className="ml-auto font-mono text-[11px] text-muted">
                    {new Date(s.completion_date).toLocaleDateString()}
                  </span>
                )}
              </div>
            )}
          </li>
        ))}
      </ol>
    </section>
  );
}
