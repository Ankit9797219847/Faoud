import { useEffect, useState, useCallback } from 'react';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';
import StatusBadge from '../StatusBadge';

// Brand Owner: GET /cases/<id>/bid-list/           (BrandOwnerBidsView — anonymized, tagged bids only, read-only)
// Account Mgr: GET /cases/<id>/bids/                (ManageBidsView — all bids for the case)
//   tagging/accepting a bid is done via the real per-bid endpoint: PATCH /bids/<bid_id>/
//   (ManageBidsView's own PATCH is registered on the wrong URL — case_id, not bid_id —
//   so it can never actually be called; BidViewSet.partial_update is the working route.)
const TAGS = ['shortlisted', 'not_shortlisted', 'best_value', 'backup'];

export default function CaseBidsPanel({ caseId, role }) {
  const [bids, setBids] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [busyId, setBusyId] = useState(null);

  const listUrl = role === 'am' ? `/cases/${caseId}/bids/` : `/cases/${caseId}/bid-list/`;

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await djangoApi.get(listUrl);
      setBids(Array.isArray(res.data) ? res.data : []);
    } catch (e) {
      setError(e.response?.data?.detail || 'Could not load bids for this case.');
    } finally {
      setLoading(false);
    }
  }, [listUrl]);

  useEffect(() => {
    load();
  }, [load]);

  async function patchBid(bidId, payload) {
    setBusyId(bidId);
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/bids/${bidId}/`, payload);
      await load();
    } catch (e) {
      alert(e.response?.data?.detail || 'Could not update this bid.');
    } finally {
      setBusyId(null);
    }
  }

  return (
    <section>
      <h2 className="mb-3 font-display text-lg text-ink">Bids</h2>
      {loading && <p className="text-sm text-muted">Loading…</p>}
      {error && <p className="rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">{error}</p>}
      {!loading && !error && bids.length === 0 && (
        <p className="rounded-sm border border-line bg-panel px-4 py-3 text-sm text-muted">
          No bids {role === 'am' ? 'submitted yet' : 'shortlisted for you yet'}.
        </p>
      )}
      {!loading && bids.length > 0 && (
        <div className="overflow-hidden rounded-sm border border-line bg-panel">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-line bg-black/[0.02] font-mono text-[11px] uppercase tracking-wider text-muted">
                <th className="px-4 py-3 font-medium">Factory</th>
                <th className="px-4 py-3 font-medium">Quote</th>
                <th className="px-4 py-3 font-medium">Status</th>
                {role === 'am' && <th className="px-4 py-3 font-medium">Tag</th>}
                {role === 'am' && <th className="px-4 py-3 font-medium" />}
              </tr>
            </thead>
            <tbody>
              {bids.map((b) => (
                <tr key={b.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-3 text-ink">
                    {typeof b.factory === 'object' ? b.factory?.name : `Factory #${b.factory}`}
                  </td>
                  <td className="px-4 py-3 font-mono text-ink/80">₹{role === 'am' ? b.quote : b.quote_bo}</td>
                  <td className="px-4 py-3">
                    <StatusBadge label={b.status} />
                  </td>
                  {role === 'am' && (
                    <td className="px-4 py-3">
                      <select
                        value={b.tag || ''}
                        onChange={(e) => patchBid(b.id, { tag: e.target.value })}
                        disabled={busyId === b.id}
                        className="rounded-sm border border-line bg-white px-2 py-1 text-xs"
                      >
                        <option value="">No tag</option>
                        {TAGS.map((t) => (
                          <option key={t} value={t}>
                            {t}
                          </option>
                        ))}
                      </select>
                    </td>
                  )}
                  {role === 'am' && (
                    <td className="px-4 py-3">
                      {b.status !== 'accepted' && (
                        <button
                          onClick={() => patchBid(b.id, { status: 'accepted' })}
                          disabled={busyId === b.id}
                          className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper hover:opacity-90 disabled:opacity-50"
                        >
                          Accept
                        </button>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
