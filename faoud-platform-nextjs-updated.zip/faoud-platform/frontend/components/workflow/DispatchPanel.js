import { useEffect, useState, useCallback } from 'react';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';
import StatusBadge from '../StatusBadge';

// GET   /cases/<id>/dispatch/                       -> dispatch record (404 if none created yet)
// PATCH /cases/<id>/dispatch/set-delivery-type/      -> Brand Owner picks delivery_type (+ address)
// PATCH /cases/<id>/dispatch/packing/                -> Factory Owner fills packing details
// PATCH /cases/<id>/dispatch/details/                -> Account Manager confirms dispatch details
const DELIVERY_TYPES = ['faoud_delivers', 'self_delivery'];

export default function DispatchPanel({ caseId, role }) {
  const [dispatch, setDispatch] = useState(null);
  const [exists, setExists] = useState(true);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [deliveryType, setDeliveryType] = useState('');
  const [trackingId, setTrackingId] = useState('');
  const [trackingLink, setTrackingLink] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await djangoApi.get(`/cases/${caseId}/dispatch/`);
      setDispatch(res.data);
      setExists(true);
      setDeliveryType(res.data.delivery_type || '');
      setTrackingId(res.data.tracking_number || '');
    } catch (e) {
      if (e.response?.status === 404) {
        setExists(false);
        setDispatch(null);
      } else {
        setError(e.response?.data?.detail || 'Could not load dispatch info.');
      }
    } finally {
      setLoading(false);
    }
  }, [caseId]);

  useEffect(() => {
    load();
  }, [load]);

  async function setDeliveryTypeAction() {
    if (!deliveryType) return;
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/cases/${caseId}/dispatch/set-delivery-type/`, { delivery_type: deliveryType });
      await load();
    } catch (e) {
      setError(e.response?.data?.delivery_type || e.response?.data?.detail || 'Could not set delivery type.');
    } finally {
      setBusy(false);
    }
  }

  async function updatePacking() {
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/cases/${caseId}/dispatch/packing/`, {
        tracking_number: trackingId
      });
      await load();
    } catch (e) {
      setError(e.response?.data?.detail || 'Could not update packing details.');
    } finally {
      setBusy(false);
    }
  }

  async function confirmDetails() {
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/cases/${caseId}/dispatch/details/`, {
        tracking_number: trackingId
      });
      await load();
    } catch (e) {
      setError(e.response?.data?.detail || 'Could not confirm dispatch details.');
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <p className="text-sm text-muted">Loading dispatch…</p>;

  return (
    <section>
      <h2 className="mb-3 font-display text-lg text-ink">Dispatch</h2>
      {error && <p className="mb-3 text-sm text-danger">{error}</p>}

      <div className="rounded-sm border border-line bg-panel p-4 text-sm">
        {exists && dispatch && (
          <div className="mb-4 flex items-center justify-between">
            <span className="text-muted">Status</span>
            <StatusBadge label={dispatch.manufacturing_status} />
          </div>
        )}

        {!exists && role !== 'brand' && (
          <p className="mb-4 text-muted">
            No dispatch record yet — the Brand Owner needs to pick a delivery type first.
          </p>
        )}

        {role === 'brand' && (
          <div className="flex items-center gap-2">
            <select
              value={deliveryType}
              onChange={(e) => setDeliveryType(e.target.value)}
              className="rounded-sm border border-line bg-white px-2 py-1.5 text-sm"
            >
              <option value="">Select delivery type…</option>
              {DELIVERY_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t.replace('_', ' ')}
                </option>
              ))}
            </select>
            <button
              onClick={setDeliveryTypeAction}
              disabled={busy || !deliveryType}
              className="rounded-sm bg-teal px-3 py-1.5 text-xs font-medium text-white hover:opacity-90 disabled:opacity-50"
            >
              Save
            </button>
          </div>
        )}

        {role === 'factory' && exists && (
          <div className="flex items-center gap-2">
            <input
              value={trackingId}
              onChange={(e) => setTrackingId(e.target.value)}
              placeholder="Tracking number"
              className="rounded-sm border border-line bg-white px-2 py-1.5 text-sm"
            />
            <button
              onClick={updatePacking}
              disabled={busy}
              className="rounded-sm bg-rust px-3 py-1.5 text-xs font-medium text-white hover:opacity-90 disabled:opacity-50"
            >
              Update packing
            </button>
          </div>
        )}

        {role === 'am' && exists && (
          <div className="flex items-center gap-2">
            <input
              value={trackingId}
              onChange={(e) => setTrackingId(e.target.value)}
              placeholder="Confirmed tracking number"
              className="rounded-sm border border-line bg-white px-2 py-1.5 text-sm"
            />
            <button
              onClick={confirmDetails}
              disabled={busy}
              className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper hover:opacity-90 disabled:opacity-50"
            >
              Confirm details
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
