import { useState } from 'react';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

// POST /cases/<id>/upload-formulation/  (multipart, field name "formulation")
// Requires the case to already have a product attached.
export default function FormulationUploadPanel({ caseId }) {
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  async function upload() {
    if (!file) return;
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      await ensureCsrfCookie();
      const body = new FormData();
      body.append('formulation', file);
      const res = await djangoApi.post(`/cases/${caseId}/upload-formulation/`, body, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setMessage(res.data.message || 'Uploaded.');
      setFile(null);
    } catch (e) {
      setError(e.response?.data?.error || 'Could not upload formulation.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <section>
      <h2 className="mb-3 font-display text-lg text-ink">Formulation</h2>
      <div className="rounded-sm border border-line bg-panel p-4 text-sm">
        {message && <p className="mb-2 text-teal">{message}</p>}
        {error && <p className="mb-2 text-danger">{error}</p>}
        <div className="flex items-center gap-2">
          <input
            type="file"
            accept="application/pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="text-xs text-muted"
          />
          <button
            onClick={upload}
            disabled={busy || !file}
            className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper hover:opacity-90 disabled:opacity-50"
          >
            {busy ? 'Uploading…' : 'Upload'}
          </button>
        </div>
        <p className="mt-2 text-xs text-muted">Requires a product to already be attached to this case.</p>
      </div>
    </section>
  );
}
