import { useEffect, useState, useCallback } from 'react';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

// GET   /qcs/completed/?case_id=<id>   -> AM/Factory see all entries; Brand sees only verified_by_am ones
// POST  /qcs/                          -> Account Manager creates a QC checkpoint {case, description}
// PATCH /qcs/<pk>/update-qc/           -> Factory Owner sets is_done (+ document); AM sets verified_by_am
export default function QCPanel({ caseId, role }) {
  const [entries, setEntries] = useState([]);
  const [description, setDescription] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      const res = await djangoApi.get('/qcs/completed/', { params: { case_id: caseId } });
      setEntries(Array.isArray(res.data) ? res.data : []);
    } catch (e) {
      setError(e.response?.data?.error || 'Could not load QC entries.');
    }
  }, [caseId]);

  useEffect(() => {
    load();
  }, [load]);

  async function addEntry() {
    if (!description.trim()) return;
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.post('/qcs/', { case: caseId, description });
      setDescription('');
      await load();
    } catch (e) {
      setError(e.response?.data?.error || 'Could not create QC entry.');
    } finally {
      setBusy(false);
    }
  }

  async function markDone(id) {
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/qcs/${id}/update-qc/`, { is_done: true });
      await load();
    } finally {
      setBusy(false);
    }
  }

  async function markVerified(id) {
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/qcs/${id}/update-qc/`, { verified_by_am: true });
      await load();
    } finally {
      setBusy(false);
    }
  }

  return (
    <section>
      <h2 className="mb-3 font-display text-lg text-ink">Quality checks</h2>
      {error && <p className="mb-3 text-sm text-danger">{error}</p>}
      <div className="flex flex-col gap-2">
        {entries.map((qc) => (
          <div key={qc.id} className="flex items-center justify-between rounded-sm border border-line bg-panel px-4 py-2.5 text-sm">
            <div>
              <p className="text-ink">{qc.description}</p>
              <p className="mt-0.5 font-mono text-[11px] text-muted">
                {qc.is_done ? 'Marked done' : 'Pending'} {qc.verified_by_am && '· Verified by AM'}
              </p>
            </div>
            <div className="flex gap-2">
              {role === 'factory' && !qc.is_done && (
                <button onClick={() => markDone(qc.id)} disabled={busy} className="rounded-sm bg-rust px-3 py-1.5 text-xs font-medium text-white">
                  Mark done
                </button>
              )}
              {role === 'am' && qc.is_done && !qc.verified_by_am && (
                <button onClick={() => markVerified(qc.id)} disabled={busy} className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper">
                  Verify
                </button>
              )}
            </div>
          </div>
        ))}
        {entries.length === 0 && <p className="text-sm text-muted">No QC entries yet.</p>}
      </div>

      {role === 'am' && (
        <div className="mt-3 flex items-center gap-2">
          <input
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="New QC checkpoint…"
            className="flex-1 rounded-sm border border-line px-3 py-2 text-sm"
          />
          <button
            onClick={addEntry}
            disabled={busy}
            className="rounded-sm bg-ink px-4 py-2 text-xs font-medium text-paper hover:opacity-90 disabled:opacity-50"
          >
            Add
          </button>
        </div>
      )}
    </section>
  );
}
