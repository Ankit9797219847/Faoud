import { useEffect, useState, useCallback } from 'react';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

// GET  /factory-owner/sample-orders/<bid_id>/tracking/  -> tracking record (auto-created if missing)
// POST /factory-owner/sample-orders/<bid_id>/tracking/  -> update tracking_id / tracking_link / remarks
export default function BidTrackingPanel({ bidId }) {
  const [tracking, setTracking] = useState(null);
  const [form, setForm] = useState({ tracking_id: '', tracking_link: '', remarks: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      const res = await djangoApi.get(`/factory-owner/sample-orders/${bidId}/tracking/`);
      setTracking(res.data);
      setForm({
        tracking_id: res.data.tracking_id || '',
        tracking_link: res.data.tracking_link || '',
        remarks: res.data.remarks || ''
      });
    } catch (e) {
      setError(e.response?.data?.detail || 'Could not load tracking details.');
    }
  }, [bidId]);

  useEffect(() => {
    load();
  }, [load]);

  async function save() {
    setBusy(true);
    setError(null);
    try {
      await ensureCsrfCookie();
      await djangoApi.post(`/factory-owner/sample-orders/${bidId}/tracking/`, form);
      await load();
    } catch (e) {
      setError(e.response?.data?.detail || 'Could not save tracking details.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-sm border border-line bg-panel p-4">
      {error && <p className="mb-3 text-sm text-danger">{error}</p>}
      {tracking?.is_confirmed_by_am && (
        <p className="mb-3 text-xs text-teal">Confirmed by Account Manager ✓</p>
      )}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <input
          value={form.tracking_id}
          onChange={(e) => setForm({ ...form, tracking_id: e.target.value })}
          placeholder="Tracking ID"
          className="rounded-sm border border-line px-3 py-2 text-sm"
        />
        <input
          value={form.tracking_link}
          onChange={(e) => setForm({ ...form, tracking_link: e.target.value })}
          placeholder="Tracking link (URL)"
          className="rounded-sm border border-line px-3 py-2 text-sm"
        />
      </div>
      <textarea
        value={form.remarks}
        onChange={(e) => setForm({ ...form, remarks: e.target.value })}
        placeholder="Remarks"
        rows={2}
        className="mt-3 w-full rounded-sm border border-line px-3 py-2 text-sm"
      />
      <button
        onClick={save}
        disabled={busy}
        className="mt-3 rounded-sm bg-rust px-4 py-2 text-xs font-medium text-white hover:opacity-90 disabled:opacity-50"
      >
        {busy ? 'Saving…' : 'Save tracking'}
      </button>
    </div>
  );
}
