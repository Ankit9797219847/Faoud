import { useEffect, useState, useCallback } from 'react';
import djangoApi, { ensureCsrfCookie } from '../lib/djangoApi';
import DataTable from './DataTable';
import ResourceForm from './ResourceForm';

export default function ResourceManager({ resource }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [editing, setEditing] = useState(null); // row object, or {} for "new", or null for closed
  const [formError, setFormError] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const columns = resource.fields
    .filter((f) => f.type !== 'textarea')
    .slice(0, 6)
    .map((f) => ({ name: f.name, type: f.type, label: f.label }));

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const res = await djangoApi.get(resource.listUrl);
      const data = res.data;
      setRows(Array.isArray(data) ? data : data.results || []);
    } catch (e) {
      setLoadError(
        e.response?.status === 404
          ? 'This endpoint is not reachable yet — check NEXT_PUBLIC_DJANGO_API_URL.'
          : e.response?.data?.detail || 'Could not load this data.'
      );
    } finally {
      setLoading(false);
    }
  }, [resource.listUrl]);

  useEffect(() => {
    load();
  }, [load]);

  async function handleSubmit(payload) {
    setSubmitting(true);
    setFormError(null);
    try {
      await ensureCsrfCookie();
      if (editing?.id) {
        await djangoApi.patch(`${resource.listUrl}${editing.id}/`, payload);
      } else {
        await djangoApi.post(resource.createUrl || resource.listUrl, payload);
      }
      setEditing(null);
      await load();
    } catch (e) {
      setFormError(
        e.response?.data ? JSON.stringify(e.response.data) : 'Save failed. Please check the fields and try again.'
      );
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(row) {
    if (!confirm(`Delete this ${resource.label.toLowerCase()} entry? This cannot be undone.`)) return;
    try {
      await ensureCsrfCookie();
      await djangoApi.delete(`${resource.listUrl}${row.id}/`);
      await load();
    } catch (e) {
      alert(e.response?.data?.detail || 'Delete failed.');
    }
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl text-ink">{resource.label}</h2>
          <p className="font-mono text-[11px] uppercase tracking-wider text-muted">
            {resource.listUrl}
            {resource.readOnly && ' · read-only (backend has no write endpoint for this)'}
          </p>
        </div>
        {!resource.readOnly && (
          <button
            onClick={() => setEditing({})}
            className="rounded-lg bg-clay px-4 py-2 text-sm font-medium text-white hover:opacity-90"
          >
            + New
          </button>
        )}
      </div>

      <DataTable
        columns={columns}
        rows={rows}
        loading={loading}
        error={loadError}
        onEdit={resource.readOnly ? undefined : (row) => setEditing(row)}
        onDelete={resource.readOnly || resource.noDelete ? undefined : handleDelete}
        emptyLabel={`No ${resource.label.toLowerCase()} yet.`}
      />

      {!resource.readOnly && editing !== null && (
        <ResourceForm
          resourceLabel={resource.label}
          fields={resource.fields}
          initialValues={editing.id ? editing : null}
          submitting={submitting}
          error={formError}
          onCancel={() => {
            setEditing(null);
            setFormError(null);
          }}
          onSubmit={handleSubmit}
        />
      )}
    </div>
  );
}
