const TONE_MAP = {
  done: 'bg-teal/10 text-teal border-teal/30',
  approved: 'bg-teal/10 text-teal border-teal/30',
  active: 'bg-ink/10 text-ink border-ink/30',
  pending: 'bg-amber/10 text-amber border-amber/30',
  review: 'bg-amber/10 text-amber border-amber/30',
  rejected: 'bg-danger/10 text-danger border-danger/30',
  cancelled: 'bg-danger/10 text-danger border-danger/30',
  default: 'bg-muted/10 text-muted border-muted/30'
};

function toneFor(value) {
  if (!value) return TONE_MAP.default;
  const v = String(value).toLowerCase();
  for (const key of Object.keys(TONE_MAP)) {
    if (v.includes(key)) return TONE_MAP[key];
  }
  return TONE_MAP.default;
}

export default function StatusBadge({ label }) {
  return (
    <span
      className={`inline-flex items-center rounded-sm border px-2 py-0.5 font-mono text-[11px] uppercase tracking-wider ${toneFor(
        label
      )}`}
    >
      {label || 'unknown'}
    </span>
  );
}
