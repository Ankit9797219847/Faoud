import Link from 'next/link';
import { useRouter } from 'next/router';
import { useAuth } from '../lib/useAuth';
import djangoApi, { ensureCsrfCookie } from '../lib/djangoApi';

const ACCENTS = {
  ink: { bar: 'bg-ink', text: 'text-ink', chip: 'bg-ink text-paper' },
  teal: { bar: 'bg-teal', text: 'text-teal', chip: 'bg-teal text-paper' },
  rust: { bar: 'bg-rust', text: 'text-rust', chip: 'bg-rust text-paper' }
};

export default function OpsShell({ roleLabel, accent, navItems, activeHref, children }) {
  const { user } = useAuth();
  const router = useRouter();
  const tone = ACCENTS[accent] || ACCENTS.ink;

  async function logout() {
    await ensureCsrfCookie();
    await djangoApi.post('/auth/logout');
    router.push('/login');
  }

  return (
    <div className="flex min-h-screen bg-paper">
      {/* Ledger rail: a stamped, colored spine identifying which side of the
          marketplace this dashboard belongs to (AM / Brand / Factory). */}
      <div className={`w-1.5 shrink-0 ${tone.bar}`} aria-hidden="true" />

      <aside className="flex w-60 shrink-0 flex-col border-r border-line px-5 py-6">
        <div className="mb-8">
          <p className="font-display text-lg leading-none text-ink">Faoud</p>
          <p className="mt-1 font-mono text-[11px] uppercase tracking-wider text-muted">
            Ops Console
          </p>
        </div>

        <span
          className={`mb-6 inline-flex w-fit items-center rounded-sm px-2 py-1 font-mono text-[11px] uppercase tracking-wider ${tone.chip}`}
        >
          {roleLabel}
        </span>

        <nav className="flex flex-col gap-1">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`rounded-sm px-3 py-2 text-sm transition-colors ${
                activeHref === item.href
                  ? `${tone.text} bg-black/[0.03] font-medium`
                  : 'text-ink/70 hover:bg-black/[0.03]'
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="mt-auto border-t border-line pt-4">
          <p className="truncate text-sm text-ink">{user?.full_name || user?.email}</p>
          <p className="truncate font-mono text-[11px] text-muted">{user?.email}</p>
          <Link
            href="/"
            className="mt-3 block text-sm text-muted underline decoration-line underline-offset-4 hover:text-ink"
          >
            Public site
          </Link>
          <button
            onClick={logout}
            className="mt-1 text-sm text-muted underline decoration-line underline-offset-4 hover:text-ink"
          >
            Sign out
          </button>
        </div>
      </aside>

      <main className="min-w-0 flex-1 px-10 py-8">{children}</main>
    </div>
  );
}
