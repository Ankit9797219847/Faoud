import { useState } from 'react';
import djangoApi from '../lib/djangoApi';
import { getClientId } from '../lib/clientId';

const CATEGORIES = ['Cosmetics', 'Nutraceuticals', 'Personal care', 'Food & beverage', 'Ayurvedic', 'Home care'];
const TIMELINES = ['ASAP', '1–3 months', '3–6 months', 'Just exploring'];

// Ported from marketing.models.OnboardingData + the brand/manufacturer
// intake flow — captures a lead progressively (each step is saved as it's
// completed) rather than only on final submit, matching how the funnel
// scored partial completions in shadow-api.
export default function OnboardingFunnelModal({ open, onClose, initialFlowType, initialEmail }) {
  const [step, setStep] = useState(1);
  const [recordId, setRecordId] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState({
    flow_type: initialFlowType || 'brand',
    product_category: '',
    product_name: '',
    quantity: '',
    email: initialEmail || '',
    mobile: '',
    company_name: '',
    timeline: '',
    budget: ''
  });

  if (!open) return null;

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function saveStep(extra) {
    setBusy(true);
    setError(null);
    try {
      const clientId = getClientId();
      const payload = { ...form, ...extra, step, client_id: clientId, source_route: '/' };
      if (recordId) {
        await djangoApi.patch(`/onboarding/${recordId}`, payload);
      } else {
        const res = await djangoApi.post('/onboarding', payload);
        setRecordId(res.data.id);
      }
      return true;
    } catch (e) {
      setError('Could not save your progress. Please try again.');
      return false;
    } finally {
      setBusy(false);
    }
  }

  async function next() {
    const ok = await saveStep({});
    if (ok) setStep((s) => s + 1);
  }

  async function finish() {
    const ok = await saveStep({});
    if (ok) setDone(true);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-navy/40 px-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl">
        <button onClick={onClose} className="float-right text-ink/40 hover:text-ink" aria-label="Close">
          ✕
        </button>

        {done ? (
          <div className="py-8 text-center">
            <p className="font-display text-xl text-navy mb-2">Thanks — we&apos;re on it.</p>
            <p className="text-sm text-ink/60">Someone from our team will reach out within a day.</p>
            <button onClick={onClose} className="mt-6 rounded-full bg-navy text-sand px-6 py-2.5 text-sm font-medium">
              Close
            </button>
          </div>
        ) : (
          <>
            <p className="text-xs uppercase tracking-wide text-teal font-medium mb-1">Step {step} of 3</p>
            {error && <p className="mb-3 text-xs text-clay">{error}</p>}

            {step === 1 && (
              <div className="space-y-4">
                <h3 className="font-display text-lg text-navy">What are you here for?</h3>
                <div className="flex gap-3">
                  {['brand', 'manufacturer'].map((ft) => (
                    <button
                      key={ft}
                      onClick={() => set('flow_type', ft)}
                      className={`flex-1 rounded-lg border px-4 py-3 text-sm capitalize ${
                        form.flow_type === ft ? 'border-teal bg-teal/10 text-navy' : 'border-navy/20 text-ink/70'
                      }`}
                    >
                      {ft === 'brand' ? 'I have a brand' : 'I run a factory'}
                    </button>
                  ))}
                </div>
                <select
                  value={form.product_category}
                  onChange={(e) => set('product_category', e.target.value)}
                  className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm bg-white"
                >
                  <option value="">Product category</option>
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <button
                  onClick={next}
                  disabled={busy || !form.product_category}
                  className="w-full rounded-lg bg-navy text-sand py-3 text-sm font-medium disabled:opacity-50"
                >
                  {busy ? 'Saving…' : 'Continue'}
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <h3 className="font-display text-lg text-navy">A bit more detail</h3>
                <input
                  placeholder="Product name (if you have one)"
                  value={form.product_name}
                  onChange={(e) => set('product_name', e.target.value)}
                  className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm"
                />
                <input
                  placeholder="Quantity you're thinking (e.g. 5000 units)"
                  value={form.quantity}
                  onChange={(e) => set('quantity', e.target.value)}
                  className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm"
                />
                <select
                  value={form.timeline}
                  onChange={(e) => set('timeline', e.target.value)}
                  className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm bg-white"
                >
                  <option value="">Timeline</option>
                  {TIMELINES.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
                <button
                  onClick={next}
                  disabled={busy}
                  className="w-full rounded-lg bg-navy text-sand py-3 text-sm font-medium disabled:opacity-50"
                >
                  {busy ? 'Saving…' : 'Continue'}
                </button>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <h3 className="font-display text-lg text-navy">How can we reach you?</h3>
                <input
                  required
                  type="email"
                  placeholder="Email"
                  value={form.email}
                  onChange={(e) => set('email', e.target.value)}
                  className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm"
                />
                <input
                  placeholder="Mobile"
                  value={form.mobile}
                  onChange={(e) => set('mobile', e.target.value)}
                  className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm"
                />
                <input
                  placeholder="Company name"
                  value={form.company_name}
                  onChange={(e) => set('company_name', e.target.value)}
                  className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm"
                />
                <button
                  onClick={finish}
                  disabled={busy || !form.email}
                  className="w-full rounded-full bg-clay text-white py-3 text-sm font-medium disabled:opacity-50"
                >
                  {busy ? 'Submitting…' : 'Submit'}
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
