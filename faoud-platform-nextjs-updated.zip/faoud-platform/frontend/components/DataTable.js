import { useMemo, useState } from 'react';
import StatusBadge from './StatusBadge';

const STATUS_FIELDS = ['status', 'is_done', 'is_active', 'is_read', 'is_paid', 'approved', 'verified', 'active'];

function renderCell(field, value) {
  if (value === null || value === undefined || value === '') return <span className="text-muted">—</span>;
  if (field.type === 'boolean' || STATUS_FIELDS.includes(field.name)) {
    return <StatusBadge label={value === true ? 'active' : value === false ? 'pending' : String(value)} />;
  }
  if (field.name === 'status') return <StatusBadge label={String(value)} />;
  if (typeof value === 'object') return <span className="text-muted">{JSON.stringify(value)}</span>;
  return String(value);
}

export default function DataTable({ columns, rows, onEdit, onDelete, loading, error, emptyLabel }) {
  const [sortKey, setSortKey] = useState(null);
  const [sortDir, setSortDir] = useState(1);

  const sortedRows = useMemo(() => {
    if (!sortKey) return rows;
    return [...rows].sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      if (av === bv) return 0;
      if (av === null || av === undefined) return 1;
      if (bv === null || bv === undefined) return -1;
      return av > bv ? sortDir : -sortDir;
    });
  }, [rows, sortKey, sortDir]);

  function toggleSort(key) {
    if (sortKey === key) {
      setSortDir((d) => -d);
    } else {
      setSortKey(key);
      setSortDir(1);
    }
  }

  if (loading) {
    return <p className="font-mono text-sm uppercase tracking-wider text-muted">Loading…</p>;
  }

  if (error) {
    return (
      <p className="rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">{error}</p>
    );
  }

  if (!rows.length) {
    return (
      <div className="rounded-sm border border-dashed border-line bg-panel px-6 py-10 text-center">
        <p className="text-sm text-muted">{emptyLabel || 'Nothing here yet.'}</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-sm border border-line bg-panel">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b border-line bg-black/[0.02]">
            {columns.map((col) => (
              <th
                key={col.name}
                onClick={() => toggleSort(col.name)}
                className="cursor-pointer whitespace-nowrap px-4 py-2 text-left font-mono text-[11px] uppercase tracking-wider text-muted hover:text-ink"
              >
                {col.label || col.name}
                {sortKey === col.name ? (sortDir === 1 ? ' ▲' : ' ▼') : ''}
              </th>
            ))}
            {(onEdit || onDelete) && (
              <th className="px-4 py-2 text-right font-mono text-[11px] uppercase tracking-wider text-muted">
                Actions
              </th>
            )}
          </tr>
        </thead>
        <tbody>
          {sortedRows.map((row) => (
            <tr key={row.id} className="border-b border-line last:border-0 hover:bg-black/[0.015]">
              {columns.map((col) => (
                <td key={col.name} className="whitespace-nowrap px-4 py-2 text-ink">
                  {renderCell(col, row[col.name])}
                </td>
              ))}
              {(onEdit || onDelete) && (
                <td className="whitespace-nowrap px-4 py-2 text-right">
                  {onEdit && (
                    <button
                      onClick={() => onEdit(row)}
                      className="mr-3 text-teal underline decoration-line underline-offset-4 hover:text-navy"
                    >
                      Edit
                    </button>
                  )}
                  {onDelete && (
                    <button
                      onClick={() => onDelete(row)}
                      className="text-danger underline decoration-line underline-offset-4 hover:opacity-80"
                    >
                      Delete
                    </button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
