import { useState } from 'react';
import ResourceManager from './ResourceManager';

export default function DataExplorer({ resources, accent }) {
  const [activeKey, setActiveKey] = useState(resources[0]?.key);
  const active = resources.find((r) => r.key === activeKey) || resources[0];

  const accentTone = { teal: 'text-teal border-teal', rust: 'text-rust border-rust', ink: 'text-ink border-ink' }[
    accent
  ] || 'text-ink border-ink';

  if (!resources.length) {
    return <p className="text-sm text-muted">No data tables are available for your role yet.</p>;
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap gap-1 border-b border-line">
        {resources.map((r) => (
          <button
            key={r.key}
            onClick={() => setActiveKey(r.key)}
            className={`whitespace-nowrap border-b-2 px-3 py-2 text-sm transition-colors ${
              active?.key === r.key ? `${accentTone} font-medium` : 'border-transparent text-ink/60 hover:text-ink'
            }`}
          >
            {r.label}
          </button>
        ))}
      </div>

      {active && <ResourceManager key={active.key} resource={active} />}
    </div>
  );
}
