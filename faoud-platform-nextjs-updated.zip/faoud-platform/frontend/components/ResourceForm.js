import { useState } from 'react';

function inputFor(field, value, onChange) {
  const base =
    'w-full rounded-lg border border-navy/20 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal';

  if (field.type === 'readonly') {
    return <p className="px-1 py-2 text-sm text-muted">{value ?? '—'}</p>;
  }

  if (field.type === 'boolean') {
    return (
      <label className="flex items-center gap-2 text-sm text-ink">
        <input
          type="checkbox"
          checked={!!value}
          onChange={(e) => onChange(e.target.checked)}
          className="h-4 w-4 rounded border-navy/30 text-teal focus:ring-teal"
        />
        Yes
      </label>
    );
  }

  if (field.type === 'textarea') {
    return (
      <textarea
        className={base}
        rows={3}
        value={value ?? ''}
        required={field.required}
        onChange={(e) => onChange(e.target.value)}
      />
    );
  }

  if (field.type === 'select') {
    return (
      <select className={base} value={value ?? ''} required={field.required} onChange={(e) => onChange(e.target.value)}>
        <option value="">Select…</option>
        {field.options.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
      </select>
    );
  }

  const typeMap = {
    number: 'number',
    decimal: 'number',
    date: 'date',
    datetime: 'datetime-local',
    email: 'email',
    fk: 'number',
    text: 'text'
  };

  return (
    <input
      type={typeMap[field.type] || 'text'}
      step={field.type === 'decimal' ? '0.01' : undefined}
      className={base}
      value={value ?? ''}
      required={field.required}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

export default function ResourceForm({ resourceLabel, fields, initialValues, onCancel, onSubmit, submitting, error }) {
  const [values, setValues] = useState(() => {
    const v = {};
    fields.forEach((f) => {
      v[f.name] = initialValues?.[f.name] ?? (f.type === 'boolean' ? false : '');
    });
    return v;
  });

  function setField(name, val) {
    setValues((prev) => ({ ...prev, [name]: val }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    // strip readonly fields and empty optional fields before sending
    const payload = {};
    fields.forEach((f) => {
      if (f.type === 'readonly') return;
      if (values[f.name] === '' && !f.required) return;
      payload[f.name] = values[f.name];
    });
    onSubmit(payload);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/40 px-4">
      <div className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-lg bg-paper p-6 shadow-xl">
        <h2 className="font-display text-xl text-navy">
          {initialValues ? `Edit ${resourceLabel}` : `New ${resourceLabel}`}
        </h2>
        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {fields.map((field) => (
            <div key={field.name}>
              <label className="mb-1 block font-mono text-[11px] uppercase tracking-wider text-muted">
                {field.label || field.name.replace(/_/g, ' ')}
                {field.required && <span className="text-clay"> *</span>}
              </label>
              {inputFor(field, values[field.name], (val) => setField(field.name, val))}
            </div>
          ))}

          {error && <p className="text-sm text-danger">{error}</p>}

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="rounded-lg border border-navy/20 px-4 py-2 text-sm text-ink/70 hover:bg-black/[0.03]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-lg bg-navy px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
            >
              {submitting ? 'Saving…' : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
