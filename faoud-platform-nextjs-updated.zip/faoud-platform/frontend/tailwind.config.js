/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}'
  ],
  theme: {
    extend: {
      colors: {
        navy: '#0B2545',
        teal: '#0F7A6B',
        clay: '#E8664B',
        sand: '#F7F4EE',
        ink: '#12181F',
        paper: '#FBFAF7',
        panel: '#FFFFFF',
        line: '#E4E1D8',
        muted: '#6B6659',
        amber: '#B8860B',
        rust: '#B4502A',
        danger: '#C0392B'
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace']
      }
    }
  },
  plugins: []
};
