const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function upsertUser(email, password, role) {
  const passwordHash = await bcrypt.hash(password, 10);
  return prisma.user.upsert({
    where: { email },
    create: { email, passwordHash, role },
    update: { passwordHash, role }
  });
}

async function main() {
  const am = await upsertUser('am@faoud.com', 'changeme123', 'account_manager');
  await prisma.aM.upsert({
    where: { userId: am.id },
    create: { userId: am.id, name: 'Default Account Manager', contactEmail: am.email },
    update: {}
  });

  const brand = await upsertUser('brand@faoud.com', 'changeme123', 'brand');
  await prisma.brandOwner.upsert({
    where: { userId: brand.id },
    create: { userId: brand.id, name: 'Default Brand Owner', contactEmail: brand.email, termsAccepted: true },
    update: {}
  });

  const factory = await upsertUser('factory@faoud.com', 'changeme123', 'factory');
  const factoryRow = await prisma.factory.upsert({
    where: { id: 1 },
    create: {
      name: 'Default Factory',
      verified: true,
      city: 'Mumbai',
      state: 'Maharashtra',
      category: 'cosmetics',
      moq: 5000,
      turnaroundDays: 30
    },
    update: {}
  });
  await prisma.factoryOwner.upsert({
    where: { userId: factory.id },
    create: {
      userId: factory.id,
      name: 'Default Factory Owner',
      contactEmail: factory.email,
      termsAccepted: true,
      factoryId: factoryRow.id
    },
    update: { factoryId: factoryRow.id }
  });

  // Sample public marketplace product, so /marketplace isn't empty on first run.
  await prisma.publicProduct.upsert({
    where: { id: 1 },
    create: {
      title: 'Herbal Face Wash — Private Label',
      description: 'Ready-to-brand herbal face wash base, customizable fragrance and packaging.',
      category: 'cosmetics',
      moq: 5000,
      leadTimeDays: 30,
      basePrice: 42.5,
      factoryId: factoryRow.id
    },
    update: {}
  });

  // Sample blog post so /blog isn't empty on first run.
  await prisma.blogPost.upsert({
    where: { slug: 'choosing-a-contract-manufacturer' },
    create: {
      title: 'How to choose the right contract manufacturer',
      slug: 'choosing-a-contract-manufacturer',
      excerpt: 'A practical checklist for brand owners evaluating factory partners.',
      content:
        'Choosing a contract manufacturer comes down to a few fundamentals: verified compliance documents, realistic MOQs for your stage, transparent costing, and a factory that communicates proactively during production. Start every shortlist with these before design or price.',
      author: 'Faoud Team',
      published: true,
      publishedAt: new Date()
    },
    update: {}
  });

  await upsertUser('admin@faoud.com', 'changeme123', 'admin');

  console.log('Seeded 4 logins (password for all: changeme123):');
  console.log('  am@faoud.com       -> Account Manager');
  console.log('  brand@faoud.com    -> Brand Owner');
  console.log('  factory@faoud.com  -> Factory Owner');
  console.log('  admin@faoud.com    -> Admin');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
