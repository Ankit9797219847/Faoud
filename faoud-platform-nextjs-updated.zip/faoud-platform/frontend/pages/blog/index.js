import { useEffect, useState } from 'react';
import Link from 'next/link';
import djangoApi from '../../lib/djangoApi';

export default function Blog() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    djangoApi.get('/blog').then((res) => setPosts(res.data)).finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-6 py-16">
      <h1 className="font-display text-3xl text-navy mb-2">Expert notes on manufacturing and formulation</h1>
      <p className="text-ink/60 mb-10">Practical guidance for brand owners and factory owners — no filler.</p>

      {loading && <p className="text-ink/50 text-sm">Loading posts…</p>}
      {!loading && posts.length === 0 && <p className="text-ink/50 text-sm">No posts published yet.</p>}

      <div className="space-y-6">
        {posts.map((p) => (
          <Link key={p.id} href={`/blog/${p.slug}`} className="block border-b border-navy/10 pb-6 hover:opacity-80 transition">
            <h2 className="font-display text-xl text-navy mb-1">{p.title}</h2>
            <p className="text-sm text-ink/60">{p.excerpt}</p>
            <p className="text-xs text-ink/40 mt-2">{p.author}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
