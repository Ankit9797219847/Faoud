import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import djangoApi from '../../lib/djangoApi';

export default function BlogPost() {
  const router = useRouter();
  const { slug } = router.query;
  const [post, setPost] = useState(null);

  useEffect(() => {
    if (!slug) return;
    djangoApi.get(`/blog/${slug}`).then((res) => setPost(res.data)).catch(() => setPost(false));
  }, [slug]);

  if (post === false) return <div className="max-w-2xl mx-auto px-6 py-16">Post not found.</div>;
  if (!post) return <div className="max-w-2xl mx-auto px-6 py-16 text-ink/50 text-sm">Loading…</div>;

  return (
    <article className="max-w-2xl mx-auto px-6 py-16">
      <h1 className="font-display text-3xl text-navy mb-3">{post.title}</h1>
      <p className="text-xs text-ink/40 mb-8">{post.author}</p>
      <div className="prose prose-sm text-ink/80 whitespace-pre-wrap leading-relaxed">{post.content}</div>
    </article>
  );
}
