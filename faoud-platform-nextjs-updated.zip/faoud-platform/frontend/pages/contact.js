import { useState } from 'react';
import djangoApi from '../lib/djangoApi';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', company_name: '', interest: 'general', message: '' });
  const [status, setStatus] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('sending');
    try {
      await djangoApi.post('/contact', form);
      setStatus('sent');
      setForm({ name: '', email: '', phone: '', company_name: '', interest: 'general', message: '' });
    } catch {
      setStatus('error');
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-16">
      <h1 className="font-display text-3xl text-navy mb-2">Talk to our team</h1>
      <p className="text-ink/60 mb-8">
        Contract manufacturing strategy, formulation, sourcing, or general questions — we usually reply within a day.
      </p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <input required placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="rounded-lg border border-navy/20 px-4 py-3 text-sm" />
          <input required type="email" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="rounded-lg border border-navy/20 px-4 py-3 text-sm" />
          <input placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="rounded-lg border border-navy/20 px-4 py-3 text-sm" />
          <input placeholder="Company" value={form.company_name} onChange={(e) => setForm({ ...form, company_name: e.target.value })}
            className="rounded-lg border border-navy/20 px-4 py-3 text-sm" />
        </div>
        <select value={form.interest} onChange={(e) => setForm({ ...form, interest: e.target.value })}
          className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm bg-white">
          <option value="general">General enquiry</option>
          <option value="formulation">Formulation & samples</option>
          <option value="consultation">Consultation</option>
          <option value="quotes">Get multiple quotes</option>
        </select>
        <textarea placeholder="Tell us about your product" rows={4} value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm" />
        <button className="bg-navy text-white rounded-lg px-6 py-3 text-sm font-medium hover:opacity-90 transition">
          {status === 'sending' ? 'Sending…' : 'Send message'}
        </button>
        {status === 'sent' && <p className="text-teal text-sm">Thanks — we'll be in touch shortly.</p>}
        {status === 'error' && <p className="text-clay text-sm">Something went wrong. Please try again.</p>}
      </form>
    </div>
  );
}
