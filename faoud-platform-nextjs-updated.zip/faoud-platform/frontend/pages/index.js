import Link from 'next/link';
import { useState } from 'react';
import OnboardingFunnelModal from '../components/OnboardingFunnelModal';

export default function Home() {
  const [email, setEmail] = useState('');
  const [funnelOpen, setFunnelOpen] = useState(false);

  const services = [
    { title: 'Get Formulation and Samples', desc: 'In-house lab experts formulate samples and support new product development to your spec.' },
    { title: 'Talk to Our Consultant', desc: 'Strategy, benchmarking, costing, NPD, packaging development, and launch support across Nykaa, Purplle, Amazon & Flipkart.' },
    { title: 'Get Multiple Quotes', desc: '250+ verified factories. Compare quotes within 24 hours based on budget, MOQ, and timelines.' },
    { title: 'Get Finished Goods', desc: 'Finished goods in as fast as 45 days — the fastest turnaround in the industry.' }
  ];

  return (
    <div>
      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-20 pb-16 text-center">
        <p className="text-teal font-medium text-sm tracking-wide uppercase mb-4">
          India's First Factory on Cloud
        </p>
        <h1 className="font-display text-4xl md:text-6xl text-navy leading-tight max-w-3xl mx-auto">
          Move from idea to factory execution, without the guesswork.
        </h1>
        <p className="mt-6 text-ink/70 max-w-xl mx-auto">
          The only platform where FMCG brands get finished goods from factories, pan India.
        </p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setFunnelOpen(true);
          }}
          className="mt-8 flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto"
        >
          <input
            type="email"
            required
            placeholder="you@brand.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="flex-1 rounded-full border border-navy/20 px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal"
          />
          <button className="bg-clay text-white rounded-full px-6 py-3 text-sm font-medium hover:opacity-90 transition">
            Signup for Free
          </button>
        </form>
      </section>

      <OnboardingFunnelModal open={funnelOpen} onClose={() => setFunnelOpen(false)} initialFlowType="brand" initialEmail={email} />

      {/* What we manufacture */}
      <section className="max-w-6xl mx-auto px-6 py-16 grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { title: 'Products You Can Launch', desc: 'Browse ready-to-manufacture products', href: '/marketplace' },
          { title: 'Live Orders', desc: 'Active manufacturing orders', href: '/manufacture/orders' },
          { title: 'How Faoud Works', desc: 'Simple steps to make your product', href: '/how-it-works' }
        ].map((c) => (
          <Link
            key={c.title}
            href={c.href}
            className="border border-navy/10 rounded-2xl p-6 hover:border-teal hover:shadow-sm transition bg-white"
          >
            <div className="font-display text-lg text-navy mb-2">{c.title}</div>
            <div className="text-sm text-ink/60">{c.desc}</div>
          </Link>
        ))}
      </section>

      {/* Services */}
      <section className="bg-white border-y border-navy/10">
        <div className="max-w-6xl mx-auto px-6 py-16 grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((s) => (
            <div key={s.title} className="flex gap-4">
              <div className="w-1.5 rounded-full bg-teal shrink-0" />
              <div>
                <h3 className="font-display text-xl text-navy mb-2">{s.title}</h3>
                <p className="text-sm text-ink/70 leading-relaxed">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Trusted by */}
      <section className="border-y border-navy/10 bg-white">
        <div className="max-w-6xl mx-auto px-6 py-10">
          <p className="text-center text-xs uppercase tracking-wider text-ink/50 mb-6">
            Manufacturers on Faoud are trusted by leading FMCG brands across India
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-4 text-navy/40 font-display text-lg">
            <span>Sirona</span>
            <span>Mars</span>
            <span>MAN Matters</span>
            <span>Nykaa</span>
            <span>BoldCare</span>
          </div>
        </div>
      </section>

      {/* Brand / Factory gateway */}
      <section className="max-w-6xl mx-auto px-6 py-20 text-center">
        <h2 className="font-display text-3xl text-navy mb-4">
          India&apos;s first B2B marketplace for the FMCG industry
        </h2>
        <p className="text-ink/70 max-w-2xl mx-auto mb-8">
          Connecting every brand with every factory in India to optimize production bandwidth,
          cut costs, and shorten turnaround — so brands launch faster and factories win more business.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/login"
            className="bg-navy text-sand rounded-full px-8 py-3 font-medium hover:opacity-90 transition"
          >
            Brand Gateway
          </Link>
          <Link
            href="/login"
            className="border border-navy/20 text-navy rounded-full px-8 py-3 font-medium hover:bg-navy hover:text-sand transition"
          >
            Factory Gateway
          </Link>
        </div>
      </section>

      {/* Seamless dashboard experience */}
      <section className="bg-white border-y border-navy/10">
        <div className="max-w-6xl mx-auto px-6 py-20 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="font-display text-3xl text-navy mb-6">Seamless dashboard experience</h2>
            <ul className="space-y-4">
              {[
                'Get quotes and samples directly through the platform',
                'Monitor production in real time and manage every order in one place',
                'Reach support whenever a production question comes up'
              ].map((item) => (
                <li key={item} className="flex gap-3 items-start">
                  <span className="mt-1.5 w-2 h-2 rounded-full bg-teal shrink-0" />
                  <span className="text-ink/70">{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-navy/10 bg-sand aspect-video flex items-center justify-center text-ink/30 text-sm">
            Dashboard preview
          </div>
        </div>
      </section>

      {/* Numbers */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { label: 'Factories onboarded', value: '250+' },
            { label: 'Orders turned around', value: '1,000+' },
            { label: 'Units delivered', value: '2M+' },
            { label: 'Brands', value: '500+' }
          ].map((stat) => (
            <div key={stat.label}>
              <div className="font-display text-3xl text-navy">{stat.value}</div>
              <div className="text-xs uppercase tracking-wide text-ink/50 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>


      <section className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="font-display text-3xl text-navy text-center mb-12">Who uses Faoud?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: 'FMCG Brands', desc: 'Launch your consumer product with us and sell it directly to your audience.' },
            { title: 'Manufacturing Factories', desc: 'Get connected with brands and get orders for your manufacturing unit.' },
            { title: 'Suppliers', desc: 'Post RFQs in our supplier network and get multiple comparable quotes.' }
          ].map((u) => (
            <div key={u.title} className="text-center px-4">
              <div className="w-14 h-14 rounded-full bg-teal/10 text-teal flex items-center justify-center mx-auto mb-4 font-display text-xl">
                {u.title[0]}
              </div>
              <h3 className="font-medium text-navy mb-2">{u.title}</h3>
              <p className="text-sm text-ink/60">{u.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Blog teaser */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
          <div>
            <p className="text-teal font-medium text-sm uppercase tracking-wide mb-3">Blog</p>
            <h2 className="font-display text-3xl text-navy mb-4">
              Expert notes on manufacturing and formulation
            </h2>
            <p className="text-ink/70 mb-6">
              Practical, no-noise guidance for brand owners and factory owners — written by people
              who actually work in production and formulation.
            </p>
            <div className="flex gap-4">
              <Link href="/blog" className="text-navy underline decoration-teal underline-offset-4">
                Read the blog
              </Link>
              <Link href="/contact" className="text-navy underline decoration-teal underline-offset-4">
                Talk to us
              </Link>
            </div>
          </div>
          <ul className="space-y-3 text-sm text-ink/60">
            <li>Practical notes on formulation, production, and scale-up decisions.</li>
            <li>Short articles that are easy to scan on mobile.</li>
            <li>Clear language, no filler.</li>
          </ul>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-navy text-sand">
        <div className="max-w-4xl mx-auto px-6 py-20 text-center">
          <h2 className="font-display text-3xl md:text-4xl mb-4">Grow your manufacturing business with Faoud</h2>
          <p className="text-sand/70 mb-8 max-w-xl mx-auto">
            Faoud connects you with premium brands, simplifies operations, and ensures sustainable growth.
          </p>
          <Link href="/signup" className="inline-block bg-clay text-white rounded-full px-8 py-3 font-medium hover:opacity-90 transition">
            Join Now
          </Link>
        </div>
      </section>
    </div>
  );
}
