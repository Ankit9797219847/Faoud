import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import djangoApi, { ensureCsrfCookie } from '../lib/djangoApi';
import { roleHome } from '../lib/roles';

export default function Login() {
  const router = useRouter();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await ensureCsrfCookie();
      const res = await djangoApi.post('/auth/login', form);
      // Session lives in an httpOnly cookie the server just set — nothing
      // to store client-side.
      router.push(roleHome(res.data.role));
    } catch (err) {
      setError(err.response?.data?.detail || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-6 py-20">
      <h1 className="font-display text-3xl text-navy mb-8 text-center">Login to Faoud</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="email"
          required
          placeholder="Email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal"
        />
        <input
          type="password"
          required
          placeholder="Password"
          value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal"
        />
        {error && <p className="text-clay text-sm">{error}</p>}
        <button
          disabled={loading}
          className="w-full bg-navy text-white rounded-lg py-3 text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
        >
          {loading ? 'Logging in…' : 'Login'}
        </button>
      </form>
      <p className="text-sm text-ink/60 text-center mt-6">
        Don&apos;t have an account? <Link href="/signup" className="text-teal font-medium">Sign up</Link>
      </p>
    </div>
  );
}
