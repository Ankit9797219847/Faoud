import { useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import djangoApi, { ensureCsrfCookie } from '../lib/djangoApi';
import { roleHome } from '../lib/roles';

export default function Signup() {
  const router = useRouter();
  const [form, setForm] = useState({
    full_name: '', company_name: '', email: '', phone: '', password: '', role: 'brand'
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await ensureCsrfCookie();
      const res = await djangoApi.post('/auth/signup', form);
      router.push(roleHome(res.data.role));
    } catch (err) {
      setError(err.response?.data?.error || 'Signup failed.');
    } finally {
      setLoading(false);
    }
  };

  const field = (key, label, type = 'text') => (
    <input
      type={type}
      required={key !== 'phone'}
      placeholder={label}
      value={form[key]}
      onChange={(e) => setForm({ ...form, [key]: e.target.value })}
      className="w-full rounded-lg border border-navy/20 px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-teal"
    />
  );

  return (
    <div className="max-w-md mx-auto px-6 py-16">
      <h1 className="font-display text-3xl text-navy mb-8 text-center">Join Faoud</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex gap-2">
          {['brand', 'factory'].map((r) => (
            <button
              type="button"
              key={r}
              onClick={() => setForm({ ...form, role: r })}
              className={`flex-1 py-2 rounded-full text-sm border capitalize transition ${
                form.role === r ? 'bg-teal text-white border-teal' : 'border-navy/20 text-ink/70'
              }`}
            >
              {r === 'brand' ? 'Brand Owner' : 'Factory Owner'}
            </button>
          ))}
        </div>
        {field('full_name', 'Full name')}
        {field('company_name', 'Company name')}
        {field('email', 'Email', 'email')}
        {field('phone', 'Phone (optional)')}
        {field('password', 'Password', 'password')}
        {error && <p className="text-clay text-sm">{error}</p>}
        <button
          disabled={loading}
          className="w-full bg-clay text-white rounded-lg py-3 text-sm font-medium hover:opacity-90 transition disabled:opacity-50"
        >
          {loading ? 'Creating account…' : 'Create account'}
        </button>
      </form>
      <p className="text-sm text-ink/60 text-center mt-6">
        Already have an account? <Link href="/login" className="text-teal font-medium">Login</Link>
      </p>
    </div>
  );
}
