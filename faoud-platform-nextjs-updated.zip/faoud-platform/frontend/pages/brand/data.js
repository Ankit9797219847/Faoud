import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import DataExplorer from '../../components/DataExplorer';
import { resourcesForRole } from '../../lib/resourceRegistry';

const NAV = [
  { label: 'Dashboard', href: '/brand/dashboard' },
  { label: 'New Case', href: '/brand/new-case' },
  { label: 'Data Tables', href: '/brand/data' },
  { label: 'Payments', href: '/brand/payments' }
];

function BrandDataInner() {
  const resources = resourcesForRole('brand');
  return (
    <OpsShell roleLabel="Brand Owner" accent="teal" navItems={NAV} activeHref="/brand/data">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Backend data</p>
        <h1 className="mt-1 font-display text-3xl text-ink">All your records, in one place</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Every table below reads and writes directly to the production backend — create, edit, or remove
          records and they update immediately.
        </p>
      </header>
      <DataExplorer resources={resources} accent="teal" />
    </OpsShell>
  );
}

export default function BrandData() {
  return (
    <RoleGuard allow={['brand']}>
      <BrandDataInner />
    </RoleGuard>
  );
}
