import { useEffect, useState } from 'react';
import Link from 'next/link';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import StatusBadge from '../../components/StatusBadge';
import api from '../../lib/djangoApi';
import { caseLabel, caseStage, factoryLabel } from '../../lib/case-helpers';

const NAV = [
  { label: 'Dashboard', href: '/brand/dashboard' },
  { label: 'New Case', href: '/brand/new-case' },
  { label: 'Data Tables', href: '/brand/data' },
  { label: 'Payments', href: '/brand/payments' }
];

function BrandDashboardInner() {
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await api.get('/cases/list_brand_owner_dashboard');
        if (cancelled) return;
        const data = res.data;
        setCases(Array.isArray(data) ? data : data.cases || []);
      } catch (e) {
        if (!cancelled) setLoadError('Could not load your cases.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <OpsShell roleLabel="Brand Owner" accent="teal" navItems={NAV} activeHref="/brand/dashboard">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">
          Your workspace
        </p>
        <h1 className="mt-1 font-display text-3xl text-ink">Products in motion</h1>
      </header>

      {loadError && (
        <p className="mb-6 rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">
          {loadError}
        </p>
      )}

      {!loading && cases.length === 0 && !loadError && (
        <div className="rounded-sm border border-dashed border-line bg-panel px-6 py-10 text-center">
          <p className="font-display text-lg text-ink">No cases yet</p>
          <p className="mt-1 text-sm text-muted">
            Once your account manager opens a case for a product, it will appear here with its
            live production stage.
          </p>
        </div>
      )}

      {(loading || cases.length > 0) && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {loading &&
            Array.from({ length: 2 }).map((_, i) => (
              <div key={i} className="h-28 animate-pulse rounded-sm border border-line bg-panel" />
            ))}
          {cases.map((c) => (
            <Link
              key={c.id}
              href={`/brand/cases/${c.id}`}
              className="rounded-sm border border-line bg-panel p-5 block hover:border-teal transition-colors"
            >
              <div className="flex items-start justify-between">
                <p className="font-display text-lg text-ink">{caseLabel(c)}</p>
                <StatusBadge label={caseStage(c)} />
              </div>
              <p className="mt-2 font-mono text-[11px] uppercase tracking-wider text-muted">
                Factory
              </p>
              <p className="text-sm text-ink/80">{factoryLabel(c)}</p>
            </Link>
          ))}
        </div>
      )}
    </OpsShell>
  );
}

export default function BrandDashboardPage() {
  return (
    <RoleGuard allow={['brand']}>
      <BrandDashboardInner />
    </RoleGuard>
  );
}
BrandDashboardPage.noPublicLayout = true;
