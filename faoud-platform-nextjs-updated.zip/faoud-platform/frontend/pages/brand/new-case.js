import { useState } from 'react';
import { useRouter } from 'next/router';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/brand/dashboard' },
  { label: 'New Case', href: '/brand/new-case' },
  { label: 'Data Tables', href: '/brand/data' },
  { label: 'Payments', href: '/brand/payments' }
];

const CATEGORIES = [
  { value: 'npd_without', label: 'New product, no formulation yet' },
  { value: 'npd_with', label: 'New product, formulation ready' },
  { value: 'reorder', label: 'Reorder an earlier product' },
  { value: 'dormantProduct', label: 'Revive a dormant product' }
];

function NewCaseInner() {
  const router = useRouter();
  const [form, setForm] = useState({ name: '', category: 'npd_without', quantity: '', eta: '', benchmark: '' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  async function submit(e) {
    e.preventDefault();
    if (!form.name.trim()) return;
    setSubmitting(true);
    setError(null);
    try {
      await ensureCsrfCookie();
      const res = await djangoApi.post('/cases/create', form);
      router.push(`/brand/cases/${res.data.id}`);
    } catch (err) {
      setError(err.response?.data?.detail || 'Could not start a new case.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <OpsShell roleLabel="Brand Owner" accent="teal" navItems={NAV} activeHref="/brand/new-case">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Start something new</p>
        <h1 className="mt-1 font-display text-3xl text-ink">New case</h1>
      </header>

      {error && (
        <p className="mb-6 rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">{error}</p>
      )}

      <form onSubmit={submit} className="max-w-xl rounded-sm border border-line bg-panel p-6">
        <label className="mb-1 block font-mono text-[11px] uppercase tracking-wider text-muted">Product / case name *</label>
        <input
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          required
          className="mb-4 w-full rounded-sm border border-line bg-white px-3 py-2 text-sm"
        />

        <label className="mb-1 block font-mono text-[11px] uppercase tracking-wider text-muted">What's this case about?</label>
        <div className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {CATEGORIES.map((c) => (
            <button
              type="button"
              key={c.value}
              onClick={() => setForm({ ...form, category: c.value })}
              className={`rounded-sm border p-3 text-left text-sm transition-colors ${
                form.category === c.value ? 'border-teal bg-teal/5 text-ink' : 'border-line text-muted hover:border-teal/40'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="mb-4 grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1 block font-mono text-[11px] uppercase tracking-wider text-muted">Quantity</label>
            <input
              type="number"
              value={form.quantity}
              onChange={(e) => setForm({ ...form, quantity: e.target.value })}
              className="w-full rounded-sm border border-line bg-white px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block font-mono text-[11px] uppercase tracking-wider text-muted">Target ETA</label>
            <input
              type="date"
              value={form.eta}
              onChange={(e) => setForm({ ...form, eta: e.target.value })}
              className="w-full rounded-sm border border-line bg-white px-3 py-2 text-sm"
            />
          </div>
        </div>

        <label className="mb-1 block font-mono text-[11px] uppercase tracking-wider text-muted">Notes / benchmark product</label>
        <textarea
          value={form.benchmark}
          onChange={(e) => setForm({ ...form, benchmark: e.target.value })}
          rows={3}
          className="mb-6 w-full rounded-sm border border-line bg-white px-3 py-2 text-sm"
        />

        <button
          disabled={submitting}
          className="rounded-sm bg-teal px-5 py-2 text-sm font-medium text-white disabled:opacity-50"
        >
          {submitting ? 'Creating…' : 'Create case'}
        </button>
      </form>
    </OpsShell>
  );
}

export default function NewCasePage() {
  return (
    <RoleGuard allow={['brand']}>
      <NewCaseInner />
    </RoleGuard>
  );
}
NewCasePage.noPublicLayout = true;
