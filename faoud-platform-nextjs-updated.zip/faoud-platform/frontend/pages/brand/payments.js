import { useEffect, useState } from 'react';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import StatusBadge from '../../components/StatusBadge';
import api from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/brand/dashboard' },
  { label: 'New Case', href: '/brand/new-case' },
  { label: 'Payments', href: '/brand/payments' }
];

function BrandPaymentsInner() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    api
      .get('/payments/transactions')
      .then((res) => {
        if (!cancelled) setTransactions(res.data);
      })
      .catch(() => {
        if (!cancelled) setLoadError('Could not load your payment history.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <OpsShell roleLabel="Brand Owner" accent="teal" navItems={NAV} activeHref="/brand/payments">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Billing</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Payment history</h1>
      </header>

      {loadError && (
        <p className="mb-6 rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">
          {loadError}
        </p>
      )}

      <div className="overflow-hidden rounded-sm border border-line bg-panel">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-black/[0.02] font-mono text-[11px] uppercase tracking-wider text-muted">
              <th className="px-4 py-3 font-medium">Case</th>
              <th className="px-4 py-3 font-medium">Layer</th>
              <th className="px-4 py-3 font-medium">Amount</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Date</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center text-muted">
                  Loading…
                </td>
              </tr>
            )}
            {!loading && transactions.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center text-muted">
                  No payments yet.
                </td>
              </tr>
            )}
            {transactions.map((t) => (
              <tr key={t.id} className="border-b border-line last:border-0">
                <td className="px-4 py-3 text-ink">{t.case_name}</td>
                <td className="px-4 py-3 text-ink/80">{t.layer_type}</td>
                <td className="px-4 py-3 font-mono text-ink/80">₹{t.amount}</td>
                <td className="px-4 py-3">
                  <StatusBadge label={t.status} />
                </td>
                <td className="px-4 py-3 font-mono text-[11px] text-muted">
                  {new Date(t.created_at).toLocaleDateString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </OpsShell>
  );
}

export default function BrandPaymentsPage() {
  return (
    <RoleGuard allow={['brand']}>
      <BrandPaymentsInner />
    </RoleGuard>
  );
}
BrandPaymentsPage.noPublicLayout = true;
