import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/router';
import RoleGuard from '../../../components/RoleGuard';
import OpsShell from '../../../components/OpsShell';
import StatusBadge from '../../../components/StatusBadge';
import djangoApi from '../../../lib/djangoApi';
import CaseStagePanel from '../../../components/workflow/CaseStagePanel';
import CaseBidsPanel from '../../../components/workflow/CaseBidsPanel';
import DispatchPanel from '../../../components/workflow/DispatchPanel';
import QCPanel from '../../../components/workflow/QCPanel';
import FormulationUploadPanel from '../../../components/workflow/FormulationUploadPanel';
import CaseChat from '../../../components/workflow/CaseChat';
import PaymentCheckoutPanel from '../../../components/workflow/PaymentCheckoutPanel';

const NAV = [
  { label: 'Dashboard', href: '/brand/dashboard' },
  { label: 'New Case', href: '/brand/new-case' },
  { label: 'Data Tables', href: '/brand/data' },
  { label: 'Payments', href: '/brand/payments' }
];

function BrandCaseDetailInner() {
  const router = useRouter();
  const { id } = router.query;
  const [caseData, setCaseData] = useState(null);
  const [stages, setStages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const [caseRes, stagesRes] = await Promise.allSettled([
        djangoApi.get(`/cases/${id}/`),
        djangoApi.get(`/cases/${id}/stages/`)
      ]);
      if (caseRes.status === 'fulfilled') {
        setCaseData(caseRes.value.data.case ?? caseRes.value.data);
      } else {
        setLoadError(caseRes.reason?.response?.data?.error || 'Could not load this case.');
      }
      if (stagesRes.status === 'fulfilled') setStages(stagesRes.value.data.stages || []);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <OpsShell roleLabel="Brand Owner" accent="teal" navItems={NAV} activeHref="/brand/dashboard">
        <p className="text-muted">Loading case…</p>
      </OpsShell>
    );
  }

  if (loadError || !caseData) {
    return (
      <OpsShell roleLabel="Brand Owner" accent="teal" navItems={NAV} activeHref="/brand/dashboard">
        <p className="rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">
          {loadError || 'Case not found.'}
        </p>
      </OpsShell>
    );
  }

  return (
    <OpsShell roleLabel="Brand Owner" accent="teal" navItems={NAV} activeHref="/brand/dashboard">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Case detail</p>
        <div className="mt-1 flex items-center gap-3">
          <h1 className="font-display text-3xl text-ink">{caseData.name}</h1>
          {caseData.priority && <StatusBadge label={caseData.priority} />}
        </div>
      </header>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1.3fr_1fr]">
        <div className="flex flex-col gap-8">
          {/* Brand Owners can view the stage timeline but only Account Managers
              can transition it — CaseStageTransitionAPIView is AM-only in the
              real backend, so canTransition is false here. */}
          <CaseStagePanel caseId={id} stages={stages} canTransition={false} />
          <CaseBidsPanel caseId={id} role="brand" />
          <FormulationUploadPanel caseId={id} />
          <QCPanel caseId={id} role="brand" />
        </div>

        <div className="flex flex-col gap-8">
          <section>
            <h2 className="mb-3 font-display text-lg text-ink">Details</h2>
            <dl className="rounded-sm border border-line bg-panel p-4 text-sm">
              <div className="flex justify-between py-1.5">
                <dt className="text-muted">Quantity</dt>
                <dd className="text-ink">{caseData.product?.quantity ?? '—'}</dd>
              </div>
              <div className="flex justify-between py-1.5">
                <dt className="text-muted">ETA</dt>
                <dd className="text-ink">{caseData.product?.eta ? new Date(caseData.product.eta).toLocaleDateString() : '—'}</dd>
              </div>
            </dl>
          </section>

          <DispatchPanel caseId={id} role="brand" />
          <PaymentCheckoutPanel caseId={id} />
          <CaseChat caseId={id} currentUserRole="brand" />
        </div>
      </div>
    </OpsShell>
  );
}

export default function BrandCaseDetailPage() {
  return (
    <RoleGuard allow={['brand']}>
      <BrandCaseDetailInner />
    </RoleGuard>
  );
}
BrandCaseDetailPage.noPublicLayout = true;
