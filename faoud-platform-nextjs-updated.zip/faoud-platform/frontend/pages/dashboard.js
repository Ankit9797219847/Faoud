import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import djangoApi from '../lib/djangoApi';
import { useAuth } from '../lib/useAuth';
import { roleHome } from '../lib/roles';

const STATUS_LABEL = {
  quote_requested: 'Quote requested',
  quoted: 'Quoted',
  confirmed: 'Confirmed',
  in_production: 'In production',
  quality_check: 'Quality check',
  dispatched: 'Dispatched',
  delivered: 'Delivered',
  cancelled: 'Cancelled'
};

export default function Dashboard() {
  const router = useRouter();
  const { user, loading: authLoading } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push('/login');
      return;
    }
    // Brand/Factory accounts have a richer case-workspace dashboard —
    // send them there instead of this plain quote-request list.
    const home = roleHome(user.role);
    if (home !== '/dashboard') {
      router.push(home);
      return;
    }
    djangoApi.get('/orders').then((res) => setOrders(res.data)).finally(() => setLoading(false));
  }, [authLoading, user, router]);

  const logout = async () => {
    await djangoApi.post('/auth/logout');
    router.push('/login');
  };

  if (authLoading || !user) {
    return <div className="max-w-6xl mx-auto px-6 py-14 text-ink/50 text-sm">Loading…</div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-6 py-14">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl text-navy">Your Dashboard</h1>
          <p className="text-ink/60 text-sm capitalize">{user.role} account</p>
        </div>
        <button onClick={logout} className="text-sm text-clay border border-clay/30 rounded-full px-4 py-2">
          Log out
        </button>
      </div>

      {loading && <p className="text-ink/50 text-sm">Loading orders…</p>}
      {!loading && orders.length === 0 && (
        <p className="text-ink/50 text-sm">No orders yet. Browse the marketplace to get started.</p>
      )}

      <div className="space-y-3">
        {orders.map((o) => (
          <div key={o.id} className="border border-navy/10 rounded-xl p-5 bg-white flex items-center justify-between">
            <div>
              <div className="font-medium text-navy">{o.order_number}</div>
              <div className="text-xs text-ink/50">Qty: {o.quantity}</div>
            </div>
            <span className="text-xs font-medium bg-teal/10 text-teal rounded-full px-3 py-1.5">
              {STATUS_LABEL[o.status] || o.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
