import { useEffect, useState } from 'react';
import djangoApi from '../lib/djangoApi';

const CATEGORIES = ['all', 'cosmetics', 'nutraceuticals', 'food', 'home care', 'personal care'];

export default function Marketplace() {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(true);
    djangoApi
      .get('/marketplace/products', { params: { category, search } })
      .then((res) => setProducts(res.data))
      .catch(() => setError('Could not load products right now.'))
      .finally(() => setLoading(false));
  }, [category, search]);

  return (
    <div className="max-w-6xl mx-auto px-6 py-14">
      <h1 className="font-display text-3xl text-navy mb-2">Product Marketplace</h1>
      <p className="text-ink/60 mb-8">Browse ready-to-manufacture products from verified factories.</p>

      <div className="flex flex-col sm:flex-row gap-3 mb-8">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search products..."
          className="flex-1 rounded-full border border-navy/20 px-5 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-teal"
        />
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="rounded-full border border-navy/20 px-5 py-2.5 text-sm bg-white"
        >
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c === 'all' ? 'All categories' : c}</option>
          ))}
        </select>
      </div>

      {loading && <p className="text-ink/50 text-sm">Loading products…</p>}
      {error && <p className="text-clay text-sm">{error}</p>}
      {!loading && !error && products.length === 0 && (
        <p className="text-ink/50 text-sm">No products found for this filter yet.</p>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((p) => (
          <div key={p.id} className="border border-navy/10 rounded-2xl p-5 bg-white hover:shadow-sm transition">
            <div className="text-xs uppercase tracking-wide text-teal font-medium mb-2">{p.category}</div>
            <h3 className="font-display text-lg text-navy mb-1">{p.title}</h3>
            <p className="text-sm text-ink/60 mb-3 line-clamp-2">{p.description}</p>
            <div className="flex justify-between text-xs text-ink/50 mb-4">
              <span>MOQ: {p.moq || '—'}</span>
              <span>{p.lead_time_days ? `${p.lead_time_days} days` : '—'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-medium text-navy">{p.base_price ? `₹${p.base_price}` : 'Get quote'}</span>
              <span className="text-xs text-ink/40">{p.factory_name}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
