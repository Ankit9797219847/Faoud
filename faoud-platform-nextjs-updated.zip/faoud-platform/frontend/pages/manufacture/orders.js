import { useEffect, useState } from 'react';
import djangoApi from '../../lib/djangoApi';

export default function LiveOrders() {
  const [factories, setFactories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    djangoApi.get('/marketplace/factories').then((res) => setFactories(res.data)).finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-6 py-14">
      <h1 className="font-display text-3xl text-navy mb-2">Verified Factories</h1>
      <p className="text-ink/60 mb-8">Explore active manufacturing partners on Faoud, pan India.</p>

      {loading && <p className="text-ink/50 text-sm">Loading…</p>}
      {!loading && factories.length === 0 && <p className="text-ink/50 text-sm">No factories listed yet.</p>}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {factories.map((f) => (
          <div key={f.id} className="border border-navy/10 rounded-2xl p-5 bg-white">
            <div className="text-xs uppercase tracking-wide text-teal font-medium mb-2">{f.category}</div>
            <h3 className="font-display text-lg text-navy mb-1">{f.factory_name}</h3>
            <p className="text-sm text-ink/60 mb-3">{f.city}, {f.state}</p>
            <div className="flex justify-between text-xs text-ink/50">
              <span>MOQ: {f.moq || '—'}</span>
              <span>{f.turnaround_days ? `${f.turnaround_days} days` : '—'}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
