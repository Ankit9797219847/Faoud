import '../styles/globals.css';
import Layout from '../components/Layout';

export default function App({ Component, pageProps }) {
  // Ops console pages (AM / Brand / Factory workspaces, ported from
  // shadow-api + faoud-frontend) render their own full-screen OpsShell
  // sidebar layout and opt out of the public marketing header/footer by
  // setting `noPublicLayout` on the page component.
  if (Component.noPublicLayout) {
    return <Component {...pageProps} />;
  }
  return (
    <Layout>
      <Component {...pageProps} />
    </Layout>
  );
}
