import prisma from '../../lib/server/prisma';

// POST /api/contact — public "Talk to our team" form. Distinct from the
// /leads resource (which is the AM's internal marketing lead-scoring
// pipeline, LeadItem) — this is the simple public contact intake.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const { name, email, phone, company_name, interest, message } = req.body || {};
  if (!name || !email) return res.status(400).json({ detail: 'Name and email are required.' });

  try {
    const lead = await prisma.contactLead.create({
      data: {
        name,
        email,
        phone: phone || null,
        companyName: company_name || null,
        interest: interest || 'general',
        message: message || null
      }
    });
    res.status(201).json({ message: "Thanks — we'll be in touch shortly.", lead });
  } catch (err) {
    console.error('[contact]', err);
    res.status(500).json({ detail: 'Could not submit your request.' });
  }
}
