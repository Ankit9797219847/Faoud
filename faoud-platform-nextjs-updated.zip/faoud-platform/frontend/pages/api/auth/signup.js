import bcrypt from 'bcryptjs';
import prisma from '../../../lib/server/prisma';
import { createSessionCookie, checkCsrf } from '../../../lib/server/session';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const { full_name, company_name, email, phone, password, role } = req.body || {};
  if (!email || !password || !role) return res.status(400).json({ error: 'Email, password, and role are required.' });
  if (!['brand', 'factory'].includes(role)) return res.status(400).json({ error: 'Invalid role.' });

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) return res.status(400).json({ error: 'An account with this email already exists.' });

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({ data: { email, passwordHash, role } });

  if (role === 'brand') {
    const brand = await prisma.brand.create({ data: { name: company_name || full_name || 'New Brand' } });
    await prisma.brandOwner.create({
      data: { userId: user.id, name: full_name, contactEmail: email, contactPhone: phone, brandId: brand.id }
    });
  } else if (role === 'factory') {
    const factory = await prisma.factory.create({ data: { name: company_name || full_name || 'New Factory' } });
    await prisma.factoryOwner.create({
      data: { userId: user.id, name: full_name, contactEmail: email, contactPhone: phone, factoryId: factory.id }
    });
  }

  res.setHeader('Set-Cookie', createSessionCookie(user));
  res.status(201).json({ id: user.id, email: user.email, role: user.role });
}
