import { issueCsrfCookie } from '../../../lib/server/session';

export default function handler(req, res) {
  const { cookie } = issueCsrfCookie();
  res.setHeader('Set-Cookie', cookie);
  res.status(200).json({ detail: 'CSRF cookie set' });
}
