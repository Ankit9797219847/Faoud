import prisma from '../../../lib/server/prisma';
import { getSession } from '../../../lib/server/session';

export default async function handler(req, res) {
  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Not authenticated' });

  const user = await prisma.user.findUnique({ where: { id: session.userId } });
  if (!user) return res.status(401).json({ detail: 'Not authenticated' });

  res.status(200).json({ id: user.id, email: user.email, role: user.role });
}
