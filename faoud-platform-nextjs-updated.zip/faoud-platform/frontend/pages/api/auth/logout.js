import { clearSessionCookie, checkCsrf } from '../../../lib/server/session';

export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });
  res.setHeader('Set-Cookie', clearSessionCookie());
  res.status(200).json({ detail: 'Logged out' });
}
