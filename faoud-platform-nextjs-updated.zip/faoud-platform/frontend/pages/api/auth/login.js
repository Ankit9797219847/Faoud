import bcrypt from 'bcryptjs';
import prisma from '../../../lib/server/prisma';
import { createSessionCookie, checkCsrf } from '../../../lib/server/session';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ detail: 'Email and password required' });

  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ detail: 'Invalid credentials' });
  }

  res.setHeader('Set-Cookie', createSessionCookie(user));
  res.status(200).json({ id: user.id, email: user.email, role: user.role });
}
