import prisma from '../../../lib/server/prisma';

function getClientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (fwd) return fwd.split(',')[0].trim();
  return req.socket?.remoteAddress || null;
}

// GET /api/go/[token] — public. Logs the click then redirects to the
// campaign's destination URL. Used for event/QR/ad campaign short links.
export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ detail: 'Method not allowed' });

  const { token } = req.query;
  try {
    const link = await prisma.campaignLink.findUnique({ where: { token } });
    if (!link || !link.isActive) return res.status(404).json({ detail: 'Link not found or inactive.' });

    await prisma.clickEvent.create({
      data: {
        linkId: link.id,
        ip: getClientIp(req),
        referrer: req.headers.referer || '',
        userAgent: req.headers['user-agent'] || ''
      }
    });

    res.writeHead(302, { Location: link.destinationUrl });
    res.end();
  } catch (err) {
    console.error('[go/token]', err);
    res.status(500).json({ detail: 'Could not process link.' });
  }
}
