import prisma from '../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../lib/server/session';

export default async function handler(req, res) {
  if (req.method === 'GET') {
    try {
      const rows = await prisma.blogPost.findMany({
        where: { published: true },
        orderBy: { publishedAt: 'desc' },
        select: { id: true, title: true, slug: true, excerpt: true, author: true, publishedAt: true }
      });
      return res.status(200).json(rows);
    } catch (err) {
      console.error('[blog] list', err);
      return res.status(500).json({ detail: 'Could not fetch blog posts.' });
    }
  }

  if (req.method === 'POST') {
    const session = getSession(req);
    if (!session || session.role !== 'admin') return res.status(403).json({ detail: 'Admin only' });
    if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

    const { title, slug, excerpt, content, author, published } = req.body || {};
    if (!title || !slug) return res.status(400).json({ detail: 'title and slug are required.' });

    try {
      const row = await prisma.blogPost.create({
        data: {
          title,
          slug,
          excerpt,
          content,
          author,
          published: !!published,
          publishedAt: published ? new Date() : null
        }
      });
      return res.status(201).json(row);
    } catch (err) {
      console.error('[blog] create', err);
      return res.status(500).json({ detail: 'Could not create post.' });
    }
  }

  res.status(405).json({ detail: 'Method not allowed' });
}
