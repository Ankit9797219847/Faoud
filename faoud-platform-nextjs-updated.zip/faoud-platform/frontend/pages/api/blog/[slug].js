import prisma from '../../../lib/server/prisma';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ detail: 'Method not allowed' });

  const { slug } = req.query;
  try {
    const post = await prisma.blogPost.findFirst({ where: { slug, published: true } });
    if (!post) return res.status(404).json({ detail: 'Post not found.' });
    res.status(200).json(post);
  } catch (err) {
    console.error('[blog/slug]', err);
    res.status(500).json({ detail: 'Could not fetch post.' });
  }
}
