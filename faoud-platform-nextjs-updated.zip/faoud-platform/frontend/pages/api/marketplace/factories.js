import prisma from '../../../lib/server/prisma';

// GET /api/marketplace/factories — public, no auth. Verified factories only.
export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ detail: 'Method not allowed' });

  try {
    const rows = await prisma.factory.findMany({
      where: { verified: true },
      orderBy: { id: 'desc' },
      take: 200
    });
    res.status(200).json(
      rows.map((f) => ({
        id: f.id,
        factory_name: f.name,
        category: f.category,
        city: f.city,
        state: f.state,
        moq: f.moq,
        turnaround_days: f.turnaroundDays
      }))
    );
  } catch (err) {
    console.error('[marketplace/factories]', err);
    res.status(500).json({ detail: 'Could not load factories.' });
  }
}
