import prisma from '../../../lib/server/prisma';

// GET /api/marketplace/products?category=&search=  — public, no auth required.
export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ detail: 'Method not allowed' });

  const { category, search } = req.query;
  const where = { active: true };
  if (category && category !== 'all') where.category = category;
  if (search) where.title = { contains: search, mode: 'insensitive' };

  try {
    const rows = await prisma.publicProduct.findMany({
      where,
      include: { factory: { select: { name: true } } },
      orderBy: { id: 'desc' },
      take: 200
    });
    res.status(200).json(
      rows.map((p) => ({
        id: p.id,
        title: p.title,
        description: p.description,
        category: p.category,
        moq: p.moq,
        lead_time_days: p.leadTimeDays,
        base_price: p.basePrice !== null ? Number(p.basePrice) : null,
        factory_name: p.factory?.name || null
      }))
    );
  } catch (err) {
    console.error('[marketplace/products]', err);
    res.status(500).json({ detail: 'Could not load products.' });
  }
}
