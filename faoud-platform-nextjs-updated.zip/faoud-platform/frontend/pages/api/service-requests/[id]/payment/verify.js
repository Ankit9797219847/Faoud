import prisma from '../../../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../../../lib/server/session';
import { verifyPaymentSignature, RazorpayNotConfiguredError } from '../../../../../lib/server/razorpay';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Authentication required' });
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const serviceRequestId = parseInt(req.query.id, 10);
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ detail: 'razorpay_order_id, razorpay_payment_id, and razorpay_signature are required.' });
  }

  try {
    const valid = verifyPaymentSignature({
      orderId: razorpay_order_id,
      paymentId: razorpay_payment_id,
      signature: razorpay_signature
    });
    if (!valid) return res.status(400).json({ detail: 'Payment signature verification failed.' });

    const payment = await prisma.servicePayment.update({
      where: { serviceRequestId },
      data: {
        status: 'SUCCEEDED',
        providerPaymentId: razorpay_payment_id,
        providerSignature: razorpay_signature,
        paidAt: new Date()
      }
    });
    res.status(200).json({ id: payment.id, status: payment.status });
  } catch (err) {
    if (err instanceof RazorpayNotConfiguredError) {
      return res.status(501).json({ detail: err.message });
    }
    console.error('[service-requests/id/payment/verify]', err);
    res.status(500).json({ detail: 'Could not verify service payment.' });
  }
}
