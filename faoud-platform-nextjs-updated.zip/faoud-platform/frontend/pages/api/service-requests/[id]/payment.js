import prisma from '../../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../../lib/server/session';
import { createRazorpayOrder, isRazorpayConfigured } from '../../../../lib/server/razorpay';

// POST /api/service-requests/[id]/payment — ported from payments.models.ServicePayment.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Authentication required' });
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const serviceRequestId = parseInt(req.query.id, 10);
  try {
    const sr = await prisma.serviceRequest.findUnique({ where: { id: serviceRequestId } });
    if (!sr) return res.status(404).json({ detail: 'Service request not found.' });
    if (sr.userId !== session.userId && !['account_manager', 'admin'].includes(session.role)) {
      return res.status(403).json({ detail: 'Not allowed' });
    }

    const amount = sr.finalPrice || sr.listPrice;
    if (!amount) return res.status(400).json({ detail: 'This service request has no price set yet.' });

    const payment = await prisma.servicePayment.upsert({
      where: { serviceRequestId },
      create: { serviceRequestId, userId: session.userId, amount, status: 'CREATED' },
      update: { amount, status: 'CREATED' }
    });

    if (!isRazorpayConfigured()) {
      return res.status(201).json({
        id: payment.id,
        status: payment.status,
        amount: Number(payment.amount),
        razorpay_configured: false,
        warning: 'Razorpay is not configured yet — set RAZORPAY_KEY_ID/SECRET in .env to enable real checkout.'
      });
    }

    const razorpayOrder = await createRazorpayOrder({
      amount,
      receipt: `service-${sr.id}-${payment.id}`,
      notes: { service_request_id: String(sr.id) }
    });
    const updated = await prisma.servicePayment.update({
      where: { id: payment.id },
      data: { providerOrderId: razorpayOrder.id, status: 'PENDING' }
    });

    res.status(201).json({
      id: updated.id,
      status: updated.status,
      amount: Number(updated.amount),
      razorpay_configured: true,
      razorpay_key_id: process.env.RAZORPAY_KEY_ID,
      razorpay_order: razorpayOrder
    });
  } catch (err) {
    console.error('[service-requests/id/payment]', err);
    res.status(500).json({ detail: 'Could not create service payment.' });
  }
}
