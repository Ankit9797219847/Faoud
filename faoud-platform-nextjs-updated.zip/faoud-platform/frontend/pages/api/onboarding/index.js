import prisma from '../../../lib/server/prisma';
import { getSession } from '../../../lib/server/session';

// POST /api/onboarding — public. Creates (or upserts, keyed by client_id) a
// draft as the visitor moves through the homepage's brand/manufacturer
// onboarding funnel. No auth required — this runs before signup.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const body = req.body || {};
  const {
    client_id,
    flow_type,
    step,
    product_category,
    product_name,
    quantity,
    instructions,
    requires_formulation,
    selected_factory,
    factory_title,
    selected_category_ids,
    selected_subcategory_ids,
    custom_category_text,
    custom_subcategory_text,
    email,
    mobile,
    company_name,
    location,
    timeline,
    budget,
    origination_source,
    source_route,
    configurator_answers,
    utm_params
  } = body;

  const session = getSession(req);

  const data = {
    flowType: flow_type,
    step,
    productCategory: product_category,
    productName: product_name,
    quantity,
    instructions,
    requiresFormulation: !!requires_formulation,
    selectedFactory: selected_factory,
    factoryTitle: factory_title,
    selectedCategoryIds: selected_category_ids,
    selectedSubcategoryIds: selected_subcategory_ids,
    customCategoryText: custom_category_text,
    customSubcategoryText: custom_subcategory_text,
    email,
    mobile,
    companyName: company_name,
    location,
    timeline,
    budget,
    originationSource: origination_source,
    sourceRoute: source_route,
    configuratorAnswers: configurator_answers,
    utmParams: utm_params,
    userId: session?.userId || null
  };
  // Strip undefined keys so Prisma doesn't try to null out fields the
  // caller didn't send on a partial-step update.
  Object.keys(data).forEach((k) => data[k] === undefined && delete data[k]);

  try {
    const row = client_id
      ? await prisma.onboardingData.upsert({
          where: { clientId: client_id },
          create: { clientId: client_id, ...data },
          update: data
        })
      : await prisma.onboardingData.create({ data });
    res.status(201).json({ id: row.id, client_id: row.clientId });
  } catch (err) {
    console.error('[onboarding] create', err);
    res.status(500).json({ detail: 'Could not save onboarding progress.' });
  }
}
