import formidable from 'formidable';
import fs from 'fs';
import path from 'path';
import prisma from '../../../../lib/server/prisma';
import { isS3Enabled, uploadToS3 } from '../../../../lib/server/storage';

export const config = { api: { bodyParser: false } };

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads', 'onboarding');

// POST /api/onboarding/[id]/attachments — public (part of the pre-signup
// funnel), same as the rest of the onboarding capture flow.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const onboardingId = parseInt(req.query.id, 10);
  const record = await prisma.onboardingData.findUnique({ where: { id: onboardingId } });
  if (!record) return res.status(404).json({ detail: 'Onboarding record not found.' });

  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const form = formidable({ uploadDir: UPLOAD_DIR, keepExtensions: true, maxFileSize: 25 * 1024 * 1024 });

  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(400).json({ detail: 'Upload failed' });
    const file = files.file?.[0] || files.file;
    if (!file) return res.status(400).json({ detail: 'No file provided.' });

    const kind = Array.isArray(fields.kind) ? fields.kind[0] : fields.kind;
    const filename = path.basename(file.filepath);
    const fileUrl = isS3Enabled()
      ? await uploadToS3(file.filepath, `onboarding/${filename}`)
      : `/uploads/onboarding/${filename}`;

    const attachment = await prisma.onboardingAttachment.create({
      data: {
        onboardingId,
        fileUrl,
        originalName: file.originalFilename || null,
        kind: kind || null
      }
    });
    res.status(201).json(attachment);
  });
}
