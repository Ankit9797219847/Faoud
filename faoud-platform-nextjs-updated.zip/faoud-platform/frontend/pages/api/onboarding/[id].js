import prisma from '../../../lib/server/prisma';
import { getSession } from '../../../lib/server/session';

export default async function handler(req, res) {
  const id = parseInt(req.query.id, 10);

  if (req.method === 'GET') {
    // Only AM/admin can read back a specific onboarding record directly;
    // the public flow re-fetches its own draft via client_id, not id.
    const session = getSession(req);
    if (!session || !['am', 'account_manager', 'admin'].includes(session.role)) {
      return res.status(403).json({ detail: 'Not allowed' });
    }
    const row = await prisma.onboardingData.findUnique({ where: { id }, include: { attachments: true } });
    if (!row) return res.status(404).json({ detail: 'Not found' });
    return res.status(200).json(row);
  }

  if (req.method === 'PATCH' || req.method === 'PUT') {
    const body = req.body || {};
    const data = {};
    const map = {
      flow_type: 'flowType',
      step: 'step',
      product_category: 'productCategory',
      product_name: 'productName',
      quantity: 'quantity',
      instructions: 'instructions',
      requires_formulation: 'requiresFormulation',
      selected_factory: 'selectedFactory',
      factory_title: 'factoryTitle',
      selected_category_ids: 'selectedCategoryIds',
      selected_subcategory_ids: 'selectedSubcategoryIds',
      custom_category_text: 'customCategoryText',
      custom_subcategory_text: 'customSubcategoryText',
      email: 'email',
      mobile: 'mobile',
      company_name: 'companyName',
      location: 'location',
      timeline: 'timeline',
      budget: 'budget',
      origination_source: 'originationSource',
      source_route: 'sourceRoute',
      configurator_answers: 'configuratorAnswers',
      utm_params: 'utmParams'
    };
    for (const [jsonKey, prismaKey] of Object.entries(map)) {
      if (jsonKey in body) data[prismaKey] = body[jsonKey];
    }
    try {
      const row = await prisma.onboardingData.update({ where: { id }, data });
      return res.status(200).json({ id: row.id });
    } catch (err) {
      console.error('[onboarding/id] update', err);
      return res.status(404).json({ detail: 'Onboarding record not found.' });
    }
  }

  res.status(405).json({ detail: 'Method not allowed' });
}
