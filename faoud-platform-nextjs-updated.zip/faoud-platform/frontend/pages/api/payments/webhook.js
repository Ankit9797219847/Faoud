import prisma from '../../../lib/server/prisma';
import { verifyWebhookSignature, RazorpayNotConfiguredError } from '../../../lib/server/razorpay';
import { recalculateOrderStatus } from '../../../lib/server/payments';

// Razorpay signs the webhook over the raw request body, so bodyParser
// must stay off here — we read the raw bytes ourselves.
export const config = { api: { bodyParser: false } };

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => (data += chunk));
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const rawBody = await readRawBody(req);
  const signature = req.headers['x-razorpay-signature'];

  try {
    const valid = verifyWebhookSignature({ rawBody, signature });
    if (!valid) return res.status(400).json({ detail: 'Invalid webhook signature.' });
  } catch (err) {
    if (err instanceof RazorpayNotConfiguredError) {
      return res.status(501).json({ detail: err.message });
    }
    return res.status(400).json({ detail: 'Could not verify webhook.' });
  }

  const event = JSON.parse(rawBody);
  const entity = event.payload?.payment?.entity;

  try {
    if (event.event === 'payment.captured' && entity?.order_id) {
      const layer = await prisma.paymentLayer.findFirst({ where: { razorpayOrderId: entity.order_id } });
      if (layer && layer.status !== 'PAID') {
        await prisma.paymentLayer.update({
          where: { id: layer.id },
          data: { status: 'PAID', razorpayPaymentId: entity.id }
        });
        await recalculateOrderStatus(layer.orderId);
      }
    } else if (event.event === 'payment.failed' && entity?.order_id) {
      const layer = await prisma.paymentLayer.findFirst({ where: { razorpayOrderId: entity.order_id } });
      if (layer) {
        await prisma.paymentLayer.update({ where: { id: layer.id }, data: { status: 'FAILED' } });
      }
    }
    res.status(200).json({ detail: 'ok' });
  } catch (err) {
    console.error('[payments/webhook]', err);
    res.status(500).json({ detail: 'Webhook processing failed.' });
  }
}
