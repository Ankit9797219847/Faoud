import prisma from '../../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../../lib/server/session';

function generateOrderId() {
  return 'ORD-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
}

// POST /api/payments/orders — ported from payments.views order-creation.
// Brand Owner creates the Order shell for a case; advance/final payment
// layers are added afterwards via /api/payments/orders/[id]/advance|final.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Authentication required' });
  if (!['brand', 'account_manager', 'admin'].includes(session.role)) {
    return res.status(403).json({ detail: 'Not allowed' });
  }
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const { case_id, total_amount, currency, expiry_days } = req.body || {};
  if (!case_id || !total_amount) return res.status(400).json({ detail: 'case_id and total_amount are required.' });

  try {
    const expiryDate = new Date(Date.now() + (expiry_days || 7) * 24 * 60 * 60 * 1000);
    const order = await prisma.order.create({
      data: {
        caseId: parseInt(case_id, 10),
        orderId: generateOrderId(),
        totalAmount: total_amount,
        amountDue: total_amount,
        currency: currency || 'INR',
        expiryDate
      }
    });
    res.status(201).json({
      id: order.id,
      order_id: order.orderId,
      case: order.caseId,
      total_amount: Number(order.totalAmount),
      amount_due: Number(order.amountDue),
      status: order.status,
      currency: order.currency,
      expiry_date: order.expiryDate
    });
  } catch (err) {
    console.error('[payments/orders] create', err);
    res.status(500).json({ detail: 'Could not create order.' });
  }
}
