import prisma from '../../../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../../../lib/server/session';
import { createPaymentLayer, serializeLayer } from '../../../../../lib/server/payments';
import { isRazorpayConfigured } from '../../../../../lib/server/razorpay';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Authentication required' });
  if (!['brand', 'account_manager', 'admin'].includes(session.role)) {
    return res.status(403).json({ detail: 'Not allowed' });
  }
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const orderId = parseInt(req.query.id, 10);
  const { amount } = req.body || {};
  if (!amount) return res.status(400).json({ detail: 'amount is required.' });

  try {
    const order = await prisma.order.findUnique({ where: { id: orderId } });
    if (!order) return res.status(404).json({ detail: 'Order not found.' });

    const { layer, razorpayOrder, razorpayError } = await createPaymentLayer({
      order,
      layerType: 'FINAL',
      amount
    });

    res.status(201).json({
      layer: serializeLayer(layer),
      razorpay_key_id: isRazorpayConfigured() ? process.env.RAZORPAY_KEY_ID : null,
      razorpay_order: razorpayOrder,
      razorpay_configured: isRazorpayConfigured(),
      warning: razorpayError || (!isRazorpayConfigured() ? 'Razorpay is not configured yet — set RAZORPAY_KEY_ID/SECRET in .env to enable real checkout.' : undefined)
    });
  } catch (err) {
    console.error('[payments/orders/id/final]', err);
    res.status(500).json({ detail: 'Could not create final payment.' });
  }
}
