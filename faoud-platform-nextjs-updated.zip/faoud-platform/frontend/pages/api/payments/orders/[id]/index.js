import prisma from '../../../../../lib/server/prisma';
import { getSession } from '../../../../../lib/server/session';
import { serializeLayer } from '../../../../../lib/server/payments';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Authentication required' });

  const id = parseInt(req.query.id, 10);
  try {
    const order = await prisma.order.findUnique({ where: { id }, include: { paymentLayers: true } });
    if (!order) return res.status(404).json({ detail: 'Order not found.' });
    res.status(200).json({
      id: order.id,
      order_id: order.orderId,
      case: order.caseId,
      total_amount: Number(order.totalAmount),
      amount_due: Number(order.amountDue),
      status: order.status,
      currency: order.currency,
      expiry_date: order.expiryDate,
      payment_layers: order.paymentLayers.map(serializeLayer)
    });
  } catch (err) {
    console.error('[payments/orders/id]', err);
    res.status(500).json({ detail: 'Could not fetch order.' });
  }
}
