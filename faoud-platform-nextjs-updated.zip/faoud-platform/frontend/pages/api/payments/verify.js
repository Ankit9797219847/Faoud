import prisma from '../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../lib/server/session';
import { verifyPaymentSignature, RazorpayNotConfiguredError } from '../../../lib/server/razorpay';
import { recalculateOrderStatus, serializeLayer } from '../../../lib/server/payments';
import { notifyUser } from '../../../lib/server/notify';

// POST /api/payments/verify — called by the frontend after Razorpay
// Checkout succeeds, with razorpay_order_id/razorpay_payment_id/
// razorpay_signature from the Checkout response.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Authentication required' });
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ detail: 'razorpay_order_id, razorpay_payment_id, and razorpay_signature are required.' });
  }

  try {
    const valid = verifyPaymentSignature({
      orderId: razorpay_order_id,
      paymentId: razorpay_payment_id,
      signature: razorpay_signature
    });
    if (!valid) return res.status(400).json({ detail: 'Payment signature verification failed.' });

    const layer = await prisma.paymentLayer.findFirst({ where: { razorpayOrderId: razorpay_order_id } });
    if (!layer) return res.status(404).json({ detail: 'Payment layer not found for this Razorpay order.' });

    const updated = await prisma.paymentLayer.update({
      where: { id: layer.id },
      data: { status: 'PAID', razorpayPaymentId: razorpay_payment_id, razorpaySignature: razorpay_signature }
    });
    await recalculateOrderStatus(layer.orderId);

    const user = await prisma.user.findUnique({ where: { id: session.userId } });
    notifyUser({
      userId: session.userId,
      type: 'email',
      to: user?.email,
      subject: 'Payment received — Faoud Industries',
      message: `Your ${layer.layerType.toLowerCase()} payment of ₹${layer.amount} has been received. Thank you.`
    }).catch(() => null);

    res.status(200).json({ detail: 'Payment verified.', layer: serializeLayer(updated) });
  } catch (err) {
    if (err instanceof RazorpayNotConfiguredError) {
      return res.status(501).json({ detail: err.message });
    }
    console.error('[payments/verify]', err);
    res.status(500).json({ detail: 'Could not verify payment.' });
  }
}
