import { getSession } from '../../lib/server/session';
import { handleResource, isKnownResource } from '../../lib/server/genericResource';
import * as wf from '../../lib/server/workflow';
import prisma from '../../lib/server/prisma';

function requireAuth(req, res) {
  const session = getSession(req);
  if (!session) {
    res.status(401).json({ detail: 'Authentication required' });
    return null;
  }
  return session;
}

export default async function handler(req, res) {
  const segments = (req.query.path || []).filter(Boolean);
  if (segments.length === 0) return res.status(404).json({ detail: 'Not found' });

  const [a, b, c, d, e] = segments;

  try {
    // ---- /leads/create/ (special create path, not the collection endpoint)
    if (a === 'leads' && b === 'create' && req.method === 'POST') {
      return handleResource(req, res, 'leads', null);
    }

    // ---- dashboard landing-page aggregations
    if (a === 'cases' && b === 'list_brand_owner_dashboard' && req.method === 'GET') {
      const session = requireAuth(req, res);
      if (!session) return;
      return wf.listBrandOwnerCases(req, res, session);
    }
    if (a === 'cases' && b === 'list_assigned' && req.method === 'GET') {
      const session = requireAuth(req, res);
      if (!session) return;
      return wf.listAssignedCases(req, res, session);
    }
    if (a === 'cases' && b === 'bidding' && req.method === 'GET') {
      return wf.listOpenCasesForBidding(req, res);
    }
    if (a === 'alerts' && !b && req.method === 'GET') {
      const session = requireAuth(req, res);
      if (!session) return;
      return wf.listAlertsForUser(req, res, session);
    }
    if (a === 'management' && b === 'brands' && req.method === 'GET') {
      return handleResource(req, res, 'brands', null);
    }
    if (a === 'materials' && (b === 'raw-materials' || b === 'packaging-materials')) {
      return handleResource(req, res, b, null);
    }
    if (a === 'factories' && b === 'me' && req.method === 'GET') {
      const session = requireAuth(req, res);
      if (!session) return;
      return wf.getMyFactories(req, res, session);
    }
    if (a === 'payments' && b === 'transactions' && req.method === 'GET') {
      const session = requireAuth(req, res);
      if (!session) return;
      return wf.listBrandOwnerPayments(req, res, session);
    }
    if (a === 'user' && b === 'bids' && req.method === 'GET') {
      const session = requireAuth(req, res);
      if (!session) return;
      return wf.getUserBids(req, res, session);
    }

    if (a === 'insights' && b === 'dashboard' && req.method === 'GET') {
      const session = requireAuth(req, res);
      if (!session) return;
      return wf.getInsightsDashboard(req, res, session);
    }

    // ---- /cases/<id>/...
    if (a === 'cases' && b === 'create' && req.method === 'POST') {
      const session = requireAuth(req, res);
      if (!session) return;
      if (session.role !== 'brand') return res.status(403).json({ detail: 'Brand Owner only' });
      return wf.createCase(req, res, session, req.body);
    }
    if (a === 'cases' && b) {
      const caseId = parseInt(b, 10);
      const session = requireAuth(req, res);
      if (!session) return;

      if (!c) {
        if (req.method === 'GET') return wf.getCase(req, res, caseId);
        return res.status(405).json({ detail: 'Method not allowed' });
      }
      if (c === 'stages' && req.method === 'GET') return wf.getStages(req, res, caseId);
      if (c === 'stage-transition' && req.method === 'POST') return wf.stageTransition(req, res, session, caseId);
      if (c === 'assignment') {
        if (req.method === 'GET') return wf.getAssignment(req, res, caseId);
        if (req.method === 'POST') return wf.postAssignment(req, res, session, caseId);
      }
      if (c === 'notes' && (req.method === 'PATCH' || req.method === 'PUT')) return wf.patchNotes(req, res, caseId);
      if (c === 'priority' && (req.method === 'PATCH' || req.method === 'PUT')) return wf.patchPriority(req, res, session, caseId);
      if (c === 'update-color' && (req.method === 'PATCH' || req.method === 'PUT')) return wf.patchColor(req, res, session, caseId);
      if (c === 'bids' && req.method === 'GET') return wf.getCaseBids(req, res, caseId);
      if (c === 'bid-list' && req.method === 'GET') return wf.getBrandOwnerBidList(req, res, caseId);
      if (c === 'briefs' && req.method === 'GET') return wf.getCaseBriefs(req, res, caseId);
      if (c === 'messages') {
        if (req.method === 'GET') return wf.getCaseMessages(req, res, session, caseId);
        if (req.method === 'POST') {
          if (d === 'mark-read') return wf.markCaseMessagesRead(req, res, session, caseId);
          return wf.postCaseMessage(req, res, session, caseId);
        }
      }
      if (c === 'chat-permission') {
        if (req.method === 'GET') return wf.getChatPermission(req, res, caseId);
        if (req.method === 'PATCH' || req.method === 'PUT') return wf.patchChatPermission(req, res, session, caseId);
      }
      if (c === 'dispatch') {
        if (!d && req.method === 'GET') return wf.getDispatch(req, res, caseId);
        if (d === 'set-delivery-type' && (req.method === 'PATCH' || req.method === 'PUT')) return wf.setDeliveryType(req, res, caseId);
        if (d === 'packing' && (req.method === 'PATCH' || req.method === 'PUT')) return wf.updatePacking(req, res, caseId);
        if (d === 'details' && (req.method === 'PATCH' || req.method === 'PUT')) return wf.confirmDetails(req, res, caseId);
      }
      return res.status(404).json({ detail: 'Not found' });
    }

    // ---- /brief/create/ , /brief/<id>/
    if (a === 'brief') {
      const session = requireAuth(req, res);
      if (!session) return;
      if (b === 'create' && req.method === 'POST') return wf.createBrief(req, res, session);
      if (b && req.method === 'DELETE') return wf.deleteBrief(req, res, parseInt(b, 10));
      return res.status(404).json({ detail: 'Not found' });
    }

    // ---- /qcs/ , /qcs/completed/ , /qcs/<id>/update-qc/
    if (a === 'qcs') {
      const session = requireAuth(req, res);
      if (!session) return;
      if (!b && req.method === 'POST') return wf.createQCEntry(req, res, session);
      if (b === 'completed' && req.method === 'GET') {
        const caseId = parseInt(req.query.case_id, 10);
        if (!caseId) return res.status(400).json({ detail: 'case_id is required' });
        return wf.getQCEntries(req, res, caseId);
      }
      if (b && c === 'update-qc' && (req.method === 'PATCH' || req.method === 'PUT')) {
        return wf.updateQCEntry(req, res, parseInt(b, 10));
      }
      return res.status(404).json({ detail: 'Not found' });
    }

    // ---- /factory-owner/sample-orders/<bidId>/tracking/
    if (a === 'factory-owner' && b === 'sample-orders' && c && d === 'tracking') {
      const session = requireAuth(req, res);
      if (!session) return;
      const bidId = parseInt(c, 10);
      if (req.method === 'GET') return wf.getOrCreateTracking(req, res, bidId);
      if (req.method === 'POST') return wf.postTracking(req, res, bidId);
      return res.status(405).json({ detail: 'Method not allowed' });
    }

    // ---- /service-requests/admin/[...]
    if (a === 'service-requests' && b === 'admin') {
      const session = requireAuth(req, res);
      if (!session) return;
      if (!c && req.method === 'GET') return wf.listServiceRequestsAdmin(req, res, session);
      if (c && d === 'status' && req.method === 'POST') return wf.updateServiceRequestStatus(req, res, session, parseInt(c, 10));
      if (c && d === 'assign' && req.method === 'POST') return wf.assignServiceRequestOwner(req, res, session, parseInt(c, 10));
      return res.status(404).json({ detail: 'Not found' });
    }

    // ---- /bids (create) — factory owners don't send their own factory ID;
    // it's derived from their session instead of trusted from the client.
    if (a === 'bids' && !b && req.method === 'POST') {
      const session = requireAuth(req, res);
      if (!session) return;
      if (session.role === 'factory') {
        const owner = await prisma.factoryOwner.findUnique({ where: { userId: session.userId } });
        if (!owner?.factoryId) return res.status(400).json({ detail: 'No factory linked to this account.' });
        req.body = { ...req.body, factory: owner.factoryId };
      }
      return handleResource(req, res, 'bids', null);
    }

    // ---- generic resource collection/detail: /<resource>/ or /<resource>/<id>/
    if (a && isKnownResource(a)) {
      const id = b && /^\d+$/.test(b) ? b : null;
      return handleResource(req, res, a, id);
    }

    return res.status(404).json({ detail: 'Not found' });
  } catch (err) {
    console.error('[api] unhandled error', err);
    return res.status(500).json({ detail: 'Internal server error' });
  }
}
