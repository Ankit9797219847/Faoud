import formidable from 'formidable';
import fs from 'fs';
import path from 'path';
import prisma from '../../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../../lib/server/session';
import { isS3Enabled, uploadToS3 } from '../../../../lib/server/storage';

export const config = { api: { bodyParser: false } };

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads', 'formulations');

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Authentication required' });
  if (!['brand', 'account_manager'].includes(session.role)) {
    return res.status(403).json({ detail: 'Not permitted' });
  }
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const caseId = parseInt(req.query.id, 10);
  const c = await prisma.case.findUnique({ where: { id: caseId }, include: { product: true } });
  if (!c) return res.status(404).json({ error: 'Case not found' });
  if (!c.product) {
    return res.status(400).json({ error: 'No product associated with this case. Please add a product before uploading formulation.' });
  }

  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const form = formidable({ uploadDir: UPLOAD_DIR, keepExtensions: true, maxFileSize: 25 * 1024 * 1024 });

  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(400).json({ error: 'Upload failed' });
    const file = files.formulation?.[0] || files.formulation;
    if (!file) return res.status(400).json({ error: 'No formulation file provided.' });

    const filename = path.basename(file.filepath);
    const documentUrl = isS3Enabled()
      ? await uploadToS3(file.filepath, `formulations/${filename}`)
      : `/uploads/formulations/${filename}`;

    await prisma.formulation.upsert({
      where: { productId: c.product.id },
      create: { productId: c.product.id, documents: documentUrl },
      update: { documents: documentUrl }
    });
    const formulation = await prisma.formulation.findUnique({ where: { productId: c.product.id } });
    await prisma.case.update({ where: { id: caseId }, data: { formulationId: formulation.id } });

    return res.status(200).json({ message: 'Formulation uploaded successfully.' });
  });
}
