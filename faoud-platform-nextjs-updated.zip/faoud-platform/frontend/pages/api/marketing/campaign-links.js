import crypto from 'crypto';
import prisma from '../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../lib/server/session';

// POST /api/marketing/campaign-links — AM only. Auto-generates the short
// token (ported from marketing.generate_token / secrets.token_urlsafe).
// GET/PATCH/DELETE for existing links still go through the generic
// /api/campaign-links resource.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session || !['account_manager', 'admin'].includes(session.role)) {
    return res.status(403).json({ detail: 'Not allowed' });
  }
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const { campaign_id, destination_url, label } = req.body || {};
  if (!campaign_id || !destination_url) {
    return res.status(400).json({ detail: 'campaign_id and destination_url are required.' });
  }

  try {
    const token = crypto.randomBytes(18).toString('base64url');
    const link = await prisma.campaignLink.create({
      data: { token, campaignId: parseInt(campaign_id, 10), destinationUrl: destination_url, label: label || '' }
    });
    res.status(201).json({
      id: link.id,
      token: link.token,
      short_url: `/api/go/${link.token}`,
      destination_url: link.destinationUrl,
      label: link.label
    });
  } catch (err) {
    console.error('[marketing/campaign-links] create', err);
    res.status(500).json({ detail: 'Could not create campaign link.' });
  }
}
