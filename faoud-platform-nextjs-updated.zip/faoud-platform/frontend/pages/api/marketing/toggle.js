import prisma from '../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../lib/server/session';

// GET is public (the homepage checks this on load). PATCH is admin-only.
export default async function handler(req, res) {
  if (req.method === 'GET') {
    try {
      const row = await prisma.marketingToggle.findFirst({ orderBy: { id: 'desc' } });
      return res.status(200).json({ is_enabled: row?.isEnabled ?? false });
    } catch (err) {
      console.error('[marketing/toggle] get', err);
      return res.status(500).json({ detail: 'Could not load toggle.' });
    }
  }

  if (req.method === 'PATCH' || req.method === 'PUT') {
    const session = getSession(req);
    if (!session || !['admin', 'account_manager'].includes(session.role)) {
      return res.status(403).json({ detail: 'Not allowed' });
    }
    if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

    const { is_enabled } = req.body || {};
    try {
      const existing = await prisma.marketingToggle.findFirst({ orderBy: { id: 'desc' } });
      const row = existing
        ? await prisma.marketingToggle.update({ where: { id: existing.id }, data: { isEnabled: !!is_enabled } })
        : await prisma.marketingToggle.create({ data: { isEnabled: !!is_enabled } });
      return res.status(200).json({ is_enabled: row.isEnabled });
    } catch (err) {
      console.error('[marketing/toggle] patch', err);
      return res.status(500).json({ detail: 'Could not update toggle.' });
    }
  }

  res.status(405).json({ detail: 'Method not allowed' });
}
