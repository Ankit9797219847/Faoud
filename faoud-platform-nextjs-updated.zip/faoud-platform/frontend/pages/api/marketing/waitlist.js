import prisma from '../../../lib/server/prisma';

function getClientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (fwd) return fwd.split(',')[0].trim();
  return req.socket?.remoteAddress || null;
}

// POST /api/marketing/waitlist — public "coming soon" waitlist capture.
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ detail: 'Method not allowed' });

  const { contact_number, email } = req.body || {};
  if (!contact_number) return res.status(400).json({ detail: 'contact_number is required.' });

  try {
    const entry = await prisma.waitlistEntry.create({
      data: { contactNumber: contact_number, email: email || null, ipAddress: getClientIp(req) }
    });
    res.status(201).json({ message: "You're on the list — we'll be in touch.", id: entry.id });
  } catch (err) {
    console.error('[marketing/waitlist]', err);
    res.status(500).json({ detail: 'Could not join the waitlist.' });
  }
}
