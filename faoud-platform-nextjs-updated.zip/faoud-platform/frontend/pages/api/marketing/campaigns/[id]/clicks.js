import prisma from '../../../../../lib/server/prisma';
import { getSession } from '../../../../../lib/server/session';

// GET /api/marketing/campaigns/[id]/clicks — AM only. Total + per-link click counts.
export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session || !['account_manager', 'admin'].includes(session.role)) {
    return res.status(403).json({ detail: 'Not allowed' });
  }

  const campaignId = parseInt(req.query.id, 10);
  try {
    const links = await prisma.campaignLink.findMany({
      where: { campaignId },
      include: { _count: { select: { clicks: true } } }
    });
    res.status(200).json({
      campaign_id: campaignId,
      total_clicks: links.reduce((sum, l) => sum + l._count.clicks, 0),
      links: links.map((l) => ({
        id: l.id,
        label: l.label,
        token: l.token,
        destination_url: l.destinationUrl,
        clicks: l._count.clicks
      }))
    });
  } catch (err) {
    console.error('[marketing/campaigns/clicks]', err);
    res.status(500).json({ detail: 'Could not load click data.' });
  }
}
