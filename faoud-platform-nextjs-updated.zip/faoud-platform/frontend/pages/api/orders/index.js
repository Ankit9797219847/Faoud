import prisma from '../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../lib/server/session';

function generateOrderNumber() {
  return (
    'FAO-' +
    Date.now().toString(36).toUpperCase() +
    '-' +
    Math.random().toString(36).slice(2, 6).toUpperCase()
  );
}

function toOrderJson(o) {
  return {
    id: o.id,
    order_number: o.orderNumber,
    quantity: o.quantity,
    status: o.status,
    notes: o.notes,
    created_at: o.createdAt
  };
}

// GET/POST /api/orders — the simple marketplace quote-request flow behind
// the plain /dashboard page. Brand Owners see their own orders, Factory
// Owners see incoming ones, AM/admin see everything. This is separate from
// the ops-console Case/Bid workflow, which is the real day-to-day flow for
// logged-in brand/factory ops users.
export default async function handler(req, res) {
  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Authentication required' });

  if (req.method === 'GET') {
    try {
      let where = {};
      if (session.role === 'brand') {
        where = { brandId: session.userId };
      } else if (session.role === 'factory') {
        const owner = await prisma.factoryOwner.findUnique({ where: { userId: session.userId } });
        if (!owner?.factoryId) return res.status(200).json([]);
        where = { factoryId: owner.factoryId };
      } else if (!['admin', 'account_manager'].includes(session.role)) {
        return res.status(403).json({ detail: 'Not allowed' });
      }
      const rows = await prisma.marketplaceOrder.findMany({ where, orderBy: { id: 'desc' }, take: 200 });
      return res.status(200).json(rows.map(toOrderJson));
    } catch (err) {
      console.error('[orders] list', err);
      return res.status(500).json({ detail: 'Could not fetch orders.' });
    }
  }

  if (req.method === 'POST') {
    if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });
    if (!['brand', 'admin'].includes(session.role)) return res.status(403).json({ detail: 'Brand Owner only' });

    const { factory_id, product_id, quantity, notes } = req.body || {};
    if (!factory_id || !quantity) return res.status(400).json({ detail: 'factory_id and quantity are required.' });

    try {
      const row = await prisma.marketplaceOrder.create({
        data: {
          orderNumber: generateOrderNumber(),
          brandId: session.userId,
          factoryId: parseInt(factory_id, 10),
          productId: product_id ? parseInt(product_id, 10) : null,
          quantity: parseInt(quantity, 10),
          notes: notes || null,
          status: 'quote_requested'
        }
      });
      return res.status(201).json(toOrderJson(row));
    } catch (err) {
      console.error('[orders] create', err);
      return res.status(500).json({ detail: 'Could not create order.' });
    }
  }

  res.status(405).json({ detail: 'Method not allowed' });
}
