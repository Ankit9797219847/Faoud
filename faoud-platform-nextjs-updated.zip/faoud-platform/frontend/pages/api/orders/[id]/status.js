import prisma from '../../../../lib/server/prisma';
import { getSession, checkCsrf } from '../../../../lib/server/session';

const VALID_STATUSES = [
  'quote_requested',
  'quoted',
  'confirmed',
  'in_production',
  'quality_check',
  'dispatched',
  'delivered',
  'cancelled'
];

export default async function handler(req, res) {
  if (req.method !== 'PATCH') return res.status(405).json({ detail: 'Method not allowed' });

  const session = getSession(req);
  if (!session) return res.status(401).json({ detail: 'Authentication required' });
  if (!['factory', 'admin', 'account_manager'].includes(session.role)) {
    return res.status(403).json({ detail: 'Not allowed' });
  }
  if (!checkCsrf(req)) return res.status(403).json({ detail: 'CSRF check failed' });

  const { status } = req.body || {};
  if (!VALID_STATUSES.includes(status)) return res.status(400).json({ detail: 'Invalid status value.' });

  try {
    const row = await prisma.marketplaceOrder.update({
      where: { id: parseInt(req.query.id, 10) },
      data: { status }
    });
    res.status(200).json({
      id: row.id,
      order_number: row.orderNumber,
      quantity: row.quantity,
      status: row.status,
      notes: row.notes,
      created_at: row.createdAt
    });
  } catch (err) {
    console.error('[orders/status]', err);
    res.status(404).json({ detail: 'Order not found.' });
  }
}
