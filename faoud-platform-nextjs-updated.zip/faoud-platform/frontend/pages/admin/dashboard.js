import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/admin/dashboard' },
  { label: 'All Data', href: '/admin/data' },
  { label: 'Insights', href: '/am/insights' }
];

function AdminDashboardInner() {
  const [kpis, setKpis] = useState(null);
  const [comingSoon, setComingSoon] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const [insightsRes, toggleRes] = await Promise.allSettled([
      djangoApi.get('/insights/dashboard'),
      djangoApi.get('/marketing/toggle')
    ]);
    if (insightsRes.status === 'fulfilled') setKpis(insightsRes.value.data);
    if (toggleRes.status === 'fulfilled') setComingSoon(!!toggleRes.value.data.is_enabled);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function toggleComingSoon() {
    setBusy(true);
    try {
      await ensureCsrfCookie();
      const res = await djangoApi.patch('/marketing/toggle', { is_enabled: !comingSoon });
      setComingSoon(!!res.data.is_enabled);
    } finally {
      setBusy(false);
    }
  }

  return (
    <OpsShell roleLabel="Admin" accent="ink" navItems={NAV} activeHref="/admin/dashboard">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Admin</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Site Overview</h1>
      </header>

      {kpis && (
        <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div className="rounded-sm border border-line bg-panel p-4">
            <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Cases (last 5d)</p>
            <p className="mt-2 font-display text-2xl text-ink">{kpis.cases_added}</p>
          </div>
          <div className="rounded-sm border border-line bg-panel p-4">
            <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Bids</p>
            <p className="mt-2 font-display text-2xl text-ink">{kpis.bids_added}</p>
          </div>
          <div className="rounded-sm border border-line bg-panel p-4">
            <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Dispatched</p>
            <p className="mt-2 font-display text-2xl text-ink">{kpis.case_dispatched}</p>
          </div>
          <div className="rounded-sm border border-line bg-panel p-4">
            <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Total paid</p>
            <p className="mt-2 font-display text-2xl text-ink">₹{Number(kpis.total_paid || 0).toLocaleString('en-IN')}</p>
          </div>
        </div>
      )}
      <p className="mb-8 text-sm">
        <Link href="/am/insights" className="text-teal underline">
          View the full insights dashboard →
        </Link>
      </p>

      <section className="mb-8">
        <h2 className="mb-3 font-display text-lg text-ink">Site status</h2>
        <div className="flex items-center justify-between rounded-sm border border-line bg-panel p-4">
          <div>
            <p className="text-sm text-ink">&ldquo;Coming Soon&rdquo; mode</p>
            <p className="text-xs text-muted">When on, the public site shows a coming-soon page instead of the homepage.</p>
          </div>
          <button
            onClick={toggleComingSoon}
            disabled={busy}
            className={`rounded-sm px-4 py-2 text-sm font-medium disabled:opacity-50 ${
              comingSoon ? 'bg-danger text-paper' : 'border border-line text-ink'
            }`}
          >
            {comingSoon ? 'Turn off' : 'Turn on'}
          </button>
        </div>
      </section>

      <section>
        <h2 className="mb-3 font-display text-lg text-ink">Content & marketing</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {[
            ['Blog posts', 'blog-posts'],
            ['Marketplace catalog', 'public-products'],
            ['Contact submissions', 'contact-leads'],
            ['Waitlist', 'waitlist-entries'],
            ['Marketplace orders', 'marketplace-orders'],
            ['Campaign links', 'campaign-links']
          ].map(([label]) => (
            <Link
              key={label}
              href="/admin/data"
              className="rounded-sm border border-line bg-panel p-4 text-sm text-ink hover:border-ink/40"
            >
              {label} →
            </Link>
          ))}
        </div>
      </section>
    </OpsShell>
  );
}

export default function AdminDashboard() {
  return (
    <RoleGuard allow={['admin']}>
      <AdminDashboardInner />
    </RoleGuard>
  );
}
AdminDashboard.noPublicLayout = true;
