import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import DataExplorer from '../../components/DataExplorer';
import { resourcesForRole } from '../../lib/resourceRegistry';

const NAV = [
  { label: 'Dashboard', href: '/admin/dashboard' },
  { label: 'All Data', href: '/admin/data' },
  { label: 'Insights', href: '/am/insights' }
];

function AdminDataInner() {
  const resources = resourcesForRole('admin');
  return (
    <OpsShell roleLabel="Admin" accent="ink" navItems={NAV} activeHref="/admin/data">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Backend data</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Every model, one console</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Admin sees every one of the {resources.length} data tables the backend exposes — the AM console
          plus content/marketing tables (blog, marketplace catalog, contact leads, waitlist, campaigns).
        </p>
      </header>
      <DataExplorer resources={resources} accent="ink" />
    </OpsShell>
  );
}

export default function AdminData() {
  return (
    <RoleGuard allow={['admin']}>
      <AdminDataInner />
    </RoleGuard>
  );
}
AdminData.noPublicLayout = true;
