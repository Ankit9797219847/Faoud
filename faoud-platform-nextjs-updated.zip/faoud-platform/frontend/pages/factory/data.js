import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import DataExplorer from '../../components/DataExplorer';
import { resourcesForRole } from '../../lib/resourceRegistry';

const NAV = [
  { label: 'Dashboard', href: '/factory/dashboard' },
  { label: 'Profile', href: '/factory/profile' },
  { label: 'Data Tables', href: '/factory/data' }
];

function FactoryDataInner() {
  const resources = resourcesForRole('factory');
  return (
    <OpsShell roleLabel="Factory Owner" accent="rust" navItems={NAV} activeHref="/factory/data">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Backend data</p>
        <h1 className="mt-1 font-display text-3xl text-ink">All your records, in one place</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Every table below reads and writes directly to the production backend — create, edit, or remove
          records and they update immediately.
        </p>
      </header>
      <DataExplorer resources={resources} accent="rust" />
    </OpsShell>
  );
}

export default function FactoryData() {
  return (
    <RoleGuard allow={['factory']}>
      <FactoryDataInner />
    </RoleGuard>
  );
}
