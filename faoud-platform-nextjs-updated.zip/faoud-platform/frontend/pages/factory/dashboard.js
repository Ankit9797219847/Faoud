import { useEffect, useState } from 'react';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import StatusBadge from '../../components/StatusBadge';
import api, { ensureCsrfCookie } from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/factory/dashboard' },
  { label: 'Profile', href: '/factory/profile' },
  { label: 'Data Tables', href: '/factory/data' },
  { label: 'My Bids', href: '/factory/bids' }
];

function FactoryDashboardInner() {
  const [openCases, setOpenCases] = useState([]);
  const [bids, setBids] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [bidQuote, setBidQuote] = useState({});
  const [submitting, setSubmitting] = useState(null);

  async function load() {
    try {
      const [casesRes, bidsRes] = await Promise.allSettled([
        api.get('/cases/bidding'),
        api.get('/user/bids')
      ]);

      if (casesRes.status === 'fulfilled') {
        const v = casesRes.value.data;
        setOpenCases(Array.isArray(v) ? v : v.results || []);
      } else {
        setLoadError('Could not load open cases.');
      }

      if (bidsRes.status === 'fulfilled') {
        const v = bidsRes.value.data;
        setBids(Array.isArray(v) ? v : v.results || []);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function submitBid(caseId) {
    const quote = bidQuote[caseId];
    if (!quote) return;
    setSubmitting(caseId);
    try {
      await ensureCsrfCookie();
      await api.post('/bids', { case: caseId, quote });
      setBidQuote((prev) => ({ ...prev, [caseId]: '' }));
      await load();
    } catch (e) {
      // surfaced inline via loadError-style banner isn't wired per-row yet;
      // keep it simple for this pass.
      setLoadError(e.response?.data?.error || 'Could not submit bid.');
    } finally {
      setSubmitting(null);
    }
  }

  return (
    <OpsShell roleLabel="Factory Owner" accent="rust" navItems={NAV} activeHref="/factory/dashboard">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">
          Bench workspace
        </p>
        <h1 className="mt-1 font-display text-3xl text-ink">Open work &amp; your bids</h1>
      </header>

      {loadError && (
        <p className="mb-6 rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">
          {loadError}
        </p>
      )}

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        <section>
          <h2 className="mb-3 font-display text-lg text-ink">Cases open for bidding</h2>
          <div className="flex flex-col gap-3">
            {loading &&
              Array.from({ length: 2 }).map((_, i) => (
                <div key={i} className="h-16 animate-pulse rounded-sm border border-line bg-panel" />
              ))}
            {!loading && openCases.length === 0 && (
              <p className="rounded-sm border border-line bg-panel px-4 py-3 text-sm text-muted">
                No cases are currently open for bidding.
              </p>
            )}
            {openCases.map((c) => (
              <div key={c.id} className="rounded-sm border border-line bg-panel px-4 py-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-ink">{c.name || `Case #${c.id}`}</p>
                  <StatusBadge label={c.stage || 'open'} />
                </div>
                <div className="mt-3 flex gap-2">
                  <input
                    type="number"
                    min="0"
                    placeholder="Your quote"
                    value={bidQuote[c.id] || ''}
                    onChange={(e) =>
                      setBidQuote((prev) => ({ ...prev, [c.id]: e.target.value }))
                    }
                    className="w-32 rounded-sm border border-line bg-white px-2 py-1.5 text-sm outline-none focus:border-ink"
                  />
                  <button
                    onClick={() => submitBid(c.id)}
                    disabled={submitting === c.id || !bidQuote[c.id]}
                    className="rounded-sm bg-ink px-3 py-1.5 text-sm font-medium text-paper transition-opacity hover:opacity-90 disabled:opacity-50"
                  >
                    {submitting === c.id ? 'Submitting…' : 'Submit bid'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h2 className="mb-3 font-display text-lg text-ink">Your bids</h2>
          <div className="overflow-hidden rounded-sm border border-line bg-panel">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line bg-black/[0.02] font-mono text-[11px] uppercase tracking-wider text-muted">
                  <th className="px-4 py-3 font-medium">Case</th>
                  <th className="px-4 py-3 font-medium">Amount</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {!loading && bids.length === 0 && (
                  <tr>
                    <td colSpan={3} className="px-4 py-6 text-center text-muted">
                      You haven&apos;t placed any bids yet.
                    </td>
                  </tr>
                )}
                {bids.map((b) => (
                  <tr key={b.id} className="border-b border-line last:border-0">
                    <td className="px-4 py-3 text-ink">{b.case_name || `Case #${b.case_id}`}</td>
                    <td className="px-4 py-3 font-mono text-ink/80">{b.quote ?? '—'}</td>
                    <td className="px-4 py-3">
                      <StatusBadge label={b.status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </OpsShell>
  );
}

export default function FactoryDashboardPage() {
  return (
    <RoleGuard allow={['factory']}>
      <FactoryDashboardInner />
    </RoleGuard>
  );
}
FactoryDashboardPage.noPublicLayout = true;
