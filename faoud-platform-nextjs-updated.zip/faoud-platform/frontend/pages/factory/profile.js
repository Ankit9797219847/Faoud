import { useEffect, useState } from 'react';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import api, { ensureCsrfCookie } from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/factory/dashboard' },
  { label: 'Profile', href: '/factory/profile' }
];

const FIELDS = [
  { key: 'name', label: 'Factory name' },
  { key: 'address', label: 'Address' },
  { key: 'website', label: 'Website' },
  { key: 'legal_entity', label: 'Legal entity' },
  { key: 'gst_number', label: 'GST number' },
  { key: 'phone', label: 'Phone' },
  { key: 'email', label: 'Email' },
  { key: 'poc_name', label: 'Point of contact' },
  { key: 'poc_email', label: 'POC email' },
  { key: 'director_name', label: 'Director name' },
  { key: 'capacity', label: 'Monthly capacity', type: 'number' }
];

function FactoryProfileInner() {
  const [factories, setFactories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loadError, setLoadError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    api
      .get('/factories/me')
      .then((res) => {
        if (!cancelled) setFactories(res.data);
      })
      .catch(() => {
        if (!cancelled) setLoadError('Could not load your factory profile.');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  function updateField(idx, key, value) {
    setFactories((prev) => prev.map((f, i) => (i === idx ? { ...f, [key]: value } : f)));
    setSaved(false);
  }

  async function save(idx) {
    setSaving(true);
    try {
      const factory = factories[idx];
      const payload = {};
      FIELDS.forEach(({ key }) => {
        payload[key] = factory[key];
      });
      await ensureCsrfCookie();
      const res = await api.patch(`/factories/${factory.id}`, payload);
      setFactories((prev) => prev.map((f, i) => (i === idx ? res.data : f)));
      setSaved(true);
    } catch (e) {
      setLoadError('Could not save changes.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <OpsShell roleLabel="Factory Owner" accent="rust" navItems={NAV} activeHref="/factory/profile">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Settings</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Factory profile</h1>
      </header>

      {loadError && (
        <p className="mb-6 rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">
          {loadError}
        </p>
      )}

      {loading && <p className="text-muted">Loading…</p>}

      {!loading && factories.length === 0 && !loadError && (
        <div className="rounded-sm border border-dashed border-line bg-panel px-6 py-10 text-center">
          <p className="font-display text-lg text-ink">No factory profile yet</p>
          <p className="mt-1 text-sm text-muted">
            Ask your Account Manager to link a factory record to your account.
          </p>
        </div>
      )}

      {factories.map((factory, idx) => (
        <div key={factory.id} className="mb-8 rounded-sm border border-line bg-panel p-6">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {FIELDS.map(({ key, label, type }) => (
              <label key={key} className="text-sm">
                <span className="mb-1 block font-mono text-[11px] uppercase tracking-wider text-muted">
                  {label}
                </span>
                <input
                  type={type || 'text'}
                  value={factory[key] ?? ''}
                  onChange={(e) => updateField(idx, key, e.target.value)}
                  className="w-full rounded-sm border border-line bg-white px-3 py-2 text-sm outline-none focus:border-ink"
                />
              </label>
            ))}
          </div>
          <div className="mt-6 flex items-center gap-3">
            <button
              onClick={() => save(idx)}
              disabled={saving}
              className="rounded-sm bg-ink px-4 py-2 text-sm font-medium text-paper transition-opacity hover:opacity-90 disabled:opacity-50"
            >
              {saving ? 'Saving…' : 'Save changes'}
            </button>
            {saved && <span className="text-sm text-teal">Saved.</span>}
          </div>
        </div>
      ))}
    </OpsShell>
  );
}

export default function FactoryProfilePage() {
  return (
    <RoleGuard allow={['factory']}>
      <FactoryProfileInner />
    </RoleGuard>
  );
}
FactoryProfilePage.noPublicLayout = true;
