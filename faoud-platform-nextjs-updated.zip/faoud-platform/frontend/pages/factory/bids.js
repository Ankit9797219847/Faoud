import { useEffect, useState } from 'react';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import StatusBadge from '../../components/StatusBadge';
import djangoApi from '../../lib/djangoApi';
import BidTrackingPanel from '../../components/workflow/BidTrackingPanel';
import DispatchPanel from '../../components/workflow/DispatchPanel';
import QCPanel from '../../components/workflow/QCPanel';

const NAV = [
  { label: 'Dashboard', href: '/factory/dashboard' },
  { label: 'Profile', href: '/factory/profile' },
  { label: 'Data Tables', href: '/factory/data' },
  { label: 'My Bids', href: '/factory/bids' }
];

// The backend has no case-list endpoint for Factory Owners (case/views.py's
// filterPerm() returns .none() for that role) — bids are the real entry
// point into case work for this role, via GET /user/bids/.
function FactoryBidsInner() {
  const [bids, setBids] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await djangoApi.get('/user/bids/');
        if (!cancelled) setBids(Array.isArray(res.data) ? res.data : []);
      } catch (e) {
        if (!cancelled) setError(e.response?.data?.error || 'Could not load your bids.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <OpsShell roleLabel="Factory Owner" accent="rust" navItems={NAV} activeHref="/factory/bids">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Your bids</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Bids & sample tracking</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Every bid you've placed, its case, and the real tracking + dispatch actions available to
          Factory Owners on this case.
        </p>
      </header>

      {loading && <p className="text-sm text-muted">Loading…</p>}
      {error && (
        <p className="rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">{error}</p>
      )}
      {!loading && !error && bids.length === 0 && (
        <div className="rounded-sm border border-dashed border-line bg-panel px-6 py-10 text-center">
          <p className="font-display text-lg text-ink">No bids yet</p>
          <p className="mt-1 text-sm text-muted">Bids you place on open cases will show up here.</p>
        </div>
      )}

      <div className="flex flex-col gap-4">
        {bids.map((b) => {
          const caseId = typeof b.case === 'object' ? b.case?.id : b.case;
          const isOpen = expanded === b.id;
          return (
            <div key={b.id} className="overflow-hidden rounded-sm border border-line bg-panel">
              <button
                onClick={() => setExpanded(isOpen ? null : b.id)}
                className="flex w-full items-center justify-between px-4 py-3 text-left text-sm hover:bg-black/[0.02]"
              >
                <span className="text-ink">
                  Case #{caseId} — Quote ₹{b.quote}
                </span>
                <div className="flex items-center gap-3">
                  <StatusBadge label={b.status} />
                  <span className="text-muted">{isOpen ? '▲' : '▼'}</span>
                </div>
              </button>
              {isOpen && (
                <div className="flex flex-col gap-4 border-t border-line p-4">
                  <BidTrackingPanel bidId={b.id} />
                  {caseId && <DispatchPanel caseId={caseId} role="factory" />}
                  {caseId && <QCPanel caseId={caseId} role="factory" />}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </OpsShell>
  );
}

export default function FactoryBidsPage() {
  return (
    <RoleGuard allow={['factory']}>
      <FactoryBidsInner />
    </RoleGuard>
  );
}
FactoryBidsPage.noPublicLayout = true;
