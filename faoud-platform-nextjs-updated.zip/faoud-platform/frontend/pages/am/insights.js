import { useEffect, useState, useCallback } from 'react';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import djangoApi from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/am/dashboard' },
  { label: 'Brands', href: '/am/brands' },
  { label: 'Materials', href: '/am/materials' },
  { label: 'Insights', href: '/am/insights' },
  { label: 'Data Tables', href: '/am/data' }
];

const KPI_LABELS = {
  brandowners_added: 'Brand Owners added',
  factories_added: 'Factories added',
  cases_added: 'Cases created',
  bids_added: 'Bids submitted',
  factory_selected: 'Factory selected',
  units_requirement_raised: 'Units requirement raised',
  case_dispatched: 'Cases dispatched',
  total_paid: 'Total paid (add-ons)'
};

function InsightsInner() {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (startDate) params.start_date = startDate;
      if (endDate) params.end_date = endDate;
      const res = await djangoApi.get('/insights/dashboard', { params });
      setData(res.data);
    } catch {
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <OpsShell roleLabel="Account Manager" accent="clay" navItems={NAV} activeHref="/am/insights">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Insights</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Business Overview</h1>
        {data && (
          <p className="mt-1 text-sm text-muted">
            {data.start_date} → {data.end_date}
          </p>
        )}
      </header>

      <div className="mb-8 flex flex-wrap items-end gap-3">
        <label className="text-xs text-muted">
          Start date
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="mt-1 block rounded-sm border border-line px-3 py-1.5 text-sm"
          />
        </label>
        <label className="text-xs text-muted">
          End date
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="mt-1 block rounded-sm border border-line px-3 py-1.5 text-sm"
          />
        </label>
        <button
          onClick={load}
          className="rounded-sm bg-ink px-4 py-1.5 text-sm font-medium text-paper hover:opacity-90"
        >
          Apply
        </button>
      </div>

      {loading && <p className="text-muted text-sm">Loading…</p>}

      {!loading && data && (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {Object.entries(KPI_LABELS).map(([key, label]) => (
            <div key={key} className="rounded-sm border border-line bg-panel p-4">
              <p className="font-mono text-[11px] uppercase tracking-wider text-muted">{label}</p>
              <p className="mt-2 font-display text-2xl text-ink">
                {key === 'total_paid' ? `₹${Number(data[key] || 0).toLocaleString('en-IN')}` : data[key] ?? 0}
              </p>
            </div>
          ))}
        </div>
      )}

      {!loading && !data && <p className="text-sm text-danger">Could not load insights for this range.</p>}
    </OpsShell>
  );
}

export default function InsightsPage() {
  return (
    <RoleGuard allow={['account_manager', 'admin']}>
      <InsightsInner />
    </RoleGuard>
  );
}
InsightsPage.noPublicLayout = true;
