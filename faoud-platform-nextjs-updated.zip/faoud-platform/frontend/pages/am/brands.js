import { useEffect, useState } from 'react';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import StatusBadge from '../../components/StatusBadge';
import api from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/am/dashboard' },
  { label: 'Brands', href: '/am/brands' },
  { label: 'Materials', href: '/am/materials' }
];

function brandName(b) {
  return b.name || b.company_name || `Brand #${b.id}`;
}

function AMBrandsInner() {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [query, setQuery] = useState('');

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await api.get('/management/brands');
        if (cancelled) return;
        setBrands(Array.isArray(res.data) ? res.data : res.data.results || []);
      } catch (e) {
        if (!cancelled) setLoadError('Could not load brands.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const filtered = brands.filter((b) =>
    brandName(b).toLowerCase().includes(query.toLowerCase())
  );

  return (
    <OpsShell roleLabel="Account Manager" accent="ink" navItems={NAV} activeHref="/am/brands">
      <header className="mb-8 flex items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-wider text-muted">
            Brand workspace
          </p>
          <h1 className="mt-1 font-display text-3xl text-ink">Every brand on the ledger</h1>
        </div>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Filter by name…"
          className="w-64 rounded-sm border border-line bg-panel px-3 py-2 text-sm outline-none focus:border-ink"
        />
      </header>

      {loadError && (
        <p className="mb-6 rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">
          {loadError}
        </p>
      )}

      <div className="overflow-hidden rounded-sm border border-line bg-panel">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-black/[0.02] font-mono text-[11px] uppercase tracking-wider text-muted">
              <th className="px-4 py-3 font-medium">Brand</th>
              <th className="px-4 py-3 font-medium">Cases</th>
              <th className="px-4 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={3} className="px-4 py-6 text-center text-muted">
                  Loading brands…
                </td>
              </tr>
            )}
            {!loading && filtered.length === 0 && (
              <tr>
                <td colSpan={3} className="px-4 py-6 text-center text-muted">
                  No brands match “{query}”.
                </td>
              </tr>
            )}
            {filtered.map((b) => (
              <tr key={b.id} className="border-b border-line last:border-0">
                <td className="px-4 py-3 text-ink">{brandName(b)}</td>
                <td className="px-4 py-3 text-ink/80">{b.case_count ?? 0}</td>
                <td className="px-4 py-3">
                  <StatusBadge label={b.is_verified ? 'active' : 'pending'} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </OpsShell>
  );
}

export default function AMBrandsPage() {
  return (
    <RoleGuard allow={['account_manager', 'admin']}>
      <AMBrandsInner />
    </RoleGuard>
  );
}
AMBrandsPage.noPublicLayout = true;
