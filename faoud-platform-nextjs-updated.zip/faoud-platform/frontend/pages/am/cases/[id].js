import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/router';
import RoleGuard from '../../../components/RoleGuard';
import OpsShell from '../../../components/OpsShell';
import djangoApi, { ensureCsrfCookie } from '../../../lib/djangoApi';
import CaseStagePanel from '../../../components/workflow/CaseStagePanel';
import CaseBidsPanel from '../../../components/workflow/CaseBidsPanel';
import DispatchPanel from '../../../components/workflow/DispatchPanel';
import BriefsPanel from '../../../components/workflow/BriefsPanel';
import QCPanel from '../../../components/workflow/QCPanel';
import FormulationUploadPanel from '../../../components/workflow/FormulationUploadPanel';
import CaseChat from '../../../components/workflow/CaseChat';

const NAV = [
  { label: 'Dashboard', href: '/am/dashboard' },
  { label: 'Brands', href: '/am/brands' },
  { label: 'Materials', href: '/am/materials' },
  { label: 'Data Tables', href: '/am/data' }
];

const PRIORITIES = ['normal', 'priority', 'inactive', 'dispatched'];
const COLORS = ['red', 'black', 'green'];

function AMCaseDetailInner() {
  const router = useRouter();
  const { id } = router.query;

  const [caseData, setCaseData] = useState(null);
  const [stages, setStages] = useState([]);
  const [assignment, setAssignment] = useState(null);
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const [caseRes, stagesRes, assignRes] = await Promise.allSettled([
        djangoApi.get(`/cases/${id}/`),
        djangoApi.get(`/cases/${id}/stages/`),
        djangoApi.get(`/cases/${id}/assignment/`)
      ]);
      if (caseRes.status === 'fulfilled') {
        setCaseData(caseRes.value.data.case ?? caseRes.value.data);
        setNotes(caseRes.value.data.case?.notes ?? caseRes.value.data.notes ?? '');
      } else {
        setLoadError(caseRes.reason?.response?.data?.error || 'Could not load this case.');
      }
      if (stagesRes.status === 'fulfilled') setStages(stagesRes.value.data.stages || []);
      if (assignRes.status === 'fulfilled') setAssignment(assignRes.value.data);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  async function saveNotes() {
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/cases/${id}/notes/`, { notes });
    } finally {
      setBusy(false);
    }
  }

  async function setPriority(priority) {
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/cases/${id}/priority/`, { priority });
      await load();
    } finally {
      setBusy(false);
    }
  }

  async function setColor(color) {
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.patch(`/cases/${id}/update-color/`, { color });
      await load();
    } finally {
      setBusy(false);
    }
  }

  async function assignAM(amId, scope) {
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await djangoApi.post(`/cases/${id}/assignment/`, { action: 'assign', am_id: amId, scope });
      await load();
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return (
      <OpsShell roleLabel="Account Manager" accent="ink" navItems={NAV} activeHref="/am/dashboard">
        <p className="text-muted">Loading case…</p>
      </OpsShell>
    );
  }

  if (loadError || !caseData) {
    return (
      <OpsShell roleLabel="Account Manager" accent="ink" navItems={NAV} activeHref="/am/dashboard">
        <p className="rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">
          {loadError || 'Case not found.'}
        </p>
      </OpsShell>
    );
  }

  return (
    <OpsShell roleLabel="Account Manager" accent="ink" navItems={NAV} activeHref="/am/dashboard">
      <header className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Case detail</p>
          <h1 className="mt-1 font-display text-3xl text-ink">{caseData.name}</h1>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-1">
            {PRIORITIES.map((p) => (
              <button
                key={p}
                onClick={() => setPriority(p)}
                disabled={busy}
                className={`rounded-sm border px-3 py-1.5 font-mono text-[11px] uppercase tracking-wider transition-colors ${
                  caseData.priority === p ? 'border-ink bg-ink text-paper' : 'border-line text-muted hover:border-ink/40'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                disabled={busy}
                title={c}
                className={`h-5 w-5 rounded-full border-2 ${caseData.color === c ? 'border-ink' : 'border-line'}`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1.3fr_1fr]">
        <div className="flex flex-col gap-8">
          <CaseStagePanel caseId={id} stages={stages} canTransition onChanged={load} />
          <CaseBidsPanel caseId={id} role="am" />
          <DispatchPanel caseId={id} role="am" />
          <FormulationUploadPanel caseId={id} />
          <QCPanel caseId={id} role="am" />
          <BriefsPanel caseId={id} />
        </div>

        <div className="flex flex-col gap-8">
          <section>
            <h2 className="mb-3 font-display text-lg text-ink">Assignment</h2>
            <div className="rounded-sm border border-line bg-panel p-4">
              <p className="mb-2 font-mono text-[11px] uppercase tracking-wider text-muted">Currently on this case</p>
              <ul className="mb-4 flex flex-col gap-1 text-sm text-ink">
                {(assignment?.viewer_ams || []).map((am) => (
                  <li key={am.id}>{am.name}</li>
                ))}
                {(!assignment || (assignment.viewer_ams || []).length === 0) && (
                  <li className="text-muted">Unassigned</li>
                )}
              </ul>
              <p className="mb-2 font-mono text-[11px] uppercase tracking-wider text-muted">Reassign</p>
              <div className="flex flex-col gap-2">
                {(assignment?.assignable_ams || []).map((am) => (
                  <div key={am.id} className="flex items-center justify-between text-sm">
                    <span className="text-ink">{am.name}</span>
                    <div className="flex gap-1">
                      <button
                        onClick={() => assignAM(am.id, 'case')}
                        disabled={busy}
                        className="rounded-sm border border-line px-2 py-1 text-[11px] hover:border-ink/40"
                      >
                        This case
                      </button>
                      <button
                        onClick={() => assignAM(am.id, 'brand')}
                        disabled={busy}
                        className="rounded-sm border border-line px-2 py-1 text-[11px] hover:border-ink/40"
                      >
                        Whole brand
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section>
            <h2 className="mb-3 font-display text-lg text-ink">Notes</h2>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={6}
              className="w-full rounded-sm border border-line bg-panel px-3 py-2 text-sm outline-none focus:border-ink"
            />
            <button
              onClick={saveNotes}
              disabled={busy}
              className="mt-2 rounded-sm bg-ink px-4 py-2 text-sm font-medium text-paper hover:opacity-90 disabled:opacity-50"
            >
              Save notes
            </button>
          </section>

          <CaseChat caseId={id} currentUserRole="am" showPermissionToggle />
        </div>
      </div>
    </OpsShell>
  );
}

export default function AMCaseDetailPage() {
  return (
    <RoleGuard allow={['account_manager', 'admin']}>
      <AMCaseDetailInner />
    </RoleGuard>
  );
}
AMCaseDetailPage.noPublicLayout = true;
