import { useEffect, useState, useCallback } from 'react';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/am/dashboard' },
  { label: 'Brands', href: '/am/brands' },
  { label: 'Materials', href: '/am/materials' },
  { label: 'Insights', href: '/am/insights' },
  { label: 'Campaigns', href: '/am/campaigns' },
  { label: 'Data Tables', href: '/am/data' }
];

function CampaignsInner() {
  const [campaigns, setCampaigns] = useState([]);
  const [links, setLinks] = useState([]);
  const [form, setForm] = useState({ campaign_name: '', campaign_id: '', destination_url: '', label: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState(null);
  const [clicksByLink, setClicksByLink] = useState({});

  const load = useCallback(async () => {
    const [campaignsRes, linksRes] = await Promise.allSettled([
      djangoApi.get('/event-campaigns'),
      djangoApi.get('/campaign-links')
    ]);
    if (campaignsRes.status === 'fulfilled') setCampaigns(campaignsRes.value.data);
    if (linksRes.status === 'fulfilled') setLinks(linksRes.value.data);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    // Pull click counts per campaign once campaigns are loaded.
    campaigns.forEach(async (c) => {
      try {
        const res = await djangoApi.get(`/marketing/campaigns/${c.id}/clicks`);
        setClicksByLink((prev) => ({ ...prev, [c.id]: res.data }));
      } catch {
        // non-fatal
      }
    });
  }, [campaigns]);

  async function createCampaign() {
    if (!form.campaign_name.trim()) return;
    setBusy(true);
    setError(null);
    try {
      await ensureCsrfCookie();
      const res = await djangoApi.post('/event-campaigns', { name: form.campaign_name });
      setForm((f) => ({ ...f, campaign_name: '', campaign_id: String(res.data.id) }));
      await load();
      setMessage('Campaign created.');
    } catch {
      setError('Could not create campaign.');
    } finally {
      setBusy(false);
    }
  }

  async function createLink() {
    if (!form.campaign_id || !form.destination_url) {
      setError('Pick a campaign and enter a destination URL.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await ensureCsrfCookie();
      await djangoApi.post('/marketing/campaign-links', {
        campaign_id: form.campaign_id,
        destination_url: form.destination_url,
        label: form.label
      });
      setForm((f) => ({ ...f, destination_url: '', label: '' }));
      setMessage('Link created.');
      await load();
    } catch {
      setError('Could not create link.');
    } finally {
      setBusy(false);
    }
  }

  const origin = typeof window !== 'undefined' ? window.location.origin : '';

  return (
    <OpsShell roleLabel="Account Manager" accent="ink" navItems={NAV} activeHref="/am/campaigns">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Marketing</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Event Campaigns & Short Links</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Create a campaign, generate short links under it (for QR codes, ads, event booths), and see
          click counts per link.
        </p>
      </header>

      {error && <p className="mb-4 text-sm text-danger">{error}</p>}
      {message && <p className="mb-4 text-sm text-teal">{message}</p>}

      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <section className="rounded-sm border border-line bg-panel p-4">
          <h2 className="mb-3 font-display text-base text-ink">New campaign</h2>
          <div className="flex gap-2">
            <input
              value={form.campaign_name}
              onChange={(e) => setForm({ ...form, campaign_name: e.target.value })}
              placeholder="Campaign name (e.g. Cosmoprof 2026)"
              className="flex-1 rounded-sm border border-line px-3 py-1.5 text-sm"
            />
            <button
              onClick={createCampaign}
              disabled={busy}
              className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper hover:opacity-90 disabled:opacity-50"
            >
              Create
            </button>
          </div>
        </section>

        <section className="rounded-sm border border-line bg-panel p-4">
          <h2 className="mb-3 font-display text-base text-ink">New short link</h2>
          <div className="flex flex-col gap-2">
            <select
              value={form.campaign_id}
              onChange={(e) => setForm({ ...form, campaign_id: e.target.value })}
              className="rounded-sm border border-line px-3 py-1.5 text-sm"
            >
              <option value="">Choose campaign…</option>
              {campaigns.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
            <input
              value={form.destination_url}
              onChange={(e) => setForm({ ...form, destination_url: e.target.value })}
              placeholder="Destination URL (e.g. https://faoud.com/contact)"
              className="rounded-sm border border-line px-3 py-1.5 text-sm"
            />
            <input
              value={form.label}
              onChange={(e) => setForm({ ...form, label: e.target.value })}
              placeholder="Label (e.g. Booth QR code)"
              className="rounded-sm border border-line px-3 py-1.5 text-sm"
            />
            <button
              onClick={createLink}
              disabled={busy}
              className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper hover:opacity-90 disabled:opacity-50"
            >
              Create link
            </button>
          </div>
        </section>
      </div>

      <section>
        <h2 className="mb-3 font-display text-lg text-ink">Links</h2>
        <div className="overflow-hidden rounded-sm border border-line bg-panel">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-line bg-black/[0.02] font-mono text-[11px] uppercase tracking-wider text-muted">
                <th className="px-4 py-3 font-medium">Label</th>
                <th className="px-4 py-3 font-medium">Short URL</th>
                <th className="px-4 py-3 font-medium">Destination</th>
                <th className="px-4 py-3 font-medium">Clicks</th>
              </tr>
            </thead>
            <tbody>
              {links.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-4 py-6 text-center text-muted">No links yet.</td>
                </tr>
              )}
              {links.map((l) => {
                const campaignClicks = clicksByLink[l.campaign]?.links?.find((cl) => cl.id === l.id);
                return (
                  <tr key={l.id} className="border-b border-line last:border-0">
                    <td className="px-4 py-3 text-ink">{l.label || '—'}</td>
                    <td className="px-4 py-3 font-mono text-xs text-teal">{origin}/api/go/{l.token}</td>
                    <td className="px-4 py-3 text-ink/70">{l.destination_url}</td>
                    <td className="px-4 py-3 text-ink">{campaignClicks?.clicks ?? '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </OpsShell>
  );
}

export default function CampaignsPage() {
  return (
    <RoleGuard allow={['account_manager']}>
      <CampaignsInner />
    </RoleGuard>
  );
}
CampaignsPage.noPublicLayout = true;
