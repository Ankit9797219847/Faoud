import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import StatusBadge from '../../components/StatusBadge';
import api from '../../lib/djangoApi';
import { caseBrandLabel, caseLabel, caseStage, factoryLabel } from '../../lib/case-helpers';

const NAV = [
  { label: 'Dashboard', href: '/am/dashboard' },
  { label: 'Brands', href: '/am/brands' },
  { label: 'Materials', href: '/am/materials' },
  { label: 'Data Tables', href: '/am/data' },
  { label: 'Service Requests', href: '/am/service-requests' }
];

function AMDashboardInner() {
  const router = useRouter();
  const [cases, setCases] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [casesRes, alertsRes] = await Promise.allSettled([
          api.get('/cases/list_assigned'),
          api.get('/alerts')
        ]);
        if (cancelled) return;

        if (casesRes.status === 'fulfilled') {
          setCases(casesRes.value.data.cases || []);
        } else {
          setLoadError('Could not load assigned cases.');
        }

        if (alertsRes.status === 'fulfilled') {
          const v = alertsRes.value.data;
          setAlerts(Array.isArray(v) ? v : v.results || []);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const openAlerts = alerts.filter((a) => !a.is_done);
  const stageCounts = cases.reduce((acc, c) => {
    const s = caseStage(c);
    acc[s] = (acc[s] || 0) + 1;
    return acc;
  }, {});

  return (
    <OpsShell roleLabel="Account Manager" accent="ink" navItems={NAV} activeHref="/am/dashboard">
      <header className="mb-8 flex items-end justify-between">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-wider text-muted">
            Ledger overview
          </p>
          <h1 className="mt-1 font-display text-3xl text-ink">Your book of cases</h1>
        </div>
      </header>

      {loadError && (
        <p className="mb-6 rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">
          {loadError}
        </p>
      )}

      <section className="mb-8 grid grid-cols-2 gap-4 md:grid-cols-4">
        <div className="rounded-sm border border-line bg-panel p-4">
          <p className="font-mono text-[11px] uppercase tracking-wider text-muted">
            Assigned cases
          </p>
          <p className="mt-2 font-display text-2xl text-ink">{cases.length}</p>
        </div>
        <div className="rounded-sm border border-line bg-panel p-4">
          <p className="font-mono text-[11px] uppercase tracking-wider text-muted">
            Open alerts
          </p>
          <p className="mt-2 font-display text-2xl text-amber">{openAlerts.length}</p>
        </div>
        {Object.entries(stageCounts)
          .slice(0, 2)
          .map(([stage, count]) => (
            <div key={stage} className="rounded-sm border border-line bg-panel p-4">
              <p className="truncate font-mono text-[11px] uppercase tracking-wider text-muted">
                {stage}
              </p>
              <p className="mt-2 font-display text-2xl text-ink">{count}</p>
            </div>
          ))}
      </section>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[2fr_1fr]">
        <section>
          <h2 className="mb-3 font-display text-lg text-ink">Cases</h2>
          <div className="overflow-hidden rounded-sm border border-line bg-panel">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-line bg-black/[0.02] font-mono text-[11px] uppercase tracking-wider text-muted">
                  <th className="px-4 py-3 font-medium">Case</th>
                  <th className="px-4 py-3 font-medium">Brand</th>
                  <th className="px-4 py-3 font-medium">Factory</th>
                  <th className="px-4 py-3 font-medium">Stage</th>
                </tr>
              </thead>
              <tbody>
                {loading && (
                  <tr>
                    <td colSpan={4} className="px-4 py-6 text-center text-muted">
                      Loading cases…
                    </td>
                  </tr>
                )}
                {!loading && cases.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-4 py-6 text-center text-muted">
                      No cases assigned to you yet.
                    </td>
                  </tr>
                )}
                {cases.map((c) => (
                  <tr
                    key={c.id}
                    onClick={() => router.push(`/am/cases/${c.id}`)}
                    className="cursor-pointer border-b border-line last:border-0 hover:bg-black/[0.02]"
                  >
                    <td className="px-4 py-3 text-ink">{caseLabel(c)}</td>
                    <td className="px-4 py-3 text-ink/80">{caseBrandLabel(c)}</td>
                    <td className="px-4 py-3 text-ink/80">{factoryLabel(c)}</td>
                    <td className="px-4 py-3">
                      <StatusBadge label={caseStage(c)} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section>
          <h2 className="mb-3 font-display text-lg text-ink">Open alerts</h2>
          <div className="flex flex-col gap-2">
            {openAlerts.length === 0 && !loading && (
              <p className="rounded-sm border border-line bg-panel px-4 py-3 text-sm text-muted">
                Nothing needs your attention right now.
              </p>
            )}
            {openAlerts.map((a) => (
              <div key={a.id} className="rounded-sm border border-amber/30 bg-amber/5 px-4 py-3">
                <p className="text-sm text-ink">{a.message || 'Alert'}</p>
                {a.created_at && (
                  <p className="mt-1 font-mono text-[11px] text-muted">
                    {new Date(a.created_at).toLocaleString()}
                  </p>
                )}
              </div>
            ))}
          </div>

          <Link
            href="/am/brands"
            className="mt-6 inline-block text-sm text-ink underline decoration-line underline-offset-4 hover:text-ink/70"
          >
            Go to brand workspace →
          </Link>
        </section>
      </div>
    </OpsShell>
  );
}

export default function AMDashboardPage() {
  return (
    <RoleGuard allow={['account_manager', 'admin']}>
      <AMDashboardInner />
    </RoleGuard>
  );
}
AMDashboardPage.noPublicLayout = true;
