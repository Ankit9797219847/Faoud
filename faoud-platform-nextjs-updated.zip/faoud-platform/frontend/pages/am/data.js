import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import DataExplorer from '../../components/DataExplorer';
import { resourcesForRole } from '../../lib/resourceRegistry';

const NAV = [
  { label: 'Dashboard', href: '/am/dashboard' },
  { label: 'Brands', href: '/am/brands' },
  { label: 'Materials', href: '/am/materials' },
  { label: 'Data Tables', href: '/am/data' }
];

function AmDataInner() {
  const resources = resourcesForRole('am');
  return (
    <OpsShell roleLabel="Account Manager" accent="ink" navItems={NAV} activeHref="/am/data">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Backend data</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Every model, one console</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Account Managers get the full set of {resourcesForRole('am').length} data tables the backend exposes
          for full CRUD — everything else (case stage transitions, bidding flow, dispatch) stays on its
          existing purpose-built page since those aren't simple record tables.
        </p>
      </header>
      <DataExplorer resources={resources} accent="ink" />
    </OpsShell>
  );
}

export default function AmData() {
  return (
    <RoleGuard allow={['account_manager']}>
      <AmDataInner />
    </RoleGuard>
  );
}
