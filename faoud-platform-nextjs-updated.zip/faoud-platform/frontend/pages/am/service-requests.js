import { useEffect, useState, useCallback } from 'react';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import StatusBadge from '../../components/StatusBadge';
import djangoApi, { ensureCsrfCookie } from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/am/dashboard' },
  { label: 'Brands', href: '/am/brands' },
  { label: 'Materials', href: '/am/materials' },
  { label: 'Data Tables', href: '/am/data' },
  { label: 'Service Requests', href: '/am/service-requests' }
];

// GET  /service-requests/admin/               -> list (filter by ?status=)
// POST /service-requests/admin/<id>/status/   -> {status, note}
// POST /service-requests/admin/<id>/assign/   -> {internal_owner_id}
const STATUSES = ['DRAFT', 'AWAITING_PAYMENT', 'PAID', 'IN_REVIEW', 'IN_PROGRESS', 'DELIVERED', 'CLOSED', 'CANCELLED'];

function AMServiceRequestsInner() {
  const [requests, setRequests] = useState([]);
  const [ams, setAms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [busyId, setBusyId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [reqRes, amRes] = await Promise.allSettled([
        djangoApi.get('/service-requests/admin/'),
        djangoApi.get('/ams/')
      ]);
      if (reqRes.status === 'fulfilled') {
        const data = reqRes.value.data;
        setRequests(Array.isArray(data) ? data : data.results || []);
      } else {
        setError('Could not load service requests.');
      }
      if (amRes.status === 'fulfilled') {
        const data = amRes.value.data;
        setAms(Array.isArray(data) ? data : data.results || []);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function updateStatus(id, status) {
    setBusyId(id);
    try {
      await ensureCsrfCookie();
      await djangoApi.post(`/service-requests/admin/${id}/status/`, { status });
      await load();
    } catch (e) {
      alert(e.response?.data?.detail || 'Could not update status.');
    } finally {
      setBusyId(null);
    }
  }

  async function assignOwner(id, ownerId) {
    setBusyId(id);
    try {
      await ensureCsrfCookie();
      await djangoApi.post(`/service-requests/admin/${id}/assign/`, { internal_owner_id: ownerId || null });
      await load();
    } catch (e) {
      alert('Could not assign owner.');
    } finally {
      setBusyId(null);
    }
  }

  return (
    <OpsShell roleLabel="Account Manager" accent="ink" navItems={NAV} activeHref="/am/service-requests">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Services</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Service requests</h1>
      </header>

      {loading && <p className="text-sm text-muted">Loading…</p>}
      {error && <p className="rounded-sm border border-danger/30 bg-danger/5 px-4 py-3 text-sm text-danger">{error}</p>}

      {!loading && !error && (
        <div className="overflow-x-auto rounded-sm border border-line bg-panel">
          <table className="min-w-full text-left text-sm">
            <thead>
              <tr className="border-b border-line bg-black/[0.02] font-mono text-[11px] uppercase tracking-wider text-muted">
                <th className="px-4 py-3">Title</th>
                <th className="px-4 py-3">Offering</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Owner</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {requests.map((r) => (
                <tr key={r.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-3 text-ink">{r.title}</td>
                  <td className="px-4 py-3 text-muted">{r.offering_name}</td>
                  <td className="px-4 py-3">
                    <StatusBadge label={r.status} />
                  </td>
                  <td className="px-4 py-3">
                    <select
                      value={r.internal_owner || ''}
                      onChange={(e) => assignOwner(r.id, e.target.value)}
                      disabled={busyId === r.id}
                      className="rounded-sm border border-line bg-white px-2 py-1 text-xs"
                    >
                      <option value="">Unassigned</option>
                      {ams.map((am) => (
                        <option key={am.id} value={am.id}>
                          {am.name}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-3">
                    <select
                      value=""
                      onChange={(e) => e.target.value && updateStatus(r.id, e.target.value)}
                      disabled={busyId === r.id}
                      className="rounded-sm border border-line bg-white px-2 py-1 text-xs"
                    >
                      <option value="">Change status…</option>
                      {STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
              {requests.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center text-muted">
                    No service requests yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </OpsShell>
  );
}

export default function AMServiceRequestsPage() {
  return (
    <RoleGuard allow={['account_manager', 'admin']}>
      <AMServiceRequestsInner />
    </RoleGuard>
  );
}
AMServiceRequestsPage.noPublicLayout = true;
