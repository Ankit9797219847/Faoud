import { useEffect, useState, useCallback } from 'react';
import RoleGuard from '../../components/RoleGuard';
import OpsShell from '../../components/OpsShell';
import api, { ensureCsrfCookie } from '../../lib/djangoApi';

const NAV = [
  { label: 'Dashboard', href: '/am/dashboard' },
  { label: 'Brands', href: '/am/brands' },
  { label: 'Materials', href: '/am/materials' }
];

function MaterialsInner() {
  const [rawMaterials, setRawMaterials] = useState([]);
  const [packagingMaterials, setPackagingMaterials] = useState([]);
  const [newRm, setNewRm] = useState({ name: '', iupac_name: '', price: '' });
  const [newPm, setNewPm] = useState({ name: '', material_shape: '', price: '' });
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const [rm, pm] = await Promise.allSettled([
      api.get('/materials/raw-materials'),
      api.get('/materials/packaging-materials')
    ]);
    if (rm.status === 'fulfilled') setRawMaterials(rm.value.data);
    if (pm.status === 'fulfilled') setPackagingMaterials(pm.value.data);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function addRawMaterial() {
    if (!newRm.name) return;
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await api.post('/materials/raw-materials', newRm);
      setNewRm({ name: '', iupac_name: '', price: '' });
      await load();
    } finally {
      setBusy(false);
    }
  }

  async function addPackagingMaterial() {
    if (!newPm.name) return;
    setBusy(true);
    try {
      await ensureCsrfCookie();
      await api.post('/materials/packaging-materials', newPm);
      setNewPm({ name: '', material_shape: '', price: '' });
      await load();
    } finally {
      setBusy(false);
    }
  }

  return (
    <OpsShell roleLabel="Account Manager" accent="amber" navItems={NAV} activeHref="/am/materials">
      <header className="mb-8">
        <p className="font-mono text-[11px] uppercase tracking-wider text-muted">Catalog</p>
        <h1 className="mt-1 font-display text-3xl text-ink">Materials</h1>
      </header>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        <section>
          <h2 className="mb-3 font-display text-lg text-ink">Raw materials</h2>
          <div className="mb-4 flex flex-col gap-2 rounded-sm border border-line bg-panel p-4">
            <input
              placeholder="Name"
              value={newRm.name}
              onChange={(e) => setNewRm({ ...newRm, name: e.target.value })}
              className="rounded-sm border border-line bg-white px-3 py-1.5 text-sm"
            />
            <input
              placeholder="IUPAC name (optional)"
              value={newRm.iupac_name}
              onChange={(e) => setNewRm({ ...newRm, iupac_name: e.target.value })}
              className="rounded-sm border border-line bg-white px-3 py-1.5 text-sm"
            />
            <input
              placeholder="Price"
              type="number"
              value={newRm.price}
              onChange={(e) => setNewRm({ ...newRm, price: e.target.value })}
              className="rounded-sm border border-line bg-white px-3 py-1.5 text-sm"
            />
            <button
              onClick={addRawMaterial}
              disabled={busy}
              className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper disabled:opacity-50"
            >
              Add raw material
            </button>
          </div>
          <ul className="flex flex-col gap-2">
            {rawMaterials.map((rm) => (
              <li key={rm.id} className="flex justify-between rounded-sm border border-line bg-panel px-4 py-2 text-sm">
                <span className="text-ink">{rm.name}</span>
                <span className="text-muted">₹{Number(rm.price).toLocaleString('en-IN')}</span>
              </li>
            ))}
          </ul>
        </section>

        <section>
          <h2 className="mb-3 font-display text-lg text-ink">Packaging materials</h2>
          <div className="mb-4 flex flex-col gap-2 rounded-sm border border-line bg-panel p-4">
            <input
              placeholder="Name"
              value={newPm.name}
              onChange={(e) => setNewPm({ ...newPm, name: e.target.value })}
              className="rounded-sm border border-line bg-white px-3 py-1.5 text-sm"
            />
            <input
              placeholder="Shape (optional)"
              value={newPm.material_shape}
              onChange={(e) => setNewPm({ ...newPm, material_shape: e.target.value })}
              className="rounded-sm border border-line bg-white px-3 py-1.5 text-sm"
            />
            <input
              placeholder="Price"
              type="number"
              value={newPm.price}
              onChange={(e) => setNewPm({ ...newPm, price: e.target.value })}
              className="rounded-sm border border-line bg-white px-3 py-1.5 text-sm"
            />
            <button
              onClick={addPackagingMaterial}
              disabled={busy}
              className="rounded-sm bg-ink px-3 py-1.5 text-xs font-medium text-paper disabled:opacity-50"
            >
              Add packaging material
            </button>
          </div>
          <ul className="flex flex-col gap-2">
            {packagingMaterials.map((pm) => (
              <li key={pm.id} className="flex justify-between rounded-sm border border-line bg-panel px-4 py-2 text-sm">
                <span className="text-ink">{pm.name}</span>
                <span className="text-muted">₹{Number(pm.price).toLocaleString('en-IN')}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </OpsShell>
  );
}

export default function MaterialsPage() {
  return (
    <RoleGuard allow={['account_manager', 'admin']}>
      <MaterialsInner />
    </RoleGuard>
  );
}
MaterialsPage.noPublicLayout = true;
